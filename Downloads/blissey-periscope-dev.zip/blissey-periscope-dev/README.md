# Blissey

[![Quality Gate Status](https://sonarqube.dexcare.engineering/api/project_badges/measure?project=blissey&metric=alert_status&token=squ_c3b1fd5668e4a405e231b1cf75f8aa9111e47cf0)](https://sonarqube.dexcare.engineering/dashboard?id=blissey)
[![Code Smells](https://sonarqube.dexcare.engineering/api/project_badges/measure?project=blissey&metric=code_smells&token=squ_c3b1fd5668e4a405e231b1cf75f8aa9111e47cf0)](https://sonarqube.dexcare.engineering/dashboard?id=blissey)
[![Coverage](https://sonarqube.dexcare.engineering/api/project_badges/measure?project=blissey&metric=coverage&token=squ_c3b1fd5668e4a405e231b1cf75f8aa9111e47cf0)](https://sonarqube.dexcare.engineering/dashboard?id=blissey)
[![Duplicated Lines (%)](https://sonarqube.dexcare.engineering/api/project_badges/measure?project=blissey&metric=duplicated_lines_density&token=squ_c3b1fd5668e4a405e231b1cf75f8aa9111e47cf0)](https://sonarqube.dexcare.engineering/dashboard?id=blissey)
[![Technical Debt](https://sonarqube.dexcare.engineering/api/project_badges/measure?project=blissey&metric=sqale_index&token=squ_c3b1fd5668e4a405e231b1cf75f8aa9111e47cf0)](https://sonarqube.dexcare.engineering/dashboard?id=blissey)
[![Vulnerabilities](https://sonarqube.dexcare.engineering/api/project_badges/measure?project=blissey&metric=vulnerabilities&token=squ_c3b1fd5668e4a405e231b1cf75f8aa9111e47cf0)](https://sonarqube.dexcare.engineering/dashboard?id=blissey)

Repository for the project Blissey. Blissey is the application that handles video for virtual visits for both patients and providers.

Quick links
- Project guide: documentation.md
- Onboarding: docs/DEVELOPER_ONBOARDING.md

## Initializing the project

To initialize Blissey against the development tier:
1. Clone the repo.

    ```git@github.com:DexCare/telehealth.blissey.git```
1. Using a split-view terminal, start the app and server:
    1. Run the following from _/blissy/app_ to install client dependencies and start the app
        ```
        nvm use
        npm ci
        npm run start
        ```
    1. Run the following from _/blissy/server_ to install server dependencies, fetch secrets, and start the server
        ```
        nvm use
        npm ci

        # populate a .env file with frosh secrets
        npm run setup

        npm run start
        ```
        * If you are running MacOS Monterey or above, you may get an error that `Port 5000` is already in use. You will need to [disable AirPlay Receiver functionality](https://developer.apple.com/forums/thread/682332), or adjust the project's port number to run it.
1. Navigate to [`localhost:5000/dogfood`](http://localhost:5000/dogfood) to create a dogfood visit

### Pointing Blissey to another environment

You can run Blissey pointed to another UAT environment by running `npm run setup:env -- {codename}` in the server folder. This requires having globally installed `@dexcare/toolbox`: 

```bash
npm i -g @dexcare/toolbox@latest
```

For example, to point blissey to rhino:

```
npm run setup:env -- rhino

npm run start
```

## Testing
Tests are run with jest, in the app and server folders.  Execute with:

```npm run test```

## Provisioning and Deployment Scripts
Located in the ./deployment folder.

## Feature Flags
Blissey uses [https://launchdarkly.com](https://launchdarkly.com/) for feature flags.
New flags are automatically added to all environments, but you will have to ensure the feature flag is set correctly for each environment.

## Storybook
This project integrates [Storybook](https://storybook.js.org) to simplify component development.

To run storybook in development mode execute the following commands while in the _/blissey/app_ directory:
```
npm run prebuild:storybook
npm run start:storybook
npm run build:storybook
```
It should automatically open a window pointed to:-
```
http://localhost:6007/
```
For each component you modify/create write stories to validate the different props and state that will be used by consuming applications.  This should allow you to develop a feature complete component that is ready to integrate with a consuming application.

## Blissey is being deconstructed!

Dont tell it yet but Blissey is not long for this world.# blissey
