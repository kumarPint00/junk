module.exports = {
    env: { node: true },
    extends: [
        '@dexcare/eslint-config',
        'prettier',
        'plugin:react/recommended',
        'plugin:react-hooks/recommended',
    ],
    plugins: ['react'],
    parserOptions: {
        tsconfigRootDir: __dirname,
        project: [
            './tsconfig.json',
            './__tests__/tsconfig.json',
            './tsconfig.test.json',
        ],
        sourceType: 'module',
        ecmaVersion: 'latest',
        ecmaFeatures: { jsx: true },
    },
    settings: {
        react: {
            version: 'detect',
        },
    },
    overrides: [
        {
            files: ['**/__tests__/**/*.test.{ts,tsx}'],
            // TODO: replace this with vitest plugin if it exists
            plugins: ['jest'],
            rules: {
                // using jest version of the rule for test files
                '@typescript-eslint/unbound-method': 'off',
                // this is needed for things like expect.any() or expect.objectContaining()
                '@typescript-eslint/no-unsafe-assignment': 'off',
                'jest/unbound-method': 'warn',
            },
        },
    ],
};
