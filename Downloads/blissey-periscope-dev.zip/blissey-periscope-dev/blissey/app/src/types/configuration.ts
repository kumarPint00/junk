import { AppConfig } from '../../../server/config/configInterfaces';

export interface Configuration {
    config: object;
    setConfig(config: object): void;
    getConfig(): AppConfig;
}
