import 'vitest-fetch-mock';

export interface Action<T = unknown> {
    type: string;
    payload: T;
}

export interface Doc extends Document {
    webkitFullscreenElement?: FullscreenOptions;
    mozFullScreenElement?: FullscreenOptions;
    webkitExitFullscreen?: FullscreenOptions;
    mozCancelFullScreen?: FullscreenOptions;
}

declare global {
    interface Notification {
        silent: boolean | null;
    }
}
