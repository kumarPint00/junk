declare module '@dexcare/festivus-aluminum-pole-analytics' {
    export const Analytics: {
        setup(): void;
        setup: <T = unknown>(data: T) => void;
        sendPageView: <T = unknown>(pageInfo: T) => void;
        sendEvent: <T = unknown>(eventData: T) => void;
    };

    export const V2Analytics: {
        setup: (config: object) => void;
        handleSendEvent: <T = unknown>(eventData: T) => void;
        interactionEvent: <T = unknown>(eventData: T) => void;
        userEvent: <T = unknown>(eventData: T) => void;
        errorEvent: <T = unknown>(eventData: T) => void;
        pageViewEvent: <T = unknown, P = unknown>(
            pageInfo: T,
            events?: P,
        ) => void;
    };

    export function isAdobeEnabled(
        adobeConfig?: Record<string, string>,
    ): boolean;
}
