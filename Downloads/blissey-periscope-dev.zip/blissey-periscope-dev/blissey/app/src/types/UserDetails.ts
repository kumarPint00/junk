import { UserDetails as UserDetailsBase } from '@dexcare/circus-saturn';

type SessionContext = 'first-party-web-app' | 'third-party-iframe';

interface UserDetailsWithJwt {
    jwt?: string;
    sharedSessionStoreEnabled: false;
}

interface UserDetailsWithSessionToken {
    sessionToken: string;
    sharedSessionStoreEnabled: true;
}

export type UserDetails = UserDetailsBase & {
    sessionContext?: SessionContext;
} & (UserDetailsWithJwt | UserDetailsWithSessionToken);

export const userDetailsHasJwt = (
    userDetails: unknown,
): userDetails is UserDetailsWithJwt => {
    return (
        (userDetails as UserDetailsWithJwt).sharedSessionStoreEnabled === false
    );
};
