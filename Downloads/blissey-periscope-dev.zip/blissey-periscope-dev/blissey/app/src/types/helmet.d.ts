import { ReactNode } from 'react';

declare module 'react-helmet' {
    interface HelmetProps {
        children?: ReactNode;
    }
}
