import { Action } from 'redux';
import { ThunkAction } from 'redux-thunk';
import { MockStoreEnhanced } from 'redux-mock-store';
import { Store } from '@redux/modules';
import { TState as TStateOtp } from '@redux/modules/otp';
import { TState } from '@redux/modules/postConsult';

// Updated to align with redux-thunk >= 3 which defines ThunkAction with 4 generic params
export interface ThunkDispatch<State, ExtraThunkArg, BasicAction extends Action> {
    <ReturnType>(
        thunkAction: ThunkAction<
            ReturnType,
            State,
            ExtraThunkArg,
            BasicAction
        >,
    ): ReturnType;

    <A extends BasicAction>(action: A): A;

    <ReturnType, A extends BasicAction>(
        action:
            | A
            | ThunkAction<ReturnType, State, ExtraThunkArg, BasicAction>,
    ): A | ReturnType;
}

export type MockStoreType = Omit<
    MockStoreEnhanced<unknown, Record<string, unknown>>,
    'dispatch'
> & {
    dispatch: ThunkDispatch<Store['All'] | TState | TStateOtp, unknown, Action>;
};
