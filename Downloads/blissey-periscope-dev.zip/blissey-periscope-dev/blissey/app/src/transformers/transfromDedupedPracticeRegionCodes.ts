import { PracticeRegion } from '@clients/VisitService/VisitInterfaces';

export const transformDedupedPracticeRegionCodes = (
    practiceRegions: PracticeRegion[],
) => {
    // Set will implicitly dedupe string values
    const dedupedPracticeRegions = new Set<string>();

    practiceRegions
        // remove undefined values
        .filter((practiceRegion: PracticeRegion) => practiceRegion)
        .forEach((practiceRegion: PracticeRegion) => {
            dedupedPracticeRegions.add(practiceRegion.regionCode);
        });

    const result: string[] = [];
    dedupedPracticeRegions.forEach((prCode) => {
        result.push(prCode);
    });

    return result.sort();
};
