import { atomWithQuery } from 'jotai-tanstack-query';
import { visitDetailsAtom } from '../atoms/visitDetails';
import { getVisitServiceClient } from '@clients/VisitService/VisitServiceClient';

export const transferOptionsQueryAtom = atomWithQuery(
    (get) => {
        const visitDetails = get(visitDetailsAtom);
        return {
            queryKey: ['getVisitTransferOptions', visitDetails?.visitId || ''],
            queryFn: async ({ queryKey }) => 
                getVisitServiceClient().getTransferOptions(queryKey[1] as string),
            enabled: !!visitDetails?.visitId,
            staleTime: 0,
            cacheTime: 0,
            refetchOnMount: true,
            refetchOnWindowFocus: false,
        }
    }
);