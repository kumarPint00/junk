import { Meta } from '@storybook/react';
import { InvisitDogfood } from './InvisitDogfood';

const meta: Meta = {
    title: 'Context/InvisitDogfood',
    component: InvisitDogfood,
    parameters: {
        layout: 'fullscreen',
    },
};

export default meta;

export const Dogfood = {
    args: {},
};