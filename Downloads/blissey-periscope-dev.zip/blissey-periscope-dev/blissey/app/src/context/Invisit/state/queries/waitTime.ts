import { atomWithQuery } from 'jotai-tanstack-query';
import { ConferenceStates } from '@dexcare/conference-stage';
import { getVisitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { visitDetailsAtom } from '../atoms/visitDetails';
import { conferenceStateAtom } from '../atoms/conferenceState';
import { userIsProviderAtom } from '../atoms/userDetails';

/**
 * Polling for wait time estimate
 */
export const waitTimeQueryAtom = atomWithQuery((get) => {
    const visitDetails = get(visitDetailsAtom);
    const conferenceState = get(conferenceStateAtom);
    const userIsProvider = get(userIsProviderAtom);
    const enabled =
        !!visitDetails?.visitId &&
        !userIsProvider &&
        conferenceState === ConferenceStates.WaitingRoom;

    return {
        queryKey: ['getVisitWaitTime', visitDetails?.visitId || ''],
        queryFn: async ({ queryKey }) =>
            getVisitServiceClient().getWaitTimeEstimateV9(
                queryKey[1] as string,
            ),
        // polling enabled when the patient is in the waiting room
        enabled,
        // always assume this data is stale
        staleTime: 0,
        // this mirrors our current refresh interval (make configurable for testing)
        refetchInterval: 1 * 60 * 1000,
        refetchOnMount: true,
    };
});
