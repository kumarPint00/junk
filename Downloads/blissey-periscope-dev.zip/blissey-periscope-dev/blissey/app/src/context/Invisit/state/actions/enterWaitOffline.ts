import { atom } from 'jotai';
import {
    userActionErrorAtom,
    userActionLoadingAtom,
} from '../atoms/userAction';
import { getVisitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { visitDetailsAtom } from '../atoms/visitDetails';
import { interactionEventAction } from './analytics';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';

export const patientEnterWaitOfflineAction = atom(null, async (get, set) => {
    /**
     * Atoms
     */
    const visitDetails = get(visitDetailsAtom) as VisitResponseV9;
    const { tokBoxVisit: {
        videoConferenceSession: {
            sessionId = '',
        }
    }} = visitDetails;

    // extract values
    const { visitId, practiceId } = visitDetails;

    // indicate loading / clear previous errors
    set(userActionLoadingAtom, true);
    set(userActionErrorAtom, undefined);

    const enterWaitOffline = async () => {
        set(interactionEventAction, 'patient_enter_wait_offline');
        return getVisitServiceClient().patientEnterWaitOffline({
            visitId,
            practiceId,
            sessionId,
        });
    };

    return enterWaitOffline().catch(() => {
        set(userActionErrorAtom, 'failure');
        set(userActionLoadingAtom, false);
    });
});
