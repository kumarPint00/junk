
import { useCallback, useEffect } from "react";
import { useAtomValue } from "jotai";
import { ConferenceEvent, ConferenceEvents } from "@dexcare/conference-client";
import { videoConferenceClientAtom } from "../state/atoms/clients";

/**
 * Hook to conference events to simulate changes to visit status triggered by them
 * (this actually happens by way of a tokbox events webhook)
 */
export interface ConferenceEventsProps {
    userRole: string;
}

export const useConferenceEvents = ({
    userRole,
}: ConferenceEventsProps) => {
    const videoClient = useAtomValue(videoConferenceClientAtom);

    const handleConferenceEvent = useCallback((event: ConferenceEvent) => {
        switch (event.type) {
            case ConferenceEvents.CONNECTED:
                if (userRole === 'telehealth_patient') {
                    void videoClient.sessionClient.sendSignal('statusChange', {
                        status: 'waitingroom',
                        timestamps: {
                            waitingroom: new Date().toISOString(),
                        }
                    });
                }
                break;
            case ConferenceEvents.JOINED:
                if (userRole === 'telehealth_patient') {
                    void videoClient.sessionClient.sendSignal('statusChange', {
                        status: 'invisit',
                        timestamps: {
                            invisit: new Date().toISOString(),
                        }
                    });
                }
                break;
            default:
                break;
        }
    }, [videoClient, userRole]);

    useEffect(() => {
        videoClient.on(ConferenceEvents.CONNECTED, handleConferenceEvent);
        videoClient.on(ConferenceEvents.JOINED, handleConferenceEvent);
        return () => {
            videoClient.off(ConferenceEvents.CONNECTED, handleConferenceEvent);
            videoClient.off(ConferenceEvents.JOINED, handleConferenceEvent);
        }
    }, [videoClient, handleConferenceEvent])
}