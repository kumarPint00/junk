import * as React from 'react';
import { InvisitContext } from './state/InvisitContext';
import { InvisitContainer } from '../../containers/Invisit/InvisitContainer';

export const InvisitRoute = () => {
    return (
        <InvisitContext>
            <InvisitContainer />
        </InvisitContext>
    );
};
 
InvisitRoute.displayName = 'InvisitRoute';