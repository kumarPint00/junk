/* eslint-disable react-hooks/exhaustive-deps */
import { useAtomValue, useSetAtom } from 'jotai';
import { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import {
    visitDetailsAtom,
    visitIsAssignedToMeAtom,
} from '../atoms/visitDetails';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';
import { userDetailsAtom, userIsProviderAtom } from '../atoms/userDetails';
import { featureFlagsAtom } from '../atoms/featureFlags';
import { FeatureFlags } from '@utils/FeatureFlags';
import {
    sessionClientAtom,
    videoConferenceClientAtom,
} from '../atoms/clients';
import { modalMessageAtom } from '../atoms/modalMessage';
import {
    postVisitProviderSurveyRoute,
    postVisitPatientSurveyRoute,
    getClosedVisitRoute,
    endRoute,
    postConsultRoute,
} from '@utils/getRoutes';
import { useNavigateAndClose } from './useNavigateAndClose';

/**
 * Handle changes to various "status" related states for the visit
 */
export const useVisitStatusEffects = () => {
    const videoSessionClient = useAtomValue(sessionClientAtom);
    const videoConferenceClient = useAtomValue(videoConferenceClientAtom);
    const visitDetails = useAtomValue(visitDetailsAtom);
    const visitIsAssignedToMe = useAtomValue(visitIsAssignedToMeAtom);
    const userIsProvider = useAtomValue(userIsProviderAtom);
    const userDetails = useAtomValue(userDetailsAtom);

    const enablePostVisitSurveyConfig =
        useAtomValue(featureFlagsAtom)?.[
            FeatureFlags.enablePostVisitSurveyConfig
        ] ?? false;

    const [t] = useTranslation();
    const setModalMessage = useSetAtom(modalMessageAtom);

    /**
     * Formally close both tokbox sessions before navigating away from the page
     */
    const navigateAndClose = useNavigateAndClose();

    /**
     * Visit status / modality redirects / effects
     */
    useEffect(() => {
        // grab current status values
        const {
            visitId = '',
            status = '',
            modality = '',
            brand = '',
        } = visitDetails || {};
        const { status: prevStatus = '' } = visitDetailsRef.current || {};

        // force redirect to "waitingroom" end page if modality converted to phone
        // NOTE: should this go someplace different for providers?
        if (modality === 'phone') {
            navigateAndClose(getClosedVisitRoute('waitingroom', false, true));
            return;
        }

        // redirect to the appropriate page based on terminal visit status
        switch (status) {
            case 'done':
                if (enablePostVisitSurveyConfig) {
                    userIsProvider
                        ? navigateAndClose(
                              postVisitProviderSurveyRoute(visitId, brand),
                          )
                        : navigateAndClose(
                              postVisitPatientSurveyRoute(visitId, brand),
                          );
                } else {
                    navigateAndClose(postConsultRoute(visitId, brand));
                }
                break;
            case 'cancelled':
                navigateAndClose(getClosedVisitRoute('cancelled', false));
                break;
            case 'providerdeclined':
            case 'staffdeclined':
                navigateAndClose(getClosedVisitRoute('staffdeclined', false));
                break;
            // this one doesnt seem acknowledged elsewhere (calling it end?)
            case 'expired':
                navigateAndClose(endRoute(brand));
                break;
            // when the status changes to "waitoffline" we want to redirect the patient
            case 'waitoffline':
                // only redirect if the status has changed to waitoffline directly from waitingroom
                // and the user is a patient
                if (prevStatus === 'waitingroom' && !userIsProvider) {
                    const redirectToUrl = `${getClosedVisitRoute(
                        'waitoffline',
                        true,
                    )}?brand=${brand}`;
                    navigateAndClose(redirectToUrl);
                }
                break;
            case 'waitingroom':
            case 'caregiverassigned':
                // if we were previously in "invisit" state this means the patient has been transferred
                // and we can "end" the visit for the provider and return to "waiting room" state for the patient
                if (prevStatus === 'invisit') {
                    if (userIsProvider) {
                        // providers should be redirected to the "done" page
                        enablePostVisitSurveyConfig
                            ? navigateAndClose(
                                  postVisitProviderSurveyRoute(visitId, brand),
                              )
                            : navigateAndClose(
                                  postConsultRoute(visitId, brand),
                              );
                    } else {
                        // force leave the call for patients
                        videoConferenceClient.leave();
                        // show a modal message for the patient
                        // NOTE: This was never added to translations. If we want something similar that is there is:
                        // "providerSoon": "One of our healthcare providers will meet you here as soon as they become available", ?
                        setModalMessage({
                            message: t(
                                'waiting-room.anotherProviderSoon',
                                'Another provider will be with you shortly.',
                            ),
                            dismissLabel: 'OK',
                        });
                    }
                }
                break;
            default:
                break;
        }
    }, [
        visitDetails,
        enablePostVisitSurveyConfig,
        userIsProvider,
        videoConferenceClient,
        setModalMessage,
        t,
    ]);

    /**
     * Provider assignment messaging
     */
    useEffect(() => {
        // If the visit has has been assigned to a different provider
        // show a modal message to the current provider
        if (
            userDetails &&
            visitDetails &&
            userIsProvider &&
            !visitIsAssignedToMe
        ) {
            // formally disconnect the current provider from the visit / chat
            void videoSessionClient.disconnect();
            // the provider to some more appropriate "end" page with a "no longer your visit" message...)
            setModalMessage({
                message:
                    'You are not the assigned provider for this visit and cannot connect with the patient.',
                dismissLabel: 'Close',
            });
        }
    }, [
        visitDetails,
        userDetails,
        userIsProvider,
        visitIsAssignedToMe,
        videoSessionClient,
        setModalMessage,
    ]);

    /**
     * Reference for previous visit details
     */
    const visitDetailsRef = useRef<VisitResponseV9>(
        visitDetails as VisitResponseV9,
    );
    useEffect(() => {
        visitDetailsRef.current = visitDetails as VisitResponseV9;
    }, [visitDetails]);
};
