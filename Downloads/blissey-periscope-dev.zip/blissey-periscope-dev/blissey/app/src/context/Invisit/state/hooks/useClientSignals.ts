import { videoConferenceClientAtom } from '../atoms/clients';
import { ConferenceEvent, ConferenceEvents } from '@dexcare/conference-client';
import { setPartialVisitDetailsAtom } from '../atoms/visitDetails';
import { useAtomValue, useSetAtom } from 'jotai';
import { useCallback, useEffect } from 'react';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';
import {
    userActionLoadingAtom,
    userActionErrorAtom,
} from '../atoms/userAction';
import { Logger } from '@utils/index';

export enum SignalTypes {
    STATUS_CHANGE = 'signal:statusChange',
    STATUS_CHANGE_ERROR = 'signal:statusChangeError',
    PATIENT_ENTER_WAIT_OFFLINE_SUCCESS = 'signal:patientEnterWaitOfflineSuccess',
    PATIENT_ENTER_WAIT_OFFLINE_ERROR = 'signal:patientEnterWaitOfflineError',
    END_CALL_AND_TRANSFER = 'signal:endCallAndTransfer',
    END_CALL_AND_TRANSFER_ERROR = 'signal:endCallAndTransferError',
    MODALITY_CONVERSION = 'signal:modalityConversion',
    MODALITY_CONVERSION_ERROR = 'signal:modalityConversionError',
}

interface ModalityConversionData {
    targetModality: string;
    error?: {
        code: string;
        message: string;
    };
}

interface StatusChangeError {
    message?: string;
}

export const useClientSignals = () => {
    const sessionClient = useAtomValue(videoConferenceClientAtom);
    const setPartialVisitDetails = useSetAtom(setPartialVisitDetailsAtom);
    const setUserActionError = useSetAtom(userActionErrorAtom);
    const setUserActionLoading = useSetAtom(userActionLoadingAtom);

    const handleSignal = useCallback(
        (event: ConferenceEvent) => {
            const signalType = event.data?.signalType;
            let signalData: unknown = {};
            try {
                signalData =
                    typeof event.data?.signalData === 'string'
                        ? JSON.parse(event.data?.signalData)
                        : event.data?.signalData;
            } catch (error: unknown) {
                Logger.error(
                    {
                        event,
                        error
                    },
                    'Could not parse signal data',
                )
            }

            switch (signalType) {
                case SignalTypes.STATUS_CHANGE:
                case SignalTypes.PATIENT_ENTER_WAIT_OFFLINE_SUCCESS: // is this superflous?
                    setPartialVisitDetails(
                        signalData as Partial<VisitResponseV9>,
                    );
                    setUserActionError(undefined);
                    setUserActionLoading(false);
                    break;
                case SignalTypes.MODALITY_CONVERSION:
                    // NOTE: are we also going to get modality updates in our status change events?
                    // if so we should just be able to forgo this whole thing
                    setPartialVisitDetails({
                        modality: (signalData as ModalityConversionData)
                            .targetModality,
                    });
                    setUserActionError(undefined);
                    setUserActionLoading(false);
                    break;
                case SignalTypes.STATUS_CHANGE_ERROR:
                    setUserActionError(
                        (signalData as StatusChangeError)?.message ||
                            'An error occurred while updating visit status. Please try again.',
                    );
                    setUserActionLoading(false);
                    break;
                case SignalTypes.PATIENT_ENTER_WAIT_OFFLINE_ERROR:
                    setUserActionError('failure');
                    setUserActionLoading(false);
                    break;
                case SignalTypes.MODALITY_CONVERSION_ERROR:
                    setUserActionError(
                        'An error occurred trying to convert visit modality. Please try again.',
                    );
                    setUserActionLoading(false);
                    break;
                case SignalTypes.END_CALL_AND_TRANSFER_ERROR:
                    setUserActionError(
                        'An error occurred trying to transfer the visit. Please try again.',
                    );
                    setUserActionLoading(false);
                    break;
                default:
                    break;
            }
        },
        [setPartialVisitDetails, setUserActionError, setUserActionLoading],
    );

    useEffect(() => {
        sessionClient.off(ConferenceEvents.SIGNAL, handleSignal);
        sessionClient.on(ConferenceEvents.SIGNAL, handleSignal);
        return () => {
            sessionClient.off(ConferenceEvents.SIGNAL, handleSignal);
        };
    }, [sessionClient, handleSignal]);
};
