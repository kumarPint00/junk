import { atom } from 'jotai';

export const userActionLoadingAtom = atom<boolean>(false);
export const userActionErrorAtom = atom<string>();
