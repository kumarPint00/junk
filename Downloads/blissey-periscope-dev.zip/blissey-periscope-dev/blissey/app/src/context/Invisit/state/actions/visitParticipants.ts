import { atom } from 'jotai';
import {
    AddParticipantFormData,
    VisitParticipant,
} from '@dexcare/visit-participants';
import {
    userActionErrorAtom,
    userActionLoadingAtom,
} from '../atoms/userAction';
import { visitParticipantsAtom } from '../atoms/visitParticipants';
import { getBackendFacade } from '@clients/Backend/BackendFacade';
import { visitDetailsAtom } from '../atoms/visitDetails';
import { videoConferenceClientAtom } from '../atoms/clients';

/**
 * Add / invite a new participant
 */
export const addParticipantAction = atom(
    null,
    async (
        get,
        set,
        formData: AddParticipantFormData,
        onSuccess: () => void = () => {},
    ) => {
        // atoms
        const visitDetails = get(visitDetailsAtom);
        const participants = get(visitParticipantsAtom);

        const { visitId = '' } = visitDetails || {};

        // indicate loading
        set(userActionLoadingAtom, true);

        return getBackendFacade()
            .addVisitParticipant(visitId, formData)
            .then((participant: VisitParticipant) => {
                // add the new participant to the list
                set(visitParticipantsAtom, [...participants, participant]);
                onSuccess();
            })
            .catch((err: { message?: string }) => {
                // set user action error
                set(
                    userActionErrorAtom,
                    err.message || 'Could not add participant',
                );
            })
            .finally(() => {
                set(userActionLoadingAtom, false);
            });
    },
);

/**
 * Set a participants attributes for updated display
 */
export const setParticipantAttributesAtom = atom(
    null,
    (
        get,
        set,
        participant: VisitParticipant,
        attributes: Partial<VisitParticipant>,
    ) => {
        const participants = get(visitParticipantsAtom);
        const pending: VisitParticipant = {
            ...participant,
            ...attributes,
        };
        const index = participants.findIndex((p) => p.id === participant.id);
        set(visitParticipantsAtom, [
            ...participants.slice(0, index),
            pending,
            ...participants.slice(index + 1),
        ]);
    },
);

/**
 * Delete a participant from the list
 * NOTE : This method / action should be invokable by a provider (moderator)
 * force disconnecting a participant from a tokbox call. We will need to see
 * about the best way to tie them together
 * (i.e. include participant id in the connection data in their token)
 */
export const deleteParticipantAction = atom(
    null,
    async (
        get,
        set,
        participant: VisitParticipant,
        forceDisconnect?: boolean,
    ) => {
        // atoms
        const visitDetails = get(visitDetailsAtom);
        const { visitId = '' } = visitDetails || {};
        const participants = get(visitParticipantsAtom);
        const sessionClient = get(videoConferenceClientAtom).sessionClient;
        // set participant pending
        set(setParticipantAttributesAtom, participant, { pendingAction: true });
        // delete
        return getBackendFacade()
            .deleteVisitParticipant(visitId, participant.id)
            .then(async () => {
                // remove the pending participant
                set(
                    visitParticipantsAtom,
                    participants.filter((p) => p.id !== participant.id),
                );
                // If we should also force disconnect the participant
                // do so now (if there is a corresponding connection)
                if (forceDisconnect) {
                    const connection = sessionClient.getConnectionForUser(
                        participant.id,
                    );
                    if (connection) {
                        return sessionClient.forceDisconnect(connection);
                    }
                }
                return;
            })
            .catch((err: { message?: string }) => {
                // set user action error
                set(
                    userActionErrorAtom,
                    err.message || 'Could not delete participant',
                );
                // set not pending
                set(setParticipantAttributesAtom, participant, {
                    pendingAction: false,
                });
            });
    },
);

/**
 * Set a participants "admitted" attribute. This will enable them to get a fully featured
 * tokbox token so that they can join the conference
 */
export const admitParticipantAction = atom(
    null,
    async (get, set, participant: VisitParticipant) => {
        // atoms
        const visitDetails = get(visitDetailsAtom);
        const { visitId = '' } = visitDetails || {};
        // set participant pending
        set(setParticipantAttributesAtom, participant, { pendingAction: true });
        // admit
        return getBackendFacade()
            .admitVisitParticipant(visitId, participant.id)
            .then(() => {
                set(setParticipantAttributesAtom, participant, {
                    pendingAction: false,
                    admitted: true,
                });
            })
            .catch((err: { message?: string }) => {
                // set user action error
                set(
                    userActionErrorAtom,
                    err.message || 'Could not admit participant',
                );
                // set not pending
                set(setParticipantAttributesAtom, participant, {
                    pendingAction: false,
                    admitted: false,
                });
            });
    },
);
