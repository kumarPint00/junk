/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import * as React from 'react';
import * as Redux from 'redux';
import { Mock, MockInstance, vi } from 'vitest';
import { Provider } from 'react-redux';
import {
    render,
    waitFor,
    RenderResult,
    fireEvent,
    act,
    cleanup,
    within,
} from '@testing-library/react/pure';
import {
    ConferenceEvents,
    ConferenceEvent,
    ClientConnection,
} from '@dexcare/conference-client';
import { i18n as I18nInterface } from 'i18next';
import { TestProvider } from '../../../__mocks__/jotai/TestProvider';
import { Store, rootReducer } from '@redux/modules';
import { UserDetails } from 'types/UserDetails';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { getVisitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { getBackendFacade } from '@clients/Backend/BackendFacade';
import { I18nextProvider } from 'react-i18next';
import { queryClientOptions } from '../../../reactQuery';
import {
    generateMockVisitSummaryResponse,
    mockBrand,
    mockPracticeId,
    mockVisitId,
    mockConferenceSession,
} from '../../../__mocks__/services/responses/mockGetVisitSummary';
import { InvisitRoute } from '../InvisitRoute';
import {
    sessionClientAtom,
    videoChatClientAtom,
    waitingRoomChatClientAtom,
    videoConferenceClientAtom,
} from '../state/atoms/clients';
import { generateProviderTokenResponse } from '../../../__mocks__/services/responses/mockGetProviderToken';
import { mockStatusEvent } from '../../../__mocks__/videoClient.mock';
import {
    mockVideoTokenResponse,
    mockWaitingroomTokenResponse,
} from '../../../__mocks__/services/responses/mockGetPatientToken';
import { generateMockWaittimeResponse } from '../../../__mocks__/services/responses/mockGetWaitTime';
import { initI18n } from '../../../__mocks__/i18n/i18n.mock';
import { getPantryConfig } from '@clients/Pantry/getPantryConfig';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';
import { config } from '@dexcare/circus-jupiter';
import { AppConfig } from '../../../../../server/config/configInterfaces';
import { Configuration } from 'types/configuration';
import { conferenceStateAtom } from '../state/atoms/conferenceState';
import { useNavigate, MemoryRouter, Routes, Route } from 'react-router-dom';
import { mockUserId } from '../../../__mocks__/services/responses/mockGetUser';
import {
    mockParticipant,
    mockParticipant2,
    mockParticipantTypes,
} from '../../../__mocks__/services/responses/mockVisitParticipants';
import { visitDetailsAtom } from '../state/atoms/visitDetails';
import { ConferenceStates } from '@dexcare/conference-stage';
import {
    MockSessionClient,
    MockVideoClient,
    MockChatClient,
} from '@dexcare/conference-client/mocks';

const mockVisitServiceClient = {
    getVisitSummary: vi.fn(),
    generateTokboxPatientToken: vi.fn(),
    getWaitTimeEstimateV9: vi.fn(),
    sendWaitingRoomEvent: vi.fn(),
    patientEnterWaitOffline: vi.fn(),
    chargeVisit: vi.fn(),
    waiveVisit: vi.fn(),
    cancelVideoWithReason: vi.fn(),
    getParticipantTypes: vi.fn(),
    cacheInstantMessage: vi.fn(),
};

const mockBackendFacade = {
    generateTokboxProviderToken: vi.fn(),
    transferBackToQueue: vi.fn(),
    transferToAnotherProvider: vi.fn(),
    convertModality: vi.fn(),
    getVisitParticipants: vi.fn(),
    addVisitParticipant: vi.fn(),
    deleteVisitParticipant: vi.fn(),
};

vi.mock('@clients/VisitService/VisitServiceClient', () => ({
    getVisitServiceClient: vi.fn(),
}));

vi.mock('@clients/Backend/BackendFacade', () => ({
    getBackendFacade: vi.fn(),
}));

vi.mock('@clients/Pantry/getPantryConfig', () => ({
    getPantryConfig: vi.fn(),
}));

vi.mock('react-player', async () => {
    const actual = await vi.importActual('react-player');
    return {
        ...actual,
        default: (props: object) => (
            <div data-testid="mock-react-player">{JSON.stringify(props)}</div>
        ),
    };
});

vi.mock('react-router-dom', async () => {
    const actual = await vi.importActual('react-router-dom');
    return {
        ...actual,
        useNavigate: vi.fn(),
    };
});

const mockGetPantryConfig = getPantryConfig as Mock;
const mockGetConfig = (config as Configuration).getConfig as Mock;
const mockUseNavigate = useNavigate as Mock;

const getMockState = (
    overrides: Partial<Store['All']> = {},
): Partial<Store['All']> => ({
    user: {
        userDetails: {
            id: 'mockUserId',
            roles: ['telehealth_provider'],
        } as UserDetails,
    },
    ...overrides,
});

/**
 * Must define query client here to avoid re-creating it in each test
 */
const queryClient = new QueryClient({
    ...queryClientOptions,
});

describe('InvisitRoute', () => {
    let mockSessionClient: MockSessionClient;
    let videoConferenceClient: MockVideoClient;
    let mockVideoChatClient: MockChatClient;
    let mockWaitingRoomChatClient: MockChatClient;
    let defaultValues: object;
    let i18nInstance: I18nInterface;
    let config: AppConfig;
    let mockJoinCall: MockInstance;
    let mockLeaveCall: MockInstance;
    let mockNavigate: Mock;

    beforeAll(async () => {
        mockSessionClient = new MockSessionClient();
        videoConferenceClient = new MockVideoClient(mockSessionClient);
        mockVideoChatClient = new MockChatClient(mockSessionClient);
        mockWaitingRoomChatClient = new MockChatClient();
        // client spies
        mockJoinCall = vi.spyOn(videoConferenceClient, 'join');
        mockLeaveCall = vi.spyOn(videoConferenceClient, 'leave');
        // atom hydration
        defaultValues = {
            sessionClientAtom: [sessionClientAtom, mockSessionClient],
            videoConferenceClientAtom: [
                videoConferenceClientAtom,
                videoConferenceClient,
            ],
            videoChatClientAtom: [videoChatClientAtom, mockVideoChatClient],
            waitingRoomChatClientAtom: [
                waitingRoomChatClientAtom,
                mockWaitingRoomChatClient,
            ],
            conferenceStateAtom: [
                conferenceStateAtom,
                ConferenceStates.WaitingRoom,
            ],
            visitDetailsAtom: [visitDetailsAtom, { visitId: mockVisitId }],
        };
        config = {
            instructionalVideoDirectUrl: 'some-video-url.com',
            waitingRoomVideoDelay: 1,
            features: {
                'enable-manually-entering-waitoffline': true,
                'waiting-room-video': true,
                'enable-patient-cancellation-with-reason': {
                    video: true,
                    phone: false,
                },
                cancellation: true,
                'release-multi-party-conference': true,
            },
            styles: {
                primaryColor: '#eeffee',
                secondaryColor: '#ffeeee',
            },
        } as unknown as AppConfig;
        i18nInstance = await initI18n();
        mockGetConfig.mockReturnValue(config);
        (getVisitServiceClient as Mock).mockReturnValue(mockVisitServiceClient);
        (getBackendFacade as Mock).mockReturnValue(mockBackendFacade);
        // mock navigate
        mockNavigate = vi.fn();
        mockUseNavigate.mockReturnValue(mockNavigate);
    });

    afterAll(() => {
        vi.resetAllMocks();
    });

    const renderComponent = (
        initialState: Partial<Store['All']> = getMockState(),
        initialAtomValues: object = defaultValues,
    ) => {
        const values = Object.values(initialAtomValues);
        const mockStore = Redux.createStore(rootReducer, initialState);
        return render(
            <I18nextProvider i18n={i18nInstance}>
                <Provider store={mockStore}>
                    <QueryClientProvider client={queryClient}>
                        <TestProvider initialValues={values}>
                            <MemoryRouter
                                initialEntries={[
                                    `/visit/${mockVisitId}?brand=${mockBrand}`,
                                ]}
                            >
                                <Routes>
                                    <Route
                                        path="/visit/:visitId"
                                        Component={InvisitRoute}
                                    />
                                </Routes>
                            </MemoryRouter>
                        </TestProvider>
                    </QueryClientProvider>
                </Provider>
            </I18nextProvider>,
        );
    };

    describe('as a provider', () => {
        const beforeSuccessfulLoad = () => {
            mockVisitServiceClient.getVisitSummary.mockResolvedValue(
                generateMockVisitSummaryResponse({
                    timestamps: {
                        created: '2021-10-01T00:00:00Z',
                        requested: '2021-10-01T00:00:00Z',
                        waitingroom: '2021-10-01T00:01:00Z',
                        caregiverassigned: '2021-10-01T00:02:30Z',
                        invisit: undefined,
                        done: undefined,
                        staffdeclined: undefined,
                        cancelled: undefined,
                        waitoffline: undefined,
                    },
                    providerId: mockUserId,
                    status: 'caregiverassigned',
                }),
            );
            mockVisitServiceClient.getParticipantTypes.mockResolvedValue(
                mockParticipantTypes,
            );
            mockVisitServiceClient.cacheInstantMessage.mockResolvedValue(
                undefined,
            );
            mockBackendFacade.generateTokboxProviderToken.mockResolvedValue(
                generateProviderTokenResponse({}),
            );
            mockBackendFacade.getVisitParticipants.mockResolvedValue([
                mockParticipant,
                mockParticipant2,
            ]);
        };

        const expectSuccessfulLoad = async (render: RenderResult) => {
            // waiting for tech check
            await waitFor(() => {
                expect(
                    render.getByTestId('provider-invisit-container'),
                ).toBeInTheDocument();
                expect(
                    render.getByTestId('tech-check-header'),
                ).toBeInTheDocument();
                expect(
                    render.getByTestId('tech-check-header').textContent,
                ).toEqual('Checking for devices');
            });
            // header displays success after connect
            const successHeader = await render.findByText(
                'Success!',
                {},
                { timeout: 5000 },
            );
            expect(successHeader).toBeInTheDocument();
        };

        const expectJoinCall = async (render: RenderResult) => {
            // provider gets a join button
            const joinButton = render.getByTestId(
                'video-conference-join-button',
            );
            expect(joinButton).toBeInTheDocument();
            // before the patient connects, the button should go to disabled state / wait
            // while the provider waits for the patient to connect
            fireEvent.click(joinButton);
            await waitFor(() => {
                expect(joinButton).toHaveAttribute('disabled');
                expect(joinButton.textContent).toEqual(
                    'Waiting for patient to connect',
                );
            });
            // the patient connects
            mockSessionClient.generateParticipants(1, [
                {
                    connection: {
                        connectionData: {
                            role: 'patient',
                        },
                    } as ClientConnection,
                },
            ]);
            mockSessionClient.connectParticipants();
            // the provider joins
            await waitFor(() => {
                // expect(videoConferenceClient.sessionClient.hasRoleConnected('patient')).toEqual(true);
                expect(mockJoinCall).toHaveBeenCalled();
            });
            await waitFor(() => {
                const incallMenu = render.getByTestId(
                    'video-conference-incall-menu',
                );
                expect(incallMenu).toBeInTheDocument();
                const timer = render.getByTestId(
                    'video-conference-time-elapsed',
                );
                expect(timer).toBeInTheDocument();
            });
        };

        describe('standard visit flow', () => {
            let render: RenderResult;
            beforeAll(() => {
                beforeSuccessfulLoad();
                render = renderComponent();
            });

            afterAll(() => {
                queryClient.clear();
                cleanup();
            });

            it('renders the container and passes tech check', async () => {
                await expectSuccessfulLoad(render);
            });

            it('joins the call once the patient connects', async () => {
                await expectJoinCall(render);
            });

            // need to skip this for the moment and let dogfood testing be enough
            // sorry :/
            it.skip('chats with the patient', async () => {
                // const headerText = render.container.querySelector(
                //     '[data-uitest="headerText"]',
                // );
                // expect(headerText).toBeInTheDocument();
                // // emit successful connection
                // act(() => {
                //     mockTextChatClient.emitSessionConnected();
                // });
                // // check chat input
                // const chatInput = render.container.querySelector(
                //     '[data-uitest="instantmessage-input"]',
                // ) as HTMLElement;
                // expect(chatInput).toBeInTheDocument();
                // const sendButton = render.container.querySelector(
                //     '[data-uitest="sendMessageButton"]',
                // ) as HTMLElement;
                // expect(sendButton).toBeInTheDocument();
                // // emit message received
                // act(() => {
                //     mockTextChatClient.emitMessageReceived(
                //         'Hello from patient',
                //         'Patient',
                //     );
                // });
                // // type a message
                // act(() => {
                //     fireEvent.change(chatInput, {
                //         target: { value: 'Hello, this is the provider' },
                //     });
                // });
                // await new Promise((resolve) => setTimeout(resolve, 350));
                // await waitFor(() => {
                //     expect(
                //         mockTextChatClient.methodCalls.sendTypingStarted.length,
                //     ).toBeGreaterThan(0);
                // });
                // fireEvent.click(sendButton);
                // expect(mockTextChatClient.methodCalls.sendMessage.length).toBe(
                //     1,
                // );
                // expect(
                //     mockTextChatClient.methodCalls.sendMessage[0].message,
                // ).toBe('Hello, this is the provider');
                // mockVisitServiceClient.cacheInstantMessage.mockImplementation(
                //     async () => Promise.resolve(),
                // );
                // act(() => {
                //     mockTextChatClient.emitMessageSent(
                //         'Hello, this is the provider',
                //     );
                // });
                // // expect call to cache the message
                // expect(
                //     mockVisitServiceClient.cacheInstantMessage,
                // ).toHaveBeenCalledWith(
                //     mockVisitId,
                //     mockConferenceSession.sessionId,
                //     expect.objectContaining({
                //         creationTime: expect.any(String),
                //         fromParticipant: 'You',
                //         message: 'Hello, this is the provider',
                //         senderId: '',
                //         uniqueId: expect.any(String),
                //     }),
                //     true,
                // );
                // // emit typing event
                // act(() => {
                //     mockTextChatClient.emitTypingStarted('Provider');
                // });
                // // check typing indicator
                // await waitFor(() => {
                //     const typingIndicator = render.container.querySelector(
                //         '[data-uitest="instantmessage-istyping"]',
                //     );
                //     expect(typingIndicator).toBeInTheDocument();
                //     expect(typingIndicator?.textContent).toBe(
                //         'Provider is typing...',
                //     );
                // });
                // act(() => {
                //     mockTextChatClient.emitTypingStopped('Provider');
                // });
                // act(() => {
                //     mockTextChatClient.emitSessionDisconnected();
                // });
                // await waitFor(() => {
                //     const notConnectedNotification = render.getByText(
                //         'Problem Connecting to Chat',
                //     );
                //     expect(notConnectedNotification).toBeInTheDocument();
                // });
                // act(() => {
                //     mockTextChatClient.emitSessionConnected();
                // });
            });

            describe('participant management', () => {
                let forceDisconnectMock: MockInstance;
                const mockConnection = {
                    id: 'some-connection-id',
                    connectionObject: {
                        connectionId: 'some-connection-id',
                    },
                };

                beforeAll(() => {
                    // set up expected mocks
                    mockBackendFacade.deleteVisitParticipant.mockResolvedValue(
                        undefined,
                    );
                    vi.spyOn(
                        mockSessionClient,
                        'getConnectionForUser',
                    ).mockReturnValue(mockConnection);
                    forceDisconnectMock = vi
                        .spyOn(mockSessionClient, 'forceDisconnect')
                        .mockResolvedValue(undefined);
                    // open the participant menu
                    const participantsButton = render.getByTestId(
                        'incall-menu-participants',
                    );
                    fireEvent.click(participantsButton);
                });

                it('lists participants', () => {
                    const participantsMenu = within(
                        render.getByTestId('incall-menu-participants-menu'),
                    );
                    expect(
                        participantsMenu.getByTestId(
                            `participant-tile-${mockParticipant.id}`,
                        ),
                    ).toBeInTheDocument();
                    // with 2 additional participants the add button should be disabled
                    expect(
                        participantsMenu.getByTestId(
                            'participants-list-disabled-add-message',
                        ),
                    ).toBeInTheDocument();
                });

                it('force disconnects deleted participants', async () => {
                    const participantsMenu = within(
                        render.getByTestId('incall-menu-participants-menu'),
                    );
                    // click delete / confirm delete on participant tile
                    const tile = participantsMenu.getByTestId(
                        `participant-tile-${mockParticipant.id}`,
                    );
                    const { getByTestId } = within(tile);
                    const deleteButton = getByTestId(
                        'participant-delete-button',
                    );
                    fireEvent.click(deleteButton);
                    const confirmDeleteButton = getByTestId(
                        'participant-confirm-delete-button',
                    );
                    fireEvent.click(confirmDeleteButton);
                    // expect call to delete action
                    expect(
                        mockBackendFacade.deleteVisitParticipant,
                    ).toHaveBeenCalledWith(mockVisitId, mockParticipant.id);
                    // expect call to declineConnection
                    await waitFor(() => {
                        expect(forceDisconnectMock).toHaveBeenCalledWith(
                            mockConnection,
                        );
                    });
                });
            });

            describe('ends the visit in different ways', () => {
                afterEach(() => {
                    queryClient.clear();
                    cleanup();
                });

                it('ends the visit (charge)', async () => {
                    // provider leaves the call
                    const leaveButton = render.getByTestId('end-visit-button');
                    expect(leaveButton).toBeInTheDocument();
                    fireEvent.click(leaveButton);
                    // by default the end visit dialog is open after provider leaves the call
                    expect(
                        render.getByTestId('end-visit-dialog'),
                    ).toBeInTheDocument();
                    expect(
                        render.getByTestId(
                            'confirmation-dialog-confirm-button',
                        ),
                    ).toBeInTheDocument();
                    const actionSelector = within(
                        render.getByTestId('postVisitActionSelector'),
                    );
                    // select an end option (charge) and confirm
                    fireEvent.click(
                        actionSelector.getByLabelText('Charge Visit'),
                    );
                    fireEvent.click(
                        render.getByTestId(
                            'confirmation-dialog-confirm-button',
                        ),
                    );
                    await waitFor(() => {
                        // expect service call
                        expect(
                            mockVisitServiceClient.chargeVisit,
                        ).toHaveBeenCalledWith(mockVisitId);
                        // expect leave call
                        expect(mockLeaveCall).toHaveBeenCalled();
                    });
                    // should be redirected to postconsult page after status updated to done
                    act(() => {
                        mockStatusEvent(mockSessionClient, {
                            status: 'done',
                        });
                    });
                    expect(mockNavigate).toHaveBeenCalledWith(
                        `/postconsult/${mockVisitId}?brand=${mockBrand}`,
                    );
                });

                // TODO: figure out why this is not rendering properly
                // the resets seem ok but not working
                // it('ends the visit (waive)', async () => {
                //     // provider leaves the call
                //     const leaveButton = render.getByTestId('end-visit-button');
                //     expect(leaveButton).toBeInTheDocument();
                //     fireEvent.click(leaveButton);
                //     const actionSelector = within(
                //         render.getByTestId('postVisitActionSelector'),
                //     );
                //     // select an end option (waive) and confirm
                //     fireEvent.click(actionSelector.getByLabelText('Waive Visit'));
                //     // select a waive reason...
                //     const dialogSelector = within(
                //         render.getByTestId('end-visit-dialog'),
                //     );
                //     const dropdown = dialogSelector
                //         .getByTestId('waive-reason-selector')
                //         .querySelector('input');
                //     fireEvent.change(dropdown as Element, {
                //         target: { value: 'demo' },
                //     });
                //     fireEvent.click(
                //         dialogSelector.getByTestId(
                //             'confirmation-dialog-confirm-button',
                //         ),
                //     );
                //     await waitFor(() => {
                //         // expect service call
                //         expect(
                //             mockVisitServiceClient.waiveVisit,
                //         ).toHaveBeenCalledWith(mockVisitId, 'demo');
                //         // expect leave call
                //         expect(mockLeaveCall).toHaveBeenCalled();
                //     });
                //     // should be redirected to postconsult page after status updated to done
                //     act(() => {
                //         mockStatusEvent({
                //             status: 'done',
                //         });
                //     });
                //     expect(mockNavigate).toHaveBeenCalledWith(
                //         `/postconsult/${mockVisitId}?brand=${mockBrand}`,
                //     );
                // });
            });
        });
    });

    describe('as a patient', () => {
        let state: Partial<Store['All']>;
        beforeAll(() => {
            state = getMockState({
                user: {
                    userDetails: {
                        id: 'mockUserId',
                        roles: ['telehealth_patient'],
                    } as UserDetails,
                },
            });
        });

        /**
         * Expected mock calls / events that lead to a successful load
         */
        const beforeSuccessfulLoad = () => {
            mockVisitServiceClient.getVisitSummary.mockResolvedValue(
                generateMockVisitSummaryResponse({}),
            );
            mockVisitServiceClient.generateTokboxPatientToken
                .mockResolvedValueOnce({ ...mockVideoTokenResponse })
                .mockResolvedValueOnce({ ...mockWaitingroomTokenResponse });
            mockVisitServiceClient.cacheInstantMessage.mockResolvedValue(
                undefined,
            );
            mockGetPantryConfig.mockResolvedValue({
                minimumWaitTimeForWaitOffline: 600,
            });
            // Cant seem to get the wait time formatting to work with the test
            // i18n setup... for now just going to return a non-localized response
            mockVisitServiceClient.getWaitTimeEstimateV9.mockResolvedValue(
                generateMockWaittimeResponse({
                    estimatedWaitTimeSeconds: 700,
                    estimatedWaitTimeMessage: 'some super fancy messaage',
                    estimateGeneratedAt: '111111111111',
                    waitTimeLocalizationInfo: undefined,
                }),
            );
        };

        /**
         * Assert behaviors of a successful load
         * @param render
         */
        const expectSuccessfulLoad = async (render: RenderResult) => {
            await waitFor(() => {
                expect(
                    render.getByTestId('patient-invisit-container'),
                ).toBeInTheDocument();
                expect(
                    render.getByTestId('tech-check-header'),
                ).toBeInTheDocument();
                expect(
                    render.getByTestId('tech-check-header').textContent,
                ).toEqual('Checking for devices');
            });
            await waitFor(() => {
                expect(
                    render.getByTestId('tech-check-header').textContent,
                ).toEqual('Success!');
                expect(
                    mockVisitServiceClient.sendWaitingRoomEvent,
                ).toHaveBeenCalledWith(mockVisitId, {
                    techCheck: {
                        status: 'pass',
                        camStatus: 'pass',
                        micStatus: 'pass',
                        mediaPermissionStatus: 'pass',
                        networkStatus: 'pass',
                    },
                });
            });
        };

        const expectWaitTimeMessage = async (render: RenderResult) => {
            await waitFor(() => {
                expect(
                    render.getByTestId('conference-stage-body').textContent,
                ).toEqual('some super fancy messaage');
            });
        };

        const expectAutoJoin = async (render: RenderResult) => {
            // provider joins
            act(() => {
                vi.spyOn(
                    videoConferenceClient.sessionClient,
                    'hasModeratorJoined',
                    'get',
                ).mockReturnValue(true);
                videoConferenceClient.emit(
                    ConferenceEvents.PARTICIPANT_JOINED,
                    new ConferenceEvent(
                        'Participant joined',
                        ConferenceEvents.PARTICIPANT_JOINED,
                    ),
                );
            });
            // the patient joins
            await waitFor(() => {
                expect(mockJoinCall).toHaveBeenCalled();
            });
            await waitFor(() => {
                const incallMenu = render.getByTestId(
                    'video-conference-incall-menu',
                );
                expect(incallMenu).toBeInTheDocument();
            });
        };

        const expectInstructionalVideo = async (render: RenderResult) => {
            await waitFor(() => {
                expect(
                    render.getByTestId('instructional-video'),
                ).toBeInTheDocument();
            });
        };

        describe('standard visit flow (provider ends the visit)', () => {
            let render: RenderResult;
            beforeAll(() => {
                beforeSuccessfulLoad();
                render = renderComponent(state);
            });

            afterAll(() => {
                queryClient.clear();
                cleanup();
            });

            it('renders the container and passes tech check', async () => {
                await expectSuccessfulLoad(render);
            });

            it('shows a waittime based message', async () => {
                await expectWaitTimeMessage(render);
            });

            it('displays an instructional video', async () => {
                await expectInstructionalVideo(render);
            });

            it('auto joins the call when the provider arrives', async () => {
                await expectAutoJoin(render);
            });

            it('provider ends the call', () => {
                // the provider ending the call results in status change
                act(() => {
                    mockStatusEvent(mockSessionClient, {
                        status: 'done',
                    });
                });
                expect(mockNavigate).toHaveBeenCalledWith(
                    `/postconsult/${mockVisitId}?brand=${mockBrand}`,
                );
            });
        });

        describe('patient leaves the call', () => {
            let render: RenderResult;
            beforeAll(() => {
                beforeSuccessfulLoad();
                render = renderComponent(state);
            });

            afterAll(() => {
                queryClient.clear();
                cleanup();
            });

            it('loads and joins the conference', async () => {
                await expectSuccessfulLoad(render);
                await expectAutoJoin(render);
            });

            it('patient leaves the call / visit', async () => {
                // patient leaves the call
                const leaveButton = render.getByTestId('leave-visit-button');
                expect(leaveButton).toBeInTheDocument();
                fireEvent.click(leaveButton);
                // the leave visit dialog is open
                expect(
                    render.getByTestId('leave-visit-dialog'),
                ).toBeInTheDocument();
                expect(
                    render.getByTestId('leave-visit-confirm'),
                ).toBeInTheDocument();
                fireEvent.click(render.getByTestId('leave-visit-confirm'));
                await waitFor(() => {
                    expect(mockNavigate).toHaveBeenCalledWith(
                        `/postconsult/${mockVisitId}?brand=${mockBrand}`,
                    );
                });
            });
        });

        // NOTE: Something tweaky with test contamination happening here
        // going to skip in the interest of being in a hurry right now...
        describe.skip('patient enters waitoffline', () => {
            let render: RenderResult;
            beforeAll(() => {
                beforeSuccessfulLoad();
                render = renderComponent(state);
            });

            afterAll(() => {
                queryClient.clear();
                cleanup();
            });

            it('renders the container and passes tech check', async () => {
                await expectSuccessfulLoad(render);
            });

            it('can opt to waitoffline', async () => {
                // mock transition to waiting room event
                act(() => {
                    mockStatusEvent(mockSessionClient, {
                        status: 'waitingroom',
                        timestamps: {
                            waitingroom: '2021-10-01T00:01:00Z',
                        },
                    } as Partial<VisitResponseV9>);
                });
                // opt to wait offline
                await waitFor(() => {
                    expect(
                        render.getByTestId('wait-offline-button'),
                    ).toBeInTheDocument();
                });
                fireEvent.click(render.getByTestId('wait-offline-button'));
                await waitFor(() => {
                    expect(
                        render.getByTestId(
                            'confirmation-dialog-confirm-button',
                        ),
                    ).toBeInTheDocument();
                });
                fireEvent.click(
                    render.getByTestId('confirmation-dialog-confirm-button'),
                );
                // expect service call
                await waitFor(() => {
                    expect(
                        getVisitServiceClient().patientEnterWaitOffline,
                    ).toHaveBeenCalledWith({
                        visitId: mockVisitId,
                        practiceId: mockPracticeId,
                        sessionId: mockConferenceSession.sessionId,
                    });
                });
            });

            it('navigates to waitoffline page after successful waitoffline', async () => {
                // mimic visit-service signal to tokbox client which then rebroadcast to the component
                act(() => {
                    mockStatusEvent(mockSessionClient, {
                        status: 'waitoffline',
                        timestamps: { waitoffline: '2021-10-01T00:02:00Z' },
                    } as never);
                });
                await waitFor(() => {
                    expect(mockNavigate).toHaveBeenCalled();
                });
            });
        });

        // NOTE: Something tweaky with test contamination happening here
        // going to skip in the interest of being in a hurry right now...
        describe.skip('patient cancels the visit', () => {
            let render: RenderResult;
            beforeAll(() => {
                beforeSuccessfulLoad();
                render = renderComponent(state);
            });

            afterAll(() => {
                queryClient.clear();
                cleanup();
            });

            it('renders the container and passes tech check', async () => {
                await expectSuccessfulLoad(render);
            });

            it('can cancel the visit', async () => {
                // mock transition to waiting room event
                act(() => {
                    mockStatusEvent(mockSessionClient, {
                        status: 'waitingroom',
                        timestamps: {
                            waitingroom: '2021-10-01T00:01:00Z',
                        },
                    } as Partial<VisitResponseV9>);
                });
                // opt to cancel
                await waitFor(() => {
                    expect(
                        render.getByTestId('cancel-button'),
                    ).toBeInTheDocument();
                });
                fireEvent.click(render.getByTestId('cancel-button'));
                await waitFor(() => {
                    expect(
                        render.getByTestId('waitingroom-dialog-cancel'),
                    ).toBeInTheDocument();
                });
                fireEvent.click(
                    render.getByTestId('waitingroom-dialog-cancel'),
                );
                // expect service call
                await waitFor(() => {
                    expect(
                        getVisitServiceClient().cancelVideoWithReason,
                    ).toHaveBeenCalled();
                    expect(mockNavigate).toHaveBeenCalled();
                });
            });
        });

        describe('patient can see ads if they are in configs', () => {
            let render: RenderResult;
            beforeAll(() => {
                beforeSuccessfulLoad();
                render = renderComponent(state);
            });

            afterAll(() => {
                queryClient.clear();
                cleanup();
            });

            it('can see ads', async () => {
                await waitFor(() => {
                    expect(
                        render.getByTestId('virtual-nudge-container'),
                    ).toBeInTheDocument();
                    const { innerHTML } = render.getByTestId(
                        'virtual-nudge-container',
                    );
                    expect(innerHTML).toMatchSnapshot();
                });
            });
        });

        describe('patient can see troubleshooting link', () => {
            let render: RenderResult;
            beforeAll(() => {
                beforeSuccessfulLoad();
                render = renderComponent(state);
            });

            afterAll(() => {
                queryClient.clear();
                cleanup();
            });

            it('can see link and hyperlink', async () => {
                await waitFor(() => {
                    const link = render.getByTestId('troubleshooting-link');
                    expect(link).toBeInTheDocument();
                    const anchor = link.querySelector('a');
                    expect(anchor).toHaveAttribute(
                        'href',
                        'https://support.google.com/chrome/answer/2693767',
                    );
                });
            });
        });
    });
});
