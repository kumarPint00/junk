import { atom } from 'jotai';
import { merge } from 'lodash';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';
import { featureFlagsAtom } from './featureFlags';
import { FeatureFlags } from '@utils/FeatureFlags';
import { pantryConfigAtom } from './pantryConfig';
import { waitTimeQueryAtom } from '../queries/waitTime';
import { userDetailsAtom, userIsProviderAtom } from './userDetails';

/**
 * Visit details state
 */
export const visitDetailsAtom = atom<VisitResponseV9>();

/**
 * Merge updates into the visit details atom
 */
export const setPartialVisitDetailsAtom = atom(
    null,
    (get, set, update: Partial<VisitResponseV9>) => {
        const details = get(visitDetailsAtom);
        const merged = merge({}, details, update);
        set(visitDetailsAtom, merged);
    },
);

/**
 * Various derived read only atoms
 * (NOTE: We should probably formalize all of this into the shared `VisitLogic` model at some point soon)
 */
export const isTravelingFromCallCenterAtom = atom<boolean>((get) => {
    const visitDetails = get(visitDetailsAtom);
    return visitDetails?.origin === 'agent' && !!visitDetails.traveling;
});

export const hasBeenInvisitAtom = atom<boolean>((get) => {
    const visitDetails = get(visitDetailsAtom);
    return !!visitDetails?.timestamps?.invisit;
});

export const canCancelVisitAtom = atom<boolean>((get) => {
    const featureFlags = get(featureFlagsAtom);
    const hasBeenInvisit = get(hasBeenInvisitAtom);
    return !!featureFlags?.[FeatureFlags.cancellation] && !hasBeenInvisit;
});

export const canWaitOfflineAtom = atom<boolean>((get) => {
    const featureFlags = get(featureFlagsAtom);
    const visitDetails = get(visitDetailsAtom) as VisitResponseV9;
    const pantryConfig = get(pantryConfigAtom);
    const hasBeenInvisit = get(hasBeenInvisitAtom);
    const { data: waitTimeData } = get(waitTimeQueryAtom);

    const enableManuallyEnteringWaitoffline =
        featureFlags?.[FeatureFlags.enableManuallyEnteringWaitoffline];
    const minimumWaitTimeForWaitOffline =
        pantryConfig?.minimumWaitTimeForWaitOffline ?? 600;
    const estimatedWaitTimeSeconds =
        waitTimeData?.estimatedWaitTimeSeconds ?? -1;

    const waitOfflineDisabled = !!(
        (
            !enableManuallyEnteringWaitoffline || // feature flag is off
            visitDetails?.status !== 'waitingroom' || // not in waiting room status
            hasBeenInvisit
        ) // has been in visit
    );

    return !!(
        (
            !waitOfflineDisabled && // above OR conditions met
            !visitDetails?.timestamps?.waitoffline && // has not already been in waitoffline
            minimumWaitTimeForWaitOffline <= estimatedWaitTimeSeconds
        ) // minimum wait time met
    );
});

export const visitIsAssignedToMeAtom = atom<boolean>((get) => {
    const visitDetails = get(visitDetailsAtom);
    const userDetails = get(userDetailsAtom);
    return userDetails?.id === visitDetails?.providerId;
});

export const canJoinVisitAtom = atom<boolean>((get) => {
    const userIsProvider = get(userIsProviderAtom);
    const visitIsAssignedToMe = get(visitIsAssignedToMeAtom);
    return (
        !userIsProvider || // user is not a provider
        visitIsAssignedToMe // user is the provider for this visit
    );
});

export const haveToAcceptTermsAtom = atom<boolean>((get) => {
    const requireConsentTerms =
        get(featureFlagsAtom)?.[FeatureFlags.requireConsentTerms] ?? false;
    const consentAccepted = get(visitDetailsAtom)?.acceptTerms;
    const userIsProvider = get(userIsProviderAtom);

    return requireConsentTerms && !consentAccepted && !userIsProvider;
});
