import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { atom } from 'jotai';
import { visitDetailsAtom } from '../atoms/visitDetails';

export const interactionEventAction = atom(
    null,
    (get, _set, eventName, ...params) => {
        const { visitId, patientGuid } = get(visitDetailsAtom) || {};
        V2Analytics?.interactionEvent({
            eventName,
            patient_id: patientGuid,
            visit_id: visitId,
            ...params,
        });
    },
);

export const errorEventAction = atom(
    null,
    (get, _set, eventName, ...params) => {
        const { visitId, patientGuid } = get(visitDetailsAtom) || {};
        V2Analytics?.errorEvent({
            eventName,
            patient_id: patientGuid,
            visit_id: visitId,
            ...params,
        });
    },
);
