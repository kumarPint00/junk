import { atomWithQuery } from 'jotai-tanstack-query';
import { FeatureFlags } from '@utils/FeatureFlags';
import { getBackendFacade } from '@clients/Backend/BackendFacade';
import { featureFlagsAtom } from '../atoms/featureFlags';

export const participantTypesQueryAtom = atomWithQuery((get) => {
    const releaseMultiPartyConference =
        get(featureFlagsAtom)?.[FeatureFlags.releaseMultiPartyConference] ??
        false;
    return {
        queryKey: ['participantTypes'],
        queryFn: async () => {
            const types = await getBackendFacade().getParticipantTypes();
            return types.slice().sort((a, b) => {
                if (a.name.toLocaleLowerCase() === 'other') return 1;
                if (b.name.toLocaleLowerCase() === 'other') return -1;
                return a.name.localeCompare(b.name);
            });
        },
        enabled: !!releaseMultiPartyConference,
        refetchOnMount: true,
    };
});
