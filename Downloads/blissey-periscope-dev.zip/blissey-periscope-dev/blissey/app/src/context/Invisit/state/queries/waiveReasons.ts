import { atom } from "jotai";
import { atomWithQuery } from 'jotai-tanstack-query';
import { FeatureFlags } from "@utils/FeatureFlags";
import { getVisitServiceClient } from "@clients/VisitService/VisitServiceClient";
import { featureFlagsAtom } from "../atoms/featureFlags";
import { ReasonType, VisitReason } from "../../../../data/VisitReasons";

export const reasonsQueryAtom = atomWithQuery(
    (get) => {
        const releaseConfigurableVisitReasons = get(
            featureFlagsAtom
        )?.[FeatureFlags.releaseConfigurableVisitReasons] || false;
        return {
            queryKey: ['reasons'],
            queryFn: async () => getVisitServiceClient().getReasons(),
            enabled: !!releaseConfigurableVisitReasons,
            refetchOnMount: true,
        }
    }
);

export const waiveReasonsAtom = atom<VisitReason[] | undefined>(
    (get) => {
        const { data } = get(reasonsQueryAtom);
        if (data) {
            return data.find(
                (reason) => reason.reasonType === ReasonType.WAIVE
            )?.reasons || [];
        }
        return undefined;
    }
);
