import * as React from 'react';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { Menu, Dialog, DialogContent } from '@mui/material';
import { Group } from '@mui/icons-material';
import { InCallMenuButton } from '@dexcare/video-conference';
import { ParticipantList, AddParticipant } from '@dexcare/visit-participants';
import { injectedMenuTextAtom } from '@context/Invisit/state/atoms/text';
import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { visitDetailsAtom } from '../atoms/visitDetails';
import { getBackendFacade } from '@clients/Backend/BackendFacade';
import { participantTypesQueryAtom } from '../queries/participantTypes';
import { featureFlagsAtom } from '../atoms/featureFlags';
import { FeatureFlags } from '@utils/FeatureFlags';
import { visitParticipantsAtom } from '../atoms/visitParticipants';
import {
    addParticipantAction,
    deleteParticipantAction,
} from '../actions/visitParticipants';
import {
    userActionErrorAtom,
    userActionLoadingAtom,
} from '../atoms/userAction';

export const useVisitParticipants = () => {
    /**
     * Atoms
     */
    const injectedMenuText = useAtomValue(injectedMenuTextAtom);
    const visitDetails = useAtomValue(visitDetailsAtom);
    const { data: participantTypes } = useAtomValue(participantTypesQueryAtom);
    const [visitParticipants, setVisitParticipants] = useAtom(
        visitParticipantsAtom,
    );
    const featureFlags = useAtomValue(featureFlagsAtom);
    const userActionLoading = useAtomValue(userActionLoadingAtom);
    const userActionError = useAtomValue(userActionErrorAtom);

    const { visitId } = visitDetails || {};
    const releaseMultiPartyConference =
        featureFlags?.[FeatureFlags.releaseMultiPartyConference] ?? false;

    /**
     * Actions
     */
    const addParticipant = useSetAtom(addParticipantAction);
    const deleteParticipant = useSetAtom(deleteParticipantAction);

    /**
     * Local state
     */
    const [addDialogOpen, setAddDialogOpen] = useState<boolean>(false);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const menuOpen = Boolean(anchorEl);
    // TODO: make this a config
    const maximumAdditionalParticipants = 2;
    const visitIsTerminal = [
        'done',
        'cancelled',
        'providerdeclined',
        'staffdeclined',
        'expired',
    ].includes(visitDetails?.status || '');
    const maxParticipantsAdded =
        visitParticipants?.length >= maximumAdditionalParticipants;
    const text = {
        participantTypeLabels: {
            family: 'Relative / Family Member',
            translator: 'Interpreter',
            other: 'Other',
        },
    };
    /// add disabled messaging
    let disableAdd: boolean | string = false;
    if (visitIsTerminal) {
        disableAdd = 'You cannot change invited participants after the visit is finished.';
    } else if (maxParticipantsAdded) {
        disableAdd = `You can only add ${maximumAdditionalParticipants} additional participants to this visit.`;
    } 

    /**
     * Queries
     */
    const {
        data: visitParticipantsData,
        error: visitParticipantError,
        isLoading: visitParticipantsLoading,
    } = useQuery({
        queryKey: ['getVisitParticipants', visitId || ''],
        queryFn: async ({ queryKey }) =>
            getBackendFacade().getVisitParticipants(queryKey[1]),
        enabled: releaseMultiPartyConference && !!visitId,
    });

    /**
     * Effects
     */
    useEffect(() => {
        setVisitParticipants(visitParticipantsData || []);
    }, [visitParticipantsData, setVisitParticipants]);

    /**
     * Menu toggles
     */
    const openMenu = (event: React.MouseEvent<HTMLElement>) => {
        setAnchorEl(event.currentTarget);
    };
    const closeMenu = () => {
        setAnchorEl(null);
    };

    /**
     * Video conference menu button / menus
     */
    const participantsMenuButton = (
        <div key="incall-menu-participants">
            <InCallMenuButton
                data-testid="incall-menu-participants"
                title={
                    injectedMenuText?.manageParticipantsLabel || 'Participants'
                }
                icon={<Group />}
                onClick={openMenu}
            />
            <Menu
                data-testid={'incall-menu-participants-menu'}
                anchorEl={anchorEl}
                open={menuOpen}
                onClose={closeMenu}
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                }}
                transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                }}
            >
                <ParticipantList
                    participants={visitParticipants || []}
                    loading={visitParticipantsLoading}
                    error={
                        visitParticipantError
                            ? 'Could not load participants'
                            : ''
                    }
                    onAdd={() => setAddDialogOpen(true)}
                    onDelete={(participant) =>
                        void deleteParticipant(participant, true)
                    }
                    onCancel={() => closeMenu()}
                    disableAdd={disableAdd}
                    disableDelete={visitIsTerminal}
                    text={text}
                />
            </Menu>
            <Dialog
                open={addDialogOpen}
                data-testid="incall-menu-participants-adddialog"
            >
                <DialogContent>
                    <AddParticipant
                        participantTypes={participantTypes || []}
                        onInvite={(formData) =>
                            void addParticipant(formData, () =>
                                setAddDialogOpen(false),
                            )
                        }
                        error={userActionError}
                        loading={userActionLoading}
                        onCancel={() => setAddDialogOpen(false)}
                        enableSms={true}
                        text={text}
                    />
                </DialogContent>
            </Dialog>
        </div>
    );

    return { participantsMenuButton, visitParticipants };
};
