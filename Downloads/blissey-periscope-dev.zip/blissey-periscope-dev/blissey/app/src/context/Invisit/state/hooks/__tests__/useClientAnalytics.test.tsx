// useClientAnalytics.test.tsx
import React from 'react';
import { renderHook } from '@testing-library/react';
import { useClientAnalytics } from '../useClientAnalytics';
import { videoConferenceClientAtom } from '../../atoms/clients';
import { visitDetailsAtom } from '../../atoms/visitDetails';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { ConferenceEvents } from '@dexcare/conference-client';
import { Provider, createStore } from 'jotai';
import { vi } from 'vitest';

// start of code written by AI
const mockVideoConferenceClient = {
    on: vi.fn(),
    off: vi.fn(),
};

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        interactionEvent: vi.fn(),
    },
}));

describe.skip('useClientAnalytics', () => {
    const visitId = 'visit-123';
    const store = createStore();
    store.set(videoConferenceClientAtom, mockVideoConferenceClient as never);
    store.set(visitDetailsAtom, { visitId } as never);

    const wrapper = ({ children }: { children: React.ReactNode }) => (
        <Provider store={store}>{children}</Provider>
    );

    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('registers and unregisters event listeners on mount/unmount', () => {
        const onSpy = vi.spyOn(mockVideoConferenceClient, 'on');
        const offSpy = vi.spyOn(mockVideoConferenceClient, 'off');

        const { unmount } = renderHook(() => useClientAnalytics(), { wrapper });

        const registeredEvents: string[] = onSpy.mock.calls.map(
            (call) => call[0] as string,
        );

        for (const event of registeredEvents) {
            expect(onSpy).toHaveBeenCalledWith(event, expect.any(Function));
            expect(offSpy).toHaveBeenCalledWith(event, expect.any(Function));
        }

        unmount();

        for (const event of registeredEvents) {
            expect(offSpy).toHaveBeenCalledWith(event, expect.any(Function));
        }
    });

    it('sends analytics event for handled conference event', () => {
        const handlers = new Map<string, (event: unknown) => void>();

        mockVideoConferenceClient.on.mockImplementation(
            (eventType: string, cb: (event: unknown) => void) => {
                handlers.set(eventType, cb);
            },
        );

        renderHook(() => useClientAnalytics(), { wrapper });

        const testEvent = {
            type: ConferenceEvents.CAMERA_ENABLED,
            data: { some: 'info' },
        };

        handlers.get(ConferenceEvents.CAMERA_ENABLED)?.(testEvent);

        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'camera_on',
            visit_id: visitId,
            data: { some: 'info' },
        });
    });

    it('does not crash if event data is missing', () => {
        const handlers = new Map<string, (event: unknown) => void>();

        mockVideoConferenceClient.on.mockImplementation(
            (eventType: string, cb: (event: unknown) => void) => {
                handlers.set(eventType, cb);
            },
        );

        renderHook(() => useClientAnalytics(), { wrapper });

        handlers.get(ConferenceEvents.CONNECTED)?.({
            type: ConferenceEvents.CONNECTED,
        });

        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'client_connected',
            visit_id: visitId,
            data: {},
        });
    });
});
// end of code written by AI
