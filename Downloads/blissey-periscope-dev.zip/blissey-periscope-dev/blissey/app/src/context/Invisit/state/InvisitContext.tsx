import React, { useEffect } from 'react';
import QueryString from 'qs';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { userDetailsAtom, userIsProviderAtom } from './atoms/userDetails';
import { useSelector } from 'react-redux';
import { Store } from '@redux/modules';
import { useLocation, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getVisitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { visitDetailsAtom } from './atoms/visitDetails';
import { SuspenseContainer } from '@dexcare/material';
import { getTokboxTokens } from '@services/getTokBoxTokens';
import { NotFoundModule } from '@modules/NotFound/NotFoundModule';
import { useSetText } from './hooks/useSetText';
import { appConfigAtom } from './atoms/appConfig';
import { config } from '@dexcare/circus-jupiter';
import { Configuration } from 'types/configuration';
import { useClientSignals } from './hooks/useClientSignals';
import { useClientAnalytics } from './hooks/useClientAnalytics';
import { PantryConfig, getPantryConfig } from '@clients/Pantry/getPantryConfig';
import { pantryConfigAtom } from './atoms/pantryConfig';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';
import { featureFlagsAtom } from './atoms/featureFlags';
import { getFeatureFlags } from '@utils/FeatureFlags';
import { useVisitStatusEffects } from './hooks/useVisitStatusEffects';
import { clientsInitializedAtom, initializeClientsAtom } from './atoms/clients';

const Context: React.FunctionComponent<React.PropsWithChildren> = ({
    children,
}) => {
    /**
     * Url params
     */
    // get visit id from url
    const { visitId } = useParams() as unknown as { visitId: string };
    // get brand from url (this might need some weird defaulting stuff from config?)
    const { search } = useLocation() as { search: string };
    let { brand } = QueryString.parse(search, { ignoreQueryPrefix: true }) as {
        brand: string;
    };
    if (brand) {
        brand = brand.toLowerCase();
    }

    /**
     * Atoms
     */
    const clientsInitialized = useAtomValue(clientsInitializedAtom);
    const [visitDetails, setVisitDetails] = useAtom(visitDetailsAtom);
    const [userDetails, setUserDetails] = useAtom(userDetailsAtom);
    const userIsProvider = useAtomValue(userIsProviderAtom);
    // clients
    const initializeClients = useSetAtom(initializeClientsAtom);
    // configs
    const setAppConfig = useSetAtom(appConfigAtom);
    const setFeatureFlags = useSetAtom(featureFlagsAtom);
    const setPantryConfig = useSetAtom(pantryConfigAtom);

    /**
     * From redux
     */
    const userDetailsRedux = useSelector(
        (state: Store['All']) => state.user.userDetails,
    );

    /**
     * Queries
     */
    // load visit details
    const { data: visitDetailsData, error: visitDetailsError } = useQuery({
        queryKey: ['getVisitSummary', visitId],
        queryFn: async ({ queryKey }) =>
            getVisitServiceClient().getVisitSummary(queryKey[1], false),
        enabled: !!visitId && !!brand,
    });

    // token lookup depends on visit / user details
    const { data: tokboxTokenData, error: tokboxTokenError } = useQuery({
        queryKey: [
            'getTokboxTokens',
            userIsProvider,
            visitDetailsData?.visitId,
            userDetails?.id,
            visitDetailsData?.tokBoxVisit?.videoConferenceSession.sessionId,
            visitDetailsData?.tokBoxVisit?.waitingRoomSession.sessionId,
        ],
        queryFn: async ({ queryKey }) =>
            getTokboxTokens({
                userIsProvider: queryKey[1] as boolean,
                visitId: queryKey[2] as string,
                userId: queryKey[3] as string,
                visitSessionId: queryKey[4] as string,
                waitingRoomSessionId: queryKey[5] as string,
            }),
        enabled:
            !!visitDetailsData && !!userDetails && userIsProvider !== undefined,
    });

    // load pantry config
    const { data: pantryConfigData } = useQuery({
        queryKey: ['getPantryConfig'],
        queryFn: async () => {
            return (await getPantryConfig()) || {};
        },
    });

    /**
     * Effects
     */
    // transfer user details to atom from redux
    useEffect(() => {
        setUserDetails(userDetailsRedux);
    }, [userDetailsRedux, setUserDetails]);

    // set visit details from retrieved data
    useEffect(() => {
        setVisitDetails(visitDetailsData as VisitResponseV9);
    }, [visitDetailsData, setVisitDetails]);

    // set up vonage session objects
    // (important to only do this once when all data is loaded)
    useEffect(() => {
        if (
            tokboxTokenData &&
            visitDetailsData?.tokBoxVisit &&
            userDetailsRedux &&
            !clientsInitialized
        ) {
            // initialize the conference clients
            initializeClients({
                video: {
                    apiKey: visitDetailsData.tokBoxVisit.apiKey,
                    sessionId:
                        visitDetailsData.tokBoxVisit.videoConferenceSession
                            .sessionId,
                    token: tokboxTokenData.visitToken,
                    displayName: userDetailsRedux.displayName,
                },
                waitingRoom: {
                    apiKey: visitDetailsData.tokBoxVisit.apiKey,
                    sessionId:
                        visitDetailsData.tokBoxVisit.waitingRoomSession
                            .sessionId,
                    token: tokboxTokenData.waitingRoomToken,
                    displayName: userDetailsRedux.displayName,
                },
            });
        }
    }, [
        tokboxTokenData,
        visitDetailsData,
        userDetailsRedux,
        clientsInitialized,
        initializeClients,
    ]);

    // set app config
    useEffect(() => {
        setAppConfig((config as Configuration).getConfig());
    }, [setAppConfig]);

    // set pantry config
    useEffect(() => {
        if (pantryConfigData) {
            setPantryConfig(pantryConfigData as PantryConfig);
        }
    }, [pantryConfigData, setPantryConfig]);

    // set feature flags
    useEffect(() => {
        setFeatureFlags(getFeatureFlags());
    }, [setFeatureFlags]);

    /**
     * State hooks
     */
    // set up translated / formatted text
    useSetText();
    // set up conference signal listeners
    useClientSignals();
    // status redirects
    useVisitStatusEffects();
    // analytics for signal events
    useClientAnalytics();

    /**
     * Render
     */
    const error = visitDetailsError || tokboxTokenError;

    // if no brand or error, show "not found"
    if (!brand || error)
        return (
            <NotFoundModule
                isTokBoxTokenError={!!tokboxTokenError}
                invalidVisitReason={
                    visitDetailsError && visitDetailsError instanceof Error
                        ? visitDetailsError.message
                        : null
                }
                tokboxTokenErrorMessage={
                    tokboxTokenError && tokboxTokenError instanceof Error
                        ? tokboxTokenError.message
                        : ''
                }
                visitId={visitId}
                isProvider={!!userIsProvider}
            />
        );

    // if loading required data show spinning wheel of false hope
    const loadingData = !userDetails || !visitDetails || !clientsInitialized;
    if (loadingData) return <SuspenseContainer />;

    // render our visit container
    return <div>{children}</div>;
};

export const InvisitContext: React.FunctionComponent<
    React.PropsWithChildren
> = ({ children }) => {
    return <Context>{children}</Context>;
};
