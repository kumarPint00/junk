import { useCallback, useEffect } from 'react';
import { useAtomValue } from 'jotai';
import { omit } from 'lodash';
import { ConferenceEvent, ConferenceEventData, ConferenceEvents } from '@dexcare/conference-client';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { videoChatClientAtom, videoConferenceClientAtom, waitingRoomChatClientAtom } from '../atoms/clients';
import { visitDetailsAtom } from '../atoms/visitDetails';
import { Logger } from '@utils/index';
import { userDetailsAtom } from '../atoms/userDetails';

const videoSessionEvents = [
    ConferenceEvents.SESSION_CONNECTING,
    ConferenceEvents.SESSION_CONNECTED,
    ConferenceEvents.SESSION_DISCONNECTING,
    ConferenceEvents.SESSION_DISCONNECTED,
    ConferenceEvents.ERROR,
    ConferenceEvents.CONNECT_ERROR,
];

const videoEvents = [
    ConferenceEvents.CONNECTING,
    ConferenceEvents.CONNECTED,
    ConferenceEvents.CONNECT_ERROR,
    ConferenceEvents.JOIN_ERROR,
    ConferenceEvents.ERROR,
    ConferenceEvents.CAMERA_ENABLED,
    ConferenceEvents.CAMERA_DISABLED,
    ConferenceEvents.AUDIO_ENABLED,
    ConferenceEvents.AUDIO_DISABLED,
    ConferenceEvents.PARTICIPANT_CONNECTED,
    ConferenceEvents.PARTICIPANT_DISCONNECTED,
    ConferenceEvents.PARTICIPANT_JOINED,
    ConferenceEvents.PARTICIPANT_LEFT,
    ConferenceEvents.CAMERA_BLUR_ENABLED,
    ConferenceEvents.CAMERA_BLUR_DISABLED,
    ConferenceEvents.AUDIO_DEVICE_CHANGED,
    ConferenceEvents.VIDEO_DEVICE_CHANGED
];

const videoChatEvents = [
    ConferenceEvents.CONNECTING,
    ConferenceEvents.CONNECTED,
    ConferenceEvents.CONNECT_ERROR,
    ConferenceEvents.ERROR,
    ConferenceEvents.RECEIVED_CHAT_MESSAGE,
    ConferenceEvents.SENT_CHAT_MESSAGE,
];

const waitingroomSessionEvents = [
    ConferenceEvents.SESSION_CONNECTING,
    ConferenceEvents.SESSION_CONNECTED,
    ConferenceEvents.SESSION_DISCONNECTING,
    ConferenceEvents.SESSION_DISCONNECTED,
    ConferenceEvents.ERROR,
    ConferenceEvents.CONNECT_ERROR,
];

const waitingroomChatEvents = [
    ConferenceEvents.CONNECTING,
    ConferenceEvents.CONNECTED,
    ConferenceEvents.CONNECT_ERROR,
    ConferenceEvents.ERROR,
    ConferenceEvents.RECEIVED_CHAT_MESSAGE,
    ConferenceEvents.SENT_CHAT_MESSAGE,
];

/**
 * Scrub any user entered / potentially sensitive info from event data
 * @returns 
 */
export const scrubChat = (data?: ConferenceEventData) => {
    return omit(data, [
        'chatMessage.message',
        'signalData'
    ]);
}

/**
 * Sanitize event data for logging / analytics
 * @param event 
 * @returns 
 */
export const loggableEventData = (event: ConferenceEvent) => {
    const eventMessage = event.message;
    const eventType = event.type;
    const eventData = scrubChat(event.data);
    return {
        eventMessage,
        eventType,
        eventData,
    }
}

export const useClientAnalytics = () => {
    const videoConferenceClient = useAtomValue(videoConferenceClientAtom);
    const videoChatClient = useAtomValue(videoChatClientAtom);
    const waitingRoomChatClient = useAtomValue(waitingRoomChatClientAtom);
    const visitDetails = useAtomValue(visitDetailsAtom);
    const userDetails = useAtomValue(userDetailsAtom);

    const onConferenceEvent = useCallback((event: ConferenceEvent, source: string) => {
        const {
            eventMessage,
            eventType,
            eventData,
        } = loggableEventData(event);
        
        switch(event.type) {
            case ConferenceEvents.CONNECT_ERROR:
            case ConferenceEvents.JOIN_ERROR:
                Logger.error(
                    {
                        eventType,
                        eventData,
                        visitId: visitDetails?.visitId,
                        userId: userDetails?.id,
                    },
                    eventMessage,
                );
                console.error(`${source} error`, { event })
                break;
            case ConferenceEvents.ERROR:
                Logger.warn(
                    {
                        eventType,
                        eventData,
                        visitId: visitDetails?.visitId,
                        userId: userDetails?.id,
                    },
                    eventMessage,
                );
                console.warn(`${source} error`, { event })
                break;
            default:
                V2Analytics?.interactionEvent({
                    eventName: `${source}_${eventType}`,
                    visit_id: visitDetails?.visitId,
                    data: eventData || {},
                });
                Logger.debug(
                    {
                        eventType,
                        eventData,
                        visitId: visitDetails?.visitId,
                        userId: userDetails?.id,
                    },
                    eventMessage,
                );
                console.log(`${source} event`, { event })
            break;
        }
    }, []);

    const handleVideoSessionEvent = useCallback((event: ConferenceEvent) => {
        onConferenceEvent(event, 'video_session');
    }, []);

    const handleVideoEvent = useCallback((event: ConferenceEvent) => {
        onConferenceEvent(event, 'video_conference');
    }, []);

    const handleVideoChatEvent = useCallback((event: ConferenceEvent) => {
        onConferenceEvent(event, 'video_chat');
    }, []);

    const handleWaitingRoomSessionEvent = useCallback((event: ConferenceEvent) => {
        onConferenceEvent(event, 'waitingroom_session');
    }, []);

    const handleWaitingRoomChatEvent = useCallback((event: ConferenceEvent) => {
        onConferenceEvent(event, 'waitingroom_chat');
    }, []);

    const off = useCallback(() => {
        videoSessionEvents.forEach((e) => {
            videoConferenceClient.sessionClient.off(e, handleVideoSessionEvent);
        });
        videoEvents.forEach((e) => {
            videoConferenceClient.off(e, handleVideoEvent);
        });
        videoChatEvents.forEach((e) => {
            videoChatClient.off(e, handleVideoChatEvent);
        });
        waitingroomSessionEvents.forEach((e) => {
            waitingRoomChatClient.sessionClient.off(e, handleWaitingRoomSessionEvent);
        });
        waitingroomChatEvents.forEach((e) => {
            waitingRoomChatClient.off(e, handleWaitingRoomChatEvent);
        });
    }, [
        videoConferenceClient,
        videoChatClient,
        waitingRoomChatClient,
        handleVideoSessionEvent,
        handleVideoEvent,
        handleVideoChatEvent,
        handleWaitingRoomSessionEvent,
        handleWaitingRoomChatEvent,
    ]);

    const on = useCallback(() => {
        off();
        videoSessionEvents.forEach((e) => {
            videoConferenceClient.sessionClient.on(e, handleVideoSessionEvent);
        });
        videoEvents.forEach((e) => {
            videoConferenceClient.on(e, handleVideoEvent);
        });
        videoChatEvents.forEach((e) => {
            videoChatClient.on(e, handleVideoChatEvent);
        });
        waitingroomSessionEvents.forEach((e) => {
            waitingRoomChatClient.sessionClient.on(e, handleWaitingRoomSessionEvent);
        });
        waitingroomChatEvents.forEach((e) => {
            waitingRoomChatClient.on(e, handleWaitingRoomChatEvent);
        });
    }, [
        videoConferenceClient,
        videoChatClient,
        waitingRoomChatClient,
        handleVideoSessionEvent,
        handleVideoEvent,
        handleVideoChatEvent,
        handleWaitingRoomSessionEvent,
        handleWaitingRoomChatEvent,
    ]);

    useEffect(() => {
        on();
        return () => {
            off();
        }
    }, [
        on,
        off,
    ]);
};
