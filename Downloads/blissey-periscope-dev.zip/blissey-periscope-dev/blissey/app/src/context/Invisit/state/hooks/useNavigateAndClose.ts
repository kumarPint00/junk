import { useAtomValue } from "jotai";
import { sessionClientAtom, waitingRoomChatClientAtom } from "../atoms/clients";
import { To, useNavigate } from "react-router-dom";

export const useNavigateAndClose = () => {
    const navigate = useNavigate();

    const videoSessionClient = useAtomValue(sessionClientAtom);
    const waitingRoomChatClient = useAtomValue(waitingRoomChatClientAtom);

    const navigateAndClose = (to: To) => {
        void Promise.all([
            videoSessionClient.disconnect(),
            waitingRoomChatClient.disconnect()
        ]);
        navigate(to);
    };

    return navigateAndClose;
}