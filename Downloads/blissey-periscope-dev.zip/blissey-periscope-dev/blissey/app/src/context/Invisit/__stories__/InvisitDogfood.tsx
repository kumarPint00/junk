/* eslint-disable @typescript-eslint/no-unsafe-assignment, react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import * as Redux from 'redux';
import { Provider, useStore } from 'react-redux';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom';
import {
    Button,
    TextField,
    Typography,
    RadioGroup,
    Radio,
    FormControlLabel,
    Checkbox,
} from '@mui/material';
import styles from './InvisitDogfood.module.css';
import { UserDetails } from '../../../types/UserDetails';
import { Store, rootReducer } from '@redux/modules';
import { queryClientOptions } from '../../../reactQuery';
import {
    mockBrand,
    mockVisitId,
} from '../../../__mocks__/services/responses/mockGetVisitSummary';
import { InvisitRoute } from '../InvisitRoute';
import { mockUserId } from '../../../__mocks__/services/responses/mockGetUser';
import { useInvisitMocks } from './useInvisitMocks';
import { config } from '@dexcare/circus-jupiter';
import defaultConfig from '../../../../../server/config/config.json';
import { useConferenceEvents } from './useConferenceEvents';

import dogimage from './dogDoctor.jpg';

const defaultAppConfig = {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
    ...defaultConfig.app,
    // add your feature flags here
    features: {
        'enable-manually-entering-waitoffline': true,
        'waiting-room-video': true,
        'enable-patient-cancellation-with-reason': {
            video: true,
            phone: false,
        },
        cancellation: true,
        'end-and-transfer-visit': true,
        'enable-visit-modality-conversion': true,
        'enable-visit-modality-conversion-for-travel-patient-call-center': true,
        'require-consent-terms': true,
        'release-multi-party-conference': true,
    },
    externalIngress: 'frosh.dex.care',
};

interface InvisitProps {
    apiKey: string;
    videoSessionId: string;
    videoToken: string;
    userRole: string;
    waitingRoomSessionId?: string;
    waitingRoomToken?: string;
    acceptTerms?: boolean;
    simulateInCallCache?: boolean;
    simulateWaitingRoomCache?: boolean;
}

const EndRoute = () => {
    const location = useLocation();
    const store = useStore();
    const state = store.getState();
    return (
        <div style={{ padding: '20px' }}>
            <div>{`You have arrived at pathname: ${location.pathname} with query: ${location.search}`}</div>
            <div>Heres all the stuff still in redux:</div>
            <pre>{JSON.stringify(state, null, 2)}</pre>
        </div>
    );
};

const InvisitWrappper = (props: InvisitProps) => {
    const [mockState, setMockState] = useState<Partial<Store['All']>>({});
    const [mockStore, setMockStore] = useState();
    const [queryClient] = useState(
        () => new QueryClient({ ...queryClientOptions }),
    );

    useEffect(() => {
        if (mockState) {
            // cast to any to avoid exhaustive Store typing in story environment
            setMockStore(
                Redux.createStore(
                    rootReducer as any,
                    mockState as any,
                ) as any,
            );
        }
    }, [mockState]);

    useEffect(() => {
        setMockState({
            user: {
                userDetails: {
                    id: mockUserId,
                    roles: [props.userRole],
                    // this needs to come from the tokbox token eventually
                    displayName: `Dog ${
                        props.userRole === 'telehealth_patient'
                            ? 'Patient'
                            : 'Doctor'
                    }`,
                } as UserDetails,
            },
        });
    }, []);

    useInvisitMocks({
        userRole: props.userRole,
        apiKey: props.apiKey,
        videoSessionId: props.videoSessionId,
        videoToken: props.videoToken,
        waitingRoomSessionId: props.waitingRoomSessionId,
        waitingRoomToken: props.waitingRoomToken,
        acceptTerms: props.acceptTerms,
        simulateInCallCache: props.simulateInCallCache,
        simulateWaitingRoomCache: props.simulateWaitingRoomCache,
    });

    useConferenceEvents({
        userRole: props.userRole,
    });

    if (!mockStore) return <div>loading...</div>;

    return (
        <Provider store={mockStore}>
            <QueryClientProvider client={queryClient}>
                <MemoryRouter
                    initialEntries={[
                        `/visit/${mockVisitId}?brand=${mockBrand}`,
                    ]}
                >
                    <Routes>
                        <Route
                            path="/visit/:visitId"
                            Component={InvisitRoute}
                        />
                        <Route path="*" Component={EndRoute} />
                    </Routes>
                </MemoryRouter>
            </QueryClientProvider>
        </Provider>
    );
};

export const InvisitDogfood = () => {
    const [apiKey, setApiKey] = React.useState('');
    const [videoSessionId, setVideoSessionId] = React.useState('');
    const [videoToken, setVideoToken] = React.useState('');
    const [userRole, setUserRole] = React.useState('telehealth_patient');
    const [waitingRoomSessionId, setWaitingRoomSessionId] = React.useState<
        string | undefined
    >();
    const [waitingRoomToken, setWaitingRoomToken] = React.useState<
        string | undefined
    >();
    const [dogFoodState, setDogfoodState] = React.useState('tokenInput');
    const [acceptTerms, setAcceptTerms] = useState(false);
    const [simulateWaitingRoomCache, setSimulateWaitingRoomCache] = useState(false);
    const [simulateInCallCache, setSimulateIncallCache] = useState(false);

    // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-unsafe-call
    config.setConfig(defaultAppConfig as never);

    return (
        <div>
            {dogFoodState === 'tokenInput' && (
                <div className={styles.formContainer}>
                    <div className={styles.header}>
                        <img
                            style={{ width: '25%' }}
                            alt="A dog doctor in a video conference"
                            src={dogimage}
                        />
                        <div>
                            <Typography variant="h6">
                                InvisitContainer Dogfood
                            </Typography>
                            <Typography>{`
                                Enter in valid vonage api key, session and token and whether you want to be the dog doctor or the dog patient.
                                Here we should be able to play out the entire visit conference experience without running blissey or creating visits.
                            `}</Typography>
                        </div>
                    </div>
                    <div className={styles.inputContainer}>
                        <TextField
                            id="apiKey"
                            label="API Key"
                            name="apiKey"
                            helperText="Enter a valid api key"
                            value={apiKey}
                            onChange={(e) => setApiKey(e.target.value)}
                        />
                        <TextField
                            id="videoSessionId"
                            label="Video Session Id"
                            name="videoSessionId"
                            helperText="Enter a valid video session id"
                            value={videoSessionId}
                            onChange={(e) => setVideoSessionId(e.target.value)}
                        />
                        <TextField
                            id="videoToken"
                            label="Video Token"
                            name="videoToken"
                            helperText="Enter a valid publisher token to join the conference"
                            value={videoToken}
                            onChange={(e) => setVideoToken(e.target.value)}
                        />
                        <RadioGroup
                            name="userRole"
                            value={userRole}
                            onChange={(e) => setUserRole(e.target.value)}
                        >
                            <FormControlLabel
                                value="telehealth_patient"
                                control={<Radio />}
                                label="Patient"
                            />
                            <FormControlLabel
                                value="telehealth_provider"
                                control={<Radio />}
                                label="Provider"
                            />
                        </RadioGroup>
                        <FormControlLabel
                            label="Patient accepted visit terms"
                            control={
                                <Checkbox
                                    checked={acceptTerms}
                                    onChange={(e) =>
                                        setAcceptTerms(e.target.checked)
                                    }
                                />
                            }
                        />
                        <FormControlLabel
                            label="Simulate cached in call messages"
                            control={
                                <Checkbox
                                    checked={simulateInCallCache}
                                    onChange={(e) =>
                                        setSimulateIncallCache(e.target.checked)
                                    }
                                />
                            }
                        />
                        {userRole === 'telehealth_patient' && (
                            <div className={styles.inputContainer}>
                                <Typography>
                                    As a patient you can chat with staff in a
                                    separate (vonage) session.
                                </Typography>
                                <TextField
                                    id="waitingRoomSessionId"
                                    label="Waiting Room Session Id"
                                    name="waitingRoomSessionId"
                                    helperText="Enter a valid waiting room session id"
                                    value={waitingRoomSessionId}
                                    onChange={(e) =>
                                        setWaitingRoomSessionId(e.target.value)
                                    }
                                />
                                <TextField
                                    id="waitingRoomToken"
                                    label="Waiting Room Token"
                                    name="waitingRoomToken"
                                    helperText="Enter a valid waiting room token"
                                    value={waitingRoomToken}
                                    onChange={(e) =>
                                        setWaitingRoomToken(e.target.value)
                                    }
                                />
                                <FormControlLabel
                                    label="Simulate cached waiting room messages"
                                    control={
                                        <Checkbox
                                            checked={simulateWaitingRoomCache}
                                            onChange={(e) =>
                                                setSimulateWaitingRoomCache(e.target.checked)
                                            }
                                        />
                                    }
                                />
                            </div>
                        )}
                    </div>
                    <div className={styles.goButtonContainer}>
                        <Button
                            color="primary"
                            variant="contained"
                            disabled={!apiKey || !videoSessionId || !videoToken}
                            onClick={() => setDogfoodState('conference')}
                        >
                            Eat Dogfood
                        </Button>
                    </div>
                </div>
            )}
            {dogFoodState === 'conference' && (
                <InvisitWrappper
                    apiKey={apiKey}
                    videoSessionId={videoSessionId}
                    videoToken={videoToken}
                    userRole={userRole}
                    waitingRoomSessionId={waitingRoomSessionId}
                    waitingRoomToken={waitingRoomToken}
                    acceptTerms={acceptTerms}
                    simulateInCallCache={simulateInCallCache}
                    simulateWaitingRoomCache={simulateWaitingRoomCache}
                />
            )}
        </div>
    );
};
