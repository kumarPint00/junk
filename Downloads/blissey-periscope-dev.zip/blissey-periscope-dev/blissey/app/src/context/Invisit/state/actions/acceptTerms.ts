import { atom } from 'jotai';
import { userActionLoadingAtom } from '../atoms/userAction';
import { getVisitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { visitDetailsAtom } from '../atoms/visitDetails';
import merge from 'lodash/merge';

export const consentAcceptedErrorMessageAtom = atom<string | null>(null);

export const acceptTermsAction = atom(null, async (get, set) => {
    const visitId = get(visitDetailsAtom)?.visitId ?? '';

    const handlePatientAcceptTerms = async () => {
        set(userActionLoadingAtom, true);
        return await getVisitServiceClient()
            .acceptConsentTerms(visitId)
            .then(() => {
                const merged = merge({}, get(visitDetailsAtom), {
                    acceptTerms: true,
                });
                set(visitDetailsAtom, merged);
            })
            .catch((err) => {
                set(
                    consentAcceptedErrorMessageAtom,
                    (err as Error).message ?? 'Error accepting consent terms.',
                );
                const merged = merge({}, get(visitDetailsAtom), {
                    acceptTerms: false,
                });
                set(visitDetailsAtom, merged);
            })
            .finally(() => {
                set(userActionLoadingAtom, false);
            });
    };

    return await handlePatientAcceptTerms();
});
