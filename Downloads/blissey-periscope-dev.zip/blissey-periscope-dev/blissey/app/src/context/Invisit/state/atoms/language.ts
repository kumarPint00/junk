import { atom } from 'jotai';
import i18next from 'i18next';

export const i18nAtom = atom<typeof i18next>(i18next);
export const languageAtom = atom<string>('en-US');
