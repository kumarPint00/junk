import { atom } from 'jotai';
import { VideoConferenceText } from '@dexcare/video-conference';
import {
    ConferenceStageText,
    TechCheckHeaderText,
    FooterTextAndLinks,
} from '@dexcare/conference-stage';
import { IAdvertisement } from '@dexcare/circus-saturn';
import { TroubleshootingTextAndLink } from '@dexcare/conference-stage';
import { TextChatText } from '@dexcare/text-chat';

export interface InjectedMenuText {
    toggleChatLabel?: string;
    toggleFullscreenLabel?: string;
    manageParticipantsLabel?: string;
    chatButtonCaption?: string;
}

export interface WaitOfflineText {
    waitOfflineClickText?: string;
    waitOfflineButtonText?: string;
    dialogTitleText?: string;
    dialogContentText?: string;
    buttonAcceptText?: string;
    buttonDeclineText?: string;
    enterWaitOfflineSuccessfulText?: string;
    enterWaitOfflineFailureText?: string;
    closeText?: string;
}

export interface EndVisitText {
    endVisitLabel?: string;
    labelForCompleteVisit?: string;
    labelForConvertModality?: string;
    labelForModalityConversionReason?: string;
    labelForTransferVisit?: string;
    labelForWaiveVisit?: string;
    labelForWaiveReason?: string;
}

export interface LeaveVisitText {
    callEndLabel?: string;
    callEndPrompt?: string;
    callEndConfirm?: string;
    callEndCancel?: string;
}

export interface CancelText {
    dialogTitleText?: string;
    dialogContentText?: string;
    buttonStayText?: string;
    buttonLeaveText?: string;
    buttonAcceptText?: string;
    buttonDeclineText?: string;
    reasonsForCancel?: { label: string; value: string }[];
    cancelVisitButtonText?: string;
    headerText?: string;
    bodyText?: string;
    instructionText?: string;
    reasonText?: string;
    label?: string;
}

export interface VirtualNudgeText {
    advertisements: IAdvertisement[];
    header: string;
}

export interface ConsentFormText {
    headerText?: string;
    consentHeaderText?: string;
    consentInstructionText?: string;
    consentCheckboxLabelText?: string;
    consentButtonText?: string;
    consentCancelLinkText?: string;
    dismissErrorModalText?: string;
}

export const videoConferenceTextAtom = atom<VideoConferenceText>({});

export const techcheckHeaderTextAtom = atom<TechCheckHeaderText>({});

export const injectedMenuTextAtom = atom<InjectedMenuText>({});

export const conferenceStageTextAtom = atom<ConferenceStageText>({});

export const footerTextAndLinkAtom = atom<FooterTextAndLinks>({});

export const waitOfflineTextAtom = atom<WaitOfflineText>({});

export const endVisitTextAtom = atom<EndVisitText>({});

export const leaveVisitTextAtom = atom<LeaveVisitText>({});

export const cancelTextAtom = atom<CancelText>({});

export const virtualNudgeTextAtom = atom<VirtualNudgeText>({
    advertisements: [],
    header: '',
});

export const consentFormTextAtom = atom<ConsentFormText>({});

export const troubleshootingTextAndLinkAtom = atom<TroubleshootingTextAndLink>(
    {},
);

export const textChatTextAtom = atom<TextChatText>({});
