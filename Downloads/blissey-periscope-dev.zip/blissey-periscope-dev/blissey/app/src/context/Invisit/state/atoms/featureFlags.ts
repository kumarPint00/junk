import { FeatureFlagsValues } from '@utils/FeatureFlags';
import { atom } from 'jotai';

export const featureFlagsAtom = atom<FeatureFlagsValues>();