import { atom } from "jotai";

export interface ModalMessage {
    message: string;
    dismissLabel?: string;
}

export const modalMessageAtom = atom<ModalMessage>();