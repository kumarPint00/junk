import { atom } from 'jotai';
import { PantryConfig } from '@clients/Pantry/getPantryConfig';

export const pantryConfigAtom = atom<PantryConfig>();
