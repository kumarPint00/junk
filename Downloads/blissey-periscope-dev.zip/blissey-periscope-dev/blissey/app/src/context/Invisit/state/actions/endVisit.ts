import { atom } from "jotai";
import { 
    PostVisitActionChange,
    PostVisitActions,
    SelectQueueOrProviderChangeType
} from "@dexcare/circus-saturn";
import { visitDetailsAtom } from "../atoms/visitDetails";
import { userDetailsAtom, userIsProviderAtom } from "../atoms/userDetails";
import { VisitResponseV9 } from "@clients/VisitService/VisitInterfaces";
import { UserDetails } from "types/UserDetails";
import { getVisitServiceClient } from "@clients/VisitService/VisitServiceClient";
import { getBackendFacade } from "@clients/Backend/BackendFacade";
import { interactionEventAction } from "./analytics";
import { videoConferenceClientAtom } from "../atoms/clients";
import { userActionErrorAtom, userActionLoadingAtom } from "../atoms/userAction";

export const endVisitAction = atom(
    null,
    async (get, set, action: PostVisitActionChange) => {
        /**
         * Atoms
         */
        const conferenceClient = get(videoConferenceClientAtom);
        const visitDetails = get(visitDetailsAtom) as VisitResponseV9;
        const userDetails = get(userDetailsAtom) as UserDetails;
        const userIsProvider = get(userIsProviderAtom);

        // ensure user is provider (patients cant end visits)
        if(!userIsProvider) {
            return;
        }

        /**
         * Action extraction
         */
        const {
            visitId
        } = visitDetails;
        const {
            id: currentProviderId,
        } = userDetails;
        const {
            selectedQueueOrProvider: {
                providerId,
                type: transferType,
            } = {},
            selectedWaiveReason,
            selectedModalityConversionReason,
        } = action;

        // ensure user is provider
        if(!userIsProvider) {
            set(userActionErrorAtom, 'Only providers can end a visit');
            set(userActionLoadingAtom, false);
            return;
        }

        // indicate loading / clear previous errors
        set(userActionLoadingAtom, true);
        set(userActionErrorAtom, undefined);

        // trransfer actions
        const transfers = {
            [SelectQueueOrProviderChangeType.Queue]: async () => {
                set(interactionEventAction, 'unassign_visit');
                return getBackendFacade().transferBackToQueue(
                    visitId,
                    currentProviderId,
                )
            },
            [SelectQueueOrProviderChangeType.Provider]: async () => {
                if (!providerId) {
                    throw new Error('Please select a provider.');
                }
                set(interactionEventAction, 'transfer_visit', providerId);
                return getBackendFacade().transferToAnotherProvider(
                    visitId,
                    providerId,
                    currentProviderId,
                )
            }
        }

        // actions
        const actions = {
            [PostVisitActions.Complete]: async () => {
                set(interactionEventAction, 'charge_visit');
                return getVisitServiceClient().chargeVisit(
                    visitDetails.visitId
                );
            },
            [PostVisitActions.Waive]: async () => { 
                if (!selectedWaiveReason) {
                    throw new Error('Please select a reason.');
                }
                set(interactionEventAction, 'waive_visit');
                return getVisitServiceClient().waiveVisit(
                    visitId,
                    selectedWaiveReason,
                );
            },
            [PostVisitActions.Convert]: async () => {
                if (!selectedModalityConversionReason) {
                    throw new Error('Please select a modality conversion reason.');
                }
                set(
                    interactionEventAction, 
                    'modality_conversion_reason',
                    selectedModalityConversionReason,
                );
                return getBackendFacade().convertModality(
                    visitId,
                    selectedModalityConversionReason,
                    'virtual',
                    'phone',
                    currentProviderId,
                )
            },
            [PostVisitActions.Transfer]: async () => {
                return transfers[transferType as SelectQueueOrProviderChangeType]();
            }
        }

        return actions[action.selectedAction]()
            .then(() => {
                // leave the visit so that the patient is not inadvertently re-auto joined
                // if we are transferring them back to the waiting room
                conferenceClient.leave();
            })
            .catch((error: unknown) => {
                const message = (error as Error)?.message;
                set(userActionErrorAtom, message || 'Error ending the visit');
                set(userActionLoadingAtom, false);
            });
    }
)