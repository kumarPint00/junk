import { atom } from 'jotai';
import { AppConfig } from '../../../../../../server/config/configInterfaces';

export const appConfigAtom = atom<AppConfig>();
