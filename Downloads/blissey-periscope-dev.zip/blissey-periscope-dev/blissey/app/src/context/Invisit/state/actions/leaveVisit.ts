import { atom } from 'jotai';
import { To } from 'react-router-dom';
import { visitDetailsAtom } from '../atoms/visitDetails';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';
import { featureFlagsAtom } from '../atoms/featureFlags';
import { FeatureFlags } from '@utils/FeatureFlags';
import { userIsProviderAtom } from '../atoms/userDetails';
import {
    postConsultRoute,
    postVisitPatientSurveyRoute,
} from '@utils/getRoutes';

export const leaveVisitAction = atom(
    null,
    (get, _set, navigateAndClose: (to: To) => void) => {
        /**
         * Atoms
         */
        const visitDetails = get(visitDetailsAtom) as VisitResponseV9;
        const userIsProvider = get(userIsProviderAtom);
        const enablePostVisitSurveyConfig =
            get(featureFlagsAtom)?.[FeatureFlags.enablePostVisitSurveyConfig] ??
            false;

        const { visitId = '', brand = '' } = visitDetails || {};

        // ensure user is patient (providers need to formally end the visit)
        if (userIsProvider) {
            return;
        }

        // navigate to approriate end state
        if (enablePostVisitSurveyConfig) {
            navigateAndClose(postVisitPatientSurveyRoute(visitId, brand));
        } else {
            navigateAndClose(postConsultRoute(visitId, brand));
        }
    },
);
