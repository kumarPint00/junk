/* eslint-disable react-hooks/exhaustive-deps */
import { useCallback, useEffect } from 'react';
import { useAtomValue } from 'jotai';
import { getWorker } from 'msw-storybook-addon';
import { mockWaitingRoomSession } from '../../../__mocks__/services/responses/mockGetVisitSummary';
import {
    mockChargeVisit,
    mockGetPatientToken,
    mockGetTransferOptions,
    mockGetVisitSummary,
    mockGetWaittime,
    mockWaiveVisit,
    mockCancelVisit,
    mockCancelVideoWithReason,
    mockPatientEnterWaitOffline,
    mockGetReasons,
    mockWaitingRoomEvent,
    mockAcceptConsent,
} from '../../../__mocks__/services/msw/VisitServiceClient';
import { mockWaitingroomToken } from '../../../__mocks__/services/responses/mockGetPatientToken';
import {
    mockAdmitVisitParticipant,
    mockGetProviderToken,
    mockVisitEvent,
} from '../../../__mocks__/services/msw/BackendFacade';
import { mockGetPantryConfig } from '../../../__mocks__/services/msw/GetPantryConfig';
import {
    mockTokboxLogEndpoints,
    mockLogsEndpoints,
} from '../../../__mocks__/services/msw/Misc';
import { videoConferenceClientAtom } from '../state/atoms/clients';
import { mockUserId } from '../../../__mocks__/services/responses/mockGetUser';
import { waitingRoomChatClientAtom } from '../state/atoms/clients';
import { ConferenceEvents } from '@dexcare/conference-client';

export interface InvisitMocksProps {
    userRole: string;
    apiKey: string;
    videoSessionId: string;
    videoToken: string;
    waitingRoomSessionId?: string;
    waitingRoomToken?: string;
    acceptTerms?: boolean;
    simulateInCallCache?: boolean;
    simulateWaitingRoomCache?: boolean;
}

export const useInvisitMocks = ({
    userRole,
    apiKey,
    videoSessionId,
    videoToken,
    waitingRoomSessionId,
    waitingRoomToken,
    acceptTerms = false,
    simulateInCallCache = false,
    simulateWaitingRoomCache = false
}: InvisitMocksProps) => {
    const videoClient = useAtomValue(videoConferenceClientAtom);
    const waitingRoomClient = useAtomValue(waitingRoomChatClientAtom)
    const worker = getWorker();

    /**
     * Simulate cached messages
     */
    const handleVideoSessionConnected = useCallback(() => {
        if (simulateInCallCache) {
            console.log('sending incall cache message', {
                toconnection: videoClient.sessionClient.connection
            });
            void videoClient.sessionClient.sendSignal('instantMessage', {
                message: 'This is a cached in call message',
                fromParticipant: 'A ghost',
                uniqueId: 'im-a-snowflake',
                creationTime: Date.now().toString(),
                senderId: 'wouldnt-you-like-to-know',
            }, videoClient.sessionClient.connection);
        }
    }, [simulateInCallCache, videoClient]);

    const handleWaitingRoomSessionConnected = useCallback(() => {
        if(simulateWaitingRoomCache) {
            console.log('sending waiting room cache message', {
                toconnection: waitingRoomClient.sessionClient.connection
            });
            void waitingRoomClient.sessionClient.sendSignal('instantMessage', {
                message: 'This is a cached waiting room message',
                fromParticipant: 'A ghost',
                uniqueId: 'im-a-snowflake',
                creationTime: Date.now().toString(),
                senderId: 'wouldnt-you-like-to-know',
            }, waitingRoomClient.sessionClient.connection);
        }
    }, [simulateWaitingRoomCache, waitingRoomClient]);

    useEffect(() => {
        videoClient.sessionClient.off(ConferenceEvents.SESSION_CONNECTED, handleVideoSessionConnected);
        waitingRoomClient.sessionClient.off(ConferenceEvents.SESSION_CONNECTED, handleWaitingRoomSessionConnected);
        videoClient.sessionClient.on(ConferenceEvents.SESSION_CONNECTED, handleVideoSessionConnected);
        waitingRoomClient.sessionClient.on(ConferenceEvents.SESSION_CONNECTED, handleWaitingRoomSessionConnected);
        return () => {
            videoClient.sessionClient.off(ConferenceEvents.SESSION_CONNECTED, handleVideoSessionConnected);
            waitingRoomClient.sessionClient.off(ConferenceEvents.SESSION_CONNECTED, handleWaitingRoomSessionConnected);
        }
    }, [
        videoClient,
        waitingRoomClient,
    ]);

    useEffect(() => {
        // visit summary base
        const mockVisitSummaryOverrides = {
            tokBoxVisit: {
                videoConferenceSession: {
                    sessionId: videoSessionId,
                },
                waitingRoomSession: {
                    sessionId:
                        waitingRoomSessionId ||
                        mockWaitingRoomSession.sessionId,
                },
                apiKey,
            },
            acceptTerms,
        };

        // pantry configs
        worker.use(mockGetPantryConfig());

        // misc endpoints to reduce logging noise in browser
        worker.use(...mockLogsEndpoints());
        worker.use(...mockTokboxLogEndpoints());

        // user specific mocks
        if (userRole === 'telehealth_patient') {
            // visit summary
            worker.use(
                mockGetVisitSummary({
                    ...mockVisitSummaryOverrides,
                }),
            );
            /// tokens
            worker.use(
                mockGetPatientToken({
                    sessionId: videoSessionId,
                    token: videoToken,
                }),
            );
            worker.use(
                mockGetPatientToken({
                    sessionId:
                        waitingRoomSessionId ||
                        mockWaitingRoomSession.sessionId,
                    token: waitingRoomToken || mockWaitingroomToken,
                }),
            );
            // wait time polling
            worker.use(mockGetWaittime({}));
            // waiting room events
            worker.use(mockWaitingRoomEvent());
            // cancel normal
            worker.use(mockCancelVisit(videoClient));
            // cancel video with reason
            worker.use(mockCancelVideoWithReason(videoClient));
            // waitoffline
            worker.use(mockPatientEnterWaitOffline(videoClient));
            // accept terms
            worker.use(mockAcceptConsent());
        } else {
            // visit summary
            worker.use(
                mockGetVisitSummary({
                    ...mockVisitSummaryOverrides,
                    timestamps: {
                        created: '2021-10-01T00:00:00Z',
                        requested: '2021-10-01T00:00:00Z',
                        waitingroom: '2021-10-01T00:01:00Z',
                        caregiverassigned: '2021-10-01T00:02:30Z',
                        invisit: undefined,
                        done: undefined,
                        staffdeclined: undefined,
                        cancelled: undefined,
                        waitoffline: undefined,
                    },
                    providerId: mockUserId,
                    status: 'caregiverassigned',
                }),
            );
            /// tokens
            worker.use(
                mockGetProviderToken({
                    sessionId: videoSessionId,
                    token: videoToken,
                }),
            );
            // transfer options
            worker.use(mockGetTransferOptions({}));
            // waive reasons
            worker.use(mockGetReasons());
            /// actions
            // charge
            worker.use(mockChargeVisit({ videoClient }));
            // waive
            worker.use(mockWaiveVisit({ videoClient }));
            // transfer to queue / transfer to provider / change modality
            worker.use(mockVisitEvent({ videoClient }));
            // admit participant
            worker.use(mockAdmitVisitParticipant({}));
        }
    }, [videoClient]);
};
