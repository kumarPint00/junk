import { atom } from 'jotai';
import { To } from 'react-router-dom';
import {
    userActionErrorAtom,
    userActionLoadingAtom,
} from '../atoms/userAction';
import { getVisitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { visitDetailsAtom } from '../atoms/visitDetails';
import { featureFlagsAtom } from '../atoms/featureFlags';
import { FeatureFlags } from '@utils/FeatureFlags';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';
import { interactionEventAction } from './analytics';
import { getClosedVisitRoute } from '@utils/getRoutes';

export const cancelVisitAction = atom(
    null,
    async (get, set, navigateAndClose: (to: To) => void, reason: string = '') => {
        /**
         * Atoms
         */
        const visitDetails = get(visitDetailsAtom) as VisitResponseV9;
        const featureFlags = get(featureFlagsAtom);

        /**
         * Feature flags
         */
        const enablePatientCancelFlowWithReason =
            featureFlags?.[FeatureFlags.enablePatientCancelFlowWithReason];

        // indicate loading / clear previous errors
        set(userActionLoadingAtom, true);
        set(userActionErrorAtom, undefined);

        /**
         * Cancel logic
         */
        const cancel = async () => {
            const { visitId } = visitDetails;
            // analytics
            set(interactionEventAction, 'visit_cancel');
            // cancel with or without reason
            if (enablePatientCancelFlowWithReason) {
                return getVisitServiceClient().cancelVideoWithReason(
                    visitId,
                    reason,
                );
            }
            return getVisitServiceClient().cancelVisit(visitId);
        };

        return cancel()
            .then(() => {
                // for cancellation we cant wait for tokbox signal with status update
                // to initiate the redirect as we may not be talking to tokbox yet
                navigateAndClose(getClosedVisitRoute('cancelled', false));
            })
            .catch((error: unknown) => {
                const message = (error as Error)?.message;
                set(userActionErrorAtom, message || 'Error cancelling visit.');
                set(userActionLoadingAtom, false);
            });
    },
);
