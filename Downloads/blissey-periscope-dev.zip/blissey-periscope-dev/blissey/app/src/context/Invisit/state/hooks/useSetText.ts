import { useSetAtom, useAtomValue } from 'jotai';
import { TechCheckFailCode } from '@dexcare/video-conference';
import {
    conferenceStageTextAtom,
    injectedMenuTextAtom,
    techcheckHeaderTextAtom,
    videoConferenceTextAtom,
    footerTextAndLinkAtom,
    waitOfflineTextAtom,
    cancelTextAtom,
    virtualNudgeTextAtom,
    consentFormTextAtom,
    troubleshootingTextAndLinkAtom,
    textChatTextAtom,
    endVisitTextAtom,
} from '../atoms/text';
import { useTranslation } from 'react-i18next';
import { useEffect } from 'react';
import { userIsProviderAtom } from '../atoms/userDetails';
import { WaitTime } from '@clients/VisitService/VisitServiceClient';
import { waitTimeQueryAtom } from '../queries/waitTime';
import { formatAndLocalizeWaitTimeMessage } from '@utils/formatAndLocalizeWaitTimeMessage';
import { languageAtom, i18nAtom } from '../atoms/language';
import { visitDetailsAtom, hasBeenInvisitAtom } from '../atoms/visitDetails';
import { defaultReasonsForCancel } from '@utils/otUtils';
import { IAdvertisement } from '@dexcare/circus-saturn';
import * as browserCheck from '@utils/BrowserCheck';
import { appConfigAtom } from '../atoms/appConfig';
import { ChatState } from '@dexcare/text-chat';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';

/**
 * Seperate helper to build correct waittime message to avoid extra ugly
 * @param isProvider
 * @param t
 * @param i18n
 * @param waitTime
 */
export const waitTimeEstimateMessage = ({
    isProvider,
    t,
    i18n,
    waitTime,
}: {
    isProvider: boolean;
    t: (text: string, options?: { [key: string]: unknown }) => string;
    i18n: { language: string };
    waitTime?: WaitTime;
}): string | undefined => {
    if (isProvider) return undefined;
    if (waitTime) {
        return getFeatureFlag(FeatureFlags.localizeWaitTimeEstimateMessage)
            ? formatAndLocalizeWaitTimeMessage(
                  waitTime.waitTimeLocalizationInfo,
                  i18n.language,
              )
            : waitTime.estimatedWaitTimeMessage;
    }
    return t('waiting-room.providerSoon', {
        defaultValue:
            'One of our clinicians will meet you here as soon as they become available',
    });
};

/**
 * Seperate helper to build waittime "as of" message to avoid extra ugly
 * @param isProvider
 * @param t
 * @param i18n
 * @param waitTime
 */
export const waitTimeEstimateAsOfMessage = ({
    isProvider,
    t,
    i18n,
    waitTime,
}: {
    isProvider: boolean;
    t: (text: string, options?: { [key: string]: unknown }) => string;
    i18n: { language: string };
    waitTime?: WaitTime;
}): string | undefined => {
    if (isProvider || !waitTime) return undefined;
    const formattedTimestamp = new Date(waitTime.estimateGeneratedAt);
    const userLang = i18n.language || 'en-US';
    return t('waiting-room.waitEstimation_asOf', {
        time: formattedTimestamp
            .toLocaleTimeString(userLang, {
                hour: 'numeric',
                minute: '2-digit',
            })
            .toLowerCase(),
    });
};

/**
 * Centralized hook to set translated / contextual text values for components within the InvisitContext
 */
export const useSetText = () => {
    const [t, i18n] = useTranslation();
    const appConfig = useAtomValue(appConfigAtom);
    const visitDetails = useAtomValue(visitDetailsAtom);
    const isProvider = useAtomValue(userIsProviderAtom);
    const { data: waitTime } = useAtomValue(waitTimeQueryAtom);
    const hasBeenInVisit = useAtomValue(hasBeenInvisitAtom);
    const setVideoConferenceText = useSetAtom(videoConferenceTextAtom);
    const setTextChatText = useSetAtom(textChatTextAtom);
    const setTechCheckHeaderText = useSetAtom(techcheckHeaderTextAtom);
    const setInjectedMenuText = useSetAtom(injectedMenuTextAtom);
    const setConferenceStageText = useSetAtom(conferenceStageTextAtom);
    const setFooterTextAndLinks = useSetAtom(footerTextAndLinkAtom);
    const setWaitOfflineText = useSetAtom(waitOfflineTextAtom);
    const setCancelText = useSetAtom(cancelTextAtom);
    const setVirtualNudgeText = useSetAtom(virtualNudgeTextAtom);
    const setConsentFormText = useSetAtom(consentFormTextAtom);
    const setTroubleshootingTextAndLink = useSetAtom(
        troubleshootingTextAndLinkAtom,
    );
    const setEndVisitText = useSetAtom(endVisitTextAtom);
    const setLanguage = useSetAtom(languageAtom);
    const seti18n = useSetAtom(i18nAtom);

    /**
     * Browser language
     * */
    useEffect(() => {
        setLanguage(i18n.language);
        seti18n(i18n); // might need this whole object later
    }, [i18n.language, setLanguage, t, i18n, seti18n]);

    /**
     * Component text
     */
    useEffect(() => {
        /**
         * TechCheckHeader
         */
        setTechCheckHeaderText({
            pendingMessage: t(
                'waiting-room.tech-check.status.checkingForDevices',
                'Checking for devices',
            ),
            successMessage: t(
                'waiting-room.tech-check.status.connectionGood',
                'Success!',
            ),
            failCodeMessages: {
                [TechCheckFailCode.NotConnected]: t(
                    'waiting-room.tech-check.errors.networkIssueMessage',
                    'Network test failed, please check your connection.',
                ),
                [TechCheckFailCode.AccessNotAllowed]: t(
                    'waiting-room.tech-check.errors.mediaPermissionIssueMessage',
                    'Please grant permission to use your camera and microphone.',
                ),
                [TechCheckFailCode.VideoInputNotDetected]: t(
                    'waiting-room.tech-check.errors.devices.camera.missingMessage',
                    'Your camera cannot be accessed. Try connecting a camera and then run the test again.',
                ),
                [TechCheckFailCode.AudioInputNotDetected]: t(
                    'waiting-room.tech-check.errors.devices.microphone.missingMessage',
                    'Your microphone cannot be accessed. Try connecting a microphone and then run the test again.',
                ),
            },
        });

        /**
         * VideoConference
         */
        setVideoConferenceText({
            // currently patients never see this button (they are only ever auto joined)
            joinButtonLabel: isProvider
                ? t(
                      'waiting-room.joinVisitButtonLabelProvider',
                      'CONNECT WITH PATIENT',
                  )
                : t('waiting-room.joinVisitButtonLabelPatient', 'JOIN CALL'),
            // practically the user will not see this message as media permissions being denied
            // is treated as an error condition and the user is notified of that on the error screen
            techCheckCondition: t(
                'tech-check.errors.mediaPermissionIssueMessage',
                'Please grant permission to use your camera and microphone',
            ),
            // This messaging will practically only be shown to providers in the waiting / ante room
            // state and is not currently translated (defaults will be fine)
            roleConnectCondition: isProvider
                ? t(
                      'waiting-room.waitingForPatientToConnect',
                      'Waiting for patient to connect',
                  )
                : t(
                      'waiting-room.waitingForProviderToConnect to connect',
                      'Waiting for provider to connect',
                  ),
            // This messaging is shown to patients when they are waiting for the provider to join (providers will not actually see it)
            moderatorJoinCondition: isProvider
                ? t(
                      'waiting-room.waitingForPatientToJoin',
                      'Waiting for patient to join',
                  )
                : t(
                      'visit.techReconnection',
                      'If you are disconnected while waiting, check your email for a link, it will reconnect and preserve your place in the queue.  Please have your Photo ID ready when your visit starts.',
                  ),
            // This messaging is shown when a participant is the only one left in the call. It is technically misleading as
            // the others may have left intentionally https://dexcare.atlassian.net/browse/ENG-20724
            waitingForParticipants: t(
                'video-conference.error-messages.otherParticipantDropped',
                "Please wait while we're reconnecting.",
            ),
        });

        /**
         * TextChat
         */
        setTextChatText({
            headerMessages: {
                [ChatState.CONNECTING]: t(
                    'video-conference.error-messages.connecting',
                    'Connecting you to the room now.',
                ),
                [ChatState.CONNECTED]: t(
                    'video-conference.chat.header', // this seemed like the only text in the config appropriate to show here
                    'Chat with patient registration representatives is shared between staff for patient lookup and registration purposes. Any communications with this feature are used and shared only with the provider team. They are not saved or recorded on this website.',
                ),
                [ChatState.ERROR]: t(
                    'video-conference.error-messages.disconnected',
                    'Poor connection, please refresh the window to reconnect.', // shruggie emoji here
                ),
            },
        });

        /**
         * Troubleshooting
         */
        let troubleshootingLink = '';
        const browser = browserCheck.getBrowser();
        const troubleshootingLinkConfigs =
            appConfig?.troubleshootingLinks ?? {};
        if (browser in troubleshootingLinkConfigs) {
            troubleshootingLink = troubleshootingLinkConfigs[browser];
        }
        setTroubleshootingTextAndLink({
            text: t(
                'visit.techTroubleshooting',
                'Troubleshooting Your Audio/Video',
            ),
            link:
                troubleshootingLink ||
                'https://support.google.com/chrome/answer/2693767',
        });

        /**
         * InjectedMenuText
         */
        setInjectedMenuText({
            toggleFullscreenLabel: t(
                'video-conference.controls.fullscreenToggle',
                'Toggle Fullscreen On/Off',
            ),
            toggleChatLabel: t('video-conference.controls.chatToggle', 'Chat'),
            chatButtonCaption: t('visit.chatButtonCaption', 'Questions?'),
        });
    }, [
        t,
        isProvider,
        setTechCheckHeaderText,
        setVideoConferenceText,
        setInjectedMenuText,
        setTroubleshootingTextAndLink,
        appConfig?.troubleshootingLinks,
    ]);

    /**
     * Waittime dependent component text (waitTime dependency will be refreshed by polling)
     */
    useEffect(() => {
        /**
         * ConferenceStage
         */
        const message = waitTimeEstimateMessage({
            isProvider: !!isProvider,
            t,
            i18n,
            waitTime: waitTime || undefined,
        });
        const footNote = waitTimeEstimateAsOfMessage({
            isProvider: !!isProvider,
            t,
            i18n,
            waitTime: waitTime || undefined,
        });
        // patient header is based on whether weve been transferred
        // (there will also be a dialog here but this seems to appropriate for the header text as well)
        // NOTE: This was never added to translations. If we want something similar that is there is:
        // "providerSoon": "One of our healthcare providers will meet you here as soon as they become available", ?
        const patientHeader = hasBeenInVisit
            ? t(
                  'waiting-room.anotherProviderSoon',
                  'Another provider will be with you shortly.',
              )
            : t('waiting-room.techGuidance', 'Please keep this window open');
        setConferenceStageText({
            header: isProvider
                ? t(
                      'waiting-room.techGuidanceProvider',
                      'Please prepare to see the patient',
                  )
                : patientHeader,
            message,
            footNote,
        });
    }, [t, i18n, isProvider, waitTime, hasBeenInVisit, setConferenceStageText]);

    /**
     * Footer
     */
    useEffect(() => {
        const currentYear = new Date().getFullYear();

        // we do some insane thing where we combine configs from argo-gitops and ecp-customer-config
        // just go with it
        setFooterTextAndLinks({
            urlTermsText: t(
                'footer.termsAndPrivacyPolicy',
                'Terms of Use & Privacy Policy',
            ),
            urlTermsLink: t('branding:footer.urlTerms', { defaultValue: null }),
            disclaimerText: t('footer.disclaimer', 'Disclaimer'),
            disclaimerLink: t('branding:footer.urlDisclaimer', {
                defaultValue: null,
            }),
            privacyText: t(
                'footer.privacyNotice',
                'Notice of Privacy Practices',
            ),
            privacyLink: t('branding:footer.urlPrivacy', {
                defaultValue: null,
            }),
            nonDescriminationText: t(
                'footer.nonDiscrimination',
                'Non-discrimination',
            ),
            nonDescriminationLink: t(
                'branding:footer.urlNonDiscrimination',
                '',
            ),
            emergencyText: t(
                'footer.contactEmergency',
                'IN CASE OF EMERGENCY - DIAL 911',
            ),
            emergencyNumber: t('branding:footer.emergencyNumber', {
                defaultValue: null,
            }),
            supportText: t('footer.contactSupport', 'Need Help? Call'),
            supportNumber: t('branding:footer.helpPhone', {
                defaultValue: null,
            }),
            copyrightText: t('branding:footer.copyright', {
                defaultValue: `\u00a9 ${currentYear} DexCare Medical Center. All Rights Reserved.`,
                year: currentYear,
            }),
            brandImageSource: t('branding:greyLogo', { defaultValue: null }),
        });
    }, [t, setFooterTextAndLinks]);

    /**
     * Wait offline
     */
    useEffect(() => {
        setWaitOfflineText({
            waitOfflineClickText: t(
                'wait-offline.buttonCaption',
                "Don't Want To Wait?",
            ),
            waitOfflineButtonText: t(
                'wait-offline.buttonText',
                'Come Back Later',
            ),
            dialogTitleText: t(
                'wait-offline.modal.header',
                'Your place in line is reserved.',
            ),
            dialogContentText: t(
                'wait-offline.modal.body',
                'We can contact you when the provider is ready.',
            ),
            buttonAcceptText: t('wait-offline.modal.accept', 'Come Back Later'),
            buttonDeclineText: t('wait-offline.modal.decline', 'Wait Here'),
            enterWaitOfflineSuccessfulText: t(
                'wait-offline.modal.success',
                'Great. We will notify you through email or text message when the provider is ready.',
            ),
            enterWaitOfflineFailureText:
                visitDetails?.status === 'caregiverassigned'
                    ? t(
                          'wait-offline.modal.failure-visit-not-allowed',
                          'Your provider is ready. Please return to the visit.',
                      )
                    : t(
                          'wait-offline.modal.failure',
                          'Something went wrong. Please try again.',
                      ),
            closeText: t('wait-offline.modal.close', 'Close'),
        });
    }, [t, setWaitOfflineText, visitDetails]);

    /**
     * Cancel
     */
    useEffect(() => {
        setCancelText({
            cancelVisitButtonText: t('visit.cancelVisit', 'Cancel Visit'),
            dialogTitleText: t(
                'modal.cancelAppointment.cancelApptTitle',
                'Your place in line is reserved.',
            ),
            dialogContentText: t(
                'modal.cancelAppointment.cancelApptBody',
                'Cancelling now will remove you from the line and your visit will be cancelled.',
            ),
            buttonStayText: t(
                'modal.cancelAppointment.cancelApptStayButton',
                'Cancel and leave',
            ),
            buttonLeaveText: t(
                'modal.cancelAppointment.cancelApptLeaveButton',
                'No, I will wait here',
            ),
            // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
            reasonsForCancel: t('cancelWithReason.reasons', {
                returnObjects: true,
                defaultValue: defaultReasonsForCancel,
            }) as { label: string; value: string }[],
            headerText: t(
                'cancelWithReason.video.header',
                'Your place in line is reserved',
            ),
            bodyText: t(
                'cancelWithReason.video.body',
                'Cancelling now will remove you from the queue.',
            ),
            instructionText: t(
                'cancelWithReason.video.instruction',
                'If you wish to keep the appointment, please close this window.',
            ),
            reasonText: t(
                'cancelWithReason.video.reason',
                'If you still need to cancel, please select a reason below.',
            ),
            label: t('cancelWithReason.video.label', 'Reason for cancelling'),
            buttonAcceptText: t(
                'cancelWithReason.video.buttonAccept',
                'CANCEL VISIT',
            ),
            buttonDeclineText: t('cancelWithReason.video.buttonClose', 'CLOSE'),
        });
    }, [t, setCancelText]);

    /**
     * Virtual Nudge, cross-sell, ads, etc.
     */
    useEffect(() => {
        setVirtualNudgeText({
            header: t('virtualNudge.header', ''),
            // eslint-disable-next-line @typescript-eslint/no-unnecessary-type-assertion
            advertisements: t('virtualNudge.advertisements', {
                returnObjects: true,
                defaultValue: [],
            }) as IAdvertisement[],
        });
    }, [t, setVirtualNudgeText]);

    /**
     * Consent Form
     */
    useEffect(() => {
        setConsentFormText({
            headerText: t('consent.headerText', 'Go To Waiting Room'),
            consentHeaderText: t(
                'consent.instructions.headerText',
                "You're almost done",
            ),
            consentInstructionText: t(
                'consent.instructions.bodyText',
                'We just need you to accept the patient consent below by selecting the checkbox. Then we will take you to the video visit virtual waiting room.',
            ),
            consentCheckboxLabelText: t(
                'consent.checkbox.labelText',
                'By selecting this box you’re agreeing to the terms.',
            ),
            consentButtonText: t(
                'consent.accept.buttonText',
                'Accept and join waiting room',
            ),
            consentCancelLinkText: t(
                'consent.cancel.buttonText',
                'Cancel Visit',
            ),
            dismissErrorModalText: t(
                'consent.error.dismissModalText',
                'Dismiss',
            ),
        });
    }, [t, setConsentFormText]);

    /**
     * End visit dialog
     */
    useEffect(() => {
        setEndVisitText({
            labelForCompleteVisit:
                appConfig?.postVisitOptions?.labelForCompleteVisit,
            labelForConvertModality:
                appConfig?.postVisitOptions?.labelForConvertModality,
            labelForModalityConversionReason:
                appConfig?.postVisitOptions?.labelForModalityConversionReason,
            labelForWaiveVisit: appConfig?.postVisitOptions?.labelForWaiveVisit,
            labelForTransferVisit:
                appConfig?.postVisitOptions?.labelForTransferVisit,
            labelForWaiveReason:
                appConfig?.postVisitOptions?.labelForWaiveReason,
        });
    }, [appConfig, setEndVisitText]);
};
