/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { atom } from 'jotai';
import { getVisitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { InstantMessageItemProps } from '@dexcare/circus-saturn';
import { visitDetailsAtom } from '../atoms/visitDetails';
import { userDetailsAtom, userIsProviderAtom } from '../atoms/userDetails';
import { Logger } from '@utils/index';
import { ChatClient, ChatMessage, ConferenceEvent } from '@dexcare/conference-client';

export type InstantMessageProps = Pick<
    InstantMessageItemProps,
    'content' | 'senderName' | 'timeSent'
> & {
    key: string;
    senderId: string;
};

export const cacheMessageAction = atom(
    null,
    (
        get,
        _set,
        payload: {
            event: ConferenceEvent;
            client: ChatClient;
        },
    ) => {
        const { event, client } = payload;
        const sessionId = client.sessionClient.conferenceSession.sessionId;
        const chatMessage = event.data?.chatMessage as ChatMessage;
        const visitDetails = get(visitDetailsAtom);
        const userDetails = get(userDetailsAtom);
        const userIsProvider = get(userIsProviderAtom);

        if (!visitDetails || !sessionId) {
            return;
        }

        const instantMessage = {
            message: chatMessage.message,
            fromParticipant: chatMessage.fromParticipant,
            uniqueId: chatMessage.uniqueId,
            creationTime: (chatMessage.creationTime || Date.now()).toString(),
            // the sender id _should_ be the user id encoded in the vonage
            // connectionData. This is not currently present for patients.
            // to make caching work we need to use _some_ id. This id will _not_
            // work for making cached messages appear as "from self"
            senderId: chatMessage.senderId || userDetails?.id,
        };

        try {
            const visitServiceClient = getVisitServiceClient();
            void visitServiceClient.cacheInstantMessage(
                visitDetails.visitId,
                sessionId,
                instantMessage,
                !!userIsProvider,
            );
        } catch (error) {
            Logger.error({ error }, 'Error caching message');
        }
    },
);
