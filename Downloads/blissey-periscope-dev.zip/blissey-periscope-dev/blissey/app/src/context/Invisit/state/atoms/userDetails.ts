import { isProvider } from "@dexcare/circus-saturn"; // we shouldnt be importing from circus-saturn
import { atom } from "jotai";
import { UserDetails } from "types/UserDetails";

export const userDetailsAtom = atom<UserDetails>();

export const userIsProviderAtom = atom<boolean | undefined>(
    (get) => {
        const userDetails = get(userDetailsAtom);
        if (userDetails) {
            return isProvider(userDetails);
        }
        return undefined
    }
);