import { atom } from 'jotai';
import { VisitParticipant } from "@dexcare/visit-participants";

export const visitParticipantsAtom = atom<VisitParticipant[]>([]);