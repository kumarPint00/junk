import { atom } from 'jotai';
import { ConferenceStates } from '@dexcare/conference-stage';

export const conferenceStateAtom = atom<ConferenceStates>(ConferenceStates.WaitingRoom);