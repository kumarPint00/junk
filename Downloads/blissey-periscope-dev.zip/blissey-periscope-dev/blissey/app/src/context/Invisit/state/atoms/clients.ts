import { atom } from 'jotai';
import { ChatClient, ConferenceSession, SessionClient, VideoClient } from '@dexcare/conference-client';
import { ClientConnection } from '@dexcare/conference-client';
import { TokboxChatClient, TokboxSessionClient, TokboxVideoClient } from '@dexcare/conference-client/tokbox';
import { admitParticipantAction, deleteParticipantAction } from '../actions/visitParticipants';
import { visitParticipantsAtom } from './visitParticipants';

export interface ClientSessions {
    waitingRoom: ConferenceSession;
    video: ConferenceSession;
}

let _sessionClient: SessionClient;
export const getSessionClientInstance = (): SessionClient => {
    if (!_sessionClient) {
        _sessionClient = new TokboxSessionClient();
    }
    return _sessionClient;
}

let _videoClient: VideoClient;
export const getVideoClientInstance = (): VideoClient => {
    if (!_videoClient) {
        _videoClient = new TokboxVideoClient(
            getSessionClientInstance() as TokboxSessionClient
        );
    }
    return _videoClient;
}

let _videoChatClient: ChatClient;
export const getVideoChatClientInstance = (): ChatClient => {
    if (!_videoChatClient) {
        _videoChatClient = new TokboxChatClient(
            getSessionClientInstance() as TokboxSessionClient,
            { connectWithSession: true }
        );
    }
    return _videoChatClient;
}

let _waitingRoomChatClient: ChatClient;
export const getWaitingRoomChatClientInstance = (): ChatClient => {
    if (!_waitingRoomChatClient) {
        _waitingRoomChatClient = new TokboxChatClient();
    }
    return _waitingRoomChatClient;
}

export const sessionClientAtom = atom<SessionClient>(getSessionClientInstance())
export const videoConferenceClientAtom = atom<VideoClient>(getVideoClientInstance());
export const videoChatClientAtom = atom<ChatClient>(getVideoChatClientInstance());
export const waitingRoomChatClientAtom = atom<ChatClient>(getWaitingRoomChatClientInstance());
export const clientsInitializedAtom = atom<boolean>(false);

export const initializeClientsAtom = atom(
    null,
    (get, set, sessions: ClientSessions) => {
        // initialize the session / chat clients
        const sessionClient = get(sessionClientAtom);
        const waitingRoomChatClient = get(waitingRoomChatClientAtom);
        const {
            video,
            waitingRoom,
        } = sessions;
        // video and videoChat clients share the same SessionClient
        sessionClient.initialize({
            ...video,
            admitConnection: async (connection: ClientConnection) => {
                // patch the participant record as "admitted"
                const participants = get(visitParticipantsAtom);
                const participant = participants.find((p) => p.id === connection.connectionData?.userId);
                if (participant) {
                    return set(admitParticipantAction, participant);
                }
            },
            declineConnection: async (connection: ClientConnection) => {
                // delete the corresponding participant (if they exist)
                const participants = get(visitParticipantsAtom);
                const participant = participants.find((p) => p.id === connection.connectionData?.userId);
                if (participant) {
                    // DO NOT set forceDisconnect (as we will already be doing that)
                    return set(deleteParticipantAction, participant);
                }
            }
        });
        // waiting room chat has its own client
        waitingRoomChatClient.initialize({ ...waitingRoom });
        set(clientsInitializedAtom, true);
    }
)

