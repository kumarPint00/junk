import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import { VisitReason } from 'data/VisitReasons';
import { atom } from 'jotai';

/**
 * Atom to store the reasons for waiving a visit
 */
export const waiveReasonsAtom = atom<VisitReason[]>([]);
export const getWaiveReasonsAtom = atom<VisitReason[] | undefined>((get) => {
    const releaseConfigurableVisitReasons = getFeatureFlag(
        FeatureFlags.releaseConfigurableVisitReasons,
    );
    return releaseConfigurableVisitReasons ? get(waiveReasonsAtom) : undefined; // Use default values from PostVisitActionSelector
});
