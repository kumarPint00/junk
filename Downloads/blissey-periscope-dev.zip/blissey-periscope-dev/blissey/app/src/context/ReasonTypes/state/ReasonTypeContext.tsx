import React, { useEffect, ReactNode } from 'react';
import { useSetAtom } from 'jotai';
import { waiveReasonsAtom } from './atoms/reasonTypes';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { ReasonType } from '../../../data/VisitReasons';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';

interface ContextProps {
    children: ReactNode;
}

const Context = (props: ContextProps) => {
    const setWaiveReasons = useSetAtom(waiveReasonsAtom);

    useEffect(() => {
        const fetchData = async () => {
            const reasons = await visitServiceClient.getReasons();
            setWaiveReasons(
                reasons?.find(
                    (reason) => reason.reasonType === ReasonType.WAIVE,
                )?.reasons || [],
            );
        };
        void fetchData();
    }, [setWaiveReasons]);

    return props.children;
};

interface ReasonTypesContextProps {
    children: ReactNode;
}
export const ReasonTypesContext = (props: ReasonTypesContextProps) => {
    const releaseConfigurableVisitReasons = getFeatureFlag(
        FeatureFlags.releaseConfigurableVisitReasons,
    );
    return releaseConfigurableVisitReasons ? (
        <Context>{props.children}</Context>
    ) : (
        props.children
    );
};
