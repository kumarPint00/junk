import React from 'react';
import { useAtomValue, useSetAtom } from 'jotai';
import { waiveReasonsAtom } from '../atoms/reasonTypes';
import { render, screen, waitFor } from '@testing-library/react';
import { ReasonTypesContext } from '../ReasonTypeContext';
import * as featureFlags from '@utils/FeatureFlags';
import { vi } from 'vitest';

const mockReason: {
    key: string;
    value: string;
} = vi.hoisted(() => ({
    key: 'reason1',
    value: 'Reason 1',
}));

vi.mock('@clients/VisitService/VisitServiceClient', () => {
    return {
        visitServiceClient: {
            getReasons: vi.fn().mockResolvedValue([
                {
                    reasonType: 'waive',
                    reasons: [mockReason],
                },
            ]),
        },
    };
});

const MockReasonTypeEntry = () => {
    const waveReasons = useAtomValue(waiveReasonsAtom);
    const reason = waveReasons[0];
    return (
        <div>
            <p data-testid="waiveReasonKey">{reason?.key}</p>
            <p data-testid="waiveReasonValue">{reason?.value}</p>
        </div>
    );
};

const MockReasonTypesConsumer = () => {
    const setWaiveReason = useSetAtom(waiveReasonsAtom);
    setWaiveReason([]);
    return (
        <ReasonTypesContext>
            <MockReasonTypeEntry />
        </ReasonTypesContext>
    );
};

describe('ReasonTypeContext', () => {
    it('should load visit reasons when releaseConfigurableVisitReasons feature flag is on', async () => {
        vi.spyOn(featureFlags, 'getFeatureFlag').mockImplementationOnce(
            () => true,
        );
        render(<MockReasonTypesConsumer />);
        await waitFor(() => {
            expect(screen.getByTestId('waiveReasonKey')).toHaveTextContent(
                mockReason.key,
            );
            expect(screen.getByTestId('waiveReasonValue')).toHaveTextContent(
                mockReason.value,
            );
        });
    });

    it('should load visit reasons when releaseConfigurableVisitReasons feature flag is off', async () => {
        vi.spyOn(featureFlags, 'getFeatureFlag').mockImplementationOnce(
            () => false,
        );
        render(<MockReasonTypesConsumer />);
        await waitFor(() => {
            expect(screen.getByTestId('waiveReasonKey')).toHaveTextContent('');
            expect(screen.getByTestId('waiveReasonValue')).toHaveTextContent(
                '',
            );
        });
    });
});
