import { CallSummaryModule } from '../CallSummaryModule';

const patientUserDetails = {
    id: 'testUserId',
    displayName: 'testDisplayName',
    givenName: 'testGivenName',
    familyName: 'testFamilyName',
    email: 'textEmail',
    token: 'testToken',
    expiration: 0,
};

const providerUserDetails = {
    id: 'testUserId',
    displayName: 'testDisplayName',
    givenName: 'testGivenName',
    familyName: 'testFamilyName',
    email: 'textEmail',
    token: 'testToken',
    expiration: 0,
    roles: ['telehealth_provider'],
};

export const Patient = {
    args: {
        localUser: patientUserDetails,
        visitId: 'test visitId',
        conferenceId: '9UqDnNDr',
        conferenceSessionId: 'test conferenceSessionId',
        callEndTime: 1527267376182,
        callStartTime: 1527267336182,
        onFlowFinished: () => {
            console.log('CallSummaryModule: onFlowFinished');
        },
    },
};

export const Provider = {
    args: {
        localUser: providerUserDetails,
        visitId: 'test visitId',
        conferenceId: '9UqDnNDr',
        conferenceSessionId: 'test conferenceSessionId',
        callEndTime: 1527267376182,
        callStartTime: 1527267336182,
        onFlowFinished: () => {
            console.log('CallSummaryModule: onFlowFinished');
        },
    },
};

export default {
    title: 'Modules/CallSummary',
    component: CallSummaryModule,
};
