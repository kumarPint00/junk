import { UserDetails } from '@dexcare/circus-saturn';

export interface CallSummaryModuleProps {
    localUser: UserDetails;
    visitId: string;
    patientGuid: string;
    providerId?: string | null;
    conferenceId: string;
    conferenceSessionId: string;
    callStartTime: number | null;
    callEndTime: number | null;
    onFlowFinished: () => void;
    isTestVisit?: boolean;
}
