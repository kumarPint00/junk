import * as React from 'react';

import { isProvider } from '@dexcare/circus-saturn';
import { LogManager, Logger } from '@dexcare/circus-jupiter';

import { Button } from '@components/Button';
import { FooterPage } from '@layout/PageLayout/FooterPage';
import { CallSummaryModuleProps } from './CallSummaryModuleInterfaces';
import { FeedbackDetail } from '@clients/Feedback/FeedbackDetail';
import { FeedbackQuestion } from '@clients/Feedback/FeedbackQuestion';
import { FeedbackQuestionType } from '@clients/Feedback/FeedbackQuestionType';
import { FeedbackComponent } from '@components/Feedback/FeedbackComponent';
import { PatientFeedbackComponent } from '@components/Feedback/PatientFeedbackComponent';
import { FeedbackAnswer } from '@clients/Feedback/FeedbackAnswer';
import { createQuestionBank } from './data/FeedbackQuestionsList';
import { QuestionBank } from './data/QuestionBank';
import { UserType } from '../../data/UserType';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { submitGTMPageViewEvent } from '@services/analytics';

import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './CallSummaryModule.css';

export class CallSummaryModule extends React.PureComponent<CallSummaryModuleProps> {
    private userType: UserType;
    private questionBank: QuestionBank;
    private logger: Logger;

    constructor(props: CallSummaryModuleProps) {
        super(props);

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'CallSummaryModule',
                userId: this.props.localUser.id,
                isTestVisit: this.props.isTestVisit,
            },
            true,
        );

        this.userType = isProvider(this.props.localUser)
            ? UserType.Provider
            : UserType.Patient;
        this.questionBank = createQuestionBank(this.userType);
    }

    public componentDidMount() {
        Analytics.sendPageView({
            destinationURL: '/postconsult/feedback',
        });
        submitGTMPageViewEvent(this.props.visitId);

        this.logger.info({ eventType: 'render', visitId: this.props.visitId });
    }

    public render() {
        if (this.userType === UserType.Provider) {
            return (
                <FooterPage headerText={'Please tell us about your visit'}>
                    <div className={styles.content}>
                        <FeedbackComponent
                            feedbackQuestions={Array.from(
                                this.questionBank
                                    .getFeedbackQuestions()
                                    .values(),
                            )}
                            onAnswerChange={this.onAnswerChange}
                        />
                        <div className={styles.submitButtonsContainer}>
                            <div className={styles.buttonContainer}>
                                <Button
                                    variant="text"
                                    data-unittest="feedback-skipbutton"
                                    onClick={this.onSkipClick}
                                    uiTestTag="feedbackSkipButton"
                                >
                                    SKIP
                                </Button>
                            </div>
                            <div className={styles.buttonContainer}>
                                <Button
                                    onClick={() => void this.onSubmitClick()}
                                    uiTestTag="feedback-submitbutton"
                                >
                                    SUBMIT FEEDBACK
                                </Button>
                            </div>
                        </div>
                    </div>
                </FooterPage>
            );
        }
        const { callEndTime, callStartTime, localUser, visitId } = this.props;

        return (
            <FooterPage>
                <div className={styles.patientContent}>
                    <PatientFeedbackComponent
                        submit={this.onPatientSubmit}
                        visitId={visitId}
                        providerId={this.props.providerId}
                        userId={localUser.id}
                        callStartTime={callStartTime}
                        callEndTime={callEndTime}
                    />
                </div>
            </FooterPage>
        );
    }

    private onAnswerChange = (
        newValue: number | string,
        questionId: string,
        answerId?: string,
    ): void => {
        this.questionBank.updateValue(questionId, newValue, answerId);
    };

    private formatTime(time: number | null): string {
        if (!time) {
            return '';
        }
        return new Date(time).toISOString();
    }

    private constructFeedbackDetail(): FeedbackDetail {
        const {
            conferenceId,
            conferenceSessionId,
            visitId,
            localUser,
            callEndTime,
            callStartTime,
        } = this.props;
        const feedbacks = Array.from(
            this.questionBank.getFeedbackQuestions().values(),
        );
        return {
            appId: 'telehealth',
            appVersion: 'v2',
            appHostEnvironment: navigator.userAgent,
            userIdentifier:
                this.userType === UserType.Provider ? localUser.id : '',
            conferenceId,
            conferenceSessionId,
            visitId: visitId || 'No_VisitId',
            userDisplayName: '', // Left blank for HIPAA compliance,
            userRole: this.userType,
            feedbacks,
            startTime: this.formatTime(callStartTime),
            endTime: this.formatTime(callEndTime),
            rating: feedbacks.find((feedback) => feedback.id === 'rating')
                ?.answers[0].value as number,
        };
    }

    private constructPatientFeedbackDetail(
        feedbacks: FeedbackQuestion[],
    ): FeedbackDetail {
        const {
            conferenceId,
            conferenceSessionId,
            visitId,
            localUser,
            callEndTime,
            callStartTime,
        } = this.props;

        return {
            appId: 'telehealth',
            appVersion: 'v2',
            appHostEnvironment: navigator.userAgent,
            userIdentifier:
                this.userType === UserType.Provider ? localUser.id : '',
            conferenceId,
            conferenceSessionId,
            visitId: visitId || 'No_VisitId',
            userDisplayName: '', // Left blank for HIPAA compliance,
            userRole: 'patient',
            feedbacks,
            startTime: this.formatTime(callStartTime),
            endTime: this.formatTime(callEndTime),
            rating: feedbacks.find((feedback) => feedback.id === 'rating')
                ?.answers[0].value as number,
        };
    }

    private patientAnalyticsSubmit(
        feedbacks: FeedbackQuestion[],
        skip?: boolean,
    ): void {
        try {
            const formName = 'Visit Questionnaire';
            const eventAction = 'formSubmission';
            for (const feedback of feedbacks) {
                if (feedback.type !== FeedbackQuestionType.Text) {
                    let fieldValue: string | number | boolean | undefined =
                        'skip';
                    if (!skip) {
                        const answer = feedback.answers.find(
                            (t: FeedbackAnswer) => !!t.value,
                        );
                        fieldValue = answer
                            ? answer.text || answer.value
                            : 'skip';
                    }
                    Analytics.sendEvent({
                        eventAction,
                        formEngagement: {
                            formName,
                            fieldName: feedback.id,
                            fieldValue,
                        },
                    });
                }
            }
        } catch (error) {
            this.logger.error(
                `Failed to send analytics for patient with skip = ${String(
                    skip,
                )} ` + error,
            );
        }
    }

    private analyticsSkip(): void {
        try {
            const formName = 'Visit Questionnaire';
            const eventAction = 'formSubmission';
            for (const feedbackQuestion of Array.from(
                this.questionBank.getFeedbackQuestions().values(),
            )) {
                if (feedbackQuestion.type !== FeedbackQuestionType.Text) {
                    Analytics.sendEvent({
                        eventAction,
                        formEngagement: {
                            formName,
                            fieldName: feedbackQuestion.id,
                            fieldValue: 'skip',
                        },
                    });

                    V2Analytics.interactionEvent({ eventName: 'skip' });
                }
            }
        } catch (error) {
            this.logger.error('Failed to send analytics for skip' + error);
        }
    }

    private analyticsSubmission(): void {
        try {
            const formName = 'Visit Questionnaire';
            const eventAction = 'formSubmission';
            for (const feedbackQuestion of Array.from(
                this.questionBank.getFeedbackQuestions().values(),
            )) {
                if (feedbackQuestion.type === FeedbackQuestionType.Text) {
                    continue;
                }
                const answer = feedbackQuestion.answers.find(
                    (t: FeedbackAnswer) => !!t.value,
                );
                const answerText = answer
                    ? answer.text || answer.value
                    : 'skip';
                Analytics.sendEvent({
                    eventAction,
                    formEngagement: {
                        formName,
                        fieldName: feedbackQuestion.id,
                        fieldValue: answerText,
                    },
                });

                V2Analytics.interactionEvent({
                    eventName: 'form_field_engage',
                    form_field: `${feedbackQuestion.id}_submit`,
                    form_name: formName.toLowerCase(),
                });
            }
        } catch (error) {
            this.logger.error('Failed to send analytics for submit' + error);
        }
    }

    private async submitFeedback(): Promise<void> {
        this.analyticsSubmission();
        const feedbackDetail: FeedbackDetail = this.constructFeedbackDetail();
        // Await to prevent failure to send on window close
        await visitServiceClient.saveFeedback(
            this.props.visitId,
            feedbackDetail,
        );
    }

    private onSkipClick = (): void => {
        this.analyticsSkip();
        this.props.onFlowFinished();
        window.close();
    };

    private onSubmitClick = async (): Promise<void> => {
        await this.submitPageFeedback();
        this.props.onFlowFinished();
        window.close();
    };

    public onPatientSubmit = (
        feedback: FeedbackQuestion[],
        skip?: boolean,
    ): void => {
        this.patientAnalyticsSubmit(feedback, skip);
        if (!skip) {
            const feedbackDetail: FeedbackDetail =
                this.constructPatientFeedbackDetail(feedback);
            // Fire and forget
            void visitServiceClient.saveFeedback(
                this.props.visitId,
                feedbackDetail,
            );
        }

        this.props.onFlowFinished();
    };

    private async submitPageFeedback(): Promise<void> {
        await this.submitFeedback().catch((error) => {
            this.logger.error('Failed to submit the feedback:' + error);
        });
    }
}
