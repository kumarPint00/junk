import { UserType } from '../../../data/UserType';
import { QuestionBank } from './QuestionBank';
import { FeedbackQuestion } from '../../../clients/Feedback/FeedbackQuestion';
import { FeedbackQuestionType } from '../../../clients/Feedback/FeedbackQuestionType';

function getProviderQuestions(): Map<string, FeedbackQuestion> {
    return new Map<string, FeedbackQuestion>([
        [
            'rating',
            {
                id: 'rating',
                text: 'Rate Your Overall Experience',
                type: FeedbackQuestionType.Number,
                answers: [
                    {
                        id: 'ratingAnswer',
                        value: 0,
                        type: FeedbackQuestionType.Number,
                        text: '',
                    },
                ],
            },
        ],
    ]);
}

// NOTE: This is only used for provider, we have a separate patient component
// This is done as we are moving towards material ui components
export function createQuestionBank(userType: UserType): QuestionBank {
    let questions: Map<string, FeedbackQuestion>;
    switch (userType) {
        case UserType.Provider:
            questions = getProviderQuestions();
            break;
        default:
            questions = new Map<string, FeedbackQuestion>();
    }
    return new QuestionBank(questions);
}
