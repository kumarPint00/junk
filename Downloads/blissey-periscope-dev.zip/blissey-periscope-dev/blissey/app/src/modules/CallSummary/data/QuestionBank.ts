import { FeedbackQuestion } from '@clients/Feedback/FeedbackQuestion';
import { FeedbackAnswer } from '@clients/Feedback/FeedbackAnswer';
import { FeedbackQuestionType } from '@clients/Feedback/FeedbackQuestionType';

export class QuestionBank {
    private questions: Map<string, FeedbackQuestion>;

    constructor(questions: Map<string, FeedbackQuestion>) {
        this.questions = questions;
    }

    public getFeedbackQuestions(): Map<string, FeedbackQuestion> {
        return this.questions;
    }

    public updateValue(
        questionId: string,
        newValue: number | string,
        answerId?: string,
    ) {
        const question = this.questions.get(questionId);
        if (!question) {
            return;
        }
        const questionType = question.type;

        if (questionType === FeedbackQuestionType.MultipleChoice) {
            question.answers.forEach(
                (a: FeedbackAnswer) => (a.value = a.id === newValue),
            );
        } else {
            const answerIndex = question.answers.findIndex(
                (t: FeedbackAnswer) => t.id === answerId,
            );
            question.answers[answerIndex].value = newValue;
        }
        this.questions.set(questionId, question);
    }
}
