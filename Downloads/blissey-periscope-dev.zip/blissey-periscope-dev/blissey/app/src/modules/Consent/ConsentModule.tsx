import * as React from 'react';
import { useState } from 'react';
import { withTranslation, WithTranslation } from 'react-i18next';
import { FooterPage } from '../../layout/PageLayout/FooterPage';
import { ConsentComponent } from '@components/Consent/ConsentComponent';
import { CancelVisitDialog } from '@components/WaitingRoom/CancelVisitDialog';
import { LogManager } from '@dexcare/circus-jupiter';
import { UserDetails } from '@dexcare/circus-saturn';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

export interface ConsentModuleProps extends WithTranslation {
    isLoading: boolean;
    errorMessage: string | null;
    userDetails: UserDetails;
    visitId: string;
    isTestVisit: boolean;
    handleAcceptTerms: () => void;
    handleCancel: () => void;
    handleSetErrorMessage: (message: string | null) => void;
}

const ConsentModule = ({
    isLoading,
    errorMessage,
    userDetails,
    visitId,
    isTestVisit,
    handleAcceptTerms,
    handleCancel,
    handleSetErrorMessage,
    t,
}: ConsentModuleProps) => {
    const logger = LogManager.getLogger().child(
        {
            eventSource: 'ConsentModule',
            userId: userDetails?.id,
            visitId: visitId,
            isTestVisit: isTestVisit,
        },
        true,
    );

    const [termsAccepted, setTermsAccepted] = useState(false);
    const [showCancelDialog, setShowCancelDialog] = useState(false);

    const onConsentButtonClick = () => {
        handleAcceptTerms();
    };
    const onConsentCancelLinkClick = () => {
        setShowCancelDialog(true);
    };
    const closeCancelVisitDialog = () => {
        setShowCancelDialog(false);
    };
    const cancelVisitHandle = (): void => {
        logger.info(
            {
                eventType: 'userAction',
                eventName: 'cancelVisit',
            },
            'Cancel this visit - clicked',
        );

        V2Analytics.interactionEvent({
            eventName: 'visit_cancel',
            visit_id: visitId,
        });
        handleCancel();
    };

    const headerText = t('consent.headerText') ?? 'Go To Waiting Room';
    const consentHeaderText =
        t('consent.instructions.headerText') ?? "You're almost done";
    const consentInstructionText =
        t('consent.instructions.bodyText') ?? 'We just need you...';
    const consentCheckboxLabelText =
        t('consent.checkbox.labelText') ?? 'By selecting this box...';
    const consentButtonText =
        t('consent.accept.buttonText') ?? 'Accept and join waiting room';
    const consentCancelLinkText =
        t('consent.cancel.buttonText') ?? 'Cancel Visit';
    // error messages can / will be translated as they come back from upstream services
    const errorMessageText = errorMessage || undefined;
    const dismissErrorModalText =
        t('consent.error.dismissModalText') ?? 'Dismiss';

    const ConsentProps = {
        localizedText: {
            consentHeaderText,
            consentInstructionText,
            consentCheckboxLabelText,
            consentButtonText,
            consentCancelLinkText,
            errorMessageText,
            dismissErrorModalText,
        },
        termsAccepted,
        isLoading,
        onConsentButtonClick,
        onConsentCancelLinkClick,
        handleSetErrorMessage,
        setTermsAccepted,
    };

    return (
        <FooterPage headerText={headerText}>
            <div data-uitest="otp-container">
                <ConsentComponent {...ConsentProps} />
            </div>
            <CancelVisitDialog
                active={showCancelDialog}
                closeCancelVisitDialog={closeCancelVisitDialog}
                endCall={cancelVisitHandle}
                visitId={visitId}
            />
        </FooterPage>
    );
};

// do we need withTranslation when this component is already wrapped with I18NextProvider? not sure
// do we need access to the store? not sure
const _ConsentModule = withTranslation()(ConsentModule);
export { _ConsentModule as ConsentModule, ConsentModule as RawConsentModule };
