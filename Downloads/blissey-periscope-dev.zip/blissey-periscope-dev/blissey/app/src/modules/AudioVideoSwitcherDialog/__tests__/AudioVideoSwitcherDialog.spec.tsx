import React from 'react';
import { AudioVideoSwitcherDialog } from '../AudioVideoSwitcherDialog';
import { render } from '@testing-library/react';
import { MediaDevice } from '@common/video/getDevices/MediaDevice';
import { vi } from 'vitest';

const videoDevices: MediaDevice[] = [
    {
        label: 'Camera 1',
        value: '1',
    },
    {
        label: 'Camera 2',
        value: '2',
    },
];
const audioDevices: MediaDevice[] = [
    {
        label: 'Mic 1',
        value: '1',
    },
    {
        label: 'Mic 2',
        value: '2',
    },
];

describe('AudioVideoSwitcherDialog', () => {
    it('should pass device ids on confirm', () => {
        const confirmSpy = vi.fn();
        const result = render(
            <AudioVideoSwitcherDialog
                open={true}
                onClose={vi.fn()}
                onCancel={vi.fn()}
                onConfirm={confirmSpy}
                videoDevices={videoDevices}
                audioDevices={audioDevices}
                defaultValue={{
                    audioDeviceId: '2',
                    videoDeviceId: '1',
                }}
            />,
        );
        result.getByTestId('confirmation-dialog-confirm-button').click();
        expect(confirmSpy).toHaveBeenCalledWith({
            audioDeviceId: '2',
            videoDeviceId: '1',
        });
    });
});
