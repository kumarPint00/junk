import { Meta } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import {
    AudioVideoSwitcherDialog,
    AudioVideoSwitcherDialogProps,
} from '../AudioVideoSwitcherDialog';

const defaultProps: AudioVideoSwitcherDialogProps = {
    onCancel: action('cancel'),
    onConfirm: action('confirm'),
    onClose: action('close'),
    audioDevices: [],
    videoDevices: [],
    open: false,
};

const meta: Meta = {
    title: 'Modules/AudioVideoSwitcherDialog',
    component: AudioVideoSwitcherDialog,
    parameters: {
        fetchMock: {},
    },
};

export default meta;

export const Default = {
    args: {
        ...defaultProps,
        open: false,
    },
};
