import * as React from 'react';
import { ConfirmationDialog } from '@components/ConfirmationDialog/ConfirmationDialog';
import { DeviceSelectionComponent } from '@components/DeviceSelection/DeviceSelectionComponent';
import { submitDeviceChangeAnalytics } from '@services/analytics';
import { BlisseyLogger as Logger } from '@utils/Logger';
import { MediaDevice } from '@common/video/getDevices/MediaDevice';

export interface AudioVideoSwitcherDialogProps {
    onCancel: () => void;
    onConfirm: (deviceIds: {
        audioDeviceId: string;
        videoDeviceId: string;
    }) => void;
    onClose: () => void;
    open: boolean;
    defaultValue?: {
        audioDeviceId: string;
        videoDeviceId: string;
    };
    videoDevices: MediaDevice[];
    audioDevices: MediaDevice[];
}

export const AudioVideoSwitcherDialog: React.FC<
    AudioVideoSwitcherDialogProps
> = ({
    onCancel,
    onConfirm,
    onClose,
    open,
    audioDevices,
    videoDevices,
    defaultValue,
}) => {
    const [audioDeviceId, setAudioDeviceId] = React.useState('');
    const [videoDeviceId, setVideoDeviceId] = React.useState('');

    const handleConfirm = () => {
        if (typeof onConfirm === 'function') {
            onConfirm({
                audioDeviceId,
                videoDeviceId,
            });
        }
    };
    const handleAudioChange = (deviceId: string) => {
        setAudioDeviceId(deviceId);
    };

    const handleVideoChange = (deviceId: string) => {
        setVideoDeviceId(deviceId);
    };

    React.useEffect(() => {
        defaultValue?.audioDeviceId &&
            setAudioDeviceId(defaultValue.audioDeviceId);
        defaultValue?.videoDeviceId &&
            setVideoDeviceId(defaultValue.videoDeviceId);
    }, [defaultValue]);

    return (
        <ConfirmationDialog
            onCancel={onCancel}
            onConfirm={handleConfirm}
            onClose={onClose}
            open={open}
        >
            <>
                <h2>Choose Audio and Video Device</h2>
                <DeviceSelectionComponent
                    onAudioChange={(e) => {
                        Logger.debug(
                            {
                                deviceID: e.target.value,
                            },
                            'audio device change',
                        );
                        submitDeviceChangeAnalytics('audio');
                        handleAudioChange(e.target.value);
                    }}
                    onCameraChange={(e) => {
                        Logger.debug(
                            {
                                deviceID: e.target.value,
                            },
                            'video device change',
                        );
                        submitDeviceChangeAnalytics('video');
                        handleVideoChange(e.target.value);
                    }}
                    videoDevices={videoDevices}
                    audioDevices={audioDevices}
                    selectedAudio={audioDeviceId}
                    selectedCamera={videoDeviceId}
                    disabled={false}
                />
            </>
        </ConfirmationDialog>
    );
};
