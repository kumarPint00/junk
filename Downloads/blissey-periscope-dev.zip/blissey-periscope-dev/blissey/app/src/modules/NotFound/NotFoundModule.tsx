import * as React from 'react';
import { NotFoundComponent } from '@components/NotFound/NotFoundComponent';
import { submitGTMPageViewEvent } from '@services/analytics';
import { FooterPage } from '../../layout/PageLayout/FooterPage';
import { Logger } from '../../utils';
import { jwtTokenHelper } from '@utils/jwt-helper';

import { Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
export interface NotFoundModuleProps {
    isProvider: boolean;
    invalidVisitReason: string | null;
    isTokBoxTokenError: boolean;
    tokboxTokenErrorMessage: string | null;
    visitId: string | undefined;
}
export class NotFoundModule extends React.Component<NotFoundModuleProps> {
    public componentDidMount() {
        const { visitId } = this.props;
        Analytics.sendPageView({
            destinationURL: window.location.pathname,
            pageName: '404 Page Not Found',
        });
        submitGTMPageViewEvent(visitId);

        Logger.info(
            {
                eventType: 'CatchPage',
                eventName: 'Client catch page hit',
                eventSource: 'app/src/modules/NotFound > NotFoundModule',
            },
            `User reached the client catch page`,
        );

        jwtTokenHelper.clearAuthenticationToken();
    }

    public render() {
        const {
            isProvider,
            invalidVisitReason,
            isTokBoxTokenError,
            tokboxTokenErrorMessage,
        } = this.props;
        return (
            <FooterPage>
                <NotFoundComponent
                    isProvider={isProvider}
                    invalidVisitReason={invalidVisitReason}
                    isTokBoxTokenError={isTokBoxTokenError}
                    tokboxTokenErrorMessage={tokboxTokenErrorMessage}
                />
            </FooterPage>
        );
    }
}
