import { NotFoundModule } from '../NotFoundModule';

export const Default = {
    args: {
        isProvider: true,
    },
};

export default {
    title: 'Modules/NotFound',
    component: NotFoundModule,
};
