import { HealthInfo } from '@common/ConnectionTest/HealthInfo';
import { TState as HealthState } from '@redux/modules/health';

import { ConferenceError } from './ConferenceError';
import type { NavigateFunction } from 'react-router-dom';

export type EndCallReasons =
    | 'remote'
    | 'user'
    | 'unmount'
    | 'declined'
    | 'done'
    | 'cancelled';

export interface VideoCallModuleProps {
    brand: string;
    setCallStartTime(time: number): void;
    setCallEndTime(time: number): void;
    health: HealthState;
    healthInfo: HealthInfo;
    isTestVisit?: boolean;
    callStartTime: number | null;
    tokBoxVideoSessionId: string;
    tokBoxVideoToken?: string;
    fetchVisitDetails: () => void;
    navigate: NavigateFunction;
}

export interface VideoCallModuleState {
    conferenceError: ConferenceError;
    providerSelfCheckCompleted: boolean;
    // tokbox video conference
    otConnectionStatus: string; // todo
    otSessionStarted: boolean;
    otRemoteConnectionDetected: boolean;
}
