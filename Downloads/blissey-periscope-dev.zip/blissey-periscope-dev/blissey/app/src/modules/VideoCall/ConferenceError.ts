export enum ConferenceError {
    JoinedElsewhere,
    ConferenceFull,
    NetworkIssues,
    Other,
    None,
}
