import * as React from 'react';
import * as redux from 'react-redux';
import thunk from '@redux/middleware/thunkShim';

import { TestStatus } from '@common/video';
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';
import VideoCallModule from '../VideoCallModule';
import configureMockStore from 'redux-mock-store';
import { MediaPermissionStatus } from '@redux/modules/health';
import { ErrorCode } from '@common/techCheckErrorMessages';
import { StoryFn } from '@storybook/react';
import { BrowserRouter, NavigateFunction } from 'react-router-dom';

const middlewares = [thunk];
const testState = {
    postconsult: {
        visitId: 'testVisitId',
        isTestVisit: false,
        isTokBox: false,
        waitingConferenceId: 'waitingconferenceid',
        videoConferenceId: 'videoconferenceid',
        consult: {},
    },
    usersettings: {
        audioDeviceId: 'audioDeviceId',
        videoDeviceId: 'videoDeviceId',
        setAudioDeviceId: () => undefined,
        setVideoDeviceId: () => undefined,
    },
    video: {
        localCamExists: true,
        localMicExists: true,
        isFullScreen: false,
        endCallConfirmation: false,
        isChatVisible: false,
    },
    instantMessage: {
        waitingInstantMessages: [],
        videoInstantMessages: [],
        waitingRoomHasUnread: false,
        videoHasUnread: false,
    },
    user: {
        userDetails: {
            id: '',
            displayName: '',
            givenName: '',
            familyName: '',
            email: '',
            token: '',
            expiration: -1,
        },
    },
    otConnection: {
        otConnectionStatus: 'sessionConnected',
    },
    runTests: () => undefined,
};

interface Args {
    brand: string;
    healthCheckStatus: keyof typeof HealthCheckStatus;
    callStartTime: number | null;
    tokBoxVideoSessionId: string;
    tokBoxVideoToken: string;
    healthCheckProgress: number;
    networkStatus: keyof typeof TestStatus;
    camStatus: keyof typeof TestStatus;
    camError?: null | ErrorCode;
    micStatus: keyof typeof TestStatus;
    micError?: null | ErrorCode;
    mediaPermissionStatus: MediaPermissionStatus;
    publishStatus: keyof typeof TestStatus;
}

const Template = ({
    brand,
    healthCheckProgress,
    networkStatus,
    camStatus,
    camError,
    micStatus,
    micError,
    mediaPermissionStatus,
    publishStatus,
    healthCheckStatus,
    callStartTime,
    tokBoxVideoSessionId,
    tokBoxVideoToken,
}: Args) => {
    const health = {
        healthCheckProgress,
        networkStatus: (networkStatus
            ? TestStatus[networkStatus]
            : TestStatus.NotRun) as TestStatus,
        camStatus: camStatus && TestStatus[camStatus],
        camError: camError || undefined,
        micStatus: micStatus && TestStatus[micStatus],
        micError: micError || undefined,
        mediaPermissionStatus,
        publishStatus: publishStatus && TestStatus[publishStatus],
    };
    const mockStore = configureMockStore(middlewares);
    const mockStoreWithState = mockStore({
        health,
        ...testState,
    });

    return (
        <BrowserRouter>
            <redux.Provider store={mockStoreWithState}>
                <VideoCallModule
                    {...{
                        brand,
                        setCallStartTime: (time: number) =>
                            console.log('setCallStartTime: ', time),
                        setCallEndTime: (time: number) =>
                            console.log('setCallEndTime: ', time),
                        navigate: ((route: string) =>
                            console.log(
                                'navigate: ',
                                route,
                            )) as NavigateFunction,
                        health,
                        healthInfo: {
                            healthCheckStatus:
                                HealthCheckStatus[healthCheckStatus],
                        },
                        isTestVisit: true,
                        callStartTime,
                        tokBoxVideoSessionId,
                        tokBoxVideoToken,
                        fetchVisitDetails: () =>
                            console.log('fetchVisitDetails'),
                    }}
                />
            </redux.Provider>
        </BrowserRouter>
    );
};

export const Default = Template.bind({}) as StoryFn<typeof Template>;
Default.args = {
    healthCheckStatus: 'Healthy',
    healthCheckProgress: 0,
    networkStatus: 'NotRun',
    camStatus: 'NotRun',
    camError: null,
    micStatus: 'NotRun',
    micError: null,
    mediaPermissionStatus: undefined,
    publishStatus: 'NotRun',
    callStartTime: null,
    tokBoxVideoSessionId: 'mock-session1',
    tokBoxVideoToken: 'mock-token',
    brand: 'swedish',
} as Args;

const testStatusOptions = {
    options: ['NotRun', 'Failed', 'Passed', 'Skipped'],
    control: 'select',
    defaultValue: 'NotRun',
};

const errorValues = [
    ...Object.values(ErrorCode).filter((m) => typeof m === 'string'),
];
const errorOptions = {
    options: errorValues,
};
export default {
    title: 'Modules/VideoCall',
    component: VideoCallModule,
    argTypes: {
        healthCheckStatus: {
            options: [
                ...Object.values(HealthCheckStatus).filter(
                    (m) => typeof m === 'string',
                ),
            ],
            control: 'select',
        },
        healthCheckProgress: {
            control: { type: 'range', min: 0, max: 100 },
        },
        networkStatus: { ...testStatusOptions },
        camStatus: { ...testStatusOptions },
        micStatus: { ...testStatusOptions },
        publishStatus: { ...testStatusOptions },
        camError: { ...errorOptions },
        micError: { ...errorOptions },
        mediaPermissionStatus: {
            options: [null, 'denied', 'allowed'],
        },
    },
};
