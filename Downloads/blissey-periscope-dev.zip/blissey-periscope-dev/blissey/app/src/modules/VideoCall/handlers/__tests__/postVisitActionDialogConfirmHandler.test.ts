import {
    PostVisitActions,
    SelectQueueOrProviderChangeType,
} from '@dexcare/circus-saturn';
import {
    postVisitActionDialogConfirmHandler,
    PostVisitActionDialogConfirmHandlerProps,
} from '../postVisitActionDialogConfirmHandler';
import { vi } from 'vitest';

const buildProps = (): PostVisitActionDialogConfirmHandlerProps => {
    return {
        postVisitAction: {
            selectedAction: PostVisitActions.Complete,
        },
        visitId: 'test-visit-id',
        actorId: 'test-actor-id',
        chargeVisit: vi.fn(),
        waiveVisit: vi.fn(),
        transferBackToQueue: vi.fn(),
        transferToAnotherProvider: vi.fn(),
        sendAnalytics: vi.fn(),
        sendEndCall: vi.fn(),
        convertModality: vi.fn(),
    };
};
describe('postVisitActionDialogConfirmHandler', () => {
    let props: PostVisitActionDialogConfirmHandlerProps;
    beforeEach(() => {
        props = buildProps();
    });
    afterEach(() => {
        vi.resetAllMocks();
    });

    it.each([
        [
            'charge',
            'chargeVisit',
            'sendEndCall',
            'error sending endCall signal for charge visit',
            () => {
                props.postVisitAction = {
                    selectedAction: PostVisitActions.Complete,
                };
            },
        ],
        [
            'waive',
            'waiveVisit',
            'sendEndCall',
            'error sending endCall signal for waive visit',
            () => {
                props.postVisitAction = {
                    selectedAction: PostVisitActions.Waive,
                    selectedWaiveReason: 'test',
                };
            },
        ],
    ])(
        '%s does not call analytics or dispatch on signaling error',
        async (_, dispatchMethod, signalMethod, errMessage, propsSetup) =>
            new Promise<void>((done) => {
                propsSetup();
                props[
                    signalMethod as keyof Pick<
                        PostVisitActionDialogConfirmHandlerProps,
                        'chargeVisit' | 'waiveVisit'
                    >
                ] = vi
                    .fn()
                    .mockImplementation((callback: (error: Error) => void) => {
                        callback(new Error('whoops'));
                    });
                postVisitActionDialogConfirmHandler(props, (err) => {
                    expect(props.sendAnalytics).not.toHaveBeenCalled();
                    expect(
                        props[
                            dispatchMethod as keyof Pick<
                                PostVisitActionDialogConfirmHandlerProps,
                                'chargeVisit' | 'waiveVisit'
                            >
                        ],
                    ).not.toHaveBeenCalled();
                    expect(err).toEqual({
                        name: 'OT signalling error',
                        message: errMessage,
                        innerError: new Error('whoops'),
                    });
                    done();
                });
            }),
    );

    it.each([
        [
            'charge',
            'chargeVisit',
            'sendEndCall',
            ['charge_visit'],
            ['test-visit-id'],
            () => {
                props.postVisitAction = {
                    selectedAction: PostVisitActions.Complete,
                };
            },
        ],
        [
            'waive',
            'waiveVisit',
            'sendEndCall',
            ['waive_visit', 'reason'],
            ['test-visit-id', 'reason'],
            () => {
                props.postVisitAction = {
                    selectedAction: PostVisitActions.Waive,
                    selectedWaiveReason: 'reason',
                };
            },
        ],
    ])(
        '%s calls analytics and dispatch in signaling callback',
        async (
            _,
            dispatchMethod,
            signalMethod,
            analyticsParams,
            dispatchParams,
            propsSetup,
        ) =>
            new Promise<void>((done) => {
                propsSetup();
                props[
                    signalMethod as keyof Pick<
                        PostVisitActionDialogConfirmHandlerProps,
                        'chargeVisit' | 'waiveVisit'
                    >
                ] = vi.fn().mockImplementation((callback: () => void) => {
                    callback();
                });
                postVisitActionDialogConfirmHandler(props, (err) => {
                    expect(err).toEqual(undefined);
                    expect(props.sendAnalytics).toHaveBeenCalledWith(
                        ...analyticsParams,
                    );
                    expect(
                        props[
                            dispatchMethod as keyof Pick<
                                PostVisitActionDialogConfirmHandlerProps,
                                'chargeVisit' | 'waiveVisit'
                            >
                        ],
                    ).toHaveBeenCalledWith(...dispatchParams);
                    done();
                });
            }),
    );

    it.each([
        [
            'transfer back to queue',
            'transferBackToQueue',
            ['unassign_visit'],
            ['test-visit-id'],
            () => {
                props.postVisitAction = {
                    selectedAction: PostVisitActions.Transfer,
                    selectedQueueOrProvider: {
                        type: SelectQueueOrProviderChangeType.Queue,
                        providerId: null,
                    },
                };
            },
        ],
        [
            'transfer to provider',
            'transferToAnotherProvider',
            ['transfer_visit', 'provider-id'],
            ['test-visit-id', 'provider-id'],
            () => {
                props.postVisitAction = {
                    selectedAction: PostVisitActions.Transfer,
                    selectedQueueOrProvider: {
                        type: SelectQueueOrProviderChangeType.Provider,
                        providerId: 'provider-id',
                    },
                };
            },
        ],
    ])(
        '%s calls analytics and dispatch',
        async (
            _,
            dispatchMethod,
            analyticsParams,
            dispatchParams,
            propsSetup,
        ) =>
            new Promise<void>((done) => {
                propsSetup();
                postVisitActionDialogConfirmHandler(props, (err) => {
                    expect(err).toEqual(undefined);
                    expect(props.sendAnalytics).toHaveBeenCalledWith(
                        ...analyticsParams,
                    );
                    expect(
                        props[
                            dispatchMethod as keyof Pick<
                                PostVisitActionDialogConfirmHandlerProps,
                                | 'transferBackToQueue'
                                | 'transferToAnotherProvider'
                            >
                        ],
                    ).toHaveBeenCalledWith(...dispatchParams);
                    done();
                });
            }),
    );

    it.each([
        [
            'convert modality',
            'convertModality',
            ['modality_conversion_reason', 'reason'],
            ['test-visit-id', 'reason'],
            () => {
                props.postVisitAction = {
                    selectedAction: PostVisitActions.Convert,
                    selectedModalityConversionReason: 'reason',
                };
            },
        ],
        [
            'convert modality (without actorId)',
            'convertModality',
            ['modality_conversion_reason', 'reason'],
            ['test-visit-id', 'reason'],
            () => {
                props.postVisitAction = {
                    selectedAction: PostVisitActions.Convert,
                    selectedModalityConversionReason: 'reason',
                };
            },
        ],
    ])(
        '%s calls analytics and dispatch',
        async (
            testName,
            dispatchMethod,
            analyticsParams,
            dispatchParams,
            propsSetup,
        ) =>
            new Promise<void>((done) => {
                propsSetup();
                if (testName.indexOf('without actorId') > -1) {
                    props.actorId = undefined;
                }
                postVisitActionDialogConfirmHandler(props, (err) => {
                    expect(err).toEqual(undefined);
                    expect(props.sendAnalytics).toHaveBeenCalledWith(
                        ...analyticsParams,
                    );
                    expect(
                        props[
                            dispatchMethod as keyof Pick<
                                PostVisitActionDialogConfirmHandlerProps,
                                'convertModality'
                            >
                        ],
                    ).toHaveBeenCalledWith(...dispatchParams);
                    done();
                });
            }),
    );

    it('does not send signalling event without waive reason', async () =>
        new Promise<void>((done) => {
            props.postVisitAction = {
                selectedAction: PostVisitActions.Waive,
            };
            postVisitActionDialogConfirmHandler(props, (err) => {
                expect(err).toEqual({
                    name: 'missing waive reason',
                    message: 'Please select a reason.',
                });
                expect(props.sendEndCall).not.toHaveBeenCalled();
                done();
            });
        }));

    it('does not send signalling event without provider id', async () =>
        new Promise<void>((done) => {
            props.postVisitAction = {
                selectedAction: PostVisitActions.Transfer,
                selectedQueueOrProvider: {
                    type: SelectQueueOrProviderChangeType.Provider,
                    providerId: null,
                },
            };
            postVisitActionDialogConfirmHandler(props, (err) => {
                expect(err).toEqual({
                    name: 'missing provider',
                    message: 'Please select a provider.',
                });
                expect(props.sendAnalytics).not.toHaveBeenCalled();
                expect(props.transferToAnotherProvider).not.toHaveBeenCalled();
                done();
            });
        }));

    it('it does not send signalling event without transfer option', async () =>
        new Promise<void>((done) => {
            props.postVisitAction = {
                selectedAction: PostVisitActions.Transfer,
            };
            postVisitActionDialogConfirmHandler(props, (err) => {
                expect(err).toEqual({
                    name: 'missing transfer option',
                    message: 'Please select a transfer option.',
                });
                expect(props.sendAnalytics).not.toHaveBeenCalled();
                expect(props.transferToAnotherProvider).not.toHaveBeenCalled();
                expect(props.transferBackToQueue).not.toHaveBeenCalled();
                done();
            });
        }));

    it('does not send signalling event without modality conversion reason', async () =>
        new Promise<void>((done) => {
            props.postVisitAction = {
                selectedAction: PostVisitActions.Convert,
            };
            postVisitActionDialogConfirmHandler(props, (err) => {
                expect(err).toEqual({
                    name: 'missing modality conversion reason',
                    message: 'Please select a modality conversion reason.',
                });
                expect(props.sendEndCall).not.toHaveBeenCalled();
                done();
            });
        }));
});
