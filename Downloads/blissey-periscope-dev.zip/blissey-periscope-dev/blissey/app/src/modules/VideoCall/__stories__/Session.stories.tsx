import * as React from 'react';
import { Provider } from 'react-redux';
import configureMockStore from 'redux-mock-store';
import thunk from '@redux/middleware/thunkShim';
import { initialState, Store } from '@redux/modules';

import Session, { SessionProps } from '../Session';
import { TestStatus } from '@common/video';
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';
import { VideoCallRenderState } from '../VideoCallRenderState';
import { Meta } from '@storybook/react/*';

const waitingRoomSessionId =
    '1_MX40NjQ5NzM1Mn5-MTYxODM1NDk0OTM2OH5DZllvRnVzbFlsWmhoSUNFcVJ2VFNJalF-UH4';
const videoSessionId =
    '2_MX40NjQ5NzM1Mn5-MTYxODM1NDk0OTM2Nn5COVhmQ2FhUTczYVJ5NklQVHRPVTZhMlB-UH4';

const state = (roles = ['telehealth_provider']): Store['All'] => ({
    ...initialState,
    postconsult: {
        ...initialState.postconsult,
        tokBoxWaitingRoomSessionId: waitingRoomSessionId,
        tokBoxVideoSessionId: videoSessionId,
    },
    user: {
        userDetails: {
            ...initialState.user.userDetails,
            roles,
        },
    },
});

const component = (state: Store['All'], props: SessionProps) => {
    const mockStore = configureMockStore([thunk]);
    const mockStoreWithState = mockStore(state);
    return (
        <Provider store={mockStoreWithState}>
            <Session {...props} />
        </Provider>
    );
};

const defaultProps = (): SessionProps => ({
    providerSelfCheckCompleted: false,
    handleSelfCheckClick: () => console.log('handleSelfCheckClick'),
    health: {
        healthCheckProgress: 0,
        networkStatus: TestStatus.NotRun,
        camStatus: TestStatus.NotRun,
        micStatus: TestStatus.NotRun,
        mediaPermissionStatus: undefined,
        publishStatus: TestStatus.NotRun,
    },
    healthInfo: {
        healthCheckStatus: HealthCheckStatus.Healthy,
    },
    brand: 'swedish',
    videoToken: '',
    waitingRoomToken: '',
    visitState: VideoCallRenderState.MultiParticipantDisplay,
    onCriticalError: () => console.log('onCriticalError'),
    updateStreamCount: () => console.log('updateStreamCount'),
    updateInstantMessages: () => {
        return () => console.log('updateInstantMessages');
    },
    onRemoteConnectionDetected: () => console.log('onRemoteConnectionDetected'),
    endCall: async () => {
        console.log('endCall');
        return Promise.resolve();
    },
    cancelVisit: () => console.log('cancelVisit'),
    onReconnect: () => console.log('onReconnect'),
    handleNotification: () => console.log('handleNotification'),
    modalityConversion: () => console.log('modalityConversion'),
    modalityConversionError: () => console.log('modalityConversionError'),
    endCallAndTransfer: () => console.log('endCallAndTransfer'),
    endCallAndTransferError: () => console.log('endCallAndTransferError'),
    navigate: () => console.log('navigate'),
});

const meta: Meta<typeof Session> = {
    title: 'Modules/Session',
    component: Session,
    decorators: [
        (story, { args }) => {
            const mockStore = configureMockStore([thunk]);
            const mockStoreWithState = mockStore({ ...state, ...args });
            return <Provider store={mockStoreWithState}>{story()}</Provider>;
        },
    ],
    parameters: {
        docs: { disable: true, hidden: true },
    },
};

export default meta;

export const ProviderInVisit = () => {
    return component(state(), defaultProps());
};

export const ProviderTytoCareInVisitTytoCareVisitNotStartedYet = () => {
    const providerState = {
        ...state(),
        tytoCare: {
            ...initialState.tytoCare,
            isTytoCareVisit: true,
            providerVisitUrl: '',
            error: '',
        },
    };
    return component(providerState, defaultProps());
};

export const ProviderTytoCareInVisitWithIframe = () => {
    const providerState = {
        ...state(),
        tytoCare: {
            ...initialState.tytoCare,
            isTytoCareVisit: true,
            providerVisitUrl:
                'https://www-stage1.tytocare.com/index.htm#/startOnlineVisit/KmOdaJzM/iZrl1RWPNYQISwkOfYRz4ayWw1U6L0EB5Uu7MoaeqgU*/true',
            error: '',
        },
    };
    return component(providerState, defaultProps());
};

export const ProviderTytoCareInVisitWithError = () => {
    const providerState = {
        ...state(),
        tytoCare: {
            ...initialState.tytoCare,
            isTytoCareVisit: true,
            providerVisitUrl:
                'https://www-stage1.tytocare.com/index.htm#/startOnlineVisit/KmOdaJzM/iZrl1RWPNYQISwkOfYRz4ayWw1U6L0EB5Uu7MoaeqgU*/true',
            error: 'Error creating TytoCare visit. One of the participants is already engaged in a TytoCare visit.  You may need to close out a previous visit in order to proceed.',
        },
    };
    return component(providerState, defaultProps());
};

export const EndCallTrue = () => {
    const providerState = {
        ...state(),
        video: {
            ...initialState.video,
            endCallConfirmation: true,
        },
    };
    return component(providerState, defaultProps());
};
