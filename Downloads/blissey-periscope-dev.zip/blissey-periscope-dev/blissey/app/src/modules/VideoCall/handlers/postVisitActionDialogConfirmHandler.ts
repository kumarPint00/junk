import {
    PostVisitActionChange,
    PostVisitActions,
    SelectQueueOrProviderChangeType,
} from '@dexcare/circus-saturn';

type TError = {
    name: string;
    message: string;
    innerError?: TError;
};
type callback = (error?: TError) => void;
type handler = (
    visitId: string,
    postVisitAction: PostVisitActionChange,
    callback: callback,
) => void;

export interface PostVisitActionDialogConfirmHandlerProps {
    postVisitAction: PostVisitActionChange | null;
    visitId: string;
    actorId?: string;
    chargeVisit: (visitId: string) => void;
    convertModality: (visitId: string, reason: string) => void;
    waiveVisit: (visitId: string, waiveReason: string) => void;
    transferBackToQueue: (visitId: string) => void;
    transferToAnotherProvider: (visitId: string, newProviderId: string) => void;
    sendAnalytics: (eventName: string, ...params: string[]) => void;
    sendEndCall: (callback: callback) => void;
}

export const postVisitActionDialogConfirmHandler = (
    {
        postVisitAction,
        visitId,
        chargeVisit,
        convertModality,
        waiveVisit,
        transferBackToQueue,
        transferToAnotherProvider,
        sendAnalytics,
        sendEndCall,
    }: PostVisitActionDialogConfirmHandlerProps,
    callback: callback,
) => {
    const transferObj: Record<string, handler> = {
        [SelectQueueOrProviderChangeType.Queue]: (vId, _pva, c) => {
            sendAnalytics('unassign_visit');
            transferBackToQueue(vId);
            c();
        },
        [SelectQueueOrProviderChangeType.Provider]: (vId, pva, c) => {
            const providerId = pva?.selectedQueueOrProvider?.providerId;
            if (!providerId) {
                c({
                    name: 'missing provider',
                    message: 'Please select a provider.',
                });
                return;
            }
            sendAnalytics('transfer_visit', providerId);
            transferToAnotherProvider(vId, providerId);
            c();
        },
    };
    const actionObj: Record<string, handler> = {
        [PostVisitActions.Complete]: (vId, _pva, c) => {
            // TODO: move this signal call into visit service
            sendEndCall((error) => {
                if (error) {
                    c({
                        name: 'OT signalling error',
                        message:
                            'error sending endCall signal for charge visit',
                        innerError: error,
                    });
                    return;
                }
                sendAnalytics('charge_visit');
                chargeVisit(vId);
                c();
            });
        },
        [PostVisitActions.Waive]: (vId, pva, c) => {
            const selectedWaiveReason = pva.selectedWaiveReason;
            if (!selectedWaiveReason) {
                c({
                    name: 'missing waive reason',
                    message: 'Please select a reason.',
                });
                return;
            }
            // TODO: move this signal call into visit service
            sendEndCall((error) => {
                if (error) {
                    c({
                        name: 'OT signalling error',
                        message: 'error sending endCall signal for waive visit',
                        innerError: error,
                    });
                    return;
                }
                sendAnalytics('waive_visit', selectedWaiveReason);
                waiveVisit(vId, selectedWaiveReason);
                c();
            });
        },
        [PostVisitActions.Transfer]: (vId, pva, c) => {
            if (!pva?.selectedQueueOrProvider?.type) {
                c({
                    name: 'missing transfer option',
                    message: 'Please select a transfer option.',
                });
                return;
            }
            transferObj[pva.selectedQueueOrProvider.type](vId, pva, c);
        },
        [PostVisitActions.Convert]: (vId, pva, c) => {
            if (!pva.selectedModalityConversionReason) {
                c({
                    name: 'missing modality conversion reason',
                    message: 'Please select a modality conversion reason.',
                });

                return;
            }

            sendAnalytics(
                'modality_conversion_reason',
                pva.selectedModalityConversionReason,
            );
            convertModality(vId, pva.selectedModalityConversionReason);
            c();
        },
    };

    if (
        postVisitAction?.selectedAction &&
        typeof actionObj[postVisitAction.selectedAction] === 'function'
    ) {
        actionObj[postVisitAction.selectedAction](
            visitId,
            postVisitAction,
            callback,
        );
    }
};
