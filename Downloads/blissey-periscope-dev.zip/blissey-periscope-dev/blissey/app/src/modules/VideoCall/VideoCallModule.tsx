import * as React from 'react';
import * as Redux from 'react-redux';
import { Action } from 'redux';

import { isProvider, UserDetails, InstantMessageItemProps } from '@dexcare/circus-saturn';
import { Logger, Counted, LogManager, config } from '@dexcare/circus-jupiter';

import { Store } from '../../redux/modules';

import {
    cancelVisit,
    chargeVisit,
    setMessageDialog,
    setPostVisitActionErrorMessage as postConsultVisitReduxSetPostVisitActionErrorMessage,
    TState,
} from '@redux/modules/postConsult';
import * as Notification from '@utils/Notification';
import { ConferenceErrorComponent } from '../../components/ConferenceError/ConferenceErrorComponent';
import {
    endRoute,
    FeatureFlags,
    getClosedVisitRoute,
    getFeatureFlag,
    paymentRoute,
    postConsultRoute,
    postVisitPatientSurveyRoute,
    postVisitProviderSurveyRoute,
} from '../../utils';
import {
    EndCallReasons,
    VideoCallModuleProps,
    VideoCallModuleState,
} from './VideoCallInterfaces';
import { VideoCallRenderState } from './VideoCallRenderState';

import {
    addVideoInstantMessage,
    addWaitingInstantMessage,
    setVideoHasUnread,
    setWaitingRoomHasUnread,
} from '@redux/modules/instantMessage';
import {
    resetVideoControls,
    setCancelButtonVisible,
    setInstructionVideoVisible,
    setIsChatVisible,
    setIsFullScreen,
} from '@redux/modules/videoMenu';
import OTSession from './Session';

import {
    ModalityConversionError,
    EndCallAndTransferError,
    InstantMessage,
    BotPromptMessage,
} from '@dexcare/yak';
import {
    instantMessageToInstantMessageItemProps,
    OTConnection,
} from '@utils/otUtils';
import { getDuration } from '@utils/callDuration';
import { ConferenceError } from './ConferenceError';
import { isHealthCheckRunning } from '@redux/modules/health';
import { TestStatus } from '@common/video';
import { submitGTMPageViewEvent } from '@services/analytics';

import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './VideoCallModule.css';
import { Configuration } from 'types/configuration';
import { Doc } from 'types/global';
import { ThunkDispatch } from 'types/redux';

interface StateProps {
    isFullScreen: boolean;
    isChatVisible: boolean;
    endCallConfirmation: boolean;
    waitingInstantMessages: InstantMessageItemProps[];
    videoInstantMessages: InstantMessageItemProps[];
    waitingRoomHasUnread: boolean;
    videoHasUnread: boolean;
    userDetails: UserDetails;
    otConnectionStatus?: OTConnection;
    visitId: string;
    patientGuid: string;
    providerId: string | null;
    tokBoxWaitingRoomSessionId: string;
    tokBoxWaitingRoomToken: string;
    publishStatus: TestStatus;
    callEndTime: number | null;
}
interface DispatchProps {
    setFullScreen: (fullScreen: boolean) => void;
    setIsChatVisible: (isChatVisible: boolean) => void;
    addWaitingInstantMessages: (message: InstantMessageItemProps) => void;
    addVideoInstantMessage: (message: InstantMessageItemProps) => void;
    setVideoHasUnread: (hasUnread: boolean) => void;
    setWaitingRoomHasUnread: (hasUnread: boolean) => void;
    setIsFullScreen: (fullScreen: boolean) => void;
    chargeVisit(visitId: string): Promise<void>;
    resetVideoControls: () => void;
    cancelVisit(): void;
    setMessageDialog(value: string): Promise<void>;
    setInstructionVideoVisible: (val: boolean) => void;
    setCancelButtonVisible: (val: boolean) => void;
    setPostVisitActionErrorMessage: (val: string) => void;
}

interface Details {
    conferenceError: ConferenceError;
    endCallConfirmation: boolean;
    message: string;
}

export type Props = StateProps & VideoCallModuleProps & DispatchProps;
const mapStateToProps = (state: Store['All']): StateProps => {
    return {
        userDetails: state.user.userDetails,
        visitId: state.postconsult.visitId,
        patientGuid: state.postconsult.patientGuid,
        providerId: state.postconsult.providerId,
        tokBoxWaitingRoomSessionId:
            state.postconsult.tokBoxWaitingRoomSessionId || '',
        tokBoxWaitingRoomToken: state.postconsult.tokBoxWaitingRoomToken || '',
        publishStatus: state.health.publishStatus,
        callEndTime: state.postconsult.callEndTime,
        ...state.instantMessage,
        ...state.video,
    };
};
const mapDispatchToProps: Redux.MapDispatchToPropsParam<
    ThunkDispatch<Store['All'] | TState, unknown, Action>,
    VideoCallModuleProps
> = (dispatch: ThunkDispatch<Store['All'] | TState, unknown, Action>) => {
    return {
        setFullScreen: (fullScreen: boolean) =>
            dispatch(setIsFullScreen(fullScreen)),
        setIsChatVisible: (isChatVisible: boolean) =>
            dispatch(setIsChatVisible(isChatVisible)),
        addWaitingInstantMessages: (message: InstantMessageItemProps) =>
            dispatch(addWaitingInstantMessage(message)),
        addVideoInstantMessage: (message: InstantMessageItemProps) =>
            dispatch(addVideoInstantMessage(message)),
        setVideoHasUnread: (hasUnread: boolean) =>
            dispatch(setVideoHasUnread(hasUnread)),
        setWaitingRoomHasUnread: (hasUnread: boolean) =>
            dispatch(setWaitingRoomHasUnread(hasUnread)),
        setIsFullScreen: (fullScreen: boolean) =>
            dispatch(setIsFullScreen(fullScreen)),
        chargeVisit: async (visitId: string) => dispatch(chargeVisit(visitId)),
        cancelVisit: async () => dispatch(cancelVisit()),
        resetVideoControls: () => dispatch(resetVideoControls()),
        setMessageDialog: (value: string) => dispatch(setMessageDialog(value)),
        setInstructionVideoVisible: (val: boolean) =>
            dispatch(setInstructionVideoVisible(val)),
        setPostVisitActionErrorMessage: (val: string) =>
            dispatch(postConsultVisitReduxSetPostVisitActionErrorMessage(val)),
        setCancelButtonVisible: (val: boolean) =>
            dispatch(setCancelButtonVisible(val)),
    };
};

export const SELF_SENDER_NAME = 'You';

export class VideoCallModule extends React.Component<
    Props,
    VideoCallModuleState
> {
    private logger: Logger;
    private instantMessageConferenceId: string;
    private endVisitEarlyForProvider: boolean;

    constructor(props: Props) {
        super(props);
        this.instantMessageConferenceId = props.tokBoxVideoSessionId;
        this.endVisitEarlyForProvider =
            (config as Configuration).getConfig().endVisitEarlyForProvider ||
            false;

        this.state = {
            conferenceError: ConferenceError.None,
            providerSelfCheckCompleted: false,
            // TOKBOX
            otConnectionStatus: '',
            otSessionStarted: false,
            otRemoteConnectionDetected: false,
        };

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'VideoCallModule',
                userId: this.props.userDetails.id,
                visitId: this.props.visitId,
                isTestVisit: this.props.isTestVisit,
            },
            true,
        );
    }

    private setConferenceId = (renderState: VideoCallRenderState) => {
        const { tokBoxVideoSessionId, tokBoxWaitingRoomSessionId } = this.props;
        switch (renderState) {
            case VideoCallRenderState.PatientWaitingRoom:
                this.instantMessageConferenceId = tokBoxWaitingRoomSessionId;
                break;
            case VideoCallRenderState.AnteRoom:
                break;
            default:
                this.instantMessageConferenceId = tokBoxVideoSessionId;
        }
    };

    public render() {
        const renderState: VideoCallRenderState = this.getTokboxRenderState();
        this.setConferenceId(renderState);

        switch (renderState) {
            case VideoCallRenderState.ConferenceError: {
                const conferenceMessageKey =
                    ConferenceError[this.state.conferenceError];
                return (
                    <div className={styles.conferenceErrorMain}>
                        <ConferenceErrorComponent
                            conferenceMessageKey={conferenceMessageKey}
                        />
                    </div>
                );
            }
            default:
                return (
                    <OTSession
                        navigate={this.props.navigate}
                        brand={this.props.brand}
                        health={this.props.health}
                        healthInfo={this.props.healthInfo}
                        providerSelfCheckCompleted={
                            this.state.providerSelfCheckCompleted
                        }
                        cancelVisit={this.cancelVisit}
                        handleSelfCheckClick={this.handleSelfCheckClick}
                        visitState={renderState}
                        onReconnect={() => this.onReconnect()}
                        updateInstantMessages={this.onTokBoxInstantMessage}
                        videoToken={this.props.tokBoxVideoToken || ''}
                        waitingRoomToken={this.props.tokBoxWaitingRoomToken}
                        onCriticalError={this.handleOTCriticalError}
                        onRemoteConnectionDetected={
                            this.setRemoteConnectionDetected
                        }
                        updateStreamCount={this.updateVideoStreamCount}
                        handleNotification={this.handleNotification}
                        endCall={this.endCall}
                        endCallAndTransfer={this.endCallAndTransfer}
                        endCallAndTransferError={this.endCallAndTransferError}
                        modalityConversion={this.modalityConversion}
                        modalityConversionError={this.modalityConversionError}
                    />
                );
        }
    }

    private isProvider = () => {
        return isProvider(this.props.userDetails);
    };

    private updateVideoStreamCount = (streamNumber: number) => {
        if (streamNumber > 0 && !this.state.otSessionStarted) {
            // remote participant has joined so start the session
            this.logger.info(`stream count updating to: ${streamNumber}`);
            this.setState({ otSessionStarted: true });
            this.setCallStartTime();
            this.props.setIsChatVisible(false);

            this.submitSessionAnalytics('start');
        }
    };

    private getTokboxRenderState = (): VideoCallRenderState => {
        if (this.state.conferenceError !== ConferenceError.None) {
            return VideoCallRenderState.ConferenceError;
        } else if (this.isProviderAnteRoom()) {
            return VideoCallRenderState.AnteRoom;
        } else if (this.isPatientWaitingRoom()) {
            return VideoCallRenderState.PatientWaitingRoom;
        }
        return VideoCallRenderState.MultiParticipantDisplay;
    };

    private handleOTCriticalError = (error: ConferenceError) => {
        this.setState({ conferenceError: error });
    };

    private isPatientWaitingRoom = (): boolean => {
        if (this.isProvider()) {
            return false;
        }
        return (
            !this.state.otSessionStarted ||
            isHealthCheckRunning(this.props.health.healthCheckProgress) ||
            // give the patient time to fix their devices - if they are bumped into the video visit
            // they won't be seen or heard
            this.props.publishStatus !== TestStatus.Passed
        );
    };

    private setRemoteConnectionDetected = () => {
        this.logger.info('tokbox remote connection detected');
        this.setState({ otRemoteConnectionDetected: true });
    };

    public isProviderAnteRoom = () => {
        // no need to check for media failures here - the providers join on a manual
        // button click so they have time to fix their media issues
        return (
            this.isProvider() &&
            (!this.state.providerSelfCheckCompleted ||
                !this.state.otRemoteConnectionDetected)
        );
    };

    private addInstantMessage = (
        messageConferenceId: string,
        newMessage: InstantMessageItemProps,
    ) => {
        if (
            messageConferenceId === this.instantMessageConferenceId &&
            !this.isProviderAnteRoom()
        ) {
            this.props.setIsChatVisible(true);
        }
        if (
            !Notification.isDocumentVisible() &&
            !newMessage.isOutgoing &&
            !this.isProvider()
        ) {
            Notification.notifyUser(
                'You have a new Chat message',
                Notification.NotificationType.chat,
            );
        }

        const eventName =
            newMessage.isOutgoing !== this.isProvider()
                ? 'user chat sent'
                : 'provider chat sent';
        Analytics.sendEvent({
            eventAction: 'chatMsg',
            eventName,
            type: 'chat',
        });
        if (messageConferenceId === this.props.tokBoxVideoSessionId) {
            this.props.addVideoInstantMessage(newMessage);
            this.props.setVideoHasUnread(true);
        } else {
            this.props.addWaitingInstantMessages(newMessage);
            this.props.setWaitingRoomHasUnread(true);
        }
    };

    public handleSelfCheckClick = (): void => {
        this.setState({ providerSelfCheckCompleted: true });
    };

    public handleNotification = (): void => {
        if (!this.isProvider()) {
            const {
                notificationText: { newNotificationText },
            } = (config as Configuration).getConfig();
            Notification.notifyUser(
                newNotificationText,
                Notification.NotificationType.alert,
            );
        }
    };

    public componentDidMount() {
        this.logger.info({
            eventType: 'pageView',
            details: { isProvider: this.isProvider(), isMount: true },
        });
        submitGTMPageViewEvent(this.props.visitId);

        try {
            Notification.initNotifications();
        } catch {
            this.logger.info(
                {
                    eventType: 'Notification',
                    eventName: 'Notifications Not Initialized',
                    eventSource: 'utils/Notification > initNotifications',
                },
                `Notifications Not Initialized - probably a mobile browser visit`,
            );
        }
        document.addEventListener(
            'webkitfullscreenchange',
            this.onFullscreenchange,
            false,
        );
        document.addEventListener(
            'mozfullscreenchange',
            this.onFullscreenchange,
            false,
        );
        document.addEventListener(
            'fullscreenchange',
            this.onFullscreenchange,
            false,
        );
        window.addEventListener('beforeunload', this.browserCloseEvent, false);
    }

    public componentDidUpdate(
        _prevProps: Readonly<Props>,
        prevState: Readonly<VideoCallModuleState>,
    ): void {
        const details: Details = this.getStateForPageViewLog(
            prevState,
            this.state,
            _prevProps,
        );
        if (Object.keys(details).length > 0) {
            this.logger.info(
                { eventType: 'pageView', details },
                details.message,
            );
        }

        if (this.props.isChatVisible !== _prevProps.isChatVisible) {
            Analytics.sendEvent({
                eventAction: this.props.isChatVisible ? 'chatStart' : 'chatEnd',
                eventName: this.props.isChatVisible
                    ? 'chat start'
                    : 'chat ended',
                type: 'chat',
            });

            if (!this.props.isChatVisible) {
                V2Analytics.interactionEvent({
                    eventName: 'chat_close',
                    visit_id: this.props.visitId,
                });
            }
        }
    }

    public componentWillUnmount() {
        document.removeEventListener(
            'webkitfullscreenchange',
            this.onFullscreenchange,
            false,
        );
        document.removeEventListener(
            'mozfullscreenchange',
            this.onFullscreenchange,
            false,
        );
        document.removeEventListener(
            'fullscreenchange',
            this.onFullscreenchange,
            false,
        );
        window.removeEventListener(
            'beforeunload',
            this.browserCloseEvent,
            false,
        );
        Analytics.sendEvent({
            eventAction: 'videoEnd',
            eventName: 'Video Conference End',
            type: 'success',
        });

        this.submitSessionAnalytics('complete');
    }

    public submitSessionAnalytics = (status = '') => {
        const { callStartTime, callEndTime, patientGuid, providerId, visitId } =
            this.props;
        if (!providerId) this.props.fetchVisitDetails();

        const { durationNumber, durationString } = getDuration(
            callStartTime,
            callEndTime,
        );
        if (status === 'start' && durationNumber > 0) {
            V2Analytics.interactionEvent({
                eventName: 'patient_rejoins',
                patient_id: patientGuid,
                visit_id: visitId,
            });
        } else {
            V2Analytics.interactionEvent({
                eventName: `virtual_session_${status}`,
                duration: durationString,
                visit_id: visitId,
                ...(this.isProvider() && { patient_id: patientGuid }),
                ...(!this.isProvider() && { provider_id: providerId }),
            });
        }
    };

    // TODO tokbox logs
    private getStateForPageViewLog(
        prevState: VideoCallModuleState,
        currentState: VideoCallModuleState,
        prevProps: Props,
    ): Details {
        const details = {} as Details;
        if (prevState.conferenceError !== currentState.conferenceError) {
            details.conferenceError = currentState.conferenceError;
        }
        if (prevProps.endCallConfirmation !== this.props.endCallConfirmation) {
            details.endCallConfirmation = this.props.endCallConfirmation;
            details.message = `End call confirmation state changed to ${
                details.endCallConfirmation as unknown as string
            }`;
        }
        return details;
    }

    private onFullscreenchange = (): void => {
        // listener for when the user hits the 'escape' button instead of clicking
        // the fullscreen button
        const doc: Doc = window.document;
        this.props.setIsFullScreen(
            !!(
                doc.fullscreenElement ||
                doc.webkitFullscreenElement ||
                doc.mozFullScreenElement
            ),
        );
    };

    private endCall = async (trigger: EndCallReasons): Promise<void> => {
        if (this.props.isFullScreen) {
            this.props.setFullScreen(!this.props.isFullScreen);
        }

        const { visitId, brand } = this.props;

        this.logger.info({
            eventName: 'endCall',
            details: { trigger },
        });

        this.props.setCallEndTime(Date.now());

        const enablePostVisitSurveyConfig = getFeatureFlag(
            FeatureFlags.enablePostVisitSurveyConfig,
        );

        if (trigger === 'declined') {
            this.props.navigate(getClosedVisitRoute('staffdeclined', false));
        } else if (trigger === 'cancelled') {
            this.props.navigate(getClosedVisitRoute('cancelled', false));
        } else if (trigger === 'done') {
            if (this.state.otSessionStarted) {
                if (enablePostVisitSurveyConfig) {
                    if (this.isProvider()) {
                        this.props.navigate(
                            postVisitProviderSurveyRoute(visitId, brand),
                        );
                    } else {
                        this.props.navigate(
                            postVisitPatientSurveyRoute(visitId, brand),
                        );
                    }
                } else {
                    this.props.navigate(postConsultRoute(visitId, brand));
                }
            } else {
                this.props.navigate(endRoute(brand));
            }
        } else {
            if (this.endVisitEarlyForProvider && this.isProvider()) {
                try {
                    await this.props.chargeVisit(this.props.visitId);
                } catch (err: unknown) {
                    this.logger.error(
                        {
                            eventType: 'chargeVisit',
                            eventName: 'VideoCallModule.endCall',
                            err,
                        },
                        'Error with charging visit',
                    );
                }
            }

            if (!this.isProvider() || trigger !== 'remote') {
                this.props.navigate(this.getEndCallRedirectRoute());
            }
        }
    };

    private endCallAndTransfer = (): void => {
        this.logger.info({
            eventName: 'endCallAndTransfer',
        });

        const enablePostVisitSurveyConfig = getFeatureFlag(
            FeatureFlags.enablePostVisitSurveyConfig,
        );

        if (this.isProvider()) {
            enablePostVisitSurveyConfig
                ? this.props.navigate(
                      postVisitProviderSurveyRoute(
                          this.props.visitId,
                          this.props.brand,
                      ),
                  )
                : this.props.navigate(
                      postConsultRoute(this.props.visitId, this.props.brand),
                  );
        } else {
            // this should result in the the state being reset to the waiting room
            this.setState({ otSessionStarted: false });
            // display "another provider will be with you" message dialog
            void this.props.setMessageDialog(
                'Another provider will be with you shortly.',
            );
            // reset video controls
            this.props.resetVideoControls();
            // don't show the waiting room video again
            this.props.setInstructionVideoVisible(false);
            // hide cancel after first interaction with provider
            this.props.setCancelButtonVisible(false);
        }
    };

    private endCallAndTransferError = (data: EndCallAndTransferError): void => {
        this.logger.info({
            eventName: 'endCallAndTransferError',
            data,
        });
        if (this.isProvider()) {
            // set error
            // NOTE: maybe branch based on error code?
            this.props.setPostVisitActionErrorMessage(
                'An error occurred trying to transfer the visit. Please try again.',
            );
        }
    };

    private modalityConversion = (): void => {
        this.logger.info({
            eventName: 'modalityConversion',
        });

        this.props.navigate(getClosedVisitRoute('waitingroom', false, true));
    };

    private modalityConversionError = (data: ModalityConversionError): void => {
        this.logger.info({
            eventName: 'modalityConversion',
            data,
        });
        if (this.isProvider()) {
            this.props.setPostVisitActionErrorMessage(
                'An error occurred trying to convert visit modality. Please try again.',
            );
        }
    };

    private cancelVisit = (): void => {
        window.removeEventListener(
            'beforeunload',
            this.browserCloseEvent,
            false,
        );
        return this.props.cancelVisit();
    };

    private getEndCallRedirectRoute() {
        let newRoute = '/';
        const { brand, visitId } = this.props;

        const enablePostVisitSurveyConfig = getFeatureFlag(
            FeatureFlags.enablePostVisitSurveyConfig,
        );

        if (this.state.otSessionStarted) {
            if (this.isProvider() && !this.endVisitEarlyForProvider) {
                newRoute = paymentRoute(visitId, brand);
            } else {
                if (enablePostVisitSurveyConfig) {
                    if (this.isProvider()) {
                        newRoute = postVisitProviderSurveyRoute(visitId, brand);
                    } else {
                        newRoute = postVisitPatientSurveyRoute(visitId, brand);
                    }
                } else {
                    newRoute = postConsultRoute(visitId, brand);
                }
            }
        } else {
            newRoute = endRoute(brand);
        }
        return newRoute;
    }

    private setCallStartTime = () => {
        const { callStartTime, setCallStartTime } = this.props;
        if (!callStartTime) {
            setCallStartTime(new Date().getTime());
        }
    };

    @Counted
    private onReconnect(): void {
        window.location.reload();
    }

    private browserCloseEvent = (evt: BeforeUnloadEvent) => {
        this.logger.info(
            {
                eventType: 'userAction',
                eventName: 'reloadOrCloseTab',
            },
            'The browser was refreshed or closed, or the close dialog is shown',
        );
        // Note: Modern browsers do not actually show this message, its here just for legacy browsers
        const dialogPrompt = 'Are you sure you want to leave the call?';
        evt = evt || window.event;
        if (evt) {
            evt.returnValue = dialogPrompt;
        }
        return dialogPrompt;
    };

    private onTokBoxInstantMessage =
        (sessionId: string) =>
        (instantMessage: InstantMessage | BotPromptMessage) => {
            const { userDetails } = this.props;
            this.addInstantMessage(
                sessionId,
                instantMessageToInstantMessageItemProps(
                    instantMessage,
                    userDetails,
                ),
            );
        };
}

export default Redux.connect<StateProps, DispatchProps, VideoCallModuleProps>(
    mapStateToProps,
    mapDispatchToProps,
)(VideoCallModule);
