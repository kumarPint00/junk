export enum VideoCallRenderState {
    ConferenceError,
    MultiParticipantDisplay,
    AnteRoom,
    PatientWaitingRoom,
}
