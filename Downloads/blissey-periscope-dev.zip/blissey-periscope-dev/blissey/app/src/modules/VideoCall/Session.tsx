import * as React from 'react';
import * as Redux from 'react-redux';
import { Action } from 'redux';
import { isProvider, PostVisitActionChange } from '@dexcare/circus-saturn';
import { UserDetails } from '../../types/UserDetails';
import { Logger as BlisseyLogger, getClosedVisitRoute } from '../../utils';
import {
    Event,
    Stream,
    Session,
    OTError,
    Connection,
    SessionHelper,
    ConnectionDestroyedEvent,
    StreamCreatedEvent,
    StreamDestroyedEvent,
    StreamPropertyChangedEvent,
    SessionStateChangeEvent,
    SessionDisconnectedEvent,
    TypingStateMessage,
    TypingState,
    SubscribeHandlers,
    InstantMessage,
    ParticipantDetailsEvent,
    IntegrationAlert,
    EndCallAndTransfer,
    EndCallAndTransferError,
    ModalityConversion,
    ModalityConversionError,
    PatientEnterWaitOfflineSuccess,
    PatientEnterWaitOfflineError,
    EventCallback,
    BotPromptMessage,
} from '@dexcare/yak';
import {
    createOutGoingMessage,
    otLostConnection,
    OTConnection,
    OTPublishingStatus,
    OTSubscribingStatus,
    streamTargetElement,
} from '@utils/otUtils';
import { AnteRoomComponent } from '@components/AnteRoom/AnteRoomComponent';
import { EndCallDialog } from './EndCallDialog';
import { Store } from '@redux/modules';
import { WaitingRoomComponent } from '@components/WaitingRoom/WaitingRoomComponent';
import { HealthInfo } from '@common/ConnectionTest/HealthInfo';
import {
    TState as InstantMessageState,
    setVideoHasUnread,
    setWaitingRoomHasUnread,
} from '@redux/modules/instantMessage';
import { VideoCallRenderState } from './VideoCallRenderState';
import { ChatPage } from '@layout/PageLayout/ChatPage';
import {
    setIsCamEnabled,
    setIsMicEnabled,
    toggleIsChatVisible,
    setIsBlurEnabled,
    setEndCallConfirmation,
} from '@redux/modules/videoMenu';
import {
    VisitServiceV6SavePatientChatMessageBody,
    visitServiceClient,
} from '@clients/VisitService/VisitServiceClient';
import { Logger, LogManager, config } from '@dexcare/circus-jupiter';
import { ConferenceError } from './ConferenceError';
import { EndCallReasons } from './VideoCallInterfaces';
import { setIsTytoCareVisit } from '@redux/modules/tytoCare';
import { MultiParticipantDisplay } from '@components/MultiPartipicantDisplay/MultiParticipantDisplay';
import { Publisher } from '@common/video';
import { initSelfView } from '@redux/modules/selfView';
import {
    healthCheckCompleted,
    runTests,
    TState as HealthCheckState,
} from '@redux/modules/health';
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';
import {
    setAudioDeviceId,
    setVideoDeviceId,
} from '@redux/modules/userSettings';
import { PostVisitActionDialog } from '@modules/PostVisitActionDialog/PostVisitActionDialog';
import { getFeatureFlag, FeatureFlags } from '@utils/FeatureFlags';
import { getConfig } from '@utils/config';
import { TransferOptionsState } from '@redux/modules/transferOptions';
import {
    TState,
    fetchTestVisitDetailsByVisitId,
    fetchVisitDetailsByVisitId,
    chargeVisit as postConsultVisitReduxChargeVisit,
    setPostVisitAction as postConsultVisitReduxSetPostVisitAction,
    setPostVisitActionErrorMessage as postConsultVisitReduxSetPostVisitActionErrorMessage,
    transferBackToQueue as postConsultVisitReduxTransferBackToQueue,
    transferToAnotherProvider as postConsultVisitReduxTransferToAnotherProvider,
    convertModality as postConsultVisitReduxConvertModality,
    waiveVisit as postConsultVisitReduxWaiveVisit,
    setMessageDialog,
    setVisitStatus,
} from '@redux/modules/postConsult';
import { postVisitActionDialogConfirmHandler } from './handlers/postVisitActionDialogConfirmHandler';
import { VisitDetails } from '@clients/VisitService/VisitInterfaces';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { Configuration } from 'types/configuration';
import { ThunkDispatch } from 'types/redux';
import { authHeaders } from '@utils/auth';
import type { NavigateFunction } from 'react-router-dom';
import { v4 } from 'uuid';

const overrideHeaders = (sharedSessionStoreEnabled: boolean) => () =>
    authHeaders(sharedSessionStoreEnabled);

type TError = {
    name: string;
    message: string;
    innerError?: Error;
};

type Callback = (error?: TError) => void;

interface StateProps {
    visitId: string;
    visitStatus: string;
    providerId: string | null;
    patientGuid: string;
    isTestVisit: boolean;
    userDetails: UserDetails;
    isChatVisible: boolean;
    videoSessionId: string;
    waitingRoomSessionId: string;
    videoEnabled: boolean;
    micEnabled: boolean;
    instantMessages: InstantMessageState;
    blurEnabled: boolean;
    endCallConfirmation: boolean;
    postVisitAction: PostVisitActionChange | null;
    postVisitActionErrorMessage: string | null;
    enableInstructionVideo: boolean;
    transferOptions: TransferOptionsState;
    enableCancelButton: boolean;
    timestamps: {
        created: string | undefined;
        requested: string | undefined;
        waitingroom: string | undefined;
        invisit: string | undefined;
        done: string | undefined;
        staffdeclined: string | undefined;
        cancelled: string | undefined;
        waitoffline: string | undefined;
        caregiverassigned: string | undefined;
    };
    practiceId: string;
    isTravelingFromCallCenter: boolean;
}
interface DispatchProps {
    clearVideoRoomHasUnread: () => void;
    clearWaitingRoomHasUnread: () => void;
    toggleChatIsVisible: () => void;
    alertOfTytoCareIntegration: () => void;
    initSelfView: (publisher: Publisher) => Promise<void>;
    setCamEnabled: (val: boolean) => void;
    setMicEnabled: (val: boolean) => void;
    setBlurEnabled: (val: boolean) => void;
    runTests: (publisher: Publisher) => void;
    changeCam: (val: string) => void;
    changeMic: (val: string) => void;
    setMessageDialog: (value: string) => Promise<void>;
    setPostVisitAction: (value: PostVisitActionChange | null) => void;
    setPostVisitActionErrorMessage: (value: string | null) => void;
    setEndCallConfirmation: (val: boolean) => void;
    chargeVisit: (visitId: string) => void;
    waiveVisit: (visitId: string, waiveReason: string) => void;
    transferBackToQueue: (visitId: string) => void;
    transferToAnotherProvider: (visitId: string, newProviderId: string) => void;
    convertModality: (visitId: string, reason: string) => void;
    fetchVisitDetailsByVisitId: (
        visitId: string,
        isProvider: boolean,
    ) => Promise<VisitDetails>;
    fetchTestVisitDetailsByVisitId: (
        visitId: string,
        providerId: string,
    ) => Promise<{ visitDetails: VisitDetails; redirect?: string }>;
    setVisitStatus: (val: string) => void;
}

export interface SessionProps {
    providerSelfCheckCompleted: boolean;
    handleSelfCheckClick: () => void;
    health: HealthCheckState;
    healthInfo: HealthInfo;
    brand: string;
    videoToken: string;
    waitingRoomToken: string;
    visitState: VideoCallRenderState;
    onCriticalError: (error: ConferenceError) => void;
    updateStreamCount: (streams: number) => void;
    updateInstantMessages: (
        sessionId: string,
    ) => (newMessage: InstantMessage | BotPromptMessage) => void;
    onRemoteConnectionDetected: () => void;
    endCall: (trigger: EndCallReasons) => Promise<void>;
    endCallAndTransfer: () => void;
    endCallAndTransferError: (data: EndCallAndTransferError) => void;
    modalityConversion: () => void;
    modalityConversionError: (data: ModalityConversionError) => void;
    cancelVisit: () => void;
    onReconnect: () => void;
    handleNotification: () => void;
    navigate: NavigateFunction;
}
export type Props = StateProps & SessionProps & DispatchProps;
const mapStateToProps = (state: Store['All']): StateProps => {
    return {
        visitId: state.postconsult.visitId,
        visitStatus: state.postconsult.visitStatus,
        providerId: state.postconsult.providerId,
        patientGuid: state.postconsult.patientGuid,
        isTestVisit: state.postconsult.isTestVisit,
        userDetails: state.user.userDetails,
        isChatVisible: state.video.isChatVisible,
        videoSessionId: state.postconsult.tokBoxVideoSessionId || '',
        waitingRoomSessionId:
            state.postconsult.tokBoxWaitingRoomSessionId || '',
        instantMessages: state.instantMessage,
        videoEnabled: state.video.isCamEnabled,
        micEnabled: state.video.isMicEnabled,
        blurEnabled: state.video.isBlurEnabled,
        postVisitAction: state.postconsult.postVisitAction,
        endCallConfirmation: state.video.endCallConfirmation,
        postVisitActionErrorMessage:
            state.postconsult.postVisitActionErrorMessage,
        enableInstructionVideo: state.video.isInstructionVideoVisible,
        enableCancelButton: state.video.isCancelButtonVisible,
        transferOptions: state.transferOptions,
        timestamps: state.postconsult.timestamps,
        practiceId: state.postconsult.practiceId,
        isTravelingFromCallCenter: state.postconsult.isTravelingFromCallCenter,
    };
};
const mapDispatchToProps: Redux.MapDispatchToPropsParam<
    ThunkDispatch<Store['All'], unknown, Action>,
    SessionProps
> = (dispatch: ThunkDispatch<Store['All'] | TState, unknown, Action>) => {
    return {
        clearVideoRoomHasUnread: () => dispatch(setVideoHasUnread(false)),
        clearWaitingRoomHasUnread: () =>
            dispatch(setWaitingRoomHasUnread(false)),
        toggleChatIsVisible: () => dispatch(toggleIsChatVisible()),
        alertOfTytoCareIntegration: () => dispatch(setIsTytoCareVisit(true)),
        initSelfView: async (publisher: Publisher) =>
            dispatch(initSelfView(publisher)),
        setCamEnabled: (val: boolean) => dispatch(setIsCamEnabled(val)),
        setMicEnabled: (val: boolean) => dispatch(setIsMicEnabled(val)),
        setBlurEnabled: (val: boolean) => dispatch(setIsBlurEnabled(val)),
        changeCam: (val: string) => dispatch(setVideoDeviceId(val)),
        changeMic: (val: string) => dispatch(setAudioDeviceId(val)),
        runTests: async (publisher: Publisher) => dispatch(runTests(publisher)),
        setMessageDialog: (value: string) => dispatch(setMessageDialog(value)),
        setPostVisitAction: (val: PostVisitActionChange) =>
            dispatch(postConsultVisitReduxSetPostVisitAction(val)),
        setEndCallConfirmation: (val: boolean) =>
            dispatch(setEndCallConfirmation(val)),
        chargeVisit: async (visitId: string) =>
            dispatch(postConsultVisitReduxChargeVisit(visitId)),
        waiveVisit: async (visitId: string, waiveReason: string) =>
            dispatch(postConsultVisitReduxWaiveVisit(visitId, waiveReason)),
        transferBackToQueue: async (visitId: string) =>
            dispatch(postConsultVisitReduxTransferBackToQueue(visitId)),
        transferToAnotherProvider: async (
            visitId: string,
            newProviderId: string,
        ) =>
            dispatch(
                postConsultVisitReduxTransferToAnotherProvider(
                    visitId,
                    newProviderId,
                ),
            ),
        convertModality: async (visitId: string, reason: string) =>
            dispatch(postConsultVisitReduxConvertModality(visitId, reason)),
        setPostVisitActionErrorMessage: (val: string | null) =>
            dispatch(postConsultVisitReduxSetPostVisitActionErrorMessage(val)),
        fetchVisitDetailsByVisitId: async (
            visitId: string,
            isProvider: boolean,
        ) => dispatch(fetchVisitDetailsByVisitId({ visitId, isProvider })),
        fetchTestVisitDetailsByVisitId: (visitId: string, providerId: string) =>
            dispatch(fetchTestVisitDetailsByVisitId(visitId, providerId)),
        setVisitStatus: (val: string) => dispatch(setVisitStatus(val)),
    };
};
type RemoteTypingState = TypingStateMessage;
export interface SessionComponentState {
    otStreams: Stream[];
    otConnectionStatus?: OTConnection;
    otWaitingRoomConnectionStatus?: OTConnection;
    otPublishingStatus?: OTPublishingStatus;
    otSubscribingStatus?: OTSubscribingStatus;
    waitingRoomRemoteTypingState: RemoteTypingState;
    videoRemoteTypingState: RemoteTypingState;
    patientEnterWaitOfflineStatus: string | null;
    patientEnterWaitOfflineErrorType: string | null;
    patientNudges: number;
}
interface ParsedErrorMessage {
    errorType: string;
}

export class SessionComponent extends React.Component<
    Props,
    SessionComponentState
> {
    public sessionHelper?: SessionHelper;
    public waitingRoomSessionHelper?: SessionHelper;
    public selfViewPublisher: Publisher;
    private PUBLISHER_ID = 'videoSessionSelfView';
    private logger: Logger;
    private videoSessionLogger: Logger;
    private botWaitingRoomReminderIntervalId: NodeJS.Timeout | null = null;

    constructor(props: Props) {
        super(props);

        this.state = {
            otStreams: [],
            waitingRoomRemoteTypingState: {
                typingState: TypingState.TypingStopped,
                displayName: '',
            },
            videoRemoteTypingState: {
                typingState: TypingState.TypingStopped,
                displayName: '',
            },
            patientEnterWaitOfflineStatus: null,
            patientEnterWaitOfflineErrorType: null,
            patientNudges: 0,
        };
        this.logger = BlisseyLogger.child({
            eventType: 'tokbox',
            eventSource: 'SessionComponent',
        });

        this.selfViewPublisher = new Publisher({
            id: this.PUBLISHER_ID,
            callbacks: {
                onCamDeviceChange: this.props.changeCam,
                onMicDeviceChange: this.props.changeMic,
                onCamEnabledChange: this.props.setCamEnabled,
                onMicEnabledChange: this.props.setMicEnabled,
                onBlurEnabledChange: this.props.setBlurEnabled,
            },
        });
    }

    private handleConnectionDetected = () => {
        this.sessionHelper!.sendParticipantDetails(
            {
                isProvider: isProvider(this.props.userDetails),
                senderId: this.props.userDetails.id,
            },
            this.handleOTError,
        );
        this.props.onRemoteConnectionDetected();
    };

    private handleOTConnected = (sessionid: string) => (err: OTError) => {
        if (err) {
            this.logger.error(
                {
                    err,
                },
                `error trying to connect`,
            );
        } else {
            this.logger.info({ sessionid }, `ot connected!`);
        }
    };

    private handleOTError = (err: OTError) => {
        if (err) {
            this.logger.error(
                {
                    err,
                },
                `tokbox error`,
            );
        }
    };

    private onSubscribeSuccess = (err: OTError) => {
        if (err) {
            this.logger.error(
                {
                    err,
                },
                `subscribe failure`,
            );
            this.setState({ otSubscribingStatus: 'subscribeFailure' });
        } else {
            this.logger.info('subscribe success');
            this.setState({ otSubscribingStatus: 'subscribeSuccess' });
        }
    };

    private subscribeToStream = (
        streamId: string,
        handlers: SubscribeHandlers,
    ) => {
        if (!this.sessionHelper) {
            this.logger.error(
                {
                    details: { streamId },
                },
                `not subscribing to stream because sessionHelper is undefined`,
            );
            return undefined;
        }

        const targetStream = this.state.otStreams.find(
            (stream) => stream.streamId === streamId,
        );
        if (!targetStream) {
            this.logger.error(
                {
                    details: { streamId },
                },
                `not subscribing to stream because stream not in state`,
            );
            return undefined;
        }

        this.setState({ otSubscribingStatus: 'subscribeStarted' });
        return this.sessionHelper.subscribe(
            targetStream,
            streamTargetElement(streamId),
            this.onSubscribeSuccess,
            handlers,
        );
    };

    private handleStreamCreated = (event: StreamCreatedEvent) => {
        this.logger.debug(
            {
                streamId: event.stream.streamId,
            },
            'stream created',
        );
        if (!this.sessionHelper) {
            this.logger.error(
                `not subscribing to stream because session object is undefined`,
            );
            return;
        }

        if (event.stream) {
            this.setState((prevState) => {
                const streams = [...prevState.otStreams, event.stream];
                this.props.updateStreamCount(streams.length);
                return { otStreams: streams };
            });
        }
    };

    private handleConnectionDestroyed = (event: ConnectionDestroyedEvent) => {
        this.logger.info(
            {
                reason: event.reason,
                connectionId: event.connection.connectionId,
            },
            'remote connection destroyed',
        );
    };

    private handleStreamDestroyed = (event: StreamDestroyedEvent) => {
        this.logger.info(
            {
                details: {
                    destroyedReason: event.reason,
                },
            },
            `stream destroyed`,
        );
        this.setState((prevState) => {
            const updatedStreams = prevState.otStreams.filter(
                (stream) => stream.streamId !== event.stream.streamId,
            );
            this.props.updateStreamCount(updatedStreams.length);
            this.logger.debug(
                {
                    details: {
                        previousLength: prevState.otStreams.length,
                        newLength: updatedStreams.length,
                    },
                },
                `stream length updated`,
            );
            return { otStreams: updatedStreams };
        });
    };

    private handleSessionStateEvent =
        (key: 'otConnectionStatus' | 'otWaitingRoomConnectionStatus') =>
        (event: SessionStateChangeEvent) => {
            this.logger.debug({ details: { event } }, 'connectionevent');
            this.setState((prevState) => ({
                ...prevState,
                [key]: event.type as OTConnection,
            }));
        };

    private handleSessionDisconnected =
        (
            key: 'otConnectionStatus' | 'otWaitingRoomConnectionStatus',
            submitAnalytics?: boolean,
        ) =>
        (event: SessionDisconnectedEvent) => {
            this.logger.info(
                { details: { disconnectReason: event.reason } },
                'session disconnected',
            );
            this.setState((prevState) => ({
                ...prevState,
                [key]: event.type as OTConnection,
            }));
            if (submitAnalytics && !isProvider(this.props.userDetails)) {
                V2Analytics.interactionEvent({
                    eventName: 'patient_disconnects',
                    patient_id: this.props.patientGuid,
                    visit_id: this.props.visitId,
                });
            }
        };

    private handleSignalEvent = (
        event: Event<'signal', Session> & {
            type?: string;
            data?: string;
            from: Connection;
        },
    ) => {
        this.logger.debug(
            { details: { eventType: event.type } },
            'signalingEvent',
        );
    };

    private handlePartipantLeft = () => {
        this.logger.info('participantLeft event received');
        void this.props.endCall('remote');
    };

    private handleEndCallAndTransfer = (data: EndCallAndTransfer) => {
        this.logger.info({ data }, 'endCallAndTransfer event received');
        this.props.endCallAndTransfer();
    };

    private handleEndCallAndTransferError = (data: EndCallAndTransferError) => {
        this.logger.info({ data }, 'endCallAndTransferError event received');
        this.props.endCallAndTransferError(data);
    };

    private handleModalityConversion = (data: ModalityConversion) => {
        this.logger.info({ data }, 'modalityConversion event received');
        this.props.modalityConversion();
    };

    private handleModalityConversionError = (data: ModalityConversionError) => {
        this.logger.info({ data }, 'modalityConversionError event received');
        this.props.modalityConversionError(data);
    };

    private handlePatientEnterWaitOfflineSuccess = (
        data: PatientEnterWaitOfflineSuccess,
    ) => {
        this.logger.info(
            { data },
            'onPatientEnterWaitOfflineSuccess event received',
        );
        this.setState({ patientEnterWaitOfflineStatus: 'success' });
    };

    private handlePatientEnterWaitOfflineError = (
        data: PatientEnterWaitOfflineError,
    ) => {
        this.logger.info(
            { data },
            'onPatientEnterWaitOfflineError event received',
        );
        this.setState({ patientEnterWaitOfflineStatus: 'failure' });
        const parsedErrorMessage: ParsedErrorMessage = JSON.parse(
            data.error.message,
        ) as ParsedErrorMessage;
        this.setState({
            patientEnterWaitOfflineErrorType: parsedErrorMessage.errorType,
        });
    };

    private handleSameProviderJoinedTwice = (
        remoteConnectionCreationTime?: number,
    ) => {
        this.logger.info('provider joined twice');
        // kick out the earlier connection
        if (
            remoteConnectionCreationTime != null &&
            this.sessionHelper!.getLocalConnectionData()!.creationTime <
                remoteConnectionCreationTime
        ) {
            this.logger.info(
                'providerJoinedElsewhere: disconnecting because this is the older connection',
            );
            this.props.onCriticalError(ConferenceError.JoinedElsewhere);
        } else {
            this.logger.info(
                'providerJoinedElsewhere: expecting other provider connection to disconnect',
            );
        }
    };

    private handleDifferentProviderJoined = (
        remoteConnectionCreationTime?: number,
    ) => {
        this.logger.info('multiple providers joined');
        // kick out the later connection
        if (
            remoteConnectionCreationTime != null &&
            this.sessionHelper!.getLocalConnectionData()!.creationTime >
                remoteConnectionCreationTime
        ) {
            this.logger.info(
                'multipleProvidersJoin: disconnecting because this is the newer connection',
            );
            this.props.onCriticalError(ConferenceError.ConferenceFull);
        } else {
            this.logger.info(
                'multipleProvidersJoin: expecting other provider connection to disconnect',
            );
        }
    };

    private handleParticipantDetails = (
        remoteParticipantDetails: ParticipantDetailsEvent,
    ) => {
        this.logger.debug(
            { details: remoteParticipantDetails },
            'participantDetails event received',
        );
        const {
            userDetails,
            userDetails: { id: localUserId },
        } = this.props;
        const {
            isProvider: remoteIsProvider,
            senderId: remoteUserId,
            connectionCreationTime,
        } = remoteParticipantDetails;
        if (
            remoteUserId === localUserId &&
            connectionCreationTime ===
                this.sessionHelper?.getLocalConnectionData()?.creationTime
        ) {
            this.logger.debug('own participant details event received');
            return;
        }
        if (isProvider(userDetails) && remoteIsProvider) {
            this.logger.info('another provider detected in conference');
            if (localUserId === remoteUserId) {
                this.handleSameProviderJoinedTwice(connectionCreationTime);
            } else {
                this.handleDifferentProviderJoined(connectionCreationTime);
            }
        }
    };

    private handleJoinedElsewhere = () => {
        this.logger.info('joined elsewhere event received');
        this.props.onCriticalError(ConferenceError.JoinedElsewhere);
    };

    public endCallSuccess = () => {
        void this.props.endCall('user');
        if (!isProvider(this.props.userDetails)) {
            V2Analytics.interactionEvent({
                eventName: 'patient_ends_session',
                patient_id: this.props.patientGuid,
                visit_id: this.props.visitId,
            });
        }
    };

    public sendEndCall = () => {
        if (this.sessionHelper) {
            this.sessionHelper.sendEndCall(this.endCallSuccess);
        }
    };

    private remoteTypingStateChange =
        (key: 'waitingRoomRemoteTypingState' | 'videoRemoteTypingState') =>
        (typingStateMessage: TypingStateMessage) => {
            this.logger.debug(
                {
                    details: { typingStateMessage },
                },
                'updating remote tokbox typing state',
            );
            this.setState((prevState) => ({
                ...prevState,
                [key]: typingStateMessage,
            }));
        };

    private setWaitingRoomTypingState = (amTyping: boolean) => {
        try {
            SessionComponent.sendTypingState(
                amTyping,
                this.props.userDetails,
                this.waitingRoomSessionHelper,
            );
        } catch (error: unknown) {
            this.logger.error({ err: error }, 'error sending typing state');
        }
    };

    private getStats = async () => {
        const publisherStats = await this.selfViewPublisher.getStats();
        const publisherRtcStats = await this.selfViewPublisher
            .getOTPublisher()
            ?.getRtcStatsReport();
        const subscriberStats = await this.sessionHelper?.getAllStats(
            this.state.otStreams,
        );
        return {
            publisherStats,
            subscriberStats: subscriberStats || [],
            rtcStats: publisherRtcStats || [],
        };
    };

    private setVideoSessionTypingState = (amTyping: boolean) => {
        try {
            SessionComponent.sendTypingState(
                amTyping,
                this.props.userDetails,
                this.sessionHelper,
            );
        } catch (error: unknown) {
            this.logger.error({ err: error }, 'error sending typing state');
        }
    };

    private static throwError: EventCallback = (error: Error) => {
        if (error) {
            throw error;
        }
    };

    private static sendTypingState = (
        amTyping: boolean,
        userDetails: UserDetails,
        sessionHelper?: SessionHelper,
    ) => {
        if (sessionHelper) {
            const typingMessage = {
                typingState: amTyping
                    ? TypingState.TypingStarted
                    : TypingState.TypingStopped,
                displayName: userDetails.displayName,
            };
            sessionHelper.sendTypingStateMessage(
                typingMessage,
                this.throwError,
            );
        } else {
            throw new Error(
                'cannot send typing state because sessionHelper is null',
            );
        }
    };

    private static sendInstantMessage = (
        message: string,
        userDetails: UserDetails,
        sessionHelper?: SessionHelper,
    ): InstantMessage => {
        const instantMessage = createOutGoingMessage(message, userDetails);
        if (sessionHelper) {
            sessionHelper.sendInstantMessage(instantMessage, this.throwError);
            return instantMessage;
        } else {
            throw new Error(
                `error sending message because sessionHelper is null`,
            );
        }
    };

    public sendVideoConferenceMessage = (message: string) => {
        const { userDetails, updateInstantMessages, videoSessionId } =
            this.props;
        try {
            this.logger.info(
                { instantMessageSessionId: videoSessionId },
                `sending instant message on video session`,
            );
            const instantMessage = SessionComponent.sendInstantMessage(
                message,
                userDetails,
                this.sessionHelper,
            );
            updateInstantMessages(videoSessionId)(instantMessage);
        } catch (error: unknown) {
            this.logger.error(
                {
                    err: error,
                    instantMessageSessionId: videoSessionId,
                },
                'error sending message on video session',
            );
        }
    };

    public sendWaitingRoomMessage = (message: string) => {
        const { userDetails, updateInstantMessages, waitingRoomSessionId } =
            this.props;
        try {
            this.logger.info(
                { instantMessageSessionId: waitingRoomSessionId },
                `sending instant message on waitingroom session`,
            );
            const instantMessage = SessionComponent.sendInstantMessage(
                message,
                userDetails,
                this.waitingRoomSessionHelper,
            );
            updateInstantMessages(waitingRoomSessionId)(instantMessage);
        } catch (error: unknown) {
            this.logger.error(
                {
                    err: error,
                    instantMessageSessionId: waitingRoomSessionId,
                },
                'error sending message on waitingroom session',
            );
        }
    };

    private onPublishSuccess = (err: OTError) => {
        if (err) {
            this.logger.error({ err }, 'publish failure');
            this.setState({ otPublishingStatus: 'publishFailure' });
        } else {
            this.logger.info(
                {
                    details: {
                        hasAudio: this.selfViewPublisher.hasAudio(),
                        hasVideo: this.selfViewPublisher.hasVideo(),
                    },
                },
                'publish success',
            );
            this.setState({ otPublishingStatus: 'publishSuccess' });
        }
    };

    private handleStreamPropertyChanged = (
        event: StreamPropertyChangedEvent,
    ) => {
        const { stream, changedProperty, newValue, oldValue } = event || {};
        const { videoEnabled, micEnabled } = this.props;
        if (
            stream.connection.connectionId ===
            this.sessionHelper!.getLocalConnectionData()?.connectionId
        ) {
            BlisseyLogger.info(
                {
                    details: {
                        changedProperty,
                        newValue,
                        oldValue,
                        hasVideo: stream.hasVideo,
                        hasAudio: stream.hasAudio,
                        streamId: stream.streamId,
                        streamConnectionId: stream.name,
                        videoDeviceId:
                            this.selfViewPublisher.getVideoDeviceId(),
                        audioDeviceId:
                            this.selfViewPublisher.getAudioDeviceId(),
                    },
                },
                'stream property changed event received for local stream',
            );
            switch (changedProperty) {
                case 'hasVideo':
                    // this is a HACK.  as of opentok 2.20, iPhone Safari video mysteriously mutes itself after about 1 second in the waitingroom.
                    // tickets have been opened with tokbox, but it is impossible to repro on their simplistic test environment.
                    // We look for a stream updated event where the video or audio is muted, and if that does not match the boolean value we hold
                    // in our state, force the publisher to match the state (unmute)
                    if (newValue !== videoEnabled) {
                        BlisseyLogger.warn(
                            {
                                details: {
                                    tokboxEvent: {
                                        changedProperty,
                                        newValue,
                                        oldValue,
                                    },
                                    localVideoValue: videoEnabled,
                                },
                            },
                            'video enabled value does not match state. attempting to force update with what is in the state',
                        );
                        this.selfViewPublisher.publishVideo(videoEnabled);
                    }
                    break;
                case 'hasAudio':
                    if (newValue !== micEnabled) {
                        BlisseyLogger.warn(
                            {
                                details: {
                                    tokboxEvent: {
                                        changedProperty,
                                        newValue,
                                        oldValue,
                                    },
                                    localMicValue: micEnabled,
                                },
                            },
                            'mic enabled value does not match state. attempting to force update with what is in the state',
                        );
                        this.selfViewPublisher.publishAudio(micEnabled);
                    }
                    break;
                default:
                // noop
            }
        }
    };

    private publish = async () => {
        BlisseyLogger.info(
            { connectionStatus: this.state.otConnectionStatus },
            'attempting to publish',
        );
        if (!this.sessionHelper) {
            this.logger.error(
                'not publishing because sessionHelper is undefined',
            );
        } else {
            this.setState({ otPublishingStatus: 'publishStarted' });
            try {
                // we _can_ await a dispatch but we really should not as this
                // breaks the redux flow of data "rules". What should should probably
                // happen here is to refactor the "publisher" methods / classes away from relying on redux
                // and hook it up to state via event handlers that can be ignorant of redux flow
                await this.props.initSelfView(this.selfViewPublisher);
                this.sessionHelper.publish(
                    this.selfViewPublisher.getOTPublisher()!,
                    this.onPublishSuccess,
                );
            } catch (err: unknown) {
                BlisseyLogger.error(
                    { details: { err } },
                    'error initializing publisher',
                );
            }
        }
    };

    public isAssignedProvider = async () => {
        let visitDetails: VisitDetails;
        if (this.props.isTestVisit) {
            const { visitDetails: testVisitDetails, redirect } =
                await this.props.fetchTestVisitDetailsByVisitId(
                    this.props.visitId,
                    this.props.userDetails?.id,
                );
            visitDetails = testVisitDetails;
            if (redirect) {
                this.props.navigate(redirect);
            }
        } else {
            visitDetails = await this.props.fetchVisitDetailsByVisitId(
                this.props.visitId,
                isProvider(this.props.userDetails),
            );
        }
        return visitDetails.providerId === this.props.userDetails.id;
    };

    public handleSelfCheckClick = async () => {
        if (await this.isAssignedProvider()) {
            this.connectToVideoSession();
            this.props.handleSelfCheckClick();
        } else {
            await this.props.setMessageDialog(
                'You are not the assigned provider for this visit and cannot connect with the patient.',
            );
        }
    };

    public sendBotPromptResponse = (prompt: string, selectedOption: string) => {
        const {
            userDetails,
            updateInstantMessages,
            waitingRoomSessionId,
            visitId,
            instantMessages,
        } = this.props;
        try {
            this.logger.info(
                {
                    instantMessageSessionId: waitingRoomSessionId,
                },
                `sending instant message on waitingroom session`,
            );
            const id = v4();
            const instantMessage: BotPromptMessage = {
                fromParticipant: userDetails.displayName,
                senderId: userDetails.id,
                creationTime: `${new Date().getTime()}`,
                uniqueId: id,
                prompt,
                options: ['Yes', 'No'],
                isBot: true,
                selectedOption,
            };

            const { waitingInstantMessages } = instantMessages;
            // if patient has responded to the bot prompt, and has not been given extended time, set a timeout to send a reminder message
            if (selectedOption || !instantMessage.isBot) {
                this.logger.info(
                    {
                        currentTime: `${new Date().getTime()}`,
                    },
                    'patient has responded to bot prompt',
                );

                if (this.botWaitingRoomReminderIntervalId) {
                    clearInterval(this.botWaitingRoomReminderIntervalId);
                    const botPatientResponseTimeSeconds: number =
                        (config as Configuration).getConfig()?.chatbot
                            ?.botPatientResponseTimeSeconds ?? 120;
                    this.botWaitingRoomReminderIntervalId = setInterval(
                        this.sendBotNudge,
                        botPatientResponseTimeSeconds * 1000,
                    );
                }

                const lastMessage =
                    waitingInstantMessages[waitingInstantMessages.length - 1];
                const { key } = lastMessage;
                instantMessage.uniqueId = key;
                const payload: VisitServiceV6SavePatientChatMessageBody = {
                    type: 'botPromptMessage',
                    data: {
                        fromParticipant: userDetails.displayName,
                        senderId: userDetails.id,
                        creationTime: `${new Date().getTime()}`,
                        uniqueId: key,
                        prompt,
                        selectedOption,
                    },
                };
                void visitServiceClient.savePatientChatMessage(
                    visitId,
                    waitingRoomSessionId,
                    payload,
                );
            }

            updateInstantMessages(waitingRoomSessionId)(instantMessage);
        } catch (error: unknown) {
            this.logger.error(
                {
                    err: error,
                    instantMessageSessionId: waitingRoomSessionId,
                },
                'error sending message on waitingroom session',
            );
        }
    };

    private sendBotNudge = () => {
        this.setState((prevState) => {
            const patientNudgeLimit: number =
                (config as Configuration).getConfig()?.chatbot
                    ?.patientNudgeLimit ?? 2;
            const { patientNudges } = prevState;
            if (patientNudges >= patientNudgeLimit) {
                this.logger.info(
                    {
                        currentTime: `${new Date().getTime()}`,
                        patientNudges,
                        patientNudgeLimit,
                    },
                    'patient has been given maximum nudges, not sending another message',
                );
                clearInterval(this.botWaitingRoomReminderIntervalId!);
                return;
            }

            const { userDetails, waitingRoomSessionId, updateInstantMessages } =
                this.props;

            const reminderMessage: BotPromptMessage = {
                fromParticipant: userDetails.displayName,
                senderId: userDetails.id,
                creationTime: `${new Date().getTime()}`,
                uniqueId: v4(),
                prompt: `Hi ${
                    userDetails.displayName ?? 'patient'
                }, do you want to continue with the pre-visit questions?`,
                options: ['Yes', 'No'],
                isBot: true,
            };

            this.setState({ patientNudges: patientNudges + 1 }, () => {
                updateInstantMessages(waitingRoomSessionId)(reminderMessage);
            });
        });
    };

    private onBotPrompt = (botMessage: BotPromptMessage) => {
        this.logger.debug(
            { details: { botMessage } },
            'botPromptMessage event received',
        );
        if (getFeatureFlag(FeatureFlags.enableAiAssistant)) {
            this.sendBotPromptResponse(
                botMessage.prompt,
                botMessage?.selectedOption ?? '',
            );
            const botPatientResponseTimeSeconds: number =
                (config as Configuration).getConfig()?.chatbot
                    ?.botPatientResponseTimeSeconds ?? 120;
            this.botWaitingRoomReminderIntervalId = setInterval(
                this.sendBotNudge,
                botPatientResponseTimeSeconds * 1000,
            );
        }
    };

    private connectToVideoSession = () => {
        this.logger.debug(
            { details: { sessionId: this.props.videoSessionId } },
            'connecting to session',
        );
        this.setState({ otConnectionStatus: 'connectionAttemptStarted' });
        this.sessionHelper!.connect(this.props.videoToken, (error: OTError) => {
            this.handleOTConnected(this.props.videoSessionId)(error);

            const otPublisher = this.selfViewPublisher.getOTPublisher();

            otPublisher?.on('streamDestroyed', (event) => {
                this.logger.warn({
                    msg: 'streamDestroyed event received',
                    event,
                });
            });
        });
    };

    private connectToWaitingRoom = (projectKey: string) => {
        const { visitId, waitingRoomSessionId, waitingRoomToken, userDetails } =
            this.props;
        const sessionHandler = this.handleSessionStateEvent(
            'otWaitingRoomConnectionStatus',
        );
        this.waitingRoomSessionHelper = new SessionHelper(
            {
                config: {
                    sessionId: waitingRoomSessionId,
                    projectKey,
                },
                sessionHandlers: {
                    onSessionConnected: sessionHandler,
                    onSessionReconnected: sessionHandler,
                    onSessionReconnecting: sessionHandler,
                    onSessionDisconnected: this.handleSessionDisconnected(
                        'otWaitingRoomConnectionStatus',
                    ),
                },
                signalingHandlers: {
                    onInstantMessage: this.props.updateInstantMessages(
                        waitingRoomSessionId,
                    ) as any,
                    onTypingStateChange: this.remoteTypingStateChange(
                        'waitingRoomRemoteTypingState',
                    ),
                    onNotification: this.props.handleNotification,
                    onVisitStatusChange: this.onVisitStatusChange,
                    onPatientEnterWaitOfflineSuccess:
                        this.handlePatientEnterWaitOfflineSuccess,
                    onPatientEnterWaitOfflineError:
                        this.handlePatientEnterWaitOfflineError,
                    onBotPromptMessage: this.onBotPrompt,
                },
                postMessageConfig: {
                    postUrl: visitServiceClient.getChatUrl(
                        isProvider(userDetails),
                        visitId,
                        waitingRoomSessionId,
                    ),
                    overrideHeaders: overrideHeaders(
                        userDetails.sharedSessionStoreEnabled,
                    ),
                },
            },
            LogManager.getLogger().child(
                { eventSource: 'yak', visitId, waitingRoomSessionId },
                true,
            ),
        );
        this.waitingRoomSessionHelper.connect(
            waitingRoomToken,
            this.handleOTConnected(this.props.waitingRoomSessionId),
        );
    };

    private onVisitStatusChange = (status: string) => {
        this.logger.info(
            { details: { newStatus: status } },
            'visit state change',
        );
        this.props.setVisitStatus(status);
        if (status === 'staffdeclined') {
            void this.props.endCall('declined');
        }
        if (status === 'done') {
            void this.props.endCall('done');
        }
        if (status === 'cancelled') {
            void this.props.endCall('cancelled');
        }
    };

    private toggleMicEnabled = () => {
        this.selfViewPublisher.publishAudio(!this.props.micEnabled);
    };
    private toggleCamEnabled = () => {
        this.selfViewPublisher.publishVideo(!this.props.videoEnabled);
    };
    private toggleBlurEnabled = () => {
        void this.selfViewPublisher.publishBlur(!this.props.blurEnabled);
    };

    private handleDeviceChange = (
        cameraDeviceId: string,
        audioDeviceId: string,
    ) => {
        const otPublisher = this.selfViewPublisher.getOTPublisher();

        BlisseyLogger.info(
            {
                cameraDeviceId,
                audioDeviceId,
                streamId: otPublisher?.stream?.streamId,
                previousCameraId: this.selfViewPublisher.getVideoDeviceId(),
                previousAudioId: this.selfViewPublisher.getAudioDeviceId(),
            },
            'device change event received',
        );

        if (cameraDeviceId !== this.selfViewPublisher.getVideoDeviceId()) {
            void this.selfViewPublisher
                .setVideoDeviceId(cameraDeviceId)
                .then(() => {
                    BlisseyLogger.info({ cameraDeviceId }, 'video device set');
                })
                .catch((err: unknown) => {
                    BlisseyLogger.error(
                        {
                            err,
                            details: { cameraDeviceId },
                        },
                        'error setting video device',
                    );
                });
        }
        if (audioDeviceId !== this.selfViewPublisher.getAudioDeviceId()) {
            void this.selfViewPublisher
                .setAudioDeviceId(audioDeviceId)
                .then(() => {
                    BlisseyLogger.info({ audioDeviceId }, 'audio device set');
                })
                .catch((err: unknown) => {
                    BlisseyLogger.error(
                        {
                            err,
                            details: { audioDeviceId },
                        },
                        'error setting audio device',
                    );
                });
        }
    };

    private onIntegrationAlert = (alertMessage: IntegrationAlert) => {
        if (isProvider(this.props.userDetails)) {
            this.logger.info({
                msg: 'received integrationAlert',
                details: { alertMessage },
            });
            const { integration = '', details: { activated = false } = {} } =
                alertMessage || {};
            if (activated && integration.toLowerCase() === 'tytocare') {
                this.props.alertOfTytoCareIntegration();
            }
        }
    };

    private initVideoSessionHelper = () => {
        const tokBoxProjectKey = (config as Configuration).getConfig()
            .tokboxProjectKey;
        const { visitId, videoSessionId, userDetails } = this.props;

        const sessionHandler =
            this.handleSessionStateEvent('otConnectionStatus');
        this.sessionHelper = new SessionHelper(
            {
                config: {
                    sessionId: videoSessionId,
                    projectKey: tokBoxProjectKey,
                },
                sessionHandlers: {
                    onStreamCreated: this.handleStreamCreated,
                    onStreamDestroyed: this.handleStreamDestroyed,
                    onStreamPropertyChanged: this.handleStreamPropertyChanged,
                    onSessionConnected: sessionHandler,
                    onSessionReconnected: sessionHandler,
                    onSessionReconnecting: sessionHandler,
                    onSessionDisconnected: this.handleSessionDisconnected(
                        'otConnectionStatus',
                        true,
                    ),
                    onRemoteParticipantConnectionCreated:
                        this.handleConnectionDetected,
                    onConnectionDestroyed: this.handleConnectionDestroyed,
                },
                signalingHandlers: {
                    onInstantMessage: this.props.updateInstantMessages(
                        videoSessionId,
                    ) as any,
                    onTypingStateChange: this.remoteTypingStateChange(
                        'videoRemoteTypingState',
                    ),
                    onParticipantLeft: this.handlePartipantLeft,
                    onGenericSignalingEvent: this.handleSignalEvent,
                    onParticipantDetails: this.handleParticipantDetails,
                    onJoinedElsewhere: this.handleJoinedElsewhere,
                    onVisitStatusChange: this.onVisitStatusChange,
                    onIntegrationAlert: this.onIntegrationAlert,
                    onEndCallAndTransfer: this.handleEndCallAndTransfer,
                    onEndCallAndTransferError:
                        this.handleEndCallAndTransferError,
                    onModalityConversion: this.handleModalityConversion,
                    onModalityConversionError:
                        this.handleModalityConversionError,
                    onBotPromptMessage: this.onBotPrompt,
                },
                postMessageConfig: {
                    postUrl: visitServiceClient.getChatUrl(
                        isProvider(userDetails),
                        visitId,
                        videoSessionId,
                    ),
                    overrideHeaders: overrideHeaders(
                        userDetails.sharedSessionStoreEnabled,
                    ),
                },
            },
            this.videoSessionLogger,
        );
    };

    public componentDidMount() {
        const { videoSessionId, userDetails, videoToken, visitId } = this.props;
        try {
            if (!videoSessionId) {
                throw new Error(
                    'attempting to connect to a tokbox session without a sessionid',
                );
            }

            if (!videoToken) {
                // TODO handle undefined case by calling for new token ?
                throw new Error(
                    'attempting to connect to a tokbox session without a token',
                );
            }
            const tokBoxProjectKey = (config as Configuration).getConfig()
                .tokboxProjectKey;
            this.videoSessionLogger = LogManager.getLogger().child(
                { eventSource: 'yak', visitId, videoSessionId },
                true,
            );
            this.initVideoSessionHelper();
            if (!isProvider(userDetails)) {
                this.connectToWaitingRoom(tokBoxProjectKey);
            }
        } catch (err: unknown) {
            this.logger.error({ err }, `error establisting OT connection`);
            this.setState({ otConnectionStatus: 'error' });
        }
    }

    public componentWillUnmount() {
        if (this.sessionHelper) {
            this.logger.debug('Session unmounting');
            this.sessionHelper.destroy();
        }

        if (this.botWaitingRoomReminderIntervalId) {
            this.logger.debug('clearing bot waiting room reminder interval');
            clearInterval(this.botWaitingRoomReminderIntervalId);
        }
    }

    public componentDidUpdate(prevProps: Props) {
        const {
            visitState,
            providerId,
            health: { healthCheckProgress },
            healthInfo: { healthCheckStatus },
            userDetails,
        } = this.props;
        const {
            visitState: prevVisitState,
            providerId: prevProviderId,
            health: { healthCheckProgress: prevHealthCheckProgress },
        } = prevProps;

        if (prevVisitState !== visitState) {
            this.logger.debug(`visit render state update to ${visitState}`);
        }

        if (prevProviderId !== providerId) {
            this.logger.debug(
                `visit assigned to new provider ${providerId as string}`,
            );
        }

        if (
            !isProvider(userDetails) &&
            !this.sessionHelper?.otSession?.connection &&
            healthCheckCompleted(prevHealthCheckProgress, healthCheckProgress)
        ) {
            if (healthCheckStatus === HealthCheckStatus.Healthy) {
                this.logger.info(
                    'healthcheck passed - connecting to video session',
                );
                this.connectToVideoSession();
            } else if (healthCheckStatus === HealthCheckStatus.Unhealthy) {
                this.logger.warn(
                    'healthcheck failed - not connecting to video session until it passes',
                );
            }
        }
    }

    private sendAnalytics = (eventName: string, ...params: string[]) => {
        V2Analytics.interactionEvent({
            eventName,
            patient_id: this.props.patientGuid,
            visit_id: this.props.visitId,
            ...params,
        });
    };

    public handlePostVisitActionDialogConfirm = () => {
        const {
            brand,
            chargeVisit,
            waiveVisit,
            postVisitAction,
            visitId,
            transferBackToQueue,
            transferToAnotherProvider,
            convertModality,
            setPostVisitActionErrorMessage,
        } = this.props;
        const logger = this.logger;
        const sendAnalytics = this.sendAnalytics;

        const sessionHelperSendEndCall = (callback: Callback) => {
            this.sessionHelper?.sendEndCall(callback);
        };

        if (!sessionHelperSendEndCall) {
            logger.warn('session helper is not defined');
            return;
        }

        postVisitActionDialogConfirmHandler(
            {
                postVisitAction,
                visitId,
                chargeVisit,
                convertModality,
                waiveVisit,
                transferBackToQueue,
                transferToAnotherProvider,
                sendAnalytics,
                sendEndCall: sessionHelperSendEndCall,
            },
            (err) => {
                if (err) {
                    logger.error(
                        {
                            error: err,
                            brand,
                            postVisitAction,
                            visitId,
                        },
                        'error handling post visit action confirmation',
                    );
                    setPostVisitActionErrorMessage(
                        err.name === 'OT signalling error'
                            ? 'A problem has occurred. Please try again.'
                            : err.message,
                    );
                    return;
                }

                // this is mainly for an edge case where a user might navigate back
                // after hitting confirm
                setTimeout(() => {
                    // update state to close the modal
                    setPostVisitActionErrorMessage(null);
                }, 1);
            },
        );
    };

    public handlePostVisitActionDialogChange = (val: PostVisitActionChange) => {
        this.props.setPostVisitAction(val);
        this.props.setPostVisitActionErrorMessage(null);
    };

    public handlePostVisitActionDialogCancel = () => {
        this.props.setPostVisitActionErrorMessage(null);
        this.props.setPostVisitAction(null);
        this.props.setEndCallConfirmation(false);
    };

    public handleSendPatientEnterWaitOffline = async () => {
        const {
            visitId,
            practiceId,
            waitingRoomSessionId: sessionId,
        } = this.props;
        this.logger.info('sending patient enter wait offline', undefined, {
            visitId,
            practiceId,
            sessionId,
        });
        V2Analytics.interactionEvent({
            eventName: 'patient_enter_wait_offline',
            visit_id: visitId,
            patient_id: this.props.patientGuid,
        });
        await visitServiceClient.patientEnterWaitOffline({
            visitId,
            practiceId,
            sessionId,
        });
    };

    public handlePatientRedirectAfterWaitOffline = (): void => {
        const redirectToUrl = `${getClosedVisitRoute(
            'waitoffline',
            true,
        )}?brand=${this.props.brand}`;
        this.props.navigate(redirectToUrl, { replace: true });
        this.sessionHelper?.destroy();
    };

    public render() {
        let displayComponent;
        const baseProps = {
            visitId: this.props.visitId,
            userDetails: this.props.userDetails,
            health: this.props.health,
            healthInfo: this.props.healthInfo,
            runTests: this.props.runTests,
            changeCam: this.props.changeCam,
            changeMic: this.props.changeMic,
        };

        const { modalityConversionReasons = [], postVisitOptions = {} } =
            getConfig();
        const enableVisitModalityConversion = !!getFeatureFlag(
            FeatureFlags.enableVisitModalityConversion,
        );
        const enableVisitModalityConversionForTravelPatientCallCenter =
            !!getFeatureFlag(
                FeatureFlags.enableVisitModalityConversionForTravelPatientCallCenter,
            );
        const endAndTransferVisit = !!getFeatureFlag(
            FeatureFlags.endAndTransferVisit,
        );

        const shouldShowProviderPostiVisitActionDialog =
            isProvider(this.props.userDetails) &&
            (enableVisitModalityConversion || endAndTransferVisit);

        const shouldShowConvertModalityOption =
            enableVisitModalityConversion &&
            (enableVisitModalityConversionForTravelPatientCallCenter ||
                !this.props.isTravelingFromCallCenter);

        const endDialog = shouldShowProviderPostiVisitActionDialog ? (
            <PostVisitActionDialog
                open={this.props.endCallConfirmation}
                showTransferOption={endAndTransferVisit}
                showConvertModalityOption={shouldShowConvertModalityOption}
                postVisitOptions={postVisitOptions}
                modalityConversionReasons={modalityConversionReasons}
                onCancel={this.handlePostVisitActionDialogCancel}
                onConfirm={this.handlePostVisitActionDialogConfirm}
                onClose={this.handlePostVisitActionDialogCancel}
                onChange={this.handlePostVisitActionDialogChange}
                errorMessage={this.props.postVisitActionErrorMessage}
                providers={this.props.transferOptions.providers}
            />
        ) : (
            <EndCallDialog onEndCall={this.sendEndCall} />
        );

        switch (this.props.visitState) {
            case VideoCallRenderState.AnteRoom:
                displayComponent = (
                    <AnteRoomComponent
                        onConnect={this.handleSelfCheckClick}
                        selfCheckCompleted={
                            this.props.providerSelfCheckCompleted
                        }
                        toggleBlur={this.toggleBlurEnabled}
                        blurEnabled={this.props.blurEnabled}
                        lostConnection={otLostConnection(
                            this.state.otConnectionStatus,
                        )}
                        {...baseProps}
                    />
                );
                break;
            case VideoCallRenderState.PatientWaitingRoom:
                displayComponent = (
                    <ChatPage
                        instantMessageProps={{
                            onSendMessage: this.sendWaitingRoomMessage,
                            onSendBotPromptResponse: this.sendBotPromptResponse,
                            onInstantMessageTyping:
                                this.setWaitingRoomTypingState,
                            instantMessages:
                                this.props.instantMessages
                                    .waitingInstantMessages,
                            hasRemoteStartedTyping:
                                this.state.waitingRoomRemoteTypingState
                                    .typingState === TypingState.TypingStarted,
                            remoteParticipantName:
                                this.state.waitingRoomRemoteTypingState
                                    .displayName,
                            hasUnreadMessages:
                                this.props.instantMessages.waitingRoomHasUnread,
                            lostConnection: otLostConnection(
                                this.state.otWaitingRoomConnectionStatus,
                            ),
                            onAllMessagesRead:
                                this.props.clearWaitingRoomHasUnread,
                            toggleChatIsVisible: this.props.toggleChatIsVisible,
                            resizeStyle: 'none',
                        }}
                    >
                        <WaitingRoomComponent
                            onChatClick={this.props.toggleChatIsVisible}
                            chatIsVisible={this.props.isChatVisible}
                            brand={this.props.brand}
                            lostConnection={otLostConnection(
                                this.state.otWaitingRoomConnectionStatus,
                            )}
                            enableInstructionVideo={
                                this.props.enableInstructionVideo
                            }
                            cancelVisit={this.props.cancelVisit}
                            isTestVisit={this.props.isTestVisit}
                            enableCancelButton={this.props.enableCancelButton}
                            timestamps={this.props.timestamps}
                            handleSendPatientEnterWaitOffline={
                                this
                                    .handleSendPatientEnterWaitOffline as () => void
                            }
                            handlePatientRedirectAfterWaitOffline={
                                this.handlePatientRedirectAfterWaitOffline
                            }
                            patientEnterWaitOfflineStatus={
                                this.state.patientEnterWaitOfflineStatus
                            }
                            patientEnterWaitOfflineErrorType={
                                this.state.patientEnterWaitOfflineErrorType
                            }
                            status={this.props.visitStatus}
                            {...baseProps}
                        />
                    </ChatPage>
                );
                break;
            default:
                displayComponent = (
                    <>
                        <ChatPage
                            instantMessageProps={{
                                onSendMessage: this.sendVideoConferenceMessage,
                                onInstantMessageTyping:
                                    this.setVideoSessionTypingState,
                                instantMessages:
                                    this.props.instantMessages
                                        .videoInstantMessages,
                                hasRemoteStartedTyping:
                                    this.state.videoRemoteTypingState
                                        .typingState ===
                                    TypingState.TypingStarted,
                                remoteParticipantName:
                                    this.state.videoRemoteTypingState
                                        .displayName,
                                hasUnreadMessages:
                                    this.props.instantMessages.videoHasUnread,
                                lostConnection: otLostConnection(
                                    this.state.otConnectionStatus,
                                ),
                                onAllMessagesRead:
                                    this.props.clearVideoRoomHasUnread,
                                toggleChatIsVisible:
                                    this.props.toggleChatIsVisible,
                                resizeStyle: 'none',
                            }}
                        >
                            <MultiParticipantDisplay
                                isProvider={isProvider(this.props.userDetails)}
                                getStats={this.getStats}
                                publish={this.publish}
                                publisherId={this.PUBLISHER_ID}
                                subscribe={this.subscribeToStream}
                                onReconnect={this.props.onReconnect}
                                cleanupSelfView={this.selfViewPublisher.cleanup}
                                toggleCamEnabled={this.toggleCamEnabled}
                                toggleMicEnabled={this.toggleMicEnabled}
                                toggleBlurEnabled={this.toggleBlurEnabled}
                                onDeviceChange={this.handleDeviceChange}
                                {...this.state}
                            />
                        </ChatPage>
                        <div>{endDialog}</div>
                    </>
                );
        }

        return <>{displayComponent}</>;
    }
}

export default Redux.connect<StateProps, DispatchProps, SessionProps>(
    mapStateToProps,
    mapDispatchToProps,
)(SessionComponent);
