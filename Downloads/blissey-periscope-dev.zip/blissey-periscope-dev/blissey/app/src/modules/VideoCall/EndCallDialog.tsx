import * as React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Action } from 'redux';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import { Store } from '@redux/modules';
import { withTranslation, WithTranslation } from 'react-i18next';

import { setEndCallConfirmation } from '@redux/modules/videoMenu';
import { Logger } from '../../utils';
import { ThunkDispatch } from 'types/redux';

export interface EndCallDialogProps extends WithTranslation {
    onEndCall: () => void;
}

const EndCallDialog = ({ onEndCall, t }: EndCallDialogProps) => {
    const callEndPromptText = t('modal.endCall.callEndPrompt');
    const callEndConfirmText = t('modal.endCall.callEndConfirm');
    const callEndCancelText = t('modal.endCall.callEndCancel');

    const {
        video: { endCallConfirmation },
    } = useSelector((state: Store['All']) => state);
    const dispatch =
        useDispatch<ThunkDispatch<Store['All'], unknown, Action>>();

    const closeEndCall = () => {
        Logger.info(
            {
                eventType: 'userAction',
                eventName: 'endCallCancelModalClick',
            },
            'End call cancel modal clicked',
        );
        dispatch(setEndCallConfirmation(false));
    };

    const dialogRef = React.useRef<HTMLDivElement>();
    React.useEffect(() => {
        if (endCallConfirmation === true) {
            setTimeout(() => {
                if (dialogRef.current) {
                    dialogRef.current.focus();
                }
            }, 1);
        }
    }, [endCallConfirmation]);

    return (
        <Dialog open={endCallConfirmation} onClose={closeEndCall}>
            <DialogContent
                id="end-call-dialog-title"
                ref={dialogRef}
                tabIndex={0}
            >
                {callEndPromptText}
            </DialogContent>
            <DialogActions>
                <Button
                    id={'endCallCancel'}
                    onClick={closeEndCall}
                    color="primary"
                >
                    {callEndCancelText.toLocaleUpperCase()}
                </Button>
                <Button
                    id={'endCallConfirm'}
                    onClick={onEndCall}
                    color="primary"
                >
                    {callEndConfirmText.toLocaleUpperCase()}
                </Button>
            </DialogActions>
        </Dialog>
    );
};

const _EndCallDialog = withTranslation()(EndCallDialog);
export { _EndCallDialog as EndCallDialog, EndCallDialog as RawEndCallDialog };
