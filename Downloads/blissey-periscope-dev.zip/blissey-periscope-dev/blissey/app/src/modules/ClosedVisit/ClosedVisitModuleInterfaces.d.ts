import { VisitStatus } from '@clients/VisitService/VisitInterfaces';
import { WithTranslation } from 'react-i18next';

export interface ClosedVisitModuleProps extends WithTranslation {
    closedReason: VisitStatus;
    visitId: string;
}
