import * as React from 'react';
import * as redux from 'react-redux';
import thunk from '@redux/middleware/thunkShim';
import configureMockStore from 'redux-mock-store';

import { ClosedVisitModule } from '../ClosedVisitModule';
import { ClosedVisitModuleProps } from '../ClosedVisitModuleInterfaces';
import { StoryFn } from '@storybook/react';

const state = {};
const middlewares = [thunk];

const Template = (props: ClosedVisitModuleProps) => {
    const mockStore = configureMockStore(middlewares);
    const mockStoreWithState = mockStore({
        ...state,
    });
    return (
        <redux.Provider store={mockStoreWithState}>
            <ClosedVisitModule {...{ ...props }} />
        </redux.Provider>
    );
};

export const Default = Template.bind({}) as StoryFn<typeof ClosedVisitModule>;
Default.args = {
    closedReason: 'cancelled',
};

export default {
    title: 'Modules/ClosedVisit',
    component: ClosedVisitModule,
    parameters: {
        layout: 'centered',
    },
    argTypes: {
        closedReason: {
            options: ['cancelled', 'staffdeclined', 'done', null],
            control: { type: 'radio' },
        },
    },
};
