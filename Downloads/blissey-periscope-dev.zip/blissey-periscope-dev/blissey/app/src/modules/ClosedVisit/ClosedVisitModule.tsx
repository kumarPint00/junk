import * as React from 'react';
import { withTranslation } from 'react-i18next';
import { ClosedVisitModuleProps } from './ClosedVisitModuleInterfaces';
import { VisitStatus } from '../../clients/VisitService/VisitInterfaces';
import { config as Config } from '@dexcare/circus-jupiter';
import { FooterPage } from '@layout/PageLayout/FooterPage';
import { useDispatch } from 'react-redux';
import { Action } from 'redux';
import { cancelVisit } from '@redux/modules/postConsult';
import { CancelVisitDialog } from '@components/WaitingRoom/CancelVisitDialog';
import Link from '@mui/material/Link';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

import * as styles from './ClosedVisitModule.css';
import { Configuration } from 'types/configuration';
import { ThunkDispatch } from 'types/redux';
import { Store } from '@redux/modules';

const config = Config as Configuration;
function ClosedVisitModule(props: ClosedVisitModuleProps) {
    const dispatch =
        useDispatch<ThunkDispatch<Store['All'], unknown, Action>>();
    const [cancelDialogOpen, setCancelDialogOpen] = React.useState(false);
    const openCancelVisitDialog = (): void => {
        setCancelDialogOpen(true);
    };
    const closeCancelVisitDialog = (): void => {
        setCancelDialogOpen(false);
    };

    const buildContent = (): JSX.Element => {
        const helpNumber: string = config.getConfig()
            .technicalSupportHelpNumber as string;
        const displayNumber = config.getConfig().displaySupportNumberOnError;
        const messageText = props.t(
            'closedVisitText.message.text',
            'If you still would like to see a provider, ',
        );
        const messagePhoneText = props.t(
            'closedVisitText.message.phoneText',
            'please schedule another visit.',
        );
        const messageContact = props.t(
            'closedVisitText.message.contact',
            'Contact support at',
        );
        const messageLinkText = props.t(
            'closedVisitText.message.linkText',
            'schedule',
        );
        const messageLinkTextPre = props.t(
            'closedVisitText.message.linkTextPre',
            'please',
        );
        const messageLinkTextPost = props.t(
            'closedVisitText.message.linkTextPost',
            'another visit.',
        );
        const messageWaitingRoom = props.t(
            'closedVisitText.message.waitingRoom',
            'You may now close this window.',
        );
        const cancelVisitButtonText = props.t('visit.cancelVisit');

        const getClosedReasonText = (closedReason: VisitStatus): string => {
            let reason = '';

            switch (closedReason) {
                case 'staffdeclined':
                    reason = props.t(
                        'closedVisitText.reasonText.staffDeclined',
                        'This visit has been declined.',
                    );
                    break;
                case 'cancelled':
                    reason = props.t(
                        'closedVisitText.reasonText.cancelled',
                        'This visit has been cancelled',
                    );
                    break;
                case 'waitoffline':
                    reason =
                        props.t('wait-offline.redirect-screen.reason') ||
                        'Thank you for requesting a virtual visit. You have successfully reserved your place in line.';
                    break;
                case 'waitingroom':
                    reason = props.t(
                        'closedVisitText.reasonText.waitingRoom',
                        'This visit has been converted to a phone visit',
                    );
                    break;
                case 'done':
                default:
                    reason = props.t(
                        'closedVisitText.reasonText.done',
                        'This visit has been completed.',
                    );
            }

            return reason;
        };

        const getBodyText = (closedReason: VisitStatus): string => {
            let body = '';

            switch (closedReason) {
                case 'waitoffline':
                    body = props.t(
                        'wait-offline.redirect-screen.body',
                        'You will be notified when the provider is ready for you. You may now close this window.',
                    );
                    break;
                case 'waitingroom':
                    body = props.t(
                        'closedVisitText.bodyText.waitingRoom',
                        'Your attending provider has converted your visit to a phone visit. Please expect a call from us shortly.',
                    );
                    break;
                default:
                    body = props.t(
                        'closedVisitText.bodyText.default',
                        'Thank you',
                    );
            }

            return body;
        };

        const getSchedulingLinkContent = (
            closedReason: VisitStatus,
        ): JSX.Element => {
            const schedulingLinkFromConfig = props.t('branding:logoutReturnTo');
            let schedulingLinkWithMode = '';

            if (
                schedulingLinkFromConfig.slice(
                    schedulingLinkFromConfig.length - 1,
                ) === '='
            ) {
                switch (closedReason) {
                    case 'staffdeclined':
                        schedulingLinkWithMode =
                            schedulingLinkFromConfig + 'decline';
                        break;
                    case 'cancelled':
                        schedulingLinkWithMode =
                            schedulingLinkFromConfig + 'cancel';
                        break;
                    case 'done':
                        schedulingLinkWithMode =
                            schedulingLinkFromConfig + 'end';
                        break;
                    default:
                        schedulingLinkWithMode =
                            schedulingLinkFromConfig + 'end';
                }
            } else {
                schedulingLinkWithMode = schedulingLinkFromConfig;
            }

            return (
                <div className={styles.smallMessage}>
                    {messageLinkTextPre}{' '}
                    <a
                        className={styles.telephone}
                        href={schedulingLinkWithMode}
                    >
                        {messageLinkText}
                    </a>{' '}
                    {messageLinkTextPost}
                </div>
            );
        };

        const reasonText = getClosedReasonText(props.closedReason);
        const linkContent = getSchedulingLinkContent(props.closedReason);
        const bodyText = getBodyText(props.closedReason);

        const phoneText = (
            <div>
                <div className={styles.smallMessage}>{messagePhoneText}</div>
                <div>
                    <br />
                </div>
                <div className={styles.smallMessage}>
                    {messageContact}{' '}
                    <a className={styles.telephone} href={`tel:${helpNumber}`}>
                        {helpNumber}
                    </a>
                    .
                </div>
            </div>
        );

        const outdatedVisitElement: JSX.Element = (
            <div className={styles.messagingBox}>
                <div
                    data-uitest="closedvisit-messageheader"
                    className={styles.largeMessage}
                >
                    {reasonText}
                </div>
                <div className={styles.smallMessage}>{messageText}</div>
                {displayNumber ? phoneText : linkContent}
            </div>
        );

        const cancelVisitHandler = () => {
            V2Analytics.interactionEvent({
                eventName: 'visit_cancel',
                visit_id: props.visitId,
            });

            dispatch(cancelVisit() as (...args: unknown[]) => void);
        };

        const cancelVisitElement = (
            <Link
                onClick={openCancelVisitDialog}
                underline="none"
                rel="noreferrer"
                data-uitest="cancelVisitLink"
                tabIndex={0}
                component="button"
                role="link"
            >
                {cancelVisitButtonText}
            </Link>
        );

        const waitOfflineElement: JSX.Element = (
            <div className={styles.messagingBox}>
                <div
                    data-uitest="waitoffline-messageheader"
                    className={styles.largeMessage}
                >
                    {reasonText}
                </div>
                <div className={styles.smallMessage}>{bodyText}</div>
                <div className={styles.smallMessage}>{cancelVisitElement}</div>
                <CancelVisitDialog
                    active={cancelDialogOpen}
                    closeCancelVisitDialog={closeCancelVisitDialog}
                    endCall={cancelVisitHandler}
                    visitId={props.visitId}
                />
            </div>
        );
        const convertedElement: JSX.Element = (
            <div className={styles.messagingBox}>
                <div
                    data-uitest="converted-messageheader"
                    className={styles.largeMessage}
                >
                    {reasonText}
                </div>
                <div className={styles.smallMessage}>{bodyText}</div>
                <br />
                <div className={styles.smallMessage}>{messageWaitingRoom}</div>
            </div>
        );

        if (props.closedReason === 'waitoffline') {
            return <div className={styles.body}>{waitOfflineElement}</div>;
        } else if (props.closedReason === 'waitingroom') {
            return <div className={styles.body}>{convertedElement}</div>;
        } else {
            return <div className={styles.body}>{outdatedVisitElement}</div>;
        }
    };

    return <FooterPage>{buildContent()}</FooterPage>;
}

const _ClosedVisitModule =
    withTranslation()<typeof ClosedVisitModule>(ClosedVisitModule);
export { _ClosedVisitModule as ClosedVisitModule };
