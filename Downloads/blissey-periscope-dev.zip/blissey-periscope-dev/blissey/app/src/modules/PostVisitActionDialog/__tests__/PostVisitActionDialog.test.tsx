import * as React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { PostVisitActionDialog } from '../PostVisitActionDialog';
import userEvent from '@testing-library/user-event';
import { mockProviders } from '../../../../__fixtures__/mockProviders';
import { vi } from 'vitest';
import { ThemeProvider, createTheme } from '@mui/material';
import createBlisseyTheme from '@utils/createBlisseyTheme';
import * as featureFlags from '@utils/FeatureFlags';
import { config } from '@dexcare/circus-jupiter';
import { Configuration } from 'types/configuration';
import { ReasonTypesContext } from '../../../context/ReasonTypes/state/ReasonTypeContext';

const mockReason: {
    key: string;
    value: string;
} = vi.hoisted(() => ({
    key: 'waive_reasons',
    value: 'Waive Reasons',
}));

vi.mock('@clients/VisitService/VisitServiceClient', () => {
    return {
        visitServiceClient: {
            getReasons: vi.fn().mockResolvedValue([
                {
                    reasonType: 'waive',
                    reasons: [mockReason],
                },
            ]),
        },
    };
});

const appTheme = createBlisseyTheme((config as Configuration).getConfig());
const theme = createTheme({
    ...appTheme,
    components: {
        MuiButtonBase: {
            defaultProps: {
                disableRipple: true,
            },
        },
    },
    transitions: {
        create: () => 'none',
    },
});

describe('Post Visit Action Dialog', () => {
    vi.spyOn(featureFlags, 'getFeatureFlag').mockImplementation(() => true);
    afterEach(() => {
        vi.clearAllMocks();
    });

    it('overrides default labels of post visit action', async () => {
        render(
            <ThemeProvider theme={theme}>
                <PostVisitActionDialog
                    onCancel={vi.fn()}
                    onChange={vi.fn()}
                    onConfirm={vi.fn()}
                    onClose={vi.fn()}
                    showTransferOption
                    open
                    postVisitOptions={{
                        labelForCompleteVisit: 'custom complete',
                        labelForConvertModality: 'custom conversion',
                        labelForModalityConversionReason: 'custom reasons',
                        labelForTransferVisit: 'custom transfer',
                        labelForWaiveVisit: 'custom incomplete',
                        labelForWaiveReason: 'custom reason',
                    }}
                />
            </ThemeProvider>,
        );

        let dialog = await screen.findByTestId('post-visit-action-dialog');
        expect(dialog).toHaveTextContent('custom incomplete');
        expect(dialog).toHaveTextContent('custom complete');
        expect(dialog).toHaveTextContent('custom transfer');

        const waiveRadioButton = dialog.querySelector(
            'input[value="waive-visit"]',
        );
        expect(waiveRadioButton).not.toBeNull();
        await userEvent.click(waiveRadioButton as Element);
        dialog = await screen.findByTestId('post-visit-action-dialog');
        expect(dialog).toHaveTextContent('custom reason');
    });

    it('renders providers correctly for end and transfer', async () => {
        render(
            <ThemeProvider theme={theme}>
                <PostVisitActionDialog
                    onChange={vi.fn()}
                    onCancel={vi.fn()}
                    onConfirm={vi.fn()}
                    onClose={vi.fn()}
                    showTransferOption
                    open
                    providers={mockProviders}
                />
            </ThemeProvider>,
        );

        let dialog = await screen.findByTestId('post-visit-action-dialog');
        const transferRadioButton = dialog.querySelector(
            'input[value="transfer-visit"]',
        );
        expect(transferRadioButton).not.toBeNull();
        await userEvent.click(transferRadioButton as Element);
        dialog = await screen.findByTestId('post-visit-action-dialog');
        expect(dialog).toMatchSnapshot();
    });

    it.each([
        ['confirm', 'confirmation-dialog-confirm-button', 'onConfirm'],
        ['cancel', 'confirmation-dialog-cancel-button', 'onCancel'],
    ])(
        'fires click handler for the %s button',
        async (_, testId, handler: string) => {
            const handlers = {
                [handler]: vi.fn(),
            };
            render(
                <ThemeProvider theme={theme}>
                    <PostVisitActionDialog
                        onCancel={vi.fn()}
                        onConfirm={vi.fn()}
                        onChange={vi.fn()}
                        onClose={vi.fn()}
                        open
                        {...handlers}
                    />
                </ThemeProvider>,
            );
            await userEvent.click(screen.getByTestId(testId));
            expect(handlers[handler]).toHaveBeenCalled();
        },
    );

    it('is not visible when open false', async () => {
        render(
            <ThemeProvider theme={theme}>
                <PostVisitActionDialog
                    onCancel={vi.fn()}
                    onConfirm={vi.fn()}
                    onChange={vi.fn()}
                    onClose={vi.fn()}
                />
            </ThemeProvider>,
        );

        // testing libraries will throw if it cannot locate an element after a render
        await expect(screen.findByTestId('post-visit-action-dialog')).rejects
            .toThrowErrorMatchingInlineSnapshot(`
          [TestingLibraryElementError: Unable to find an element by: [data-testid="post-visit-action-dialog"]

          Ignored nodes: comments, script, style
          [36m<body>[39m
            [36m<div />[39m
          [36m</body>[39m

          Ignored nodes: comments, script, style
          [36m<body>[39m
            [36m<div />[39m
          [36m</body>[39m]
        `);
    });

    it('is visible when open true', () => {
        render(
            <ThemeProvider theme={theme}>
                <PostVisitActionDialog
                    onCancel={vi.fn()}
                    onConfirm={vi.fn()}
                    onClose={vi.fn()}
                    onChange={vi.fn()}
                    open
                />
            </ThemeProvider>,
        );
        const dialog = screen.getByTestId('post-visit-action-dialog');
        expect(dialog).toBeVisible();
    });

    it('with custom reasons', async () => {
        render(
            <ThemeProvider theme={theme}>
                <ReasonTypesContext>
                    <PostVisitActionDialog
                        onCancel={vi.fn()}
                        onChange={vi.fn()}
                        onConfirm={vi.fn()}
                        onClose={vi.fn()}
                        showTransferOption
                        open
                    />
                </ReasonTypesContext>
            </ThemeProvider>,
        );

        const dialog = await screen.findByTestId('post-visit-action-dialog');
        const waiveRadioButton = dialog.querySelector(
            'input[value="waive-visit"]',
        );
        expect(waiveRadioButton).not.toBeNull();
        await userEvent.click(waiveRadioButton as Element);
        const dropdown = dialog.querySelector('#waive-reason-selector');
        await userEvent.click(dropdown as HTMLDivElement);
        expect(screen.getByText('Waive Reasons')).toBeDefined();
    });
});
