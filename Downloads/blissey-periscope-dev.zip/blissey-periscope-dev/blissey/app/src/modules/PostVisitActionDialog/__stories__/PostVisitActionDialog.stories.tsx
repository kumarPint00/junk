import { Meta } from '@storybook/react';
import { action } from '@storybook/addon-actions';
import { PostVisitActionDialog } from '../PostVisitActionDialog';
import { mockProviders } from '../../../../__fixtures__/mockProviders';

const defaultProps = {
    onCancel: action('cancel'),
    onConfirm: action('confirm'),
    onClose: action('close'),
    onChange: action('change'),
};

const meta: Meta = {
    title: 'Modules/PostVisitActionDialog',
    component: PostVisitActionDialog,
    parameters: {
        fetchMock: {},
    },
};

export default meta;

export const Default = {
    args: {
        ...defaultProps,
        providers: mockProviders,
        open: false,
    },
};

export const LabelOverrides = {
    args: {
        ...defaultProps,
        providers: mockProviders,
        postVisitOptions: {
            labelForCompleteVisit: 'Complete',
            labelForConvertModality: 'Convert to Phone Visit',
            labelForModalityConversionReason: 'Reason for Modality Conversion',
            labelForTransferVisit: 'Transfer this visit',
            labelForWaiveVisit: 'Incomplete',
            labelForWaiveReason: 'Reason for incomplete',
        },
        open: false,
    },
};

export const NoProviders = {
    args: {
        ...defaultProps,
        providers: [],
        open: false,
    },
};

export const WithError = {
    args: {
        ...defaultProps,
        errorMessage: 'An error occured. Please try again.',
        providers: mockProviders,
        postVisitOptions: {
            labelForCompleteVisit: 'Complete',
            labelForConvertModality: 'Convert to Phone Visit',
            labelForModalityConversionReason: 'Reason for Modality Conversion',
            labelForTransferVisit: 'Transfer this visit',
            labelForWaiveVisit: 'Incomplete',
            labelForWaiveReason: 'Reason for incomplete',
        },
        open: false,
    },
};

export const WithModalityConversionReasons = {
    args: {
        ...defaultProps,
        providers: mockProviders,
        showConvertModalityOption: true,
        modalityConversionReasons: [
            {
                label: 'Option 1',
                value: 'OPTION_1',
            },
            {
                label: 'Option 2',
                value: 'OPTION_2',
            },
        ],
        postVisitOptions: {
            labelForCompleteVisit: 'Complete',
            labelForConvertModality: 'Convert to Phone Visit',
            labelForModalityConversionReason: 'Reason for Modality Conversion',
            labelForTransferVisit: 'Transfer this visit',
            labelForWaiveVisit: 'Incomplete',
            labelForWaiveReason: 'Reason for incomplete',
        },
        open: true,
    },
};
