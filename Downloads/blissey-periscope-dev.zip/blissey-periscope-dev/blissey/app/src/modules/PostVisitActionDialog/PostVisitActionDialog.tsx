import * as React from 'react';
import { useAtomValue } from 'jotai';
import { Provider } from '@clients/VisitService/VisitInterfaces';

import { ConfirmationDialog } from '@components/ConfirmationDialog/ConfirmationDialog';
import {
    PostVisitActionChange,
    PostVisitActionSelector,
} from '@dexcare/circus-saturn';
import { ProviderRadioListItem } from '@dexcare/provider-card';
import { AppConfig } from '../../../../server/config/configInterfaces';
import ErrorIcon from '@mui/icons-material/Error';
import * as styles from './styles.css';
import { getWaiveReasonsAtom } from '../../context/ReasonTypes/state/atoms/reasonTypes';

export interface PostVisitActionDialogProps {
    onCancel: () => void;
    onConfirm: () => void;
    onClose: () => void;
    onChange: (value: PostVisitActionChange) => void;
    errorMessage?: string | null;
    open?: boolean;
    loading?: boolean;
    showTransferOption?: boolean;
    showConvertModalityOption?: boolean;
    providers?: Provider[];
    postVisitOptions?: AppConfig['postVisitOptions'];
    modalityConversionReasons?: AppConfig['modalityConversionReasons'];
    value?: PostVisitActionChange;
}

export { PostVisitActions } from '@dexcare/circus-saturn';

export const PostVisitActionDialog = ({
    onConfirm,
    onCancel,
    onClose,
    onChange,
    errorMessage,
    modalityConversionReasons = [],
    postVisitOptions = {},
    showTransferOption = false,
    showConvertModalityOption = false,
    open = false,
    loading = false,
    providers = [],
}: PostVisitActionDialogProps) => {
    const waiveReasons = useAtomValue(getWaiveReasonsAtom);
    const {
        labelForCompleteVisit,
        labelForConvertModality,
        labelForModalityConversionReason,
        labelForTransferVisit,
        labelForWaiveVisit,
        labelForWaiveReason,
    } = postVisitOptions;

    return (
        <ConfirmationDialog
            onConfirm={onConfirm}
            onCancel={onCancel}
            onClose={onClose}
            open={open}
            loading={loading}
            data-testid="post-visit-action-dialog"
        >
            <>
                <PostVisitActionSelector
                    labels={{
                        labelForCompleteVisit,
                        labelForConvertModality,
                        labelForModalityConversionReason,
                        labelForWaiveVisit,
                        labelForTransferVisit,
                        labelForReason: labelForWaiveReason,
                    }}
                    showTransferOption={showTransferOption}
                    showConvertModalityOption={showConvertModalityOption}
                    modalityConversionReasons={modalityConversionReasons}
                    providers={providers as unknown as ProviderRadioListItem[]}
                    transferOptions={{
                        providerColumns: 2,
                        providerRows: 2,
                    }}
                    waiveReasons={waiveReasons}
                    onChange={onChange}
                />
                {errorMessage && (
                    <div className={styles.errorContainer}>
                        <ErrorIcon style={{ marginRight: '0.2em' }} />{' '}
                        {errorMessage}
                    </div>
                )}
            </>
        </ConfirmationDialog>
    );
};
