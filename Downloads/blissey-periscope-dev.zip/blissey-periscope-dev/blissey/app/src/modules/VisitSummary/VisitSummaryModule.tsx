import * as React from 'react';

import { Button } from '@components/Button';
import { Logger, LogManager, config as Config } from '@dexcare/circus-jupiter';

import { VisitSummaryModuleProps } from './VisitSummaryInterfaces';
import { FooterPage } from '@layout/PageLayout/FooterPage';
import { VisitSummaryCard } from '@components/VisitSummary/VisitSummaryCard';
import { withTranslation } from 'react-i18next';

import { Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './VisitSummary.css';
import { Configuration } from 'types/configuration';
import { getExitSurveyInterface } from '@common/getExitSurveyInterface';

const config = Config as Configuration;
class VisitSummaryModule extends React.Component<VisitSummaryModuleProps> {
    private logger: Logger;

    constructor(props: VisitSummaryModuleProps) {
        super(props);
        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'VisitSummaryModule',
                eventType: 'render',
            },
            true,
        );
    }

    public componentDidMount() {
        Analytics.sendPageView({
            destinationURL: '/end',
        });
        this.logger.info({ eventType: 'render' });
    }

    public render() {
        const { onSignOut } = this.props;

        const header = this.props.t('appointment-summary.title');
        const thanks = this.props.t('appointment-summary.thanks');
        const conclude = this.props.t('appointment-summary.conclusion');

        // TODO: Once all customers have moved their strings into the translation files,
        //   This section can be cleaned up to not pull strings from the config files, and the
        //   `visitSummaryText` object can be removed from all config files
        const treatmentPlan =
            this.props.t('appointment-summary.conclusionSummary', '') ||
            config.getConfig().visitSummaryText.treatmentPlan;
        const treatmentPlanAlt =
            this.props.t('appointment-summary.treatmentPlanAlt', '') ||
            config.getConfig().visitSummaryText.treatmentPlanAlt;
        const treatmentPlanAltURL =
            this.props.t('appointment-summary.treatmentPlanAltURL', '') ||
            config.getConfig().visitSummaryText.treatmentPlanAltURL;
        const treatmentPlanAltTime =
            this.props.t('appointment-summary.treatmentPlanAltTime', '') ||
            config.getConfig().visitSummaryText.treatmentPlanAltTime;

        const prescription = this.props.t(
            'appointment-summary.prescriptionSummary',
            { interpolation: { escapeValue: false } },
        );

        const surveyInterface = getExitSurveyInterface(window);

        const signOutButton = surveyInterface
            ? this.props.t('appointment-summary.done')
            : this.props.t('appointment-summary.signOut');

        const followupText = this.props.t(
            'appointment-summary.followupText',
            '',
        );

        return (
            <FooterPage headerText={header}>
                <div className={styles.container}>
                    <div className={styles.cardButtonContainer}>
                        <VisitSummaryCard
                            thanksText={thanks}
                            concludeText={conclude}
                            treatmentPlanText={treatmentPlan}
                            treatmentPlanAltText={treatmentPlanAlt}
                            treatmentPlanAltURL={treatmentPlanAltURL}
                            treatmentPlanAltTimeText={treatmentPlanAltTime}
                            followupText={followupText}
                            prescriptionText={prescription}
                            t={this.props.t}
                            visitId={this.props.visitId}
                        />
                        <div className={styles.buttonContainer}>
                            <Button
                                onClick={onSignOut}
                                uiTestTag={'visitsummary-signout'}
                            >
                                {signOutButton}
                            </Button>
                        </div>
                    </div>
                </div>
            </FooterPage>
        );
    }
}

const _VisitSummaryModule =
    withTranslation()<typeof VisitSummaryModule>(VisitSummaryModule);
export { _VisitSummaryModule as VisitSummaryModule };
