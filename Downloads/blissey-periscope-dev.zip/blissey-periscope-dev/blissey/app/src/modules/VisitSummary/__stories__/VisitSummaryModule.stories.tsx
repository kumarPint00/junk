import * as React from 'react';
import { VisitSummaryModuleProps } from '../VisitSummaryInterfaces';
import { VisitSummaryModule } from '../VisitSummaryModule';

import * as wrapperStyles from './VisitSummaryModuleStory.css';

const Template = (props: VisitSummaryModuleProps) => (
    <div className={wrapperStyles.div}>
        <VisitSummaryModule
            {...{
                ...props,
                onSignOut: () => {
                    console.log('SIGNOUT CLICKED!');
                },
            }}
        />
    </div>
);

export const Default = Template.bind({}) as typeof Template;

export default {
    title: 'Modules/VisitSummary',
    component: VisitSummaryModule,
};
