import { WithTranslation } from 'react-i18next';

export interface VisitSummaryModuleProps extends WithTranslation {
    // firstName: string; TODO bring this in when we have access to patient information
    onSignOut: () => void;
    visitId: string;
}
