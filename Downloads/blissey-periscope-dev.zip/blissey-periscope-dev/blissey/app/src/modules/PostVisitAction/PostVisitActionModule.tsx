import { Button } from '@components/Button';
import {
    PostVisitActionChange,
    PostVisitActionSelector,
    PostVisitActions,
} from '@dexcare/circus-saturn';
import { ProviderRadioListItem } from '@dexcare/provider-card';
import Card from '@mui/material/Card';
import { PaymentStatus } from '@redux/utils/PaymentStatus';
import { getConfig } from '@utils/config';
import { getWaiveReasonsAtom } from '../../context/ReasonTypes/state/atoms/reasonTypes';
import * as React from 'react';
import { useCallback, useState } from 'react';
import { useAtomValue } from 'jotai';
import { getProviders } from './getProviders';
import { PostVisitActionModuleProps } from './interfaces';

import * as styles from './styles.css';

export function PostVisitActionModule({
    chargedStatus = PaymentStatus.none,
    showTransferOption = false,
    showConvertModalityOption = false,
    visitId,
    disabled = false,
    onSubmit,
}: PostVisitActionModuleProps) {
    const [postVisitActionChange, setPostVisitActionChange] =
        useState<PostVisitActionChange>({
            selectedAction: PostVisitActions.Complete,
        });
    const [providers, setProviders] = useState<ProviderRadioListItem[]>([]);
    const waiveReasons = useAtomValue(getWaiveReasonsAtom);

    React.useEffect(() => {
        if (showTransferOption && visitId) {
            void getProviders(visitId).then((list) => {
                if (list)
                    setProviders(list as unknown as ProviderRadioListItem[]);
            });
        }
    }, [showTransferOption, visitId]);

    const handleChange = useCallback(
        (change: PostVisitActionChange) => setPostVisitActionChange(change),
        [],
    );

    const handleSubmit = useCallback(() => {
        onSubmit(postVisitActionChange);
    }, [postVisitActionChange, onSubmit]);

    const { postVisitOptions = {} } = getConfig();
    const {
        labelForCompleteVisit,
        labelForConvertModality,
        labelForModalityConversionReason,
        labelForTransferVisit,
        labelForWaiveVisit,
        labelForWaiveReason,
    } = postVisitOptions;

    let body: JSX.Element;
    if (chargedStatus === PaymentStatus.none) {
        body = (
            <PostVisitActionSelector
                labels={{
                    labelForCompleteVisit,
                    labelForConvertModality,
                    labelForModalityConversionReason,
                    labelForWaiveVisit,
                    labelForTransferVisit,
                    labelForReason: labelForWaiveReason,
                }}
                waiveReasons={waiveReasons}
                showTransferOption={showTransferOption}
                showConvertModalityOption={showConvertModalityOption}
                providers={providers}
                modalityConversionReasons={
                    getConfig().modalityConversionReasons
                }
                transferOptions={{
                    providerColumns: 2,
                    providerRows: 2,
                }}
                onChange={handleChange}
            />
        );
    } else {
        body = (
            <p className={styles.text}>{`You already decided to ${
                chargedStatus === PaymentStatus.charged ? 'charge' : 'waive'
            } this visit.  Please continue to submit feedback.`}</p>
        );
    }

    return (
        <div
            className={styles.container}
            data-uitest="post-visit-action-module"
        >
            <Card className={styles.card}>{body}</Card>
            <Button
                disabled={disabled}
                uiTestTag="postVisitActionModule-continueButton"
                onClick={() => void handleSubmit()}
                fullWidth
            >
                CONTINUE
            </Button>
        </div>
    );
}
