import * as React from 'react';
import { render, screen, configure } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import { PostVisitActionModule } from '../PostVisitActionModule';
import { vi, Mocked } from 'vitest';
import { PaymentStatus } from '@redux/utils/PaymentStatus';
import * as featureFlags from '@utils/FeatureFlags';
import { ReasonTypesContext } from '../../../context/ReasonTypes/state/ReasonTypeContext';

let mockConfig: Mocked<typeof import('@utils/config')>;

const mockReason: {
    key: string;
    value: string;
} = vi.hoisted(() => ({
    key: 'waive_reasons',
    value: 'Waive Reasons',
}));

vi.mock('@clients/VisitService/VisitServiceClient', () => {
    return {
        visitServiceClient: {
            getReasons: vi.fn().mockResolvedValue([
                {
                    reasonType: 'waive',
                    reasons: [mockReason],
                },
            ]),
        },
    };
});

describe('Post Visit Action Modul', () => {
    configure({ testIdAttribute: 'data-uitest' });
    vi.spyOn(featureFlags, 'getFeatureFlag').mockImplementation(() => true);
    beforeEach(async () => {
        mockConfig = await vi.importMock('@utils/config');
    });
    afterEach(() => {
        vi.clearAllMocks();
    });
    it('with default labels', async () => {
        render(
            <PostVisitActionModule
                showTransferOption={false}
                visitId="visitId"
                onSubmit={vi.fn()}
            />,
        );

        const module = await screen.findByTestId('post-visit-action-module');
        expect(module).toHaveTextContent('Charge VisitWaive VisitCONTINUE');
    });

    it('overrides default labels of post visit action', async () => {
        mockConfig.getConfig.mockReturnValue({
            postVisitOptions: {
                labelForCompleteVisit: 'labelForCompleteVisit',
            },
        } as never);
        render(
            <PostVisitActionModule
                chargedStatus={PaymentStatus.charged}
                showTransferOption={false}
                visitId="visitId"
                onSubmit={vi.fn()}
            />,
        );

        const module = await screen.findByTestId('post-visit-action-module');
        expect(module).toHaveTextContent(
            'You already decided to charge this visit. Please continue to submit feedback.CONTINUE',
        );
    });

    it('with custom reasons', async () => {
        render(
            <ReasonTypesContext>
                <PostVisitActionModule
                    showTransferOption={false}
                    visitId="visitId"
                    onSubmit={vi.fn()}
                />
            </ReasonTypesContext>,
        );

        const module = await screen.findByTestId('post-visit-action-module');
        const waiveRadioButton = module.querySelector(
            'input[value="waive-visit"]',
        );
        expect(waiveRadioButton).not.toBeNull();
        await userEvent.click(waiveRadioButton as Element);
        const dropdown = module.querySelector('#waive-reason-selector');
        await userEvent.click(dropdown as HTMLDivElement);
        expect(screen.getByText('Waive Reasons')).toBeDefined();
    });
});
