import { vi } from 'vitest';
import { successResponse } from '../__stories__/getTransferOptions';
import { getProviders } from '../getProviders';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';

vi.mock('@clients/VisitService/VisitServiceClient');

describe('getProviders', () => {
    const visitId = 'visit-id';

    it.each([undefined, {}, { practiceRegions: [] }])(
        'should return undefined if no providers in response',
        async (response) => {
            visitServiceClient.getTransferOptions = vi
                .fn()
                .mockResolvedValueOnce(response);
            const result = await getProviders(visitId);
            expect(result).toBeUndefined();
        },
    );

    it('should throw if transfer options throws', async () => {
        visitServiceClient.getTransferOptions = vi
            .fn()
            .mockRejectedValueOnce('boom');
        try {
            await getProviders(visitId);
            expect(false).toBeTruthy();
        } catch (err) {
            expect(err).toBeDefined();
        }
    });

    it('should return empty list if no providers found', async () => {
        const transferOptions = { providers: [] };
        visitServiceClient.getTransferOptions = vi
            .fn()
            .mockResolvedValueOnce(transferOptions);
        const result = await getProviders(visitId);
        expect(result).toEqual([]);
    });

    it('should return providers successfully', async () => {
        const transferOptions = successResponse;
        visitServiceClient.getTransferOptions = vi
            .fn()
            .mockResolvedValueOnce(transferOptions);
        const result = await getProviders(visitId);
        expect(result).toMatchSnapshot();
    });
});
