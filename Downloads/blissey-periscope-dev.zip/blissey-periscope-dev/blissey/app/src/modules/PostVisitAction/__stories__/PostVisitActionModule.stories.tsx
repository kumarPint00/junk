import { action } from '@storybook/addon-actions';
import { PostVisitActionModule } from '../PostVisitActionModule';
import { successResponse } from './getTransferOptions';

const visitId = 'success-visit-id';
const transferOptionsMock = {
    matcher: {
        end: `/v1/visits/${visitId}/transfer-options`,
    },
    response: {
        status: 200,
        body: successResponse,
    },
};

export default {
    title: 'Modules/PostVisitAction',
    component: PostVisitActionModule,
    parameters: {
        layout: 'centered',
        fetchMock: {
            debug: true,
            mocks: [transferOptionsMock],
        },
    },
};

export const Default = {
    args: {
        visitId,
        onSubmit: action('onSubmit'),
    },
};
