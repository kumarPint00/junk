import {
    TransferOptions,
    Provider,
} from '@clients/VisitService/VisitInterfaces';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';

/**
 * Get transfer options and extract a list of providers in UI format
 * @param visitId
 * @returns
 */
export async function getProviders(
    visitId: string,
): Promise<Provider[] | undefined> {
    const transferOptions: TransferOptions =
        await visitServiceClient.getTransferOptions(visitId);

    if (!transferOptions?.providers) return undefined;

    return (
        transferOptions.providers
            // remove undefined values;
            .filter((provider: Provider) => provider)
    );
}
