export const successResponse = {
    providers: [
        {
            id: '32069188-fc7d-4489-90c8-3dec0b36111c1',
            overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
            smsNumber: '2025551212',
            displayInfo: {
                name: 'DexCare Provider.121',
                specialty: 'ECV',
            },
            oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
            practiceRegions: [
                {
                    id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                    regionCode: 'MT',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                    regionCode: 'WA',
                    practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                    market: 'Backup',
                },
                {
                    id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                    regionCode: 'OR',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                    regionCode: 'WA',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
            ],
            assignmentQualifiers: [
                {
                    id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                    name: 'pediatric',
                },
                {
                    id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                    name: 'adult',
                },
            ],
            modalities: [
                {
                    id: '57ffd934-1226-41be-b93a-30af16c056e4',
                    name: 'virtual',
                },
                {
                    id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                    name: 'phone',
                },
            ],
            version: 0,
            createdAt: '2021-12-16T20:06:42.271Z',
            updatedAt: '2023-09-19T22:12:50.153Z',
            deletedAt: null,
            visitId: null,
        },
        {
            id: '32069188-fc7d-4489-90c8-3dec0b36111c2',
            overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
            smsNumber: '2025551212',
            displayInfo: {
                name: 'DexCare Provider.122',
                specialty: 'ECV',
            },
            oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
            practiceRegions: [
                {
                    id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                    regionCode: 'MT',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                    regionCode: 'WA',
                    practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                    market: 'Backup',
                },
                {
                    id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                    regionCode: 'OR',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                    regionCode: 'WA',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
            ],
            assignmentQualifiers: [
                {
                    id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                    name: 'pediatric',
                },
                {
                    id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                    name: 'adult',
                },
            ],
            modalities: [
                {
                    id: '57ffd934-1226-41be-b93a-30af16c056e4',
                    name: 'virtual',
                },
                {
                    id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                    name: 'phone',
                },
            ],
            version: 0,
            createdAt: '2021-12-16T20:06:42.271Z',
            updatedAt: '2023-09-19T22:12:50.153Z',
            deletedAt: null,
            visitId: null,
        },
        {
            id: '32069188-fc7d-4489-90c8-3dec0b36111c3',
            overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
            smsNumber: '2025551212',
            displayInfo: {
                name: 'DexCare Provider.123',
                specialty: 'ECV',
            },
            oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
            practiceRegions: [
                {
                    id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                    regionCode: 'MT',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                    regionCode: 'WA',
                    practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                    market: 'Backup',
                },
                {
                    id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                    regionCode: 'OR',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                    regionCode: 'WA',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
            ],
            assignmentQualifiers: [
                {
                    id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                    name: 'pediatric',
                },
                {
                    id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                    name: 'adult',
                },
            ],
            modalities: [
                {
                    id: '57ffd934-1226-41be-b93a-30af16c056e4',
                    name: 'virtual',
                },
                {
                    id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                    name: 'phone',
                },
            ],
            version: 0,
            createdAt: '2021-12-16T20:06:42.271Z',
            updatedAt: '2023-09-19T22:12:50.153Z',
            deletedAt: null,
            visitId: null,
        },
        {
            id: '32069188-fc7d-4489-90c8-3dec0b36111c4',
            overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
            smsNumber: '2025551212',
            displayInfo: {
                name: 'DexCare Provider.124',
                specialty: 'ECV',
            },
            oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
            practiceRegions: [
                {
                    id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                    regionCode: 'MT',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                    regionCode: 'WA',
                    practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                    market: 'Backup',
                },
                {
                    id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                    regionCode: 'OR',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                    regionCode: 'WA',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
            ],
            assignmentQualifiers: [
                {
                    id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                    name: 'pediatric',
                },
                {
                    id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                    name: 'adult',
                },
            ],
            modalities: [
                {
                    id: '57ffd934-1226-41be-b93a-30af16c056e4',
                    name: 'virtual',
                },
                {
                    id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                    name: 'phone',
                },
            ],
            version: 0,
            createdAt: '2021-12-16T20:06:42.271Z',
            updatedAt: '2023-09-19T22:12:50.153Z',
            deletedAt: null,
            visitId: null,
        },
        {
            id: '32069188-fc7d-4489-90c8-3dec0b36111c5',
            overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
            smsNumber: '2025551212',
            displayInfo: {
                name: 'DexCare Provider.122',
                specialty: 'ECV',
            },
            oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
            practiceRegions: [
                {
                    id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                    regionCode: 'MT',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                    regionCode: 'WA',
                    practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                    market: 'Backup',
                },
                {
                    id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                    regionCode: 'OR',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                    regionCode: 'WA',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
            ],
            assignmentQualifiers: [
                {
                    id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                    name: 'pediatric',
                },
                {
                    id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                    name: 'adult',
                },
            ],
            modalities: [
                {
                    id: '57ffd934-1226-41be-b93a-30af16c056e4',
                    name: 'virtual',
                },
                {
                    id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                    name: 'phone',
                },
            ],
            version: 0,
            createdAt: '2021-12-16T20:06:42.271Z',
            updatedAt: '2023-09-19T22:12:50.153Z',
            deletedAt: null,
            visitId: null,
        },
        {
            id: '32069188-fc7d-4489-90c8-3dec0b36111c6',
            overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
            smsNumber: '2025551212',
            displayInfo: {
                name: 'DexCare Provider.122',
                specialty: 'ECV',
            },
            oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
            practiceRegions: [
                {
                    id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                    regionCode: 'MT',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                    regionCode: 'WA',
                    practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                    market: 'Backup',
                },
                {
                    id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                    regionCode: 'OR',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                    regionCode: 'WA',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
            ],
            assignmentQualifiers: [
                {
                    id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                    name: 'pediatric',
                },
                {
                    id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                    name: 'adult',
                },
            ],
            modalities: [
                {
                    id: '57ffd934-1226-41be-b93a-30af16c056e4',
                    name: 'virtual',
                },
                {
                    id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                    name: 'phone',
                },
            ],
            version: 0,
            createdAt: '2021-12-16T20:06:42.271Z',
            updatedAt: '2023-09-19T22:12:50.153Z',
            deletedAt: null,
            visitId: null,
        },
        {
            id: '32069188-fc7d-4489-90c8-3dec0b36111c7',
            overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
            smsNumber: '2025551212',
            displayInfo: {
                name: 'DexCare Provider.122',
                specialty: 'ECV',
            },
            oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
            practiceRegions: [
                {
                    id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                    regionCode: 'MT',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                    regionCode: 'WA',
                    practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                    market: 'Backup',
                },
                {
                    id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                    regionCode: 'OR',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                    regionCode: 'WA',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
            ],
            assignmentQualifiers: [
                {
                    id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                    name: 'pediatric',
                },
                {
                    id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                    name: 'adult',
                },
            ],
            modalities: [
                {
                    id: '57ffd934-1226-41be-b93a-30af16c056e4',
                    name: 'virtual',
                },
                {
                    id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                    name: 'phone',
                },
            ],
            version: 0,
            createdAt: '2021-12-16T20:06:42.271Z',
            updatedAt: '2023-09-19T22:12:50.153Z',
            deletedAt: null,
            visitId: null,
        },
        {
            id: '32069188-fc7d-4489-90c8-3dec0b36111c8',
            overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
            smsNumber: '2025551212',
            displayInfo: {
                name: 'DexCare Provider.122',
                specialty: 'ECV',
            },
            oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
            practiceRegions: [
                {
                    id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                    regionCode: 'MT',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                    regionCode: 'WA',
                    practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                    market: 'Backup',
                },
                {
                    id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                    regionCode: 'OR',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                    regionCode: 'WA',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
            ],
            assignmentQualifiers: [
                {
                    id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                    name: 'pediatric',
                },
                {
                    id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                    name: 'adult',
                },
            ],
            modalities: [
                {
                    id: '57ffd934-1226-41be-b93a-30af16c056e4',
                    name: 'virtual',
                },
                {
                    id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                    name: 'phone',
                },
            ],
            version: 0,
            createdAt: '2021-12-16T20:06:42.271Z',
            updatedAt: '2023-09-19T22:12:50.153Z',
            deletedAt: null,
            visitId: null,
        },
        {
            id: '32069188-fc7d-4489-90c8-3dec0b36111c9',
            overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
            smsNumber: '2025551212',
            displayInfo: {
                name: 'DexCare Provider.122',
                specialty: 'ECV',
            },
            oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
            practiceRegions: [
                {
                    id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                    regionCode: 'MT',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                    regionCode: 'WA',
                    practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                    market: 'Backup',
                },
                {
                    id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                    regionCode: 'OR',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
                {
                    id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                    regionCode: 'WA',
                    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                    market: 'default',
                },
            ],
            assignmentQualifiers: [
                {
                    id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                    name: 'pediatric',
                },
                {
                    id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                    name: 'adult',
                },
            ],
            modalities: [
                {
                    id: '57ffd934-1226-41be-b93a-30af16c056e4',
                    name: 'virtual',
                },
                {
                    id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                    name: 'phone',
                },
            ],
            version: 0,
            createdAt: '2021-12-16T20:06:42.271Z',
            updatedAt: '2023-09-19T22:12:50.153Z',
            deletedAt: null,
            visitId: null,
        },
    ],
    practiceRegions: [
        {
            id: '2dfdc1bf-ff7f-4e3f-a25f-c546aa5fcfbc',
            practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
            displayName: 'Washington Backup',
            regionCode: 'WA',
            active: true,
            availability: [
                {
                    start: '2023-09-17T07:00:00.000Z',
                    end: '2023-09-18T06:59:00.000Z',
                },
                {
                    start: '2023-09-18T07:00:00.000Z',
                    end: '2023-09-19T06:59:00.000Z',
                },
                {
                    start: '2023-09-19T07:00:00.000Z',
                    end: '2023-09-20T06:59:00.000Z',
                },
                {
                    start: '2023-09-20T07:00:00.000Z',
                    end: '2023-09-21T06:59:00.000Z',
                },
                {
                    start: '2023-09-21T07:00:00.000Z',
                    end: '2023-09-22T06:59:00.000Z',
                },
                {
                    start: '2023-09-22T07:00:00.000Z',
                    end: '2023-09-23T06:59:00.000Z',
                },
                {
                    start: '2023-09-23T07:00:00.000Z',
                    end: '2023-09-24T06:59:00.000Z',
                },
            ],
            busy: false,
            busyMessage: 'Providers are currently at capacity and closed',
            paymentAccountId: '3faed309-efd8-45ab-a9de-1bc149745bb2',
            visitPrice: 4900,
            orderWeight: 0,
            departments: [
                {
                    id: '4d2a72d5-41d5-462d-985b-9e2ce41c1570',
                    epicDepartmentId: '405772000',
                    ehrSystemName: 'org.providence.dig.epic.provorca',
                    defaultDepartmentName: 'Interstate',
                },
            ],
            market: {
                id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                name: 'Backup',
                description: 'Backup',
            },
            transferOptionBufferInMinutes: 700,
        },
    ],
};
