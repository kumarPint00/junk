import { PostVisitActionChange } from '@dexcare/circus-saturn';
import { PaymentStatus } from '@redux/utils/PaymentStatus';

export interface PostVisitActionModuleProps {
    chargedStatus?: PaymentStatus;
    showTransferOption?: boolean;
    showConvertModalityOption?: boolean;
    visitId?: string; // needed if transfer is enabled
    disabled?: boolean;
    // callbacks
    onSubmit: (change: PostVisitActionChange) => void;
}
