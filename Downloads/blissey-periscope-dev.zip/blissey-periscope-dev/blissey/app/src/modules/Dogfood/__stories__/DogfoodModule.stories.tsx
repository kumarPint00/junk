import { DogFoodModule } from '../DogFoodModule';

export default {
    title: 'Modules/Dogfood',
    component: DogFoodModule,
};

export const Default = {
    args: {
        userDetails: {
            id: '',
            displayName: '',
            givenName: '',
            familyName: '',
            email: '',
            token: '',
            expiration: -1,
            roles: [],
        },
        brands: ['brand1', 'brand2'],
    },
};
