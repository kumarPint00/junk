import * as React from 'react';
import { Timed } from '@dexcare/circus-jupiter';
import { SelectChangeEvent } from '@mui/material';

import { DogFoodHeader } from '../../components/Dogfood/DogFoodHeader';
import { DogFoodForm } from '../../components/Dogfood/DogFoodForm';
import { backendFacade } from '../../clients/Backend/BackendFacade';
import { UserDetails } from '@dexcare/circus-saturn';

import * as styles from './DogFoodModule.css';

export interface DogfoodModuleProps {
    userDetails: UserDetails;
    brands: string[];
}

export interface DogfoodModuleState {
    brand: string;
    providerLink?: string;
    patientLink?: string;
    patientWaitingRoomToken?: string;
    patientVideoToken?: string;
    waitingRoomSessionId?: string;
    videoSessionId?: string;
}

export class DogFoodModule extends React.PureComponent<
    DogfoodModuleProps,
    DogfoodModuleState
> {
    private static domain = window.location.href.split('dogfood')[0];
    private dogFoodForm: DogFoodForm;

    constructor(props: DogfoodModuleProps) {
        super(props);
        this.onGenerateClick = this.onGenerateClick.bind(
            this,
        ) as typeof this.onGenerateClick;
        const { brands } = props;

        this.state = {
            brand: brands[0],
        };
    }

    @Timed
    public render() {
        const { providerLink, patientLink } = this.state;
        const { brands } = this.props;

        const dropdownValues: { value: string; label: string }[] = [];
        brands.forEach((key) =>
            dropdownValues.push({ value: key, label: key }),
        );
        return (
            <div className={styles.dogfood}>
                <DogFoodHeader />
                <DogFoodForm
                    providerLink={providerLink}
                    patientLink={patientLink}
                    onBrandChange={this.onSelectChange('brand')}
                    brands={dropdownValues}
                    selectedBrand={this.state.brand}
                    onGenerateClick={() => void this.onGenerateClick()}
                    ref={
                        this.setDogFoodFormRef.bind(
                            this,
                        ) as typeof this.setDogFoodFormRef
                    }
                    patientVideoToken={this.state.patientVideoToken}
                    patientWaitingRoomToken={this.state.patientWaitingRoomToken}
                    waitingRoomSessionId={this.state.waitingRoomSessionId}
                    videoSessionId={this.state.videoSessionId}
                />
            </div>
        );
    }

    private onCheckboxChange =
        (key: keyof DogfoodModuleState) =>
        (event: React.ChangeEvent<HTMLInputElement>) => {
            const checked = event.target.checked;
            this.setState((prevState) => ({ ...prevState, [key]: checked }));
        };

    private onSelectChange =
        (key: keyof DogfoodModuleState) =>
        (event: SelectChangeEvent<string>) => {
            const value = event.target.value;
            this.setState((prevState) => ({ ...prevState, [key]: value }));
        };

    private setDogFoodFormRef(ref: DogFoodForm): void {
        this.dogFoodForm = ref;
    }

    private createProviderLink = (visitId: string, queryParams?: string) => {
        return `${DogFoodModule.domain}room/${visitId}?${queryParams || ''}`;
    };

    private createPatientLink = (visitId: string, queryParams?: string) => {
        return `${DogFoodModule.domain}visit/${visitId}?${queryParams || ''}`;
    };

    private async createTokBoxSession() {
        return await backendFacade.requestTokboxDogfoodVisit();
    }

    private async onGenerateClick() {
        // add a timestamp to make the visitid unique for logging purposes
        const visitId = `testvisit-tokbox-${new Date().getTime()}-okay`;
        const [waitingRoomSession, videoSession] = await Promise.all([
            this.createTokBoxSession(),
            this.createTokBoxSession(),
        ]);
        const queryParams = {
            brand: this.state.brand,
            waitingRoomSessionId: waitingRoomSession.sessionId,
            videoSessionId: videoSession.sessionId,
        };
        const patientWaitingRoomToken = waitingRoomSession.patientToken;
        const patientVideoToken = videoSession.patientToken;

        const objToQs = (obj: { [key: string]: string }) => {
            return Object.keys(obj)
                .map((key: string) => key + '=' + encodeURIComponent(obj[key]))
                .join('&');
        };

        const patientLink = this.createPatientLink(
            visitId,
            objToQs(queryParams),
        );
        const providerLink = this.createProviderLink(
            visitId,
            objToQs(queryParams),
        );

        this.setState({
            patientLink,
            providerLink,
            patientVideoToken,
            patientWaitingRoomToken,
            waitingRoomSessionId: waitingRoomSession.sessionId,
            videoSessionId: videoSession.sessionId,
        });
    }
}
