import * as React from 'react';

import { config } from '@dexcare/circus-jupiter';
import { UserDetails } from '@dexcare/circus-saturn';
import { Hangup } from '../../components/Hangup/Hangup';

import * as styles from './HangupModule.css';
import { Configuration } from 'types/configuration';

interface Props {
    userDetails?: UserDetails;
}

export class HangupModule extends React.PureComponent<Props> {
    public render() {
        const caregiverPortalLink = (config as Configuration).getConfig()
            .caregiverPortalLink;
        return (
            <div className={styles.main}>
                <Hangup caregiverPortalLink={caregiverPortalLink} />
            </div>
        );
    }
}
