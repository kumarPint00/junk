import { HangupModule } from '../HangupModule';

export const Default = {
    args: {},
};
export default {
    title: 'Components/HangupModule',
    component: HangupModule,
    parameters: {
        layout: 'centered',
    },
};
