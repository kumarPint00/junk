import * as React from 'react';
import { PaymentModule } from '../PaymentModule';
import { PaymentStatus } from '@redux/utils/PaymentStatus';
import { StoryFn } from '@storybook/react';

const handleAction = (name: string) => () => {
    console.log(`action ${name}`);
};

interface Args {
    disabled: boolean;
    chargedStatus: keyof typeof PaymentStatus;
}
const Template = (args: Args) => {
    return (
        <PaymentModule
            visitId="1"
            handleCharge={handleAction('charge')}
            handleWaive={handleAction('waive')}
            handleContinue={handleAction('continue')}
            chargedStatus={PaymentStatus[args.chargedStatus]}
            disabled={args.disabled}
        />
    );
};

export const Default = Template.bind({}) as StoryFn<typeof Template>;
Default.args = {
    disabled: false,
    chargedStatus: 'none',
};

export default {
    title: 'Modules/Payment',
    component: PaymentModule,
    argTypes: {
        chargedStatus: {
            options: [
                ...Object.values(PaymentStatus).filter(
                    (m) => typeof m === 'string',
                ),
            ],
            control: 'radio',
        },
    },
    parameters: {
        layout: 'centered',
    },
};
