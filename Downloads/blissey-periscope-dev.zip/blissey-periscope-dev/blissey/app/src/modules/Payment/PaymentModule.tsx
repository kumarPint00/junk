import * as React from 'react';
import { useCallback, useState } from 'react';
import Card from '@mui/material/Card';
import {
    ChargeOrWaiveSelector,
    CHARGE_ID,
    WAIVE_ID,
} from '@dexcare/charge-or-waive-selector';
import { Button } from '@components/Button';
import { PaymentStatus } from '@redux/utils/PaymentStatus';
import { PaymentModuleProps } from './PaymentModuleInterfaces';

import * as styles from './PaymentModule.css';

const getAlreadyDecidedText = (chargedStatus: PaymentStatus) => {
    const infinitive =
        chargedStatus === PaymentStatus.charged ? 'charge' : 'waive';
    return `You already decided to ${infinitive} this visit.  Please continue to submit feedback.`;
};

/**
 * @deprecated
 * @param param0
 * @returns
 */
export const PaymentModule = ({
    handleCharge,
    handleWaive,
    handleContinue,
    chargedStatus,
    disabled,
}: PaymentModuleProps) => {
    const [waiveReason, setWaiveReason] = useState('');
    const [radioValue, setRadioValue] = useState(CHARGE_ID);

    const handleRadioChange = useCallback(
        (value: string) => setRadioValue(value),
        [],
    );
    const handleDropdownChange = useCallback(
        (value: string) => setWaiveReason(value),
        [],
    );

    const handleSubmit = useCallback(() => {
        if (chargedStatus === PaymentStatus.none) {
            if (radioValue === WAIVE_ID) {
                handleWaive(waiveReason);
            } else {
                handleCharge();
            }
        } else {
            handleContinue();
        }
    }, [
        radioValue,
        waiveReason,
        chargedStatus,
        handleWaive,
        handleCharge,
        handleContinue,
    ]);

    const body =
        chargedStatus === PaymentStatus.none ? (
            <ChargeOrWaiveSelector
                selectedChargeChoice={radioValue}
                selectedWaiveReason={waiveReason}
                handleChargeChoiceChange={handleRadioChange}
                handleWaiveReasonChange={handleDropdownChange}
            />
        ) : (
            <p className={styles.text}>
                {getAlreadyDecidedText(chargedStatus)}
            </p>
        );
    return (
        <div className={styles.container}>
            <Card className={styles.card}>{body}</Card>
            <Button
                disabled={disabled}
                uiTestTag="payment-continueButton"
                onClick={() => void handleSubmit()}
                fullWidth
            >
                CONTINUE
            </Button>
        </div>
    );
};
