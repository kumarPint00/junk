import { PaymentStatus } from '@redux/utils/PaymentStatus';

export class PaymentModuleProps {
    public handleWaive: (waiveReason: string) => void;
    public handleCharge: () => void;
    public handleContinue: () => void;
    public chargedStatus: PaymentStatus;
    public disabled: boolean;
    public visitId: string;
}

export class PaymentModuleState {
    public radioValue: string;
    public waiveReason: string;
}
