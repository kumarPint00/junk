import * as React from 'react';
import { withTranslation, WithTranslation } from 'react-i18next';
import { FooterPage } from '../../layout/PageLayout/FooterPage';
import {
    GetPasscodeOTPComponent,
    GetPasscodeOTPComponentProps,
} from '@components/OTPFlow/GetPasscodeOTPComponent';
import { VerifyOTPComponent } from '@components/OTPFlow/VerifyOTPComponent';

import * as styles from './OTPModule.css';

export interface OTPModuleProps extends WithTranslation {
    windowToDisplay: string;
    email: string;
    sms?: string;
    otpMethod: string;
    otpCode: string;
    isLoading: boolean;
    errorMessage: string | undefined;
    setOTPMethod: (otpMethod: string) => void;
    setOTPCode: (otpCode: string) => void;
    handleGetOTPCode: () => void;
    handleSubmitOTPCode: () => void;
    handleResendOTPCode: () => void;
    handleSetErrorMessage: (message: string | undefined) => void;
}

const OTPModule = ({
    windowToDisplay,
    email,
    sms,
    otpMethod,
    otpCode,
    isLoading,
    errorMessage,
    setOTPMethod,
    setOTPCode,
    handleGetOTPCode,
    handleSubmitOTPCode,
    handleResendOTPCode,
    handleSetErrorMessage,
    t,
}: OTPModuleProps) => {
    const onGetPasscodeButtonClick = () => {
        handleGetOTPCode();
    };
    const onVerifyPasscodeButtonClick = () => {
        handleSubmitOTPCode();
    };
    const onVerifyDidNotReceiveCode = () => {
        handleResendOTPCode();
    };

    const headerText = t('otp.headerText') ?? 'Go To Waiting Room';
    const getOTPInstructionHeaderText =
        t('otp.get.instructions.headerText') ?? 'Get Passcode';
    const getOTPInstructionBodyText =
        t('otp.get.instructions.bodyText') ??
        'Choose how you’d like to receive your one-time passcode via email or SMS text from the email address or phone number you provided when booking the visit. Then enter the passcode on the next step.';
    const getOTPDisclaimerText =
        t('otp.get.instructions.disclaimerText') ??
        'By choosing to receive your passcode at your mobile number, you consent to receive an SMS message containing a one-time passcode for the purpose of user verification. You understand and acknowledge that message and data rates may apply depending on your mobile service plan. You understand that the SMS message containing the one-time passcode may not be secure and could be intercepted or accessed by unauthorized individuals. You agree to hold the sender harmless from any liability arising from the use, transmission, or receipt of the SMS message.';
    const getOTPButtonText = t('otp.get.buttonText') ?? 'Get Passcode';
    const verifyInstructionHeaderText =
        t('otp.verify.instructions.headerText') ??
        'Enter your one-time passcode';
    const verifyInstructionLineValid =
        t('otp.verify.instructions.lineValid') ??
        'Allow 3 to 5 minutes for your passcode to arrive. It will be valid for 20 minutes.';
    const verifyInstructionPhone =
        t('otp.verify.instructions.phone') ??
        'A passcode has been sent to your phone number';
    const verifyInstructionEmail =
        t('otp.verify.instructions.email') ??
        'A passcode has been sent to your email';
    const verifyModifiedInstructionPhone = `${verifyInstructionPhone} ${sms}`;
    const verifyModifiedInstructionEmail = `${verifyInstructionEmail} ${email}`;
    const verifyButtonText = t('otp.verify.buttonText') ?? 'Next';
    const verifyLinkText = t('otp.verify.linkText') ?? 'Did not get the code?';
    const verifyPasscodeLabelText =
        t('otp.verify.passcodeLabel') ?? 'One-time Passcode';
    const dismissErrorModalText =
        t('otp.get.errors.dismissErrorModalText') ?? 'Dismiss';
    // error messages can / will be translated as they come back from upstream services
    const errorMessageText = errorMessage || undefined;

    const GetPasscodeOTPProps = {
        patientInfo: {
            email,
            sms,
        },
        localizedText: {
            getOTPInstructionHeaderText,
            getOTPInstructionBodyText,
            getOTPDisclaimerText,
            getOTPButtonText,
            errorMessageText,
            dismissErrorModalText,
        },
        otpMethod,
        isLoading,
        onGetPasscodeButtonClick,
        setOTPMethod,
        handleSetErrorMessage,
    } as GetPasscodeOTPComponentProps;

    const VerifyPasscodeOTPProps = {
        localizedText: {
            verifyInstructionHeaderText,
            verifyInstructionLineValid,
            verifyModifiedInstructionPhone,
            verifyModifiedInstructionEmail,
            verifyButtonText,
            verifyPasscodeLabelText,
            verifyLinkText,
            errorMessageText,
        },
        onVerifyPasscodeButtonClick,
        onVerifyDidNotReceiveCode,
        otpCode,
        setOTPCode,
        otpMethod,
        isLoading,
    };

    const getPasswordDisplay = (
        <GetPasscodeOTPComponent {...GetPasscodeOTPProps} />
    );

    const verifyPasswordDisplay = (
        <VerifyOTPComponent {...VerifyPasscodeOTPProps} />
    );

    return (
        <FooterPage
            headerText={headerText}
            customStyles={{
                main: styles.footerPageMainContainer,
                content: styles.footerPageContent,
                header: styles.footerPageHeader,
            }}
        >
            <div data-uitest="otp-container" className={styles.container}>
                {windowToDisplay === 'get'
                    ? getPasswordDisplay
                    : verifyPasswordDisplay}
            </div>
        </FooterPage>
    );
};

// do we need withTranslation when this component is already wrapped with I18NextProvider? not sure
// do we need access to the store? not sure
const _OTPModule = withTranslation()(OTPModule);
export { _OTPModule as OTPModule, OTPModule as RawOTPModule };
