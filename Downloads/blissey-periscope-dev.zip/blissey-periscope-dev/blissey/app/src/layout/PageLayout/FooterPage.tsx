import * as React from 'react';
import classnames from 'classnames';
import { Footer } from '@components/Footer/Footer';

import * as styles from './FooterPage.css';

export const FooterPage: React.FunctionComponent<
    React.PropsWithChildren<{
        headerText?: string;
        customStyles?: {
            main?: string;
            content?: string;
            header?: string;
        };
    }>
> = ({ children, headerText, customStyles }) => {
    return (
        <div className={classnames(styles.mainContainer, customStyles?.main)}>
            <div className={classnames(styles.content, customStyles?.content)}>
                {headerText ? (
                    <h1
                        className={classnames(
                            styles.header,
                            customStyles?.header,
                        )}
                    >
                        {headerText}
                    </h1>
                ) : null}
                {children}
            </div>
            {<Footer />}
        </div>
    );
};
