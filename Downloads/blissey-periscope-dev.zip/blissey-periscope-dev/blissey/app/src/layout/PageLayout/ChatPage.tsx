import * as React from 'react';
import { withTranslation, WithTranslation } from 'react-i18next';
import {
    InstantMessageComponent,
    InstantMessageComponentProps
} from '@dexcare/circus-saturn';
import { Store } from '@redux/modules';
import { useSelector } from 'react-redux';
import { config } from '@dexcare/circus-jupiter';

import * as styles from './ChatPage.css';
import { Configuration } from 'types/configuration';

export interface ChatPageProps
    extends WithTranslation,
        React.PropsWithChildren<object> {
    instantMessageProps: InstantMessageComponentProps & {
        ref?: (ref: InstantMessageComponent) => void;
    };
}

const ChatPage: React.FunctionComponent<ChatPageProps> = ({
    instantMessageProps,
    children,
    t,
}) => {
    const isChatVisible = useSelector(
        (state: Store['All']) => state.video.isChatVisible,
    );
    let sidebarClasses = styles.chatSidebar;
    let cameraDisplayClasses = styles.cameraDisplay;

    if (isChatVisible) {
        sidebarClasses = [styles.chatSidebar, styles.chatSidebarShown].join(
            ' ',
        );
        cameraDisplayClasses = [
            styles.cameraDisplay,
            styles.cameraDisplayShrunk,
        ].join(' ');
    }

    const headerText: string =
        t('video-conference.chat.header') ||
        (config as Configuration).getConfig().chat.headerText;
    const sendButtonText = t('video-conference.chat.sendButtonText', {
        defaultValue: 'Send',
    });

    return (
        <>
            <div className={cameraDisplayClasses}>{children}</div>
            <div className={sidebarClasses}>
                <div className={styles.instantMessageComponent}>
                    <InstantMessageComponent
                        isDisabled={!isChatVisible}
                        sendButtonText={sendButtonText}
                        onSendBotPromptResponse={
                            instantMessageProps.onSendBotPromptResponse
                        }
                        {...{
                            ...instantMessageProps,
                            instantMessages:
                                instantMessageProps.instantMessages.sort(
                                    (a, b) => a.timeSent - b.timeSent,
                                ),
                            headerText: `${headerText}`,
                            ariaLabel: t('video-conference.chat.textAreaAria'),
                        }}
                    />
                </div>
            </div>
        </>
    );
};

const _ChatPage = withTranslation()(ChatPage);
export { _ChatPage as ChatPage };
