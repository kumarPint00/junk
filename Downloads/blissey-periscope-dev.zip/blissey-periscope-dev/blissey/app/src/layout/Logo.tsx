import * as React from 'react';

import * as styles from './Logo.css';

// TODO: Add a logo.  The non-breaking-space is added here as a placeholder.
export class Logo extends React.Component {
    public render() {
        return (
            <span className={styles.logo}>
                <br />
            </span>
        );
    }
}
