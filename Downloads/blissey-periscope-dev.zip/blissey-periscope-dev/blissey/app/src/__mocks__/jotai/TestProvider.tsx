import * as React from 'react';
import { useHydrateAtoms } from 'jotai/utils';

type InitialValues = Parameters<typeof useHydrateAtoms>[0];

interface HydrateAtomsProps {
  initialValues: InitialValues | any[]; // broaden for legacy tests supplying raw tuples
  children: React.ReactNode;
}

/**
 * Because we are running "providerless" with jotai and using its associated `getDefaultStore` function throughout our app
 * we need to "dangerously" hydrate our atoms and _not_ use the `Provider` component from jotai in tests.
 * 
 * _Not_ running providerless in our app seems to create collisions with the redux store so we cant do that
 * at this time. So for now remain providerless in tests and hydrate atoms "dangerously" as needed (in tests anyway)
 */

const HydrateAtoms = ({ initialValues, children }: HydrateAtomsProps) => {
  const coerced = (initialValues as any) as InitialValues;
  useHydrateAtoms(coerced, { dangerouslyForceHydrate: true });
  return <>{children}</>;
};

export const TestProvider = ({ initialValues, children }: HydrateAtomsProps) => {
  return <HydrateAtoms initialValues={initialValues}>{children}</HydrateAtoms>;
};