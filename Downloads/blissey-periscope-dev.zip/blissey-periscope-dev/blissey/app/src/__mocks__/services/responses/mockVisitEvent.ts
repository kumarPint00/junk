import { mockOtherProviderId } from "./mockGetTransferOptions";
import { mockUserId } from "./mockGetUser";
import { mockVisitId } from "./mockGetVisitSummary";

export const mockRequestTransferToQueue = {
    action: 'updateProvider',
    data: {
        visitId: mockVisitId,
        assignmentMethod: 'unassign',
        unassignProviderId: mockUserId,
        actorId: mockUserId,
    },
}

export const mockRequestTransferToProvider = {
    action: 'updateProvider',
    data: {
        visitId: mockVisitId,
        assignmentMethod: 'end_and_transfer',
        providerId: mockOtherProviderId,
        unassignProviderId: mockUserId,
        actorId: mockUserId,
    }
}

export const mockRequestConvertModality = {
    action: 'modalityConversion',
    data: {
        visitId: mockVisitId,
        conversionReason: 'reason',
        originalModality: 'virtual',
        targetModality: 'phone',
        actorId: mockUserId,
    }
}