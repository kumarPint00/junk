import { http, HttpResponse } from 'msw';

export const mockPantryConfigResponse = {
    minimumWaitTimeForWaitOffline: 600,
};

export const mockGetPantryConfig = () => {
    const response = mockPantryConfigResponse;
    return http.get('https://api.frosh.dex.care/v2/blisseyconfigs', () => {
        return HttpResponse.json(response);
    });
};
