export const mockReasons = [{
    reasonType: 'waive',
    reasons: [{
        key: 'a-good-reason',
        value: 'A good reason',
    }]
}];