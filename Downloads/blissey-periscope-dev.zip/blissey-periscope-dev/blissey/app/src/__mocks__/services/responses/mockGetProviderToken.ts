export const mockProviderToken = 'mockProviderToken';

export const mockProviderTokenResponse = {
    token: mockProviderToken
}

/**
 * Generate a mock visit summary response
 * @param overrides 
 * @returns 
 */
export const generateProviderTokenResponse = (overrides?: object) => {
    return {
        ...mockProviderTokenResponse,
        ...overrides,
    }
}