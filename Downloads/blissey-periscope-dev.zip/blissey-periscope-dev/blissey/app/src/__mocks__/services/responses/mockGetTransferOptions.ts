import { TransferOptions, Provider } from "../../../clients/VisitService/VisitInterfaces"

export const mockOtherProviderId = 'provider-1';

export const mockTransferOptions: TransferOptions = {
    providers: [{
        id: mockOtherProviderId,
        displayInfo: {
            name: 'Provider One',
        }
    }] as Provider[],
    practiceRegions: [{
        id: 'pr-1',
        regionCode: 'CO',
        practiceId: 'mockPracticeId',
    }]
} as TransferOptions

/**
 * Generate a mock visit summary response
 * @param overrides 
 * @returns 
 */
export const generateTransferOptionsResponse = (overrides?: Partial<TransferOptions>) : TransferOptions => {
    return {
        ...mockTransferOptions,
        ...overrides,
    }
}