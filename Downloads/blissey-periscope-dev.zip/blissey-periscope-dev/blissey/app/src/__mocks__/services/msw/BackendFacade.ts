/* eslint-disable */
/* tslint:disable */

import { http, HttpResponse } from 'msw';
import { VideoClient } from '@dexcare/conference-client';
import {
    mockVideoConferenceSession,
    mockVisitId,
} from '../responses/mockGetVisitSummary';
import { mockUserId } from '../responses/mockGetUser';
import {
    generateProviderTokenResponse,
    mockProviderToken,
} from '../responses/mockGetProviderToken';
import { mockRequestTransferToQueue } from '../responses/mockVisitEvent';
import { mockOtherProviderId } from '../responses/mockGetTransferOptions';
import { mockParticipant } from '../responses/mockVisitParticipants';

export interface GetProviderTokenOverrides {
    sessionId?: string;
    visitId?: string;
    userId?: string;
    token?: string;
}

export const mockGetProviderToken = (overrides?: GetProviderTokenOverrides) => {
    const {
        visitId = mockVisitId,
        sessionId = mockVideoConferenceSession.sessionId,
        userId = mockUserId,
        token = mockProviderToken,
    } = overrides || {};

    const response = generateProviderTokenResponse({ token });

    return http.post(
        `/tokbox/createProviderToken?sessionId=${sessionId}&visitId=${visitId}&userId=${userId}`,
        () => {
            return HttpResponse.json(response);
        },
    );
};

export interface VisitEventOverrides {
    eventBody?: any;
    videoClient: VideoClient;
}

export const mockVisitEvent = (overrides?: VisitEventOverrides) => {
    const { eventBody = mockRequestTransferToQueue, videoClient } =
        overrides || {};

    return http.post('/visits/event', async ({ request }) => {
        const body: any = await request.json();
        let event: () => void;
        // endCallAndTransfer
        if (body.action === 'modalityConversion' && videoClient) {
            event = () =>
                videoClient.sessionClient.sendSignal('statusChange', {
                    modality: 'phone',
                });
        } else if (body.data?.assignmentMethod === 'unassign' && videoClient) {
            event = () => {
                videoClient.sessionClient.sendSignal('endCallAndTransfer', {});
                videoClient.sessionClient.sendSignal('statusChange', {
                    status: 'waitingroom',
                    providerId: null,
                });
            };
        } else if (
            body.data?.assignmentMethod === 'end_and_transfer' &&
            videoClient
        ) {
            event = () => {
                videoClient.sessionClient.sendSignal('endCallAndTransfer', {});
                videoClient.sessionClient.sendSignal('statusChange', {
                    status: 'caregiverassigned',
                    providerId:
                        eventBody?.data?.providerId || mockOtherProviderId,
                });
            };
        }
        setTimeout(() => event && event(), 200); // simulate short gap before event is sent
        return HttpResponse.json({});
    });
};

export interface AdmitVisitParticipantOverrides {
    visitId?: string;
    participantId?: string;
}

export const mockAdmitVisitParticipant = (
    overrides: AdmitVisitParticipantOverrides,
) => {
    const { visitId = mockVisitId, participantId = mockParticipant.id } =
        overrides || {};

    return http.post(
        `/visits/${visitId}/participants/${participantId}/admit`,
        () => {
            return HttpResponse.json({
                ...mockParticipant,
                admitted: true,
            });
        },
    );
};
