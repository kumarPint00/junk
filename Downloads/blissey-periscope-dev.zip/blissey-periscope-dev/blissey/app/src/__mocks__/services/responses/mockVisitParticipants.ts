import { mockVisitId } from './mockGetVisitSummary';

export const mockParticipantId = 'some-participant-id';

export const mockParticipantTypes = [
    {
        id: '1',
        name: 'translator',
    },
    {
        id: '2',
        name: 'family',
    },
    {
        id: '3',
        name: 'other',
    },
];

export const mockParticipant = {
    id: mockParticipantId,
    visitId: mockVisitId,
    participantType: {
        id: '3',
        name: 'other',
    },
    createdAt: new Date(),
    email: 'h*****s@gmail.com',
};

export const mockParticipant2 = {
    ...mockParticipant,
    id: 'some-other-participant-id',
};
