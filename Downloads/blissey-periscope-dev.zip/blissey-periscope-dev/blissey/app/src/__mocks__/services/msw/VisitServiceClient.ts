import { http, HttpResponse } from 'msw';
import { VideoClient } from '@dexcare/conference-client';
import {
    TransferOptions,
    VisitResponseV9,
} from '@clients/VisitService/VisitInterfaces';
import {
    generateMockVisitSummaryResponse,
    mockVideoConferenceSession,
    mockVisitId,
} from '../responses/mockGetVisitSummary';
import { generateMockWaittimeResponse } from '../responses/mockGetWaitTime';
import { generateTransferOptionsResponse } from '../responses/mockGetTransferOptions';
import { mockVideoToken } from '../responses/mockGetPatientToken';
import { mockVideoTokenResponse } from '../responses/mockGetPatientToken';
import { WaitTime } from '@clients/VisitService/VisitServiceClient';
import { mockReasons } from '../responses/mockGetReasons';

/**
 * mockGetVisitSummary
 */
export const mockGetVisitSummary = (overrides?: Partial<VisitResponseV9>) => {
    const response = generateMockVisitSummaryResponse(overrides);
    const { visitId } = response;
    return http.get(
        `https://ecvapi.frosh.dex.care/api/9/visits/${visitId}/summary`,
        () => {
            return HttpResponse.json(response);
        },
    );
};

/**
 * mockGetPatientTokens
 */
export interface GetPatientTokensOverrides {
    visitId?: string;
    sessionId?: string;
    token?: string;
}
export const mockGetPatientToken = (overrides?: GetPatientTokensOverrides) => {
    const {
        visitId = mockVisitId,
        sessionId = mockVideoConferenceSession.sessionId,
        token = mockVideoToken,
    } = overrides || {};

    const response = {
        ...mockVideoTokenResponse,
        token,
    };
    return http.get(
        `https://ecvapi.frosh.dex.care/api/6/visit/${visitId}/token/${sessionId}`,
        () => {
            return HttpResponse.json(response);
        },
    );
};

/**
 * mockGetWaittime
 */
export interface GetWaitTimeOverrides {
    visitId?: string;
    responseOverrides?: Partial<WaitTime>;
}
export const mockGetWaittime = ({
    visitId = mockVisitId,
    responseOverrides,
}: GetWaitTimeOverrides) => {
    const response = generateMockWaittimeResponse(responseOverrides);
    return http.get(
        `https://ecvapi.frosh.dex.care/api/9/visits/${visitId}/waittime`,
        () => {
            return HttpResponse.json(response);
        },
    );
};

/**
 * mockChargeVisit
 */
export interface ChargeOrWaiveVisitOverrides {
    videoClient?: VideoClient;
    visitId?: string;
}
export const mockChargeVisit = ({
    visitId = mockVisitId,
    videoClient,
}: ChargeOrWaiveVisitOverrides) => {
    return http.post(
        `https://ecvapi.frosh.dex.care/api/8/visits/virtual/charge/${visitId}`,
        () => {
            let event: () => void;
            // mock tokbox status signal eventing
            if (videoClient) {
                event = () => {
                    void videoClient.sessionClient.sendSignal('statusChange', {
                        status: 'done',
                    });
                };
            }
            setTimeout(() => event && event(), 200); // simulate short gap before event is sent
            return HttpResponse.json({});
        },
    );
};

/**
 * mockWaiveVisit
 */
export const mockWaiveVisit = ({
    visitId,
    videoClient,
}: ChargeOrWaiveVisitOverrides) => {
    return http.post(
        `https://ecvapi.frosh.dex.care/api/8/visits/virtual/waive/${visitId}`,
        () => {
            let event: () => void;
            // mock tokbox status eventing
            if (videoClient) {
                // mock tokbox status signal eventing
                event = () => void videoClient.sessionClient.sendSignal('statusChange', {
                    status: 'done',
                });
            }
            setTimeout(() => event && event(), 200); // simulate short gap before event is sent
            return HttpResponse.json({});
        },
    );
};

/**
 * mockGetTransferOptions
 */
export interface GetTransferOptionsOverrides {
    visitId?: string;
    responseOverrides?: Partial<TransferOptions>;
}
export const mockGetTransferOptions = ({
    visitId = mockVisitId,
    responseOverrides,
}: GetTransferOptionsOverrides) => {
    const response = generateTransferOptionsResponse(responseOverrides);
    return http.get(
        `https://ecvapi.frosh.dex.care/v1/visits/${visitId}/transfer-options`,
        () => {
            return HttpResponse.json(response);
        },
    );
};

/**
 * mockCancelVisit
 */
export const mockCancelVisit = (videoClient: VideoClient) => {
    return http.post(
        `https://ecvapi.frosh.dex.care/api/9/visits/virtual/mockVisitId/cancel`,
        () => {
            let event: () => void;
            if (videoClient) {
                event = () => void videoClient.sessionClient.sendSignal('statusChange', {
                    status: 'cancelled',
                    timestamps: {
                        cancelled: new Date().toISOString(),
                    },
                });
            }
            setTimeout(() => event && event(), 200); // simulate short gap before event is sent
            return HttpResponse.json({});
        },
    );
};

/**
 * mockCancelVideoWithReason
 */
export const mockCancelVideoWithReason = (videoClient: VideoClient) => {
    return http.post(
        `https://ecvapi.frosh.dex.care/v1/visits/mockVisitId/patient-cancel-video`,
        () => {
            let event: () => void;
            if (videoClient) {
                event = () => void videoClient.sessionClient.sendSignal('statusChange', {
                    status: 'cancelled',
                    timestamps: {
                        cancelled: new Date().toISOString(),
                    },
                });
            }
            setTimeout(() => event && event(), 200); // simulate short gap before event is sent
            return HttpResponse.json({});
        },
    );
};

/**
 * mockPatientEnterWaitOffline
 */
export const mockPatientEnterWaitOffline = (videoClient: VideoClient) => {
    return http.post(
        `https://ecvapi.frosh.dex.care//v1/visits/event`,
        () => {
            let event: () => void;
            if (videoClient) {
                event = () => {
                    void videoClient.sessionClient.sendSignal(
                        'patientEnterWaitOfflineSuccess',
                        {},
                    );
                    void videoClient.sessionClient.sendSignal('statusChange', {
                        status: 'waitoffline',
                        timestamps: {
                            waitoffline: new Date().toISOString(),
                        },
                    });
                };
            }
            setTimeout(() => event && event(), 200); // simulate short gap before event is sent
            return HttpResponse.json({});
        },
    );
};

/**
 * mockWaitingRoomEvent
 */
export const mockWaitingRoomEvent = (visitId: string = mockVisitId) => {
    return http.post(
        `https://ecvapi.frosh.dex.care/api/8/visits/virtual/${visitId}/waitingRoomEvents`,
        () => {
            return HttpResponse.json({});
        },
    );
};

/**
 * mockGetReasons
 */
export const mockGetReasons = (visitId: string = mockVisitId) => {
    return http.get(
        `https://ecvapi.frosh.dex.care/api/9/visits/${visitId}/waittime`,
        () => {
            return HttpResponse.json(mockReasons);
        },
    );
}

/**
 * mockAcceptConsent
 */
export const mockAcceptConsent = (visitId: string = mockVisitId) => {
    return http.put(
        `https://ecvapi.frosh.dex.care/api/9/visits/${visitId}/acceptTerms`,
        () => {
            return HttpResponse.json({});
        },
    );
};