import { WaitTime } from "@clients/VisitService/VisitServiceClient"

const mockWaitTime: WaitTime = {
    estimatedWaitTimeSeconds: 700,
    estimatedWaitTimeMessage: 'some super fancy messaage',
    estimateGeneratedAt: new Date().toISOString(),
    waitTimeLocalizationInfo: {
        waitTimeMapKey: 'template',
        timeMinSeconds: 1000,
        timeMaxSeconds: 5000,
        modality: 'virtual',
    }
} as WaitTime

/**
 * Generate a mock visit summary response
 * @param overrides 
 * @returns 
 */
export const generateMockWaittimeResponse = (overrides?: Partial<WaitTime>) : WaitTime => {
    return {
        ...mockWaitTime,
        ...overrides,
    }
}