import {
    TokboxSession,
    VisitResponseV9,
} from '@clients/VisitService/VisitInterfaces';

export const mockBrand = 'mockBrand';
export const mockVisitId = 'mockVisitId';
export const mockPracticeId = 'mockPracticeId';
export const mockPatientGuid = 'mockPatientGuid';
export const mockApiKey = 'mockApiKey';
export const mockConferenceSession: TokboxSession = {
    sessionId: 'mockConferenceSessionId',
};
export const mockVideoConferenceSession: TokboxSession = {
    sessionId: 'mockVideoConferenceSessionId',
};
export const mockWaitingRoomSession: TokboxSession = {
    sessionId: 'mockWaitingRoomSessionId',
};

export const mockVisitSummary: VisitResponseV9 = {
    visitId: mockVisitId,
    patientGuid: mockPatientGuid,
    practiceId: mockPracticeId,
    status: 'requested',
    modality: 'virtual',
    tokBoxVisit: {
        videoConferenceSession: mockConferenceSession,
        waitingRoomSession: mockWaitingRoomSession,
        apiKey: mockApiKey,
    },
    acceptTerms: true,
    brand: mockBrand,
    timestamps: {
        created: '2021-10-01T00:00:00Z',
        requested: '2021-10-01T00:00:00Z',
        waitingroom: undefined,
        invisit: undefined,
        done: undefined,
        staffdeclined: undefined,
        cancelled: undefined,
        waitoffline: undefined,
        caregiverassigned: undefined,
    },
    providerId: null,
    deviceModel: 'desktop',
    // will see how many of these matter later...
    // type: string;
    // assignmentQualifiers: string[];
    // isHighPriority: boolean;
    // stateLicensure: string;
    // homeMarket: string;
    // integrations: VisitIntegrations;
    // origin?: string;
    // traveling?: boolean;
} as VisitResponseV9;

/**
 * Generate a mock visit summary response
 * @param overrides
 * @returns
 */
export const generateMockVisitSummaryResponse = (
    overrides?: Partial<VisitResponseV9>,
): VisitResponseV9 => {
    return {
        ...mockVisitSummary,
        ...overrides,
    };
};
