import { http, HttpResponse, bypass } from 'msw';

export const mockLogsEndpoints = () => [
    http.post('/logs', () => {
        return HttpResponse.text('');
    }),
];

export const mockTokboxLogEndpoints = () => [
    http.post(
        'https://enterprise-hlg.tokbox.com/prod/logging/ClientEvent',
        () => HttpResponse.text(''),
    ),
    http.post('https://hlg.tokbox.com/prod/logging/ClientEvent', () =>
        HttpResponse.text(''),
    ),
    http.get('https://config.opentok.com/project/*/config.json', () =>
        HttpResponse.text(''),
    ),
];

export const mockTranslation = () => {
    return http.get('/l10n/en/translation', async () => {
        const actualReq = new Request('https://customer-assets.frosh.dex.care/blissey/v1/l10n/en/translation.json');
        const response = await fetch(bypass(actualReq));
        const text = await response.text();
        try {
            const json = JSON.parse(text);
            return HttpResponse.json(json);
        } catch {
            // If parsing fails, return an empty object
            const json = {};
            return HttpResponse.json({});
        }
    });
};
