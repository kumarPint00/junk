export const mockVideoToken = 'mockVideoToken';
export const mockWaitingroomToken = 'mockWaitingroomToken';

export const mockVideoTokenResponse = {
    token: mockVideoToken
}

export const mockWaitingroomTokenResponse = {
    token: mockWaitingroomToken
}