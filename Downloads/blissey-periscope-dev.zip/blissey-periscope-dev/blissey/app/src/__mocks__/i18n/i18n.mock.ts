import i18n, { i18n as I18nInterface } from 'i18next';

export const i18nextConfig = {
    ns: ['translation'],
    fallbackNS: ['translation'],
    fallbackLng: 'en',
    preload: [],
    interpolation: {
        escapeValue: false,
    },
    lng: 'en',
    resources: {
        en: {
            translation: {
                'waiting-room': {
                    waitTimeStringMap: {
                        template:
                            'One of our healthcare providers will meet you here in {min} to {max}',
                    },
                },
                virtualNudge: {
                    header: "What's New at DexCare?",
                    advertisements: [
                        {
                            type: 'providerDirectBooking',
                            title: 'Advertisement 1',
                            description: 'This is the first advertisement',
                            linkUrl: 'https://www.dexcare.com',
                            linkText: 'Click me!',
                        },
                        {
                            type: 'retailBooking',
                            title: 'Advertisement 2',
                            description: 'This is the second advertisement',
                            linkUrl: 'https://www.dexcare.com',
                            linkText: 'Click me!',
                        },
                    ],
                },
            },
        },
    },
};

export const initI18n = async (): Promise<I18nInterface> => {
    await i18n.init(i18nextConfig);
    return i18n;
};
