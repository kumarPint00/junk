import { vi } from 'vitest';
import {
    ConferenceEvents,
    ConferenceEvent,
} from '@dexcare/conference-client';
import {
    MockSessionClient,
    MockVideoClient
} from '@dexcare/conference-client/mocks';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';

export const mockVideoConnected = (client: MockVideoClient) => {
    return vi
        .spyOn(client, 'connect')
        .mockResolvedValue(undefined);
};

export const mockVideoJoin = (client: MockVideoClient) => {
    return vi
        .spyOn(client, 'join')
        .mockResolvedValue(undefined);
};

export const mockVideoLeave = (client: MockVideoClient) => {
    return vi
        .spyOn(client, 'leave')
        .mockResolvedValue(undefined);
};

export const mockVideoConnectedEvent = (client: MockVideoClient) => {
    client.emit(
        ConferenceEvents.CONNECTED,
        new ConferenceEvent(
            'Connected to session',
            ConferenceEvents.CONNECTED,
            {
                techCheck: {
                    isConnected: true,
                    audioInputDetected: true,
                    videoInputDetected: true,
                    accessAllowed: true,
                },
            },
        ),
    );
};

export const mockStatusEvent = (
    sessionClient: MockSessionClient,
    signalData: Partial<VisitResponseV9>
) => {
    sessionClient.emit(
        ConferenceEvents.SIGNAL,
        new ConferenceEvent('Signal event', ConferenceEvents.SIGNAL, {
            signalType: 'signal:statusChange',
            signalData: { ...signalData },
        }),
    );
};

export const mockWaitOfflineSuccessEvent = (
    client: MockVideoClient,
    signalData: Partial<VisitResponseV9>,
) => {
    client.emit(
        ConferenceEvents.SIGNAL,
        new ConferenceEvent('Signal event', ConferenceEvents.SIGNAL, {
            signalType: 'signal:patientEnterWaitOfflineSuccess',
            signalData: { ...signalData },
        }),
    );
};
