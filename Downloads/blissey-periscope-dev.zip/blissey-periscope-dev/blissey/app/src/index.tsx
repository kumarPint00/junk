import { addMetric, config } from '@dexcare/circus-jupiter';
import { isPatient } from '@dexcare/circus-saturn';
import createBlisseyTheme from '@utils/createBlisseyTheme';
import { initRum } from '@utils/initRum';
import 'autotrack';
import parseQuery from 'query-string';
import * as React from 'react';
import { Container, createRoot } from 'react-dom/client';
import { I18nextProvider } from 'react-i18next';
import { Provider } from 'react-redux';
import { RouterProvider } from 'react-router-dom';
import * as Redux from 'redux';
import thunk from 'redux-thunk';
import { AppConfig, Script } from '../../server/config/configInterfaces';
import { backendFacade } from './clients/Backend/BackendFacade';
import { initI18nInstance } from './common/i18n/i18nInstance';
import './index.css';
import './common/sharedcss/Swedish.css';
import {
    getLocalState,
    localStorageMiddleware,
} from './redux/middleware/localStorage';
import { Store, initialState, rootReducer } from './redux/modules/index';
import {
    setIsTestVisit,
    setTokBoxVideoSessionId,
    setTokBoxWaitingRoomSessionId,
} from './redux/modules/postConsult';
import { setUserDetails } from './redux/modules/userDetails';
import { UserDetails } from './types/UserDetails';
import { AppStageContainer } from './rendering/AppStageContainer';
import { UserNotAuthenticated } from './rendering/UserNotAuthenticated';
import { getRoutes } from './routes';
import { Logger, checkTestVisit } from './utils';
import { initVisitServiceClient } from './clients/VisitService/VisitServiceClient';
import { recoverGuestSessionFromAccessCode } from './app';
import { loadAuthToken } from './utils/loadAuthToken';
import { Configuration } from 'types/configuration';
import { ThunkDispatch } from 'types/redux';
import {
    Analytics,
    V2Analytics,
    isAdobeEnabled,
} from '@dexcare/festivus-aluminum-pole-analytics';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import { ThemeProvider } from '@mui/material';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './reactQuery';

export interface BlisseyQueryParameters {
    brand?: string;
    videoConferenceId?: string;
    waitingConferenceId?: string;
    videoSessionId?: string;
    waitingRoomSessionId?: string;
}

let userDetails: UserDetails;

declare const window: Window & {
    __REDUX_DEVTOOLS_EXTENSION_COMPOSE__: typeof Redux.compose;
    gtmDataLayer: object[];
};

// Cast thunk to any to bridge potential versioned type mismatch pending full store refactor
const enhancer = Redux.applyMiddleware(thunk as any, localStorageMiddleware);

const composeEnhancers =
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || Redux.compose;

const localState = getLocalState(initialState);
const store: Omit<Redux.Store<Store['All']>, 'dispatch'> & {
    dispatch: ThunkDispatch<Store['All'], unknown, Redux.Action>;
} = Redux.createStore(
    rootReducer as any,
    localState as any,
    composeEnhancers(enhancer) as any,
);

const dispatchIfNotUndefined = (
    key: string | string[] | undefined,
    action: (key: string) => Redux.Action,
) => {
    if (key) {
        store.dispatch(action(key as string));
    }
};

const initiaizeApiClients = ({
    sharedSessionStoreEnabled,
}: {
    sharedSessionStoreEnabled: boolean;
}) => {
    initVisitServiceClient({ sharedSessionStoreEnabled });
};

const container = document.querySelector('#root') as Container;
const root = createRoot(container);

void recoverGuestSessionFromAccessCode(document.location)
    .catch((err: string) => {
        Logger.error('Unhandled error while recovering guest session', err);
    })
    .then(async () => backendFacade.getUser())
    .then((loggedInUserDetails) => {
        void backendFacade.getConfig().then(async (retrievedConfig) => {
            (config as Configuration).setConfig(retrievedConfig);
            const { pathname, search } = window.location;
            const parsed = (parseQuery as any).parse
                ? (parseQuery as any).parse(search)
                : (parseQuery as any)(search);
            let { brand } = parsed as { brand?: string | string[] };
            if (Array.isArray(brand)) {
                brand = brand[0];
            }

            if (!brand || !retrievedConfig.brandConfig[brand.toLowerCase()]) {
                brand = retrievedConfig.brands[0];
            }
            brand = brand.toLowerCase();
            loadAuthToken(loggedInUserDetails, retrievedConfig, brand);
            userDetails = loggedInUserDetails;
            initiaizeApiClients({
                sharedSessionStoreEnabled:
                    loggedInUserDetails.sharedSessionStoreEnabled,
            });

            const isTestVisit = checkTestVisit(pathname);
            const routes = getRoutes(userDetails, retrievedConfig, brand);

            // add the full user details to the logger context
            Logger.addApplicationContext({
                isTestVisit,
                userDetails,
            });
            store.dispatch(setUserDetails(userDetails));

            const appConfig: AppConfig = (config as Configuration).getConfig();
            const gtmScriptUrl = appConfig.gtmContainerUrl;
            const footerScripts = appConfig.footerScripts;
            const headScripts = appConfig.headScripts;
            const consentScripts = appConfig.consentScripts;

            // Consent scripts must load before any other scripts in the document
            if (
                (isPatient(loggedInUserDetails) ||
                    window.location.pathname.startsWith('/guest')) &&
                !isTestVisit &&
                consentScripts?.length
            ) {
                consentScripts.forEach((script: Script) => {
                    addHeadScript(script);
                });
            }

            // Analytics setup must be done before loading the related scripts
            // Legacy module that sends tealium events
            Analytics.setup();
            const enableAdobe = isAdobeEnabled(appConfig.adobeAlloyConfig);
            const enableAdobeAlloyDebugEnabled = getFeatureFlag(
                FeatureFlags.enableAdobeAlloyDebugEnabled,
            );
            if (gtmScriptUrl || enableAdobe) {
                // New module that sends events to GTM and/or Adobe
                V2Analytics.setup({
                    gtmEnabled: !!gtmScriptUrl,
                    adobeConfig: {
                        ...appConfig.adobeAlloyConfig,
                        debugEnabled: enableAdobeAlloyDebugEnabled,
                    },
                });
            } else {
                Logger.info(
                    'skipping analytics module setup because no platform was enabled',
                );
            }

            if (gtmScriptUrl) {
                addScript(gtmScriptUrl, true);
            } else {
                Logger.info(
                    'skipping gtm analytics script injection because no gtmScriptUrl was provided',
                );
            }

            if (isPatient(loggedInUserDetails) && !isTestVisit) {
                const tagScriptUrl = appConfig.tagScriptUrl;
                tagScriptUrl
                    ? addScript(tagScriptUrl)
                    : Logger.info(
                          'skipping analytics script injection because no tagScriptUrl was provided',
                      );
            }
            if (isTestVisit) {
                store.dispatch(setIsTestVisit(true));
                const { videoSessionId, waitingRoomSessionId } =
                    ((parseQuery as any).parse
                        ? (parseQuery as any).parse(search)
                        : (parseQuery as any)(search) as BlisseyQueryParameters) || {};
                dispatchIfNotUndefined(videoSessionId, setTokBoxVideoSessionId);
                dispatchIfNotUndefined(
                    waitingRoomSessionId,
                    setTokBoxWaitingRoomSessionId,
                );
            }

            const stylesheet = document.createElement('style');
            document.head.append(stylesheet);
            const { styles } = appConfig;
            stylesheet.innerHTML = `
                    :root {
                        --primaryColor: ${styles.primaryColor};
                        --secondaryColor: ${styles.secondaryColor};
                    }
                `;

            if (footerScripts && footerScripts.length > 0) {
                footerScripts.forEach((script: Script) => {
                    addFooterScript(script.src);
                });
            }

            if (headScripts && headScripts.length > 0) {
                headScripts.forEach((script: Script) => {
                    addHeadScript(script);
                });
            }

            initRum(appConfig, userDetails);

            const i18nInstance = await initI18nInstance(
                retrievedConfig.brandConfig[brand],
            );

            root.render(
                <I18nextProvider i18n={i18nInstance}>
                    <Provider store={store}>
                        <QueryClientProvider client={queryClient}>
                            <ThemeProvider
                                theme={createBlisseyTheme(appConfig)}
                            >
                                <React.Suspense fallback="loading...">
                                    <AppStageContainer
                                        user={userDetails}
                                        brand={brand}
                                    >
                                        <RouterProvider router={routes} />
                                    </AppStageContainer>
                                </React.Suspense>
                            </ThemeProvider>
                        </QueryClientProvider>
                    </Provider>
                </I18nextProvider>,
            );
        });
    })
    .catch((error: unknown) => {
        // TODO: UX team has to provide us a template to show error messages
        // https://provinnovate.atlassian.net/browse/NH-403
        addMetric('blissey.indexPage.Fail', 1, 'count', [{ userDetails }]);
        void backendFacade.getBasicConfig().then((retrievedConfig) => {
            root.render(
                <UserNotAuthenticated
                    reasons={error}
                    siteTitle={retrievedConfig?.siteTitle}
                    favicon={retrievedConfig?.favicon}
                />,
            );
        });
    });

function addScript(source: string, isGTM?: boolean) {
    const script = document.createElement('script');
    if (isGTM && window.gtmDataLayer)
        window.gtmDataLayer.push({
            'gtm.start': Date.now(),
            event: 'gtm.js',
        });
    script.src = source;
    script.async = true;
    script.defer = true;
    document.querySelectorAll('head')[0].append(script);
}

function addFooterScript(source: string) {
    const script = document.createElement('script');
    script.src = source;
    script.async = true;
    script.type = 'text/javascript';
    document.body.append(script);
}

function addHeadScript(script: Script) {
    const headScript = document.createElement('script');
    if (script.inline) {
        headScript.innerText = script.src;
    } else {
        headScript.src = script.src;
    }
    headScript.async = !!script.async;
    headScript.defer = !!script.defer;
    headScript.type = 'text/javascript';

    if (script.attributes) {
        Object.entries(script.attributes as Record<string, string>).forEach(
            ([key, value]) => {
                headScript.setAttribute(key, value);
            },
        );
    }
    if (script.prepend) {
        document.querySelectorAll('head')[0].prepend(headScript);
    } else {
        document.querySelectorAll('head')[0].append(headScript);
    }
}
