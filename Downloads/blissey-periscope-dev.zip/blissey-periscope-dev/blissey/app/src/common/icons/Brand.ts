import { config } from '@dexcare/circus-jupiter';
import { Configuration } from 'types/configuration';

export function getDomainFromBrand(brand: string): string {
    const brandConfig = (config as Configuration).getConfig().brandConfig;
    return brandConfig[brand].domain;
}
