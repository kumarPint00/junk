import { init } from '@common/ConferenceErrorMessage';
import { AppConfig } from '../../../../server/config/configInterfaces';
import { Mocked, vi } from 'vitest';

import * as featureFlags from '@utils/FeatureFlags';
let mockConfig: Mocked<typeof import('@utils/config')>;

describe('ConferenceErrorMessage', () => {
    afterEach(() => vi.clearAllMocks());
    beforeEach(async () => {
        mockConfig = await vi.importMock('@utils/config');
    });
    it('uses defaults when no config', async () => {
        mockConfig.getConfig.mockReturnValue({} as AppConfig);
        init();

        const map = await import('@common/ConferenceErrorMessage');
        expect(map.conferenceMessageMap).toMatchSnapshot();
    });
    it('uses config to override defaults', async () => {
        mockConfig.getConfig.mockReturnValue({
            videoUserMessages: {
                camMuted: 'mock camMuted message',
                micMuted: 'mock micMuted message',
                removedFromCall: 'mock removedFromCall message',
                joinedElseWhere: 'mock joinedElseWhere message',
                roomFull: 'mock roomFull message',
                networkError: 'mock networkError message',
                unknownError: 'mock unknownError message',
                connecting: 'mock connecting message',
                otherParticipantDropped: 'mock otherParticipantDropped message',
                reconnecting: 'mock reconnecting message',
                disconnected: 'mock disconnected message',
            },
        } as AppConfig);
        init();
        const map = await import('@common/ConferenceErrorMessage');
        expect(map.conferenceMessageMap).toMatchSnapshot();
    });
    it('merges', async () => {
        mockConfig.getConfig.mockReturnValue({
            videoUserMessages: {
                camMuted: 'mock camMuted message',
                micMuted: 'mock micMuted message',
                otherParticipantDropped: 'mock otherParticipantDropped message',
                reconnecting: 'mock reconnecting message',
                disconnected: 'mock disconnected message',
            },
        } as AppConfig);
        init();

        const map = await import('@common/ConferenceErrorMessage');
        expect(map.conferenceMessageMap).toMatchSnapshot();
    });
    it('sets micMuted message without phone when feature flag is on', async () => {
        vi.spyOn(featureFlags, 'getFeatureFlag').mockReturnValue(true);
        mockConfig.getConfig.mockReturnValue({} as AppConfig);

        init();

        const map = await import('@common/ConferenceErrorMessage');
        expect(map.conferenceMessageMap).toMatchSnapshot();
    });
});
