import { vi } from 'vitest';
import {
    getExitSurveyInterface,
    WindowWithSurvey,
} from '../getExitSurveyInterface';

describe('getExitSurveyInterface', () => {
    it('should return and call Android.onExitSurvey', () => {
        const onExitSurveySpy = vi.fn();
        const window: WindowWithSurvey = {
            Android: {
                onExitSurvey: onExitSurveySpy,
            },
        } as unknown as WindowWithSurvey;

        const exitSurveyFn = getExitSurveyInterface(window);
        expect(exitSurveyFn).toBeInstanceOf(Function);

        exitSurveyFn!();
        expect(onExitSurveySpy).toHaveBeenCalled();
    });

    it('should return iOS window.webkit.messageHandlers.onExitSurvey.postMessage', () => {
        const window: WindowWithSurvey = {
            webkit: {
                messageHandlers: {
                    onExitSurvey: {
                        postMessage: vi.fn(),
                    },
                },
            },
        } as unknown as WindowWithSurvey;
        expect(getExitSurveyInterface(window)).toBeInstanceOf(Function);
    });

    it('should return window.onExitSurvey', () => {
        const window: WindowWithSurvey = {
            onExitSurvey: vi.fn(),
        } as unknown as WindowWithSurvey;
        expect(getExitSurveyInterface(window)).toBe(window.onExitSurvey);
    });

    it('should return undefined', () => {
        const window: WindowWithSurvey = {} as unknown as WindowWithSurvey;
        expect(getExitSurveyInterface(window)).toBeUndefined();
    });
});
