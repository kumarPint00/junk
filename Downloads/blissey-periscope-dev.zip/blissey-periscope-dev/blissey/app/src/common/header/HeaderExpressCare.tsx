import * as React from 'react';
import { withTranslation } from 'react-i18next';
import { config } from '@dexcare/circus-jupiter';

import * as styles from './HeaderExpressCare.css';
import { Configuration } from 'types/configuration';

function HeaderExpressCare(props: {
    t: {
        (key: string): string;
    };
}): JSX.Element {
    return (
        <div className={styles.header}>
            <div className={styles.header}>
                <img
                    alt={
                        (config as Configuration).getConfig().siteTitle +
                        ' logo'
                    }
                    className={styles.logo}
                    src={props.t('branding:logo')}
                />
            </div>
        </div>
    );
}

const _HeaderExpressCare = withTranslation()(HeaderExpressCare);
export { _HeaderExpressCare as HeaderExpressCare };
