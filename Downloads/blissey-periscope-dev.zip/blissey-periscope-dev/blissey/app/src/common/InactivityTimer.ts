import { LogManager, config } from '@dexcare/circus-jupiter';
import { jwtTokenHelper } from '../utils/jwt-helper';
import { Configuration } from 'types/configuration';

export class InactivityTimer {
    private static timeoutId: number;
    private static readonly Logger = LogManager.getLogger().child(
        {
            eventSource: 'InactivityTimer',
        },
        true,
    );

    public static attachTimeout() {
        window.addEventListener('mousedown', InactivityTimer.resetTimer, false);
        window.addEventListener('keypress', InactivityTimer.resetTimer, false);
        window.addEventListener(
            'DOMMouseScroll',
            InactivityTimer.resetTimer,
            false,
        );
        window.addEventListener(
            'mousewheel',
            InactivityTimer.resetTimer,
            false,
        );
        window.addEventListener('touchmove', InactivityTimer.resetTimer, false);
        window.addEventListener(
            'MSPointerMove',
            InactivityTimer.resetTimer,
            false,
        );

        InactivityTimer.resetTimer();
    }

    public static detachTimeout() {
        InactivityTimer.clearTimer();
        window.removeEventListener(
            'mousedown',
            InactivityTimer.resetTimer,
            false,
        );
        window.removeEventListener(
            'keypress',
            InactivityTimer.resetTimer,
            false,
        );
        window.removeEventListener(
            'DOMMouseScroll',
            InactivityTimer.resetTimer,
            false,
        );
        window.removeEventListener(
            'mousewheel',
            InactivityTimer.resetTimer,
            false,
        );
        window.removeEventListener(
            'touchmove',
            InactivityTimer.resetTimer,
            false,
        );
        window.removeEventListener(
            'MSPointerMove',
            InactivityTimer.resetTimer,
            false,
        );
    }

    private static clearTimer() {
        window.clearTimeout(InactivityTimer.timeoutId);
    }

    private static startTimer = (): void => {
        InactivityTimer.timeoutId = window.setTimeout(
            InactivityTimer.logout,
            (config as Configuration).getConfig().inactivityTimeout,
        );
    };

    private static resetTimer = (): void => {
        InactivityTimer.clearTimer();
        InactivityTimer.startTimer();
    };

    private static logout = (): void => {
        InactivityTimer.Logger.info({
            eventName: 'logout',
        });
        jwtTokenHelper.clearAuthenticationToken();
        const search = window.location.search
            ? encodeURIComponent(window.location.search)
            : '';
        window.location.replace(
            `/expired?location=patientauth/logout${search}`,
        );
    };
}
