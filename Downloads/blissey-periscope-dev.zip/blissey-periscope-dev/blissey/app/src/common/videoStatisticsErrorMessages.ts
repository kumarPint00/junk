import { getConfig } from '@utils/config';

export interface PacketStats {
    packetsLost: number;
    packetsSucceeded: number;
}

const defaultPacketLossThresholds = {
    alertThreshold: 5,
    alertMessage:
        'Extreme packet loss detected. Your connection may be very poor',
    warnThreshold: 3,
    warnMessage: 'Some packet loss detected.',
};

export function calculatePacketLossPercentage({
    packetsLost,
    packetsSucceeded,
}: PacketStats) {
    return (packetsLost / (packetsLost + packetsSucceeded)) * 100;
}

export function getWarningMessage(stats?: PacketStats) {
    if (!stats) return undefined;
    const overridePackageThresholds =
        getConfig().videoUserMessages?.packetLossErrors || {};

    const packageMessages = {
        ...defaultPacketLossThresholds,
        ...overridePackageThresholds,
    };

    const packetLoss = calculatePacketLossPercentage(stats);
    return packetLoss > packageMessages.alertThreshold
        ? packageMessages.alertMessage
        : packetLoss > packageMessages.warnThreshold
        ? packageMessages.warnMessage
        : undefined;
}
