import * as React from 'react';

import { ConferenceError } from '@modules/VideoCall/ConferenceError';
import { getConfig } from '@utils/config';
import { VideoUserMessages } from '../../../server/config/configInterfaces';
import { MessageType } from '@components/Message/MessageInterfaces';
import { getI18nInstance } from '@common/i18n/i18nInstance';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';

export interface MessageDetails {
    message: React.ReactNode;
    messageType: MessageType;
    icon?: string; // An icon to override the default for this message type
}

enum ConferenceMessageType {
    DialingMessage,
    ConnectedMessage,
    CameraWarningMessage,
    MicrophoneWarningMessage,
    ReconnectingMessage,
    DisconnectedMessage,
}

export const conferenceMessageMap = new Map<string, MessageDetails>();

export function init() {
    const i18nextInstance = getI18nInstance();

    const ASSISTANCE_MESSAGE_DEFAULT = i18nextInstance.t(
        'video-conference.error-messages.assistance',
    );
    const ASSISTANCE_MESSAGE_WITHOUT_PHONE = i18nextInstance.t(
        'video-conference.error-messages.assistanceWithoutPhone',
    );
    const defaultVideoErrorMessages: Partial<VideoUserMessages> = {
        camMuted: i18nextInstance.t('video-conference.error-messages.camMuted'),
        micMuted: i18nextInstance.t('video-conference.error-messages.micMuted'),
        removedFromCall: i18nextInstance.t(
            'video-conference.error-messages.removedFromCall',
        ),
        joinedElseWhere: i18nextInstance.t(
            'video-conference.error-messages.joinedElsewhere',
        ),
        roomFull: i18nextInstance.t('video-conference.error-messages.roomFull'),
        networkError: i18nextInstance.t(
            'video-conference.error-messages.networkError',
        ),
        unknownError: i18nextInstance.t(
            'video-conference.error-messages.unknownError',
        ),
        connecting: i18nextInstance.t(
            'video-conference.error-messages.connecting',
        ),
        otherParticipantDropped: i18nextInstance.t(
            'video-conference.error-messages.otherParticipantDropped',
        ),
        reconnecting: i18nextInstance.t(
            'video-conference.error-messages.reconnecting',
        ),
        disconnected: i18nextInstance.t(
            'video-conference.error-messages.disconnected',
        ),
    };

    const excludePhoneInAssistanceMessage = getFeatureFlag(
        FeatureFlags.excludePhoneInAssistanceMessage,
    );

    const technicalSupportHelpNumber = getConfig().technicalSupportHelpNumber;
    const assistanceMessage = excludePhoneInAssistanceMessage
        ? ASSISTANCE_MESSAGE_WITHOUT_PHONE
        : getConfig().assistanceMessage || ASSISTANCE_MESSAGE_DEFAULT;
    const assistanceMessageWithPhone = technicalSupportHelpNumber
        ? `${assistanceMessage} ${technicalSupportHelpNumber}`
        : '';

    const messages = {
        ...defaultVideoErrorMessages,
        ...getConfig().videoUserMessages,
    };
    // Error message for joining the same conference in a new tab/window
    conferenceMessageMap.set(ConferenceError[ConferenceError.JoinedElsewhere], {
        message: (
            <div>
                {' '}
                {messages.removedFromCall} <br /> {messages.joinedElseWhere}{' '}
            </div>
        ),
        messageType: MessageType.Error,
    });
    conferenceMessageMap.set(ConferenceError[ConferenceError.ConferenceFull], {
        message: (
            <div>
                {' '}
                {messages.roomFull} <br />{' '}
                {excludePhoneInAssistanceMessage
                    ? assistanceMessage
                    : assistanceMessageWithPhone}{' '}
            </div>
        ),
        messageType: MessageType.Error,
    });
    conferenceMessageMap.set(ConferenceError[ConferenceError.NetworkIssues], {
        message: (
            <div>
                {' '}
                {messages.networkError} <br />{' '}
                {excludePhoneInAssistanceMessage
                    ? assistanceMessage
                    : assistanceMessageWithPhone}{' '}
            </div>
        ),
        messageType: MessageType.Error,
    });
    conferenceMessageMap.set(ConferenceError[ConferenceError.Other], {
        message: (
            <div>
                {' '}
                {messages.unknownError} <br />{' '}
                {excludePhoneInAssistanceMessage
                    ? assistanceMessage
                    : assistanceMessageWithPhone}{' '}
            </div>
        ),
        messageType: MessageType.Error,
    });
    // Info messages
    conferenceMessageMap.set(
        ConferenceMessageType[ConferenceMessageType.DialingMessage],
        {
            message: <div> {messages.connecting} </div>,
            messageType: MessageType.Info,
        },
    );
    conferenceMessageMap.set(
        ConferenceMessageType[ConferenceMessageType.ConnectedMessage],
        {
            message: <div> {messages.otherParticipantDropped}</div>,
            messageType: MessageType.Info,
        },
    );
    conferenceMessageMap.set(
        ConferenceMessageType[ConferenceMessageType.CameraWarningMessage],
        {
            message: (
                <div>
                    {' '}
                    {messages.camMuted}{' '}
                    {excludePhoneInAssistanceMessage
                        ? assistanceMessage
                        : assistanceMessageWithPhone}{' '}
                </div>
            ),
            messageType: MessageType.Info,
        },
    );
    conferenceMessageMap.set(
        ConferenceMessageType[ConferenceMessageType.MicrophoneWarningMessage],
        {
            message: (
                <div>
                    {' '}
                    {messages.micMuted}{' '}
                    {excludePhoneInAssistanceMessage
                        ? assistanceMessage
                        : assistanceMessageWithPhone}{' '}
                </div>
            ),
            messageType: MessageType.Info,
        },
    );
    conferenceMessageMap.set(
        ConferenceMessageType[ConferenceMessageType.ReconnectingMessage],
        {
            message: <div> {messages.reconnecting} </div>,
            messageType: MessageType.Info,
        },
    );
    // Action messages
    conferenceMessageMap.set(
        ConferenceMessageType[ConferenceMessageType.DisconnectedMessage],
        {
            message: (
                <div>
                    {' '}
                    {messages.disconnected} <br />{' '}
                    {excludePhoneInAssistanceMessage
                        ? assistanceMessage
                        : assistanceMessageWithPhone}{' '}
                </div>
            ),
            messageType: MessageType.Action,
            icon: 'cloud_off',
        },
    );
}
