import * as React from 'react';
import {
    Location,
    useParams,
    useLocation,
    useNavigate,
    NavigateFunction,
} from 'react-router-dom';

export interface RouterProps<Params = Record<string, string | undefined>> {
    router: {
        params: Params;
        location: Location;
        navigate: NavigateFunction;
    };
}

export function withRouter<OwnProps>(
    Component: React.ComponentType<OwnProps>,
): React.ComponentType<OwnProps> {
    function ComponentWithRouterProp(props: Omit<OwnProps, 'router'>) {
        const params = useParams();
        const location = useLocation();
        const navigate = useNavigate();

        return (
            <Component
                {...(props as OwnProps)}
                router={{ location, navigate, params }}
            />
        );
    }

    return ComponentWithRouterProp;
}
