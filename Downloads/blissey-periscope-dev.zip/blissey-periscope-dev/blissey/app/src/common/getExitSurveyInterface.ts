export interface WindowWithSurvey extends Window {
    onExitSurvey?: (() => void) | null;
    Android?: {
        onExitSurvey?: () => void;
    };
    webkit?: {
        messageHandlers?: {
            onExitSurvey?: {
                postMessage?: (message: unknown) => void;
            };
        };
    };
}

export function getExitSurveyInterface(
    window: WindowWithSurvey,
): (() => void) | undefined {
    //check for Android
    if (window.Android && typeof window.Android.onExitSurvey === 'function') {
        return () => {
            try {
                window.Android?.onExitSurvey?.();
            } catch (error) {
                throw new Error(
                    'Error calling onExitSurvey on Android interface',
                );
            }
        };
    }

    //check for iOS
    if (
        window.webkit?.messageHandlers?.onExitSurvey &&
        typeof window.webkit.messageHandlers.onExitSurvey.postMessage ===
            'function'
    ) {
        return () => {
            try {
                window.webkit?.messageHandlers?.onExitSurvey?.postMessage?.(
                    null,
                );
            } catch (error) {
                throw new Error('Error calling postMessage on iOS interface');
            }
        };
    }

    //fallback for any other implementation
    if (typeof window.onExitSurvey === 'function') {
        return window.onExitSurvey;
    }

    return undefined;
}
