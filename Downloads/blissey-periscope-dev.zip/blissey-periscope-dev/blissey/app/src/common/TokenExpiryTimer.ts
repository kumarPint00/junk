import { LogManager, config, location } from '@dexcare/circus-jupiter';
import { StageId } from '../stageManagement/StageId';
import { jwtTokenHelper } from '../utils/jwt-helper';
import { Configuration } from 'types/configuration';

export class TokenExpiryTimer {
    private static timeoutId: number;
    private static readonly Logger = LogManager.getLogger().child(
        {
            eventSource: 'TokenExpiryTimer',
        },
        true,
    );
    private static closeToExpiryInMillis = 30 * 1000;

    public static attachTimeout(
        expiry: number,
        stage: StageId,
        conferenceOrVisitId: string,
        isProvider = true,
    ) {
        const data = {
            eventName: 'attachTimeout',
            expiry,
            stage,
            conferenceOrVisitId,
            isProvider,
        };
        // clear any existing timeout
        TokenExpiryTimer.detachTimeout();
        const timeToExpiry = TokenExpiryTimer.getTimeToExpiry(expiry);
        TokenExpiryTimer.Logger.info({ ...data, timeToExpiry });

        switch (stage) {
            case StageId.InConsult:
                TokenExpiryTimer.logoutIfCloseToExpiry(
                    '/conference/' + conferenceOrVisitId,
                    timeToExpiry,
                );
                break;
            case StageId.InVisit: {
                const inVisitPath = isProvider ? 'room' : 'visit';
                TokenExpiryTimer.logoutIfCloseToExpiry(
                    `/${inVisitPath}/${conferenceOrVisitId}`,
                    timeToExpiry,
                );
                break;
            }
            case StageId.Hangup:
                TokenExpiryTimer.delayedLogoutIfTokenExpired(timeToExpiry);
                break;
            default:
                TokenExpiryTimer.startTimer(timeToExpiry);
        }
    }

    public static detachTimeout() {
        TokenExpiryTimer.Logger.info({
            eventName: 'detachTimeout',
            timeoutId: TokenExpiryTimer.timeoutId,
        });
        window.clearTimeout(TokenExpiryTimer.timeoutId);
    }

    private static startTimer(timeToExpiry: number): void {
        TokenExpiryTimer.Logger.info({
            eventName: 'startTimer',
            timeToExpiry,
        });
        // clear any existing timeout
        TokenExpiryTimer.detachTimeout();
        // set new timeout
        TokenExpiryTimer.timeoutId = window.setTimeout(
            TokenExpiryTimer.logout,
            timeToExpiry,
        );
    }

    private static logoutIfCloseToExpiry(
        callPath: string,
        timeToExpiry: number,
    ): void {
        if (timeToExpiry <= TokenExpiryTimer.closeToExpiryInMillis) {
            TokenExpiryTimer.Logger.info({
                eventName: 'logoutIfCloseToExpiry',
                timeToExpiry,
                callPath,
            });
            TokenExpiryTimer.relogin(callPath);
        }
    }

    private static delayedLogoutIfTokenExpired(timeToExpiry: number): void {
        const delay = (config as Configuration).getConfig().readMessageDelay;
        TokenExpiryTimer.Logger.info({
            eventName: 'delayedLogoutIfTokenExpired',
            timeToExpiry,
            delay,
        });
        if (timeToExpiry <= delay) {
            TokenExpiryTimer.startTimer(delay);
        } else {
            TokenExpiryTimer.startTimer(timeToExpiry);
        }
    }

    public static logout = (): void => {
        TokenExpiryTimer.Logger.info({
            eventName: 'logout',
        });

        jwtTokenHelper.clearAuthenticationToken();
        const search = window.location.search
            ? encodeURIComponent(window.location.search)
            : '';
        window.location.replace(
            `/expired?location=patientauth/logout${search}`,
        );
    };

    private static relogin(callPath: string): void {
        TokenExpiryTimer.Logger.info({
            eventName: 'relogin',
            callPath,
        });

        jwtTokenHelper.clearAuthenticationToken();
        location.setLocationPathname('/expired' + callPath);
    }

    /**
     * Given an epoch time expiration in the future (IN SECONDS!)
     * return the millseconds left until expiration
     * @returns {number} (milliseconds)
     */
    public static getTimeToExpiry(expiryInSeconds: number): number {
        TokenExpiryTimer.Logger.info({
            eventName: 'getTimeToExpiry',
            expiryInSeconds,
        });
        const currentTime: number = Date.now();
        return expiryInSeconds * 1000 - currentTime;
    }
}
