export enum HealthCheckStatus {
    Healthy,
    Unhealthy,
    Unknown,
}
