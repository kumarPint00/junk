import * as React from 'react';

export interface ConnectionTestMessage {
    index: number;
    message?: string;
}

export const getConnectionTestMessageMap = (i18nextInstance: {
    t: (s: string) => string;
}) => {
    const connectionTestMessageMap = new Map<number, React.ReactNode>();
    connectionTestMessageMap.set(
        25,
        <div>
            {i18nextInstance.t(
                'waiting-room.tech-check.status.checkingForNetwork',
            )}
        </div>,
    );
    connectionTestMessageMap.set(
        50,
        <div>
            {i18nextInstance.t(
                'waiting-room.tech-check.status.checkingForDevices',
            )}
        </div>,
    );
    connectionTestMessageMap.set(
        75,
        <div>
            {i18nextInstance.t('waiting-room.tech-check.status.savingDevices')}
        </div>,
    );
    return connectionTestMessageMap;
};
