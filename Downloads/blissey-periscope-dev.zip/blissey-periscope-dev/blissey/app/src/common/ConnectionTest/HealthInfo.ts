import { HealthCheckStatus } from './HealthCheckStatus';

export interface HealthInfo {
    healthCheckStatus: HealthCheckStatus;
}
