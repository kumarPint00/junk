import i18n, { InitOptions, i18n as I18nInterface } from 'i18next';
import LanguageDetector from 'i18next-browser-languagedetector';
import HttpApi from 'i18next-http-backend';

import { BrandConfig } from '../../../../server/config/configInterfaces';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';

export const i18nCommonInitOptions = {
    ns: ['translation'],
    fallbackNS: ['translation'],
    fallbackLng: 'en',
    preload: [],
    interpolation: {
        escapeValue: false, // not needed for react as it escapes by default
    },
};

const getI18nInstance = () => {
    return i18n;
};

const initI18nInstance = async (
    brandConfig: BrandConfig,
): Promise<I18nInterface> => {
    const translationsEnabled = getFeatureFlag(FeatureFlags.enableLocalization);
    let brandingTranslations;
    try {
        brandingTranslations = brandConfig;
    } catch (e) {
        console.log(
            `I18n init: error initializing for ${JSON.stringify(brandConfig)}`,
        );
        return {} as I18nInterface;
    }

    const i18nextConfig: InitOptions & {
        backend: { loadPath: string; crossDomain: boolean };
    } = {
        load: 'languageOnly', // This sets i18next to ignore regional (ie, country/national) settings & *only* look at the requested language
        backend: {
            loadPath: `/l10n/{{lng}}/{{ns}}`,
            crossDomain: true,
        },
        ...i18nCommonInitOptions,
    };

    if (!translationsEnabled) {
        i18nextConfig.lng = 'en';
    }

    await i18n
        .use(LanguageDetector) // Attempts to use the browser's configured language settings for translations (https://github.com/i18next/i18next-browser-languageDetector)
        .use(HttpApi) // We will need to make an HTTP call to retrieve translation.json assets (https://github.com/i18next/i18next-http-backend)
        .init(i18nextConfig);

    // We add the branding-related strings from the brandingConfig as an additional bundle
    //   The keys are stored under an i18next namespace named "branding"
    i18n.addResourceBundle('en', 'branding', brandingTranslations, true, true);

    return i18n;
};

export { initI18nInstance, getI18nInstance };
