import {
    Publisher as OTPublisher,
    initPublisher,
    Event,
    Stream,
    VideoDimensionsChangedEvent,
    PublisherStatsArr,
    BackgroundBlurFilter,
} from '@dexcare/yak';
import { BlisseyLogger } from '@utils/Logger';

type TokboxEventHandler<T, V = Record<string, never>> = (
    event: Event<T, Publisher> & V,
) => void;
export type TokboxEvent<T> = Event<T, Publisher>;

interface AudioInfo {
    audioLevel: number;
}
export interface MediaStoppedInfo {
    track: MediaStreamTrack | undefined;
}
export interface StreamCreatedInfo {
    stream: Stream;
}
interface StreamDestroyedInfo {
    stream: Stream;
    reason: string;
}
interface VideoElementInfo {
    element: HTMLVideoElement | HTMLObjectElement;
}

type DeviceEnabledChange = (val: boolean) => void;
type DeviceChange = (id: string) => void;

interface PublishCallbacks {
    accessAllowed?: TokboxEventHandler<'accessAllowed'>;
    accessDenied?: TokboxEventHandler<'accessDenied'>;
    accessDialogClosed?: TokboxEventHandler<'accessDialogClosed'>;
    accessDialogOpened?: TokboxEventHandler<'accessDialogOpened'>;
    audioLevelUpdated?: TokboxEventHandler<'audioLevelUpdated', AudioInfo>;
    destroyed?: TokboxEventHandler<'destroyed'>;
    mediaStopped?: TokboxEventHandler<'mediaStopped', MediaStoppedInfo>;
    streamCreated?: TokboxEventHandler<'streamCreated', StreamCreatedInfo>;
    streamDestroyed?: TokboxEventHandler<
        'streamDestroyed',
        StreamDestroyedInfo
    >;
    videoDimensionsChanged?: (
        event: VideoDimensionsChangedEvent<OTPublisher>,
    ) => void;
    videoElementCreated?: TokboxEventHandler<
        'videoElementCreated',
        VideoElementInfo
    >;
    muteForced?: TokboxEventHandler<'muteForced'>;
}

export class Publisher {
    private id: string;
    private otPublisher?: OTPublisher | null;

    private onCamEnabledChange?: DeviceEnabledChange;
    private onMicEnabledChange?: DeviceEnabledChange;
    private onCamDeviceChange?: DeviceChange;
    private onMicDeviceChange?: DeviceChange;

    private onBlurEnabledChange?: DeviceEnabledChange;

    private logMediaStopped(
        callback?: TokboxEventHandler<'mediaStopped', MediaStoppedInfo>,
    ) {
        return (event: Event<'mediaStopped', Publisher> & MediaStoppedInfo) => {
            BlisseyLogger.warn({ details: { event } }, 'media stopped');
            if (callback) callback(event);
        };
    }
    private blurVideoFilter: BackgroundBlurFilter = {
        type: 'backgroundBlur',
        blurStrength: 'high',
    };

    constructor({
        id,
        callbacks: {
            onCamEnabledChange,
            onMicEnabledChange,
            onCamDeviceChange,
            onMicDeviceChange,
            onBlurEnabledChange,
        },
    }: {
        id: string;
        callbacks: {
            onCamEnabledChange?: DeviceEnabledChange;
            onMicEnabledChange?: DeviceEnabledChange;
            onCamDeviceChange?: DeviceChange;
            onMicDeviceChange?: DeviceChange;
            onBlurEnabledChange?: DeviceEnabledChange;
        };
    }) {
        this.id = id;

        this.onCamEnabledChange = onCamEnabledChange;
        this.onMicEnabledChange = onMicEnabledChange;
        this.onCamDeviceChange = onCamDeviceChange;
        this.onMicDeviceChange = onMicDeviceChange;
        this.onBlurEnabledChange = onBlurEnabledChange;
    }

    public getOTPublisher() {
        return this.otPublisher;
    }

    public async initVideoElement({
        publisherOverrides,
        callbacks,
    }: {
        publisherOverrides: OT.PublisherProperties;
        callbacks: PublishCallbacks;
    }) {
        if (this.otPublisher) {
            this.cleanup();
        }

        return new Promise<void>((resolve, reject) => {
            this.otPublisher = initPublisher(
                this.id,
                {
                    insertMode: 'append',
                    fitMode: 'cover',
                    width: '100%',
                    height: '100%',
                    videoContentHint: 'detail',
                    showControls: false,
                    publishVideo: true,
                    publishAudio: true,
                    style: {
                        buttonDisplayMode: 'off',
                    },
                    ...publisherOverrides,
                },
                (error?: Error) => {
                    if (error) {
                        reject(error);
                    } else {
                        resolve();
                    }
                },
            );
            this.otPublisher.on({
                ...callbacks,
                mediaStopped: this.logMediaStopped(callbacks.mediaStopped),
            });
        });
    }

    public cleanup = () => {
        BlisseyLogger.info(
            { details: { publisherId: this.id } },
            'destroying publisher',
        );
        if (this.otPublisher) {
            this.otPublisher.off();
            this.otPublisher.destroy();
            this.otPublisher = null;
        }
    };

    public async getStats(): Promise<PublisherStatsArr> {
        return new Promise((res, rej) => {
            this.otPublisher?.getStats((err, stats) => {
                if (err) {
                    rej(err.name as unknown as Error);
                } else {
                    res(stats || []);
                }
            });
        });
    }

    public getVideoDeviceId() {
        return this.otPublisher?.getVideoSource()?.deviceId || null;
    }

    public getAudioDeviceId() {
        return (
            this.otPublisher?.getAudioSource()?.getSettings()?.deviceId || null
        );
    }

    public async setVideoDeviceId(deviceId: string) {
        BlisseyLogger.info(
            { details: { deviceId, publisherId: this.id } },
            'changing video device',
        );

        await this.otPublisher?.setVideoSource(deviceId);
        if (this.onCamDeviceChange) this.onCamDeviceChange(deviceId);
    }

    public async cycleVideoDevice() {
        await this.otPublisher?.cycleVideo();
    }

    public async setAudioDeviceId(deviceId: string) {
        BlisseyLogger.info(
            { details: { deviceId, publisherId: this.id } },
            'changing audio device',
        );
        await this.otPublisher?.setAudioSource(deviceId);
        if (this.onMicDeviceChange) this.onMicDeviceChange(deviceId);
    }

    public publishVideo(enabled: boolean) {
        BlisseyLogger.info(
            { details: { enabled, publisherId: this.id } },
            'changing local cam state',
        );
        this.otPublisher?.publishVideo(enabled);
        if (this.onCamEnabledChange) this.onCamEnabledChange(enabled);
    }

    public publishAudio(enabled: boolean) {
        BlisseyLogger.info(
            { details: { enabled, publisherId: this.id } },
            'changing local audio state',
        );
        this.otPublisher?.publishAudio(enabled);
        if (this.onMicEnabledChange) this.onMicEnabledChange(enabled);
    }

    public async publishBlur(enabled: boolean) {
        BlisseyLogger.info(
            { details: { enabled, publisherId: this.id } },
            'changing local blur state',
        );
        if (enabled) {
            this.blurVideoFilter.blurStrength = 'high';
            await this.otPublisher?.applyVideoFilter(this.blurVideoFilter);
        } else {
            await this.otPublisher?.clearVideoFilter();
        }
        if (this.onBlurEnabledChange) this.onBlurEnabledChange(enabled);
    }

    public hasAudio() {
        return this.otPublisher?.stream?.hasAudio;
    }

    public hasVideo() {
        return this.otPublisher?.stream?.hasVideo;
    }
}
