import { OTClient } from '@dexcare/yak';
import NetworkTest, { ErrorNames } from 'opentok-network-test-js';
import { TestStatus } from './TestStatus';

export interface TestSession {
    readonly apiKey: string;
    readonly sessionId: string;
    readonly token: string;
}

export interface NetworkTestError {
    camError: boolean;
    micError: boolean;
    mediaPermissionsError: boolean;
    publishError: boolean;
    connectionError: boolean;
    loggingServerError: boolean;
    unknownError: boolean;
}

export interface NetworkTestResults {
    networkStatus: TestStatus;
    // the network test isn't great at diagnosing media errors, but still return them
    // (usually comes back as a generic publish error)
    error?: NetworkTestError;
}

const errorMap: Partial<Record<ErrorNames, keyof NetworkTestError>> = {
    [ErrorNames.FAILED_TO_OBTAIN_MEDIA_DEVICES]: 'mediaPermissionsError',
    [ErrorNames.NO_AUDIO_CAPTURE_DEVICES]: 'micError',
    [ErrorNames.NO_VIDEO_CAPTURE_DEVICES]: 'camError',
    [ErrorNames.FAILED_TO_CREATE_LOCAL_PUBLISHER]: 'publishError',
    [ErrorNames.LOGGING_SERVER_CONNECTION_ERROR]: 'loggingServerError',
};

export async function networkCheck(
    testSession: TestSession,
): Promise<NetworkTestResults> {
    const otNetworkTest = new NetworkTest(
        OTClient as unknown as NetworkTest['OT'],
        testSession,
    );
    const error: NetworkTestError = {
        camError: false,
        micError: false,
        mediaPermissionsError: false,
        connectionError: false,
        publishError: false,
        unknownError: false,
        loggingServerError: false,
    };

    try {
        const connectivityResults = await otNetworkTest.testConnectivity();
        if (connectivityResults.success) {
            return { networkStatus: TestStatus.Passed };
        } else {
            if (!connectivityResults.failedTests?.length) {
                error.unknownError = true;
            }

            (connectivityResults.failedTests || []).forEach((test) => {
                const name = test.error.name as ErrorNames;
                const errorKey = errorMap[name] || 'connectionError';
                // ENG-1885.
                error[errorKey] = true;
            });
            return { networkStatus: TestStatus.Failed, error };
        }
    } catch (error) {
        return {
            networkStatus: TestStatus.Failed,
            error: { ...(error as NetworkTestError), unknownError: true },
        };
    }
}
