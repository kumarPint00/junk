export enum TestStatus {
    NotRun,
    Failed,
    Passed,
    Skipped,
}
