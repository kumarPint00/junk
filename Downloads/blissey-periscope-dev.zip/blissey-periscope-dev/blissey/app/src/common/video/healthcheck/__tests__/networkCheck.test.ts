import NetworkTest, { ErrorNames } from 'opentok-network-test-js';
import { networkCheck } from '../networkCheck';
import { TestStatus } from '../TestStatus';
import { Mock, vi } from 'vitest';

vi.mock('opentok-network-test-js');

const mockNetworkTest = NetworkTest as unknown as Mock<NetworkTest[]>;

const mockOTNetworkTest = (success = true, failedTests: unknown[] = []) => {
    mockNetworkTest.mockImplementation(
        () =>
            ({
                testConnectivity: () => ({ success, failedTests }),
            } as unknown as NetworkTest),
    );
};

const mockTestSession = {
    apiKey: 'test-apiKey',
    sessionId: 'test-sessionId',
    token: 'test-token',
};

describe('networkCheck', () => {
    it('returns success response', async () => {
        mockOTNetworkTest();

        const results = await networkCheck(mockTestSession);
        expect(results.networkStatus).toEqual(TestStatus.Passed);
        expect(results).toMatchInlineSnapshot(`
            {
              "networkStatus": 2,
            }
        `);
    });
    it('returns error response', async () => {
        mockOTNetworkTest(false, [
            { error: { name: ErrorNames.CONNECTIVITY_ERROR } },
        ]);

        const results = await networkCheck(mockTestSession);
        expect(results.networkStatus).toEqual(TestStatus.Failed);
        expect(results).toMatchInlineSnapshot(`
            {
              "error": {
                "camError": false,
                "connectionError": true,
                "loggingServerError": false,
                "mediaPermissionsError": false,
                "micError": false,
                "publishError": false,
                "unknownError": false,
              },
              "networkStatus": 1,
            }
        `);
    });
    it('returns error response if there are no failed tests', async () => {
        mockOTNetworkTest(false, []);

        const results = await networkCheck(mockTestSession);
        expect(results.networkStatus).toEqual(TestStatus.Failed);
        expect(results).toMatchInlineSnapshot(`
            {
              "error": {
                "camError": false,
                "connectionError": false,
                "loggingServerError": false,
                "mediaPermissionsError": false,
                "micError": false,
                "publishError": false,
                "unknownError": true,
              },
              "networkStatus": 1,
            }
        `);
    });
    it('catches', async () => {
        mockNetworkTest.mockImplementation(
            () =>
                ({
                    testConnectivity: () => {
                        throw new Error('disconnected!');
                    },
                } as unknown as NetworkTest),
        );

        const results = await networkCheck(mockTestSession);
        expect(results.networkStatus).toEqual(TestStatus.Failed);
        expect(results).toMatchInlineSnapshot(`
            {
              "error": {
                "unknownError": true,
              },
              "networkStatus": 1,
            }
        `);
    });
});
