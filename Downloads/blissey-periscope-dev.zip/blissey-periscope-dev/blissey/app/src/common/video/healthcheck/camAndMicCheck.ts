import { getDevices } from '../getDevices';
import { MediaDevice } from '../getDevices';

export interface CamAndMicResults {
    hasCamera: boolean;
    hasMic: boolean;
    videoDevices: MediaDevice[];
    audioDevices: MediaDevice[];
}

const hasUsableDevice = (devices: MediaDevice[]) => {
    return !!devices.length;
};

export async function camAndMicCheck(): Promise<CamAndMicResults> {
    const { videoDevices, audioDevices } = await getDevices();
    const hasCamera = hasUsableDevice(videoDevices);
    const hasMic = hasUsableDevice(audioDevices);

    return {
        hasCamera,
        hasMic,
        videoDevices,
        audioDevices,
    };
}
