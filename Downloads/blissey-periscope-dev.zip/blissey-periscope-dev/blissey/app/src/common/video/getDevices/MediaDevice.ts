export interface MediaDevice {
    label: string;
    value: string;
}
