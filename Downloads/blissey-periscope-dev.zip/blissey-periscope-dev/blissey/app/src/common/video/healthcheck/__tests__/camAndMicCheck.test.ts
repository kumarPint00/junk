import { camAndMicCheck } from '../';
import { getDevices } from '@dexcare/yak';
import { Mock, vi } from 'vitest';

vi.mock('opentok-network-test-js');

const mockGetDevices = (mediaResponse: undefined | unknown[]) => {
    (getDevices as Mock).mockImplementation(
        (callback: (error: null, devices?: unknown[]) => void) => {
            callback(null, mediaResponse);
        },
    );
};

const videoDevice = {
    label: 'Test Video Device',
    deviceId: 'video1',
    kind: 'videoInput',
};
const audioDevice = {
    label: 'Test Audio Device',
    deviceId: 'audio1',
    kind: 'audioInput',
};

const runTest = async (mediaResponse: undefined | unknown[]) => {
    mockGetDevices(mediaResponse);

    const result = await camAndMicCheck();
    expect(result).toMatchSnapshot();
};

describe('camAndMicCheck', () => {
    it('cam and mic available', async () =>
        runTest([audioDevice, videoDevice]));
    it('mic is not available', async () => runTest([videoDevice]));
    it('cam is not available', async () => runTest([audioDevice]));
    it('cam and mic are not available', async () => runTest(undefined));
});
