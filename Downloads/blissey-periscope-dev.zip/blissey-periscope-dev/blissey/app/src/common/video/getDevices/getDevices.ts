import { Device as OTDevice, getDevices as otGetDevices } from '@dexcare/yak';
import { MediaDevice } from './MediaDevice';
import { BlisseyLogger } from '@utils/Logger';

const findDevices = async (): Promise<OTDevice[] | undefined> => {
    return new Promise((res, rej) => {
        otGetDevices((error: Error, devices) => {
            if (error) {
                BlisseyLogger.error({
                    msg: 'opentok get devices error',
                    details: { error },
                });
                rej(error);
            } else {
                res(devices);
            }
        });
    });
};

export const getDevices = async () => {
    const videoDevices: MediaDevice[] = [];
    const audioDevices: MediaDevice[] = [];

    try {
        const devices = await findDevices();
        BlisseyLogger.debug(
            {
                details: {
                    devices: JSON.stringify(devices),
                },
            },
            'opentok found devices',
        );
        (devices || []).forEach((device: OTDevice) => {
            switch (device?.kind || '') {
                case 'videoInput': {
                    const videoLabel =
                        device.label || 'Camera ' + (videoDevices.length + 1);
                    videoDevices.push({
                        label: videoLabel,
                        value: device.deviceId,
                    });
                    break;
                }
                case 'audioInput': {
                    const audioLabel =
                        device.label ||
                        'Microphone ' + (audioDevices.length + 1);
                    audioDevices.push({
                        label: audioLabel,
                        value: device.deviceId,
                    });
                    break;
                }
                default:
            }
        });
    } catch (error) {
        BlisseyLogger.info('found no devices');
    }
    return {
        videoDevices,
        audioDevices,
    };
};
