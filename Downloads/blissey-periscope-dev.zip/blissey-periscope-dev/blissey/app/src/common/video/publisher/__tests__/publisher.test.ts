import { Publisher as OTPublisher } from '@dexcare/yak';
import { Publisher } from '..';
import { Mocked, vi } from 'vitest';

vi.mock('@dexcare/yak');

let yakMock: Mocked<typeof import('@dexcare/yak')>;

const audioDeviceId = 'audio-device-id';
const videoDeviceId = 'video-device-id';
const publisherId = 'testId';

describe('publisher', () => {
    let publisher: Publisher;
    let off: () => void;
    let destroy: () => void;
    let setAudioSource: () => void;
    let setVideoSource: () => void;
    let publishAudio: () => void;
    let publishVideo: () => void;
    let onCamEnabledChange: () => void;
    let onMicEnabledChange: () => void;
    let onCamDeviceChange: () => void;
    let onMicDeviceChange: () => void;
    let applyVideoFilter: () => void;
    let clearVideoFilter: () => void;
    beforeEach(async () => {
        off = vi.fn();
        destroy = vi.fn();
        setAudioSource = vi.fn();
        setVideoSource = vi.fn();
        publishVideo = vi.fn();
        publishAudio = vi.fn();
        onCamEnabledChange = vi.fn();
        onMicEnabledChange = vi.fn();
        onCamDeviceChange = vi.fn();
        onMicDeviceChange = vi.fn();
        applyVideoFilter = vi.fn();
        clearVideoFilter = vi.fn();
        publisher = new Publisher({
            id: publisherId,
            callbacks: {
                onCamEnabledChange,
                onMicEnabledChange,
                onCamDeviceChange,
                onMicDeviceChange,
            },
        });

        yakMock = await vi.importMock('@dexcare/yak');
        yakMock.initPublisher.mockImplementation((_id, _vals, callback) => {
            if (callback) callback();
            return {
                off,
                on: vi.fn(),
                destroy,
                publishVideo,
                publishAudio,
                setVideoSource,
                setAudioSource,
                getAudioSource: vi.fn(() => ({
                    getSettings: vi.fn(() => ({
                        deviceId: audioDeviceId,
                    })),
                })),
                getVideoSource: vi.fn(() => ({
                    deviceId: videoDeviceId,
                })),
                applyVideoFilter,
                clearVideoFilter,
            } as unknown as OTPublisher;
        });
    });
    afterEach(() => {
        vi.clearAllMocks();
    });
    it('inits', async () => {
        await publisher.initVideoElement({
            publisherOverrides: {},
            callbacks: {},
        });
        expect(yakMock.initPublisher).toHaveBeenCalledTimes(1);
        expect(yakMock.initPublisher.mock.calls).toMatchInlineSnapshot(`
            [
              [
                "testId",
                {
                  "fitMode": "cover",
                  "height": "100%",
                  "insertMode": "append",
                  "publishAudio": true,
                  "publishVideo": true,
                  "showControls": false,
                  "style": {
                    "buttonDisplayMode": "off",
                  },
                  "videoContentHint": "detail",
                  "width": "100%",
                },
                [Function],
              ],
            ]
        `);
    });
    it('inits with overrides and callbacks', async () => {
        await publisher.initVideoElement({
            publisherOverrides: {
                videoSource: 'video1',
                audioSource: 'audio1',
            },
            callbacks: {
                videoDimensionsChanged: vi.fn(),
            },
        });
        expect(yakMock.initPublisher).toHaveBeenCalledTimes(1);
        expect(yakMock.initPublisher.mock.calls).toMatchInlineSnapshot(`
            [
              [
                "testId",
                {
                  "audioSource": "audio1",
                  "fitMode": "cover",
                  "height": "100%",
                  "insertMode": "append",
                  "publishAudio": true,
                  "publishVideo": true,
                  "showControls": false,
                  "style": {
                    "buttonDisplayMode": "off",
                  },
                  "videoContentHint": "detail",
                  "videoSource": "video1",
                  "width": "100%",
                },
                [Function],
              ],
            ]
        `);
    });
    it('gets audio device', async () => {
        await publisher.initVideoElement({
            publisherOverrides: {},
            callbacks: {},
        });

        expect(publisher.getAudioDeviceId()).toEqual(audioDeviceId);
    });
    it('gets video device', async () => {
        await publisher.initVideoElement({
            publisherOverrides: {},
            callbacks: {},
        });

        expect(publisher.getVideoDeviceId()).toEqual(videoDeviceId);
    });
    it('sets audio device', async () => {
        await publisher.initVideoElement({
            publisherOverrides: {},
            callbacks: {},
        });
        await publisher.setAudioDeviceId(audioDeviceId);
        expect(setAudioSource).toHaveBeenCalledWith(audioDeviceId);
        expect(onMicDeviceChange).toHaveBeenCalledWith(audioDeviceId);
    });
    it('sets video device', async () => {
        await publisher.initVideoElement({
            publisherOverrides: {},
            callbacks: {},
        });
        await publisher.setVideoDeviceId(videoDeviceId);
        expect(setVideoSource).toHaveBeenCalledWith(videoDeviceId);
        expect(onCamDeviceChange).toHaveBeenCalledWith(videoDeviceId);
    });
    it('publishes audio', async () => {
        await publisher.initVideoElement({
            publisherOverrides: {},
            callbacks: {},
        });
        publisher.publishAudio(true);
        expect(publishAudio).toHaveBeenCalledWith(true);
        expect(onMicEnabledChange).toHaveBeenCalledWith(true);
    });
    it('publishes video', async () => {
        await publisher.initVideoElement({
            publisherOverrides: {},
            callbacks: {},
        });
        publisher.publishVideo(true);
        expect(publishVideo).toHaveBeenCalledWith(true);
        expect(onCamEnabledChange).toHaveBeenCalledWith(true);
    });
    it('cleans up', async () => {
        await publisher.initVideoElement({
            publisherOverrides: {},
            callbacks: {},
        });

        publisher.cleanup();
        expect(publisher.getOTPublisher()).toEqual(null);
        expect(off).toHaveBeenCalledTimes(1);
        expect(destroy).toHaveBeenCalledTimes(1);
    });
    describe('publishBlur', () => {
        beforeEach(async () => {
            await publisher.initVideoElement({
                publisherOverrides: {},
                callbacks: {},
            });
        });
        it('enabled', async () => {
            await publisher.publishBlur(true);
            expect(applyVideoFilter).toHaveBeenCalledWith({
                blurStrength: 'high',
                type: 'backgroundBlur',
            });
        });
        it('disabled', async () => {
            await publisher.publishBlur(false);
            expect(clearVideoFilter).toHaveBeenCalled();
        });
    });
});
