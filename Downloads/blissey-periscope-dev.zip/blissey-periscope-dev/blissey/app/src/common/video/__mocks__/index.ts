import { vi } from 'vitest';
import * as actual from '@common/video';

module.exports = {
    ...actual,
    Publisher: vi.fn().mockImplementation(() => ({
        getOTPublisher: vi.fn().mockReturnValue({}),
        publishVideo: vi.fn(),
        publishAudio: vi.fn(),
        setVideoDeviceId: vi.fn(),
        setAudioDeviceId: vi.fn(),
        cleanup: vi.fn(),
        initVideoElement: vi.fn(),
        getVideoDeviceId: vi.fn().mockReturnValue('videoDevice1'),
        getAudioDeviceId: vi.fn().mockReturnValue('audioDevice1'),
        hasAudio: vi.fn(),
        hasVideo: vi.fn(),
    })),
    camAndMicCheck: vi.fn(),
    networkCheck: vi.fn(),
};
