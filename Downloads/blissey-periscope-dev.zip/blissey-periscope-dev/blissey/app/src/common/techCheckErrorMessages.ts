import { TestStatus } from '@common/video';
import { TState as TechCheckState } from '@redux/modules/health';
import { getI18nInstance } from '@common/i18n/i18nInstance';

const i18nextInstance = getI18nInstance();

export enum ErrorCode {
    // errors from opentok:
    mediaAccessDenied = 'OT_USER_MEDIA_ACCESS_DENIED',
    unableToCaptureMedia = 'OT_UNABLE_TO_CAPTURE_MEDIA',
    hardwareUnavailable = 'OT_HARDWARE_UNAVAILABLE',
    // other:
    missingDevice = 'NO_DEVICES_FOUND',
    unknown = 'UNKNOWN',
}
type DeviceName = 'camera' | 'microphone';

export interface ErrorMessageConfig {
    readonly techCheckHeader?: string;
    readonly techCheckDescription?: string;
    readonly selfViewInstructions?: string;
    readonly selfViewErrorDescription?: {
        message: string;
        type: 'media access' | 'device' | 'network';
        action?: 'rerun' | 'reload';
    };
}

export type MediaErrorMessageMap = Readonly<
    Record<ErrorCode, ErrorMessageConfig>
>;

const deviceErrorMessages = (deviceName: DeviceName): MediaErrorMessageMap => ({
    [ErrorCode.unableToCaptureMedia]: {
        techCheckDescription: i18nextInstance.t(
            `waiting-room.tech-check.errors.devices.${deviceName}.alreadyInUseMessage`,
        ),
        techCheckHeader: i18nextInstance.t(
            'waiting-room.tech-check.errors.deviceIssueHeader',
        ),
        selfViewErrorDescription: {
            message: i18nextInstance.t(
                `waiting-room.tech-check.errors.devices.${deviceName}.alreadyInUseDescription`,
            ),
            action: 'rerun',
            type: 'device',
        },
    },
    [ErrorCode.hardwareUnavailable]: {
        techCheckDescription: i18nextInstance.t(
            `waiting-room.tech-check.errors.devices.${deviceName}.alreadyInUseMessage`,
        ),
        techCheckHeader: i18nextInstance.t(
            'waiting-room.tech-check.errors.deviceIssueHeader',
        ),
        selfViewErrorDescription: {
            message: i18nextInstance.t(
                `waiting-room.tech-check.errors.devices.${deviceName}.alreadyInUseDescription`,
            ),
            action: 'rerun',
            type: 'device',
        },
    },
    [ErrorCode.missingDevice]: {
        techCheckDescription: i18nextInstance.t(
            `waiting-room.tech-check.errors.devices.${deviceName}.missingMessage`,
        ),
        techCheckHeader: i18nextInstance.t(
            'waiting-room.tech-check.errors.deviceIssueHeader',
        ),
        selfViewErrorDescription: {
            message: i18nextInstance.t(
                `waiting-room.tech-check.errors.devices.${deviceName}.missingDescription`,
            ),
            action: 'rerun',
            type: 'device',
        },
    },
    [ErrorCode.unknown]: {
        techCheckDescription: i18nextInstance.t(
            `waiting-room.tech-check.errors.devices.${deviceName}.unknownMessage`,
        ),
        techCheckHeader: i18nextInstance.t(
            'waiting-room.tech-check.errors.deviceIssueHeader',
        ),
    },
    [ErrorCode.mediaAccessDenied]: {
        techCheckDescription: i18nextInstance.t(
            'waiting-room.tech-check.errors.mediaPermissionIssueMessage',
        ),
        techCheckHeader: i18nextInstance.t(
            'waiting-room.tech-check.errors.mediaPermissionIssueHeader',
        ),
        selfViewErrorDescription: {
            message: i18nextInstance.t(
                'waiting-room.tech-check.errors.mediaPermissionIssueDescription',
            ),
            // on safari, you have to refresh the screen for media permission changes to take effect
            action: 'reload',
            type: 'media access',
        },
    },
});

const getUserMediaErrorMessage = (
    deviceName: DeviceName,
    error: ErrorCode | undefined,
) => {
    const map = deviceErrorMessages(deviceName);
    let config = map[error || ErrorCode.unknown];
    if (!config) {
        config = {
            techCheckDescription: i18nextInstance.t(
                'waiting-room.tech-check.errors.genericIssue',
            ),
            techCheckHeader: i18nextInstance.t(
                'waiting-room.tech-check.errors.unknownIssueHeader',
            ),
        };
    }
    return config;
};

// TODO: possibly move to the getHealthInfo selector
export function getErrorMessage(
    health: TechCheckState,
    lostConnection: boolean,
): ErrorMessageConfig {
    const mediaAccessDeniedConfig: ErrorMessageConfig = {
        techCheckDescription: i18nextInstance.t(
            'waiting-room.tech-check.errors.mediaPermissionIssueMessage',
        ),
        techCheckHeader: i18nextInstance.t(
            'waiting-room.tech-check.errors.mediaPermissionIssueHeader',
        ),
        selfViewErrorDescription: {
            message: i18nextInstance.t(
                'waiting-room.tech-check.errors.mediaPermissionIssueDescription',
            ),
            // on safari, you have to refresh the screen for media permission changes to take effect
            action: 'reload',
            type: 'media access',
        },
    };
    const networkErrorConfig: ErrorMessageConfig = {
        techCheckDescription: i18nextInstance.t(
            'waiting-room.tech-check.errors.networkIssueMessage',
        ),
        techCheckHeader: i18nextInstance.t(
            'waiting-room.tech-check.errors.connectionIssueHeader',
        ),
        selfViewErrorDescription: {
            message: i18nextInstance.t(
                'waiting-room.tech-check.errors.networkIssueDescription',
            ),
            action: 'rerun',
            type: 'network',
        },
    };
    const lostConnectionConfig: ErrorMessageConfig = {
        techCheckDescription: i18nextInstance.t(
            'waiting-room.tech-check.errors.connectionIssueDescription',
        ),
        techCheckHeader: i18nextInstance.t(
            'waiting-room.tech-check.errors.connectionIssueHeader',
        ),
    };
    const genericErrorConfig: ErrorMessageConfig = {
        techCheckDescription: i18nextInstance.t(
            'waiting-room.tech-check.errors.genericIssue',
        ),
        techCheckHeader: i18nextInstance.t(
            'waiting-room.tech-check.errors.unknownIssueHeader',
        ),
    };

    if (health.mediaPermissionStatus === 'denied') {
        return mediaAccessDeniedConfig;
    } else if (health.camStatus === TestStatus.Failed) {
        return getUserMediaErrorMessage('camera', health.camError);
    } else if (health.micStatus === TestStatus.Failed) {
        return getUserMediaErrorMessage('microphone', health.micError);
    } else if (health.networkStatus === TestStatus.Failed) {
        return networkErrorConfig;
    } else if (lostConnection) {
        return lostConnectionConfig;
    } else {
        return genericErrorConfig;
    }
}
