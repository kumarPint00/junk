export const TYTO_CARE_GENERIC_ERROR = 'Error creating TytoCare visit.';
export const TYTO_CARE_PROVIDER_CONFLICT = `${TYTO_CARE_GENERIC_ERROR}  Please check that you have closed out your previous visits.`;
export const TYTO_CARE_PATIENT_CONFLICT = `${TYTO_CARE_GENERIC_ERROR}  The patient is already engaged in a different TytoCare visit.`;
export const TYTO_CARE_PARTICIPANT_CONFLICT = `${TYTO_CARE_GENERIC_ERROR}  One of the participants is already engaged in a TytoCare visit.  You may need to close out a previous visit in order to proceed.`;
export const TYTO_CARE_MAX_ACCOUNT_LINKS = `${TYTO_CARE_GENERIC_ERROR}  The patient has reached their maximum account links on TytoCare.`;
export const TYTO_CARE_ACCOUNT_NOT_FOUND = `${TYTO_CARE_GENERIC_ERROR}  The TytoCare account could not be found.`;

export const TYTO_CARE_ERROR_MAP: { [key: string]: string } = {
    'add patient to account conflict': TYTO_CARE_MAX_ACCOUNT_LINKS,
    'provider already associated with an active visit':
        TYTO_CARE_PROVIDER_CONFLICT,
    'patient already associated with an active visit':
        TYTO_CARE_PATIENT_CONFLICT,
    'a participant has a conflict': TYTO_CARE_PARTICIPANT_CONFLICT,
    'account not found': TYTO_CARE_ACCOUNT_NOT_FOUND,
};
