import { Logger, LogManager, jupiterOptions } from '@dexcare/circus-jupiter';

jupiterOptions.applicationName = 'blissey';
jupiterOptions.logSource = process.env.NODE_ENV === 'development';
jupiterOptions.metricsEndpoint = '/appMetrics';
jupiterOptions.logLevel =
    process.env.NODE_ENV === 'development' ? 'debug' : 'info';

export class BlisseyLogger {
    private static _logger: Logger;

    public static addApplicationContext(fields: unknown) {
        LogManager.addApplicationContext(fields);
        this._logger = LogManager.getLogger();
    }

    public static addCustomHeaders(headers: Record<string, string>) {
        jupiterOptions.logsHeaders = {
            ...jupiterOptions.logsHeaders,
            ...headers,
        };
    }

    public static init() {
        this._logger = LogManager.getLogger();
    }

    public static child(fields: unknown): Logger {
        return this._logger.child(fields, true);
    }

    public static info(fields: unknown, message?: string) {
        this._logger.info(fields, message);
    }

    public static warn(fields: unknown, message?: string) {
        this._logger.warn(fields, message);
    }

    public static debug(fields: unknown, message?: string) {
        this._logger.debug(fields, message);
    }

    public static error(fields: unknown, message?: string) {
        this._logger.error(fields, message);
    }
}

BlisseyLogger.init();
