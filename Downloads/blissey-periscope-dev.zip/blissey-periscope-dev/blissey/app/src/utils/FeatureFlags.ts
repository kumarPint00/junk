import { config } from '@dexcare/circus-jupiter';
import { Configuration } from 'types/configuration';

export interface BlisseyBrowserFeatureFlag {
    minVersion: string;
    name: string;
    patient: boolean;
    provider: boolean;
}

export interface BlisseyBrowserFeatureFlagObject {
    video: boolean;
    phone: boolean;
}

export enum FeatureFlags {
    cancellation = 'cancellation',
    waitingRoomVideo = 'waiting-room-video',
    providerStatsAndReportIssue = 'provider-stats-and-report-issue',
    showBlurOption = 'enable-blur-background',
    enableLocalization = 'use-localization',
    localizeWaitTimeEstimateMessage = 'localize-wait-time-estimate-message',
    extraPatientSurvey1 = 'extra-patient-survey-question-1',
    extraPatientSurvey2 = 'extra-patient-survey-question-2',
    suppressPatientSurvey = 'skip-patient-survey',
    excludePhoneInAssistanceMessage = 'exclude-phone-in-assistance-message',
    requireConsentTerms = 'require-consent-terms',
    endAndTransferVisit = 'end-and-transfer-visit',
    enableManuallyEnteringWaitoffline = 'enable-manually-entering-waitoffline',
    enableGuestFlowForPatientAuth = 'enable-guest-flow-patient-auth',
    enableDynamicConnectionForPatientAuth = 'enable-dynamic-connection-patient-auth',
    enableAdobeAlloyDebugEnabled = 'enable-adobe-alloy-debug-enabled',
    enablePostVisitSurveyConfig = 'release-enable-post-visit-survey-config',
    enableVisitModalityConversion = 'enable-visit-modality-conversion',
    enableVisitModalityConversionForTravelPatientCallCenter = 'enable-visit-modality-conversion-for-travel-patient-call-center',
    releaseCameraSwitcher = 'release-camera-switcher',
    enablePatientCancelFlowWithReason = 'enable-patient-cancellation-with-reason',
    releaseConfigurableVisitReasons = 'release-configurable-visit-reasons',
    enableAiAssistant = 'enable-ai-assistant',
    releaseSharedVideoComponents = 'release-shared-video-components',
    releaseMultiPartyConference = 'release-multi-party-conference',
    multiPartyForMobile = 'multi-party-for-mobile',
    enableThingsYouCanTry = 'enable-things-you-can-try',
}

export const defaultValues: {
    [key: string]:
        | boolean
        | BlisseyBrowserFeatureFlag[]
        | BlisseyBrowserFeatureFlagObject;
} = {
    // TODO: remove cancellation flag
    [FeatureFlags.cancellation]: false,
    [FeatureFlags.waitingRoomVideo]: false,
    [FeatureFlags.showBlurOption]: [],
    [FeatureFlags.enableLocalization]: false,
    [FeatureFlags.localizeWaitTimeEstimateMessage]: false,
    [FeatureFlags.extraPatientSurvey1]: false,
    [FeatureFlags.extraPatientSurvey2]: false,
    [FeatureFlags.suppressPatientSurvey]: false,
    [FeatureFlags.excludePhoneInAssistanceMessage]: false,
    [FeatureFlags.requireConsentTerms]: false,
    [FeatureFlags.endAndTransferVisit]: false,
    [FeatureFlags.enableManuallyEnteringWaitoffline]: false,
    [FeatureFlags.enableVisitModalityConversion]: false,
    [FeatureFlags.enableVisitModalityConversionForTravelPatientCallCenter]:
        false,
    [FeatureFlags.releaseCameraSwitcher]: false,
    [FeatureFlags.enablePatientCancelFlowWithReason]: {
        video: false,
        phone: false,
    },
    [FeatureFlags.releaseConfigurableVisitReasons]: false,
    [FeatureFlags.enableAiAssistant]: false,
    [FeatureFlags.releaseSharedVideoComponents]: false,
    [FeatureFlags.releaseMultiPartyConference]: false,
    [FeatureFlags.multiPartyForMobile]: false,
    [FeatureFlags.enableThingsYouCanTry]: false,
};

export function getFeatureFlag(
    featureFlag: FeatureFlags,
): boolean | { [key: string]: boolean } {
    const appConfig = (config as Configuration).getConfig();
    if (appConfig.features && featureFlag in appConfig.features) {
        return (appConfig.features as { [key: string]: boolean })[featureFlag];
    }
    return (defaultValues as { [key: string]: boolean })[featureFlag];
}

export function getArrayFeatureFlag(
    featureFlag: FeatureFlags,
): BlisseyBrowserFeatureFlag[] {
    const appConfig = (config as Configuration).getConfig();
    if (appConfig.features && featureFlag in appConfig.features) {
        return (
            appConfig.features as {
                [key: string]: BlisseyBrowserFeatureFlag[];
            }
        )[featureFlag];
    }
    return (defaultValues as { [key: string]: BlisseyBrowserFeatureFlag[] })[
        featureFlag
    ];
}

export interface FeatureFlagsValues {
    [key: string]:
        | boolean
        | BlisseyBrowserFeatureFlag[]
        | BlisseyBrowserFeatureFlagObject;
}

export function getFeatureFlags(): FeatureFlagsValues {
    const appConfig = (config as Configuration).getConfig();
    return {
        ...defaultValues,
        ...appConfig.features,
    };
}
