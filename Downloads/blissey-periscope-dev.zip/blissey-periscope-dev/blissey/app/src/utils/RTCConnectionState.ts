export enum RTCConnectionState {
    Connecting = 0,
    Connected = 1,
    Reconnecting = 2,
    Closed = 3,
}
