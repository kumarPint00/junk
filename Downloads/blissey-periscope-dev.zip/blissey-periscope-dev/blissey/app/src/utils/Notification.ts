import { Logger } from './index';
import { config } from '@dexcare/circus-jupiter';
import { Configuration } from 'types/configuration';

declare const document: {
    hidden: boolean;
    msHidden: boolean;
    webkitHidden: boolean;
};

const alertSound = new Audio('/assets/sounds/alert.mp3');
const chatSound = new Audio('/assets/sounds/chat.mp3');
const notificationLockTime = 5000;
let lockNotification = false;

export enum NotificationType {
    alert,
    chat,
}

function playSound(type: NotificationType) {
    switch (type) {
        case NotificationType.alert:
            void alertSound.play();
            break;
        case NotificationType.chat:
            void chatSound.play();
            break;
        default:
        // Do not play sound in the default case
    }
}

function hasNotification() {
    return typeof Notification !== 'undefined';
}

export function initNotifications() {
    if (hasNotification() && Notification?.permission !== 'granted') {
        void Notification.requestPermission((permission: string) => {
            Logger.info(
                {
                    eventType: 'Notification',
                    eventName: 'Notification permission set',
                    eventSource: 'utils/Notification > initNotifications',
                },
                `Receive notifications permission set to ${permission}`,
            );
        });
    }
}

export function notifyUser(text: string, type: NotificationType) {
    try {
        if (!hasNotification() || Notification.permission !== 'granted' || lockNotification) {
            return;
        }
        lockNotification = true;
        setTimeout(() => {
            lockNotification = false;
        }, notificationLockTime);

        const options = {
            body: text,
            silent: true,
        };
        const {
            notificationText: { notificationTitle },
        } = (config as Configuration).getConfig();
        const notification = new Notification(notificationTitle, options);
        notification.onclick = (evt: Event) => {
            evt.preventDefault();
            window.focus();
            notification.close();
        };

        Logger.info(
            {
                eventType: 'Notification',
                eventSource: 'utils/Notification',
                details: text,
            },
            `Notification sent to user`,
        );

        // Some browsers like FF will play a default sound with notification even though we said silent
        // Only play sound if the browser has not played a sound for the notification
        if (notification.silent === true) {
            playSound(type);
        }
        return notification;
    } catch (err: unknown) {
        Logger.warn(
            {
                eventType: 'Notification',
                eventName: 'notifyUser',
                eventSource: 'utils/Notification > initNotifications',
                details: { err },
            },
            'error triggering notification',
        );
        return undefined;
    }
}

export function isDocumentVisible() {
    if (document.hidden || document.msHidden || document.webkitHidden) {
        return false;
    }

    return true;
}
