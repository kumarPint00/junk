import { UserDetails } from '@dexcare/circus-saturn';

// where does this go?
export type GuestUserDetails = UserDetails & {
    requiresOTPAuth: boolean | undefined;
    sms: string | undefined;
};

/**
 * Returns the phone number to call for assistance based on the role of the logged in user.
 * Providers call the DAC and patients call the PEC
 * @param isProvider whether or not the current user is a provider
 */
export function getAssistancePhone(isProvider: boolean) {
    return isProvider ? '877-353-2436' : '855-360-5472';
}

/**
 * Detect whether the user needs to go through the OTP auth flow
 * @param userDetails
 */
export function requiresOTPAuth(userDetails: GuestUserDetails) {
    // How should we do this? a special role?, certain combination of properties?
    // This might belong in a more central location once this is decided
    return Boolean(userDetails.requiresOTPAuth);
}
