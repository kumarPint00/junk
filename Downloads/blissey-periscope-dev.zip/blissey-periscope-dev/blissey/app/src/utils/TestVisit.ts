export function checkTestVisit(pathname: string): boolean {
    return !!pathname.match(/\/testvisit-/);
}
