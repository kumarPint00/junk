import { UAParser } from 'ua-parser-js';
import { BlisseyBrowserFeatureFlag } from './FeatureFlags';

export function getBrowser() {
    const parser = new UAParser();
    const ua = parser.getResult();
    return (ua.browser.name || 'unknown').toLowerCase();
}

export function getBrowserVersion() {
    const parser = new UAParser();
    const browserVersion = parser.getBrowser().version;
    return browserVersion;
}

export function isSupportedBrowser(
    supportedBrowsers: BlisseyBrowserFeatureFlag[],
) {
    let supportedBrowser = false;
    let providerAvailable = false;
    let patientAvailable = false;

    const browser = getBrowser();
    const browserVersion = getBrowserVersion() || '0';

    const userBrowserInfo = supportedBrowsers.filter(
        (browserInfo) => browserInfo.name === browser,
    );

    if (userBrowserInfo[0]?.minVersion <= browserVersion) {
        supportedBrowser = true;
        providerAvailable = userBrowserInfo[0]?.provider;
        patientAvailable = userBrowserInfo[0]?.patient;
    }

    return { supportedBrowser, providerAvailable, patientAvailable };
}
