import React, { useEffect, useRef, useState } from 'react';
import { useAtomValue } from 'jotai';
import { Chat } from '@mui/icons-material';
import { InCallMenuButton } from '@dexcare/video-conference';
import { injectedMenuTextAtom } from '@context/Invisit/state/atoms/text';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { visitDetailsAtom } from '@context/Invisit/state/atoms/visitDetails';

export const useToggleChat = () => {
    const visitId = useAtomValue(visitDetailsAtom)?.visitId;
    const injectedMenuText = useAtomValue(injectedMenuTextAtom);
    const [showChat, setShowChat] = useState<boolean>(false);
    const showRef = useRef<boolean>();

    useEffect(() => {
        showRef.current = showChat;
    });

    const toggleChat = (show?: boolean) => {
        V2Analytics?.interactionEvent({
            eventName: `chat_toggle_${show ? 'on' : 'off'}`,
            visit_id: visitId,
        });
        setShowChat(show !== undefined ? show : !showRef.current);
    };

    const chatMenuButton = (
        <InCallMenuButton
            key="incall-menu-chat"
            title={injectedMenuText?.toggleChatLabel || 'Chat'}
            icon={<Chat />}
            onClick={() => toggleChat()}
        />
    );

    return { showChat, chatMenuButton, toggleChat };
};
