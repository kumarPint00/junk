import React, { useCallback } from 'react';
import {
    ConferenceStage,
    ConferenceStates,
    VideoBox,
} from '@dexcare/conference-stage';
import { useAtomValue, useAtom, useSetAtom } from 'jotai';
import {
    VideoConference,
    TechCheckLogic,
    ExpectedParticipant,
} from '@dexcare/video-conference';
import { ConferenceEvent } from '@dexcare/conference-client';
import { TextChat } from '@dexcare/text-chat';
import { useToggleChat } from './hooks/useToggleChat';
import { ToggleWrapperStage } from '@dexcare/toggle-wrapper';
import { useTechCheck } from './hooks/useTechCheck';
import {
    videoChatClientAtom,
    videoConferenceClientAtom,
} from '@context/Invisit/state/atoms/clients';
import { useToggleFullscreen } from './hooks/useToggleFullscreen';
import { conferenceStateAtom } from '@context/Invisit/state/atoms/conferenceState';
import {
    conferenceStageTextAtom,
    techcheckHeaderTextAtom,
    videoConferenceTextAtom,
    footerTextAndLinkAtom,
    textChatTextAtom,
} from '@context/Invisit/state/atoms/text';
import { useEndVisit } from './hooks/useEndVisit';
import {
    canJoinVisitAtom,
    visitDetailsAtom,
} from '@context/Invisit/state/atoms/visitDetails';
import { modalMessageAtom } from '@context/Invisit/state/atoms/modalMessage';
import { useVisitParticipants } from '@context/Invisit/state/hooks/useVisitParticipants';
import { featureFlagsAtom } from '@context/Invisit/state/atoms/featureFlags';
import { userDetailsAtom } from '@context/Invisit/state/atoms/userDetails';
import { FeatureFlags } from '@utils/FeatureFlags';
import * as Notification from '@utils/Notification';
import { cacheMessageAction } from '@context/Invisit/state/actions/cacheMessage';
import { Logger } from '@utils/index';

export const ProviderInVisit = () => {
    /**
     * Atoms
     */
    // flags
    const featureFlags = useAtomValue(featureFlagsAtom);
    // clients
    const videoConferenceClient = useAtomValue(videoConferenceClientAtom);
    const textChatClient = useAtomValue(videoChatClientAtom);
    // text
    const videoConferenceText = useAtomValue(videoConferenceTextAtom);
    const techCheckHeaderText = useAtomValue(techcheckHeaderTextAtom);
    const conferenceStageText = useAtomValue(conferenceStageTextAtom);
    const footerTextAndLinks = useAtomValue(footerTextAndLinkAtom);
    const textChatText = useAtomValue(textChatTextAtom);
    // visit details / messaging
    const visitDetails = useAtomValue(visitDetailsAtom);
    const userDetails = useAtomValue(userDetailsAtom);
    const canJoinVisit = useAtomValue(canJoinVisitAtom);
    const modalMessage = useAtomValue(modalMessageAtom);
    // get / set conference state
    const [conferenceState, setConferenceState] = useAtom(conferenceStateAtom);
    // write message on cache
    const cacheMessage = useSetAtom(cacheMessageAction);

    const releaseMultiPartyConference =
        !!featureFlags?.[FeatureFlags.releaseMultiPartyConference];
    const multiPartyForMobile =
        !!featureFlags?.[FeatureFlags.multiPartyForMobile];

    /**
     * Shared state hooks / injected compoonents
     */
    const { showChat, chatMenuButton, toggleChat } = useToggleChat();
    const { fullscreenMenuButton, toggleFullscreen } = useToggleFullscreen();
    const { techCheck, setTechCheck } = useTechCheck();
    const { leaveMenuButton } = useEndVisit();
    const { participantsMenuButton, visitParticipants } =
        useVisitParticipants();

    /**
     * Callbacks
     * Wrap these in useCallback to prevent unnecessary re-renders
     * in our shared media components
     */
    const onJoinedCall = useCallback(() => {
        // when the provider joins the call set the visit state to "invisit"
        setConferenceState(ConferenceStates.Invisit);
    }, [setConferenceState]);

    const onLeftCall = useCallback(() => {
        // exit fullscreen mode (should we be in it)
        void toggleFullscreen(false);
        // go back to anteroom state
        setConferenceState(ConferenceStates.WaitingRoom);
    }, [toggleFullscreen, setConferenceState]);

    const onTechCheck = useCallback(
        (v: TechCheckLogic) => {
            setTechCheck(v);
        },
        [setTechCheck],
    );

    const handleNewMessage = useCallback(() => {
        toggleChat(true);
        if (!Notification.isDocumentVisible()) {
            Notification.notifyUser(
                'You have a new Chat message',
                Notification.NotificationType.chat,
            );
        }
    }, [toggleChat]);

    const handleOnSentMessage = useCallback(
        (event: ConferenceEvent) => {
            cacheMessage({
                client: textChatClient,
                event,
            });
        },
        [textChatClient, cacheMessage],
    );

    const handleTechCheckRefresh = useCallback(() => {
        window.location.reload();
    }, []);

    const onFatalError = useCallback(
        (event: ConferenceEvent) => {
            // exit fullscreen mode (should we be in it)
            void toggleFullscreen(false);
            // go back to anteroom state while we evaluate the situation
            setConferenceState(ConferenceStates.WaitingRoom);
            Logger.error(
                {
                    event,
                    visitId: visitDetails?.visitId,
                    userId: userDetails?.id,
                },
                event.message,
            );
        },
        [
            setConferenceState,
            toggleFullscreen,
            visitDetails?.visitId,
            userDetails?.id,
        ],
    );

    const onError = useCallback(
        (event: ConferenceEvent) => {
            Logger.warn(
                {
                    event,
                    visitId: visitDetails?.visitId,
                    userId: userDetails?.id,
                },
                event.message,
            );
        },
        [visitDetails?.visitId, userDetails?.id],
    );

    React.useEffect(() => {
        try {
            Notification.initNotifications();
        } catch (e) {
            console.error('Error initializing notifications', e);
        }
    }, []);

    // determine injected menu items based on feature flag
    let injectedMenu = [fullscreenMenuButton, chatMenuButton];
    if (releaseMultiPartyConference) {
        injectedMenu = [fullscreenMenuButton, chatMenuButton];

        // some (hopefully very temporary) disabling for mobile sdk visits)
        const device = visitDetails?.deviceModel?.toLowerCase() ?? '';
        const disallowedDevices = ['ios', 'android'];
        const isDisallowed = disallowedDevices.some(
            (disallowed) => device === disallowed,
        );
        if (!isDisallowed || multiPartyForMobile) {
            injectedMenu.push(participantsMenuButton);
        }
    }

    return (
        <ToggleWrapperStage
            data-testid="provider-invisit-container"
            toggleShow={
                showChat && conferenceState === ConferenceStates.Invisit
            }
            toggleWidth="300px"
            toggleHeight="50%"
            toggleChildren={
                <TextChat
                    data-testid="text-chat"
                    client={textChatClient}
                    text={textChatText}
                    onMessageReceived={handleNewMessage}
                    onSentMessage={handleOnSentMessage}
                    toggleChatIsVisible={() => toggleChat(false)}
                />
            }
            sx={{
                position: 'absolute',
            }}
        >
            <ConferenceStage
                text={conferenceStageText}
                conferenceState={conferenceState}
                techCheck={techCheck}
                techCheckHeaderText={techCheckHeaderText}
                footerTextAndLinks={footerTextAndLinks}
                onRefresh={handleTechCheckRefresh}
            >
                <VideoBox conferenceState={conferenceState}>
                    <VideoConference
                        client={videoConferenceClient}
                        text={videoConferenceText}
                        onJoinedCall={onJoinedCall}
                        onLeftCall={onLeftCall}
                        onTechCheck={onTechCheck}
                        onFatalError={onFatalError}
                        onError={onError}
                        joinOptions={{
                            autoJoin: false,
                            disableJoin: !canJoinVisit,
                            disabledMessage: modalMessage?.message,
                            joinConditions: {
                                techCheckPassed: true,
                                userRoleConnected: 'patient',
                            },
                        }}
                        injectedInCallMenu={injectedMenu}
                        injectedLeaveButton={leaveMenuButton}
                        expectedParticipants={visitParticipants.map(
                            (vp) =>
                                ({
                                    id: vp.id,
                                    displayName: vp.email ?? vp.sms,
                                    role: vp.participantType.name,
                                } as ExpectedParticipant),
                        )}
                        moderationEnabled={releaseMultiPartyConference}
                        displayTimeElapsed
                        blurEnabled
                    />
                </VideoBox>
            </ConferenceStage>
        </ToggleWrapperStage>
    );
};
