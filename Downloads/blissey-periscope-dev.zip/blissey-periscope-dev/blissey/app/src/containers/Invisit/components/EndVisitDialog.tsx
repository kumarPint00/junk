import React, { useState } from 'react';
import { useAtomValue, useSetAtom, useAtom } from 'jotai';
import { featureFlagsAtom } from '@context/Invisit/state/atoms/featureFlags';
import { FeatureFlags } from '@utils/FeatureFlags';
import { isTravelingFromCallCenterAtom } from '@context/Invisit/state/atoms/visitDetails';
import { endVisitAction } from '@context/Invisit/state/actions/endVisit';
import { endVisitTextAtom } from '@context/Invisit/state/atoms/text';
import { transferOptionsQueryAtom } from '@context/Invisit/state/queries/transferOptions';
import { waiveReasonsAtom } from '@context/Invisit/state/queries/waiveReasons';
import { appConfigAtom } from '@context/Invisit/state/atoms/appConfig';
import { ConfirmationDialog } from '@components/ConfirmationDialog/ConfirmationDialog';
import {
    PostVisitActionChange,
    PostVisitActionSelector,
} from '@dexcare/circus-saturn';
import { ProviderRadioListItem } from '@dexcare/provider-card';
import ErrorIcon from '@mui/icons-material/Error';

import * as styles from '../../../modules/PostVisitActionDialog/styles.css';
import {
    userActionErrorAtom,
    userActionLoadingAtom,
} from '@context/Invisit/state/atoms/userAction';

export const EndVisitDialog = ({
    open = false,
    onClose,
}: {
    open: boolean;
    onClose: () => void;
}) => {
    /**
     * Atoms
     */
    const featureFlags = useAtomValue(featureFlagsAtom);
    const text = useAtomValue(endVisitTextAtom);
    const isTravelingFromCallCenter = useAtomValue(
        isTravelingFromCallCenterAtom,
    );
    const { data: transferOptions } = useAtomValue(transferOptionsQueryAtom);
    const { modalityConversionReasons = [] } =
        useAtomValue(appConfigAtom) || {};
    const waiveReasons = useAtomValue(waiveReasonsAtom);
    const loading = useAtomValue(userActionLoadingAtom);
    const [errorMessage, setErrorMessage] = useAtom(userActionErrorAtom);

    /**
     * Actions
     */
    const endVisit = useSetAtom(endVisitAction);

    /**
     * Local state
     */
    const [action, setAction] = useState<PostVisitActionChange>();

    /**
     * Handlers
     */
    const handleClose = () => {
        // clear error messaging before closing
    setErrorMessage(undefined as any);
        onClose();
    };

    /**
     * Props munging
     */
    const endAndTransferVisit =
        !!featureFlags?.[FeatureFlags.endAndTransferVisit];
    const enableVisitModalityConversion =
        !!featureFlags?.[FeatureFlags.enableVisitModalityConversion];
    const enableVisitModalityConversionForTravelPatientCallCenter =
        !!featureFlags?.[
            FeatureFlags.enableVisitModalityConversionForTravelPatientCallCenter
        ];
    const showConvertModalityOption =
        enableVisitModalityConversion &&
        (enableVisitModalityConversionForTravelPatientCallCenter ||
            !isTravelingFromCallCenter);

    return (
        <ConfirmationDialog
            open={open}
            onConfirm={() => void endVisit(action as PostVisitActionChange)}
            onCancel={handleClose}
            onClose={handleClose}
            loading={loading}
            data-testid="end-visit-dialog"
        >
            <>
                <PostVisitActionSelector
                    labels={text}
                    showTransferOption={endAndTransferVisit}
                    showConvertModalityOption={showConvertModalityOption}
                    modalityConversionReasons={modalityConversionReasons}
                    waiveReasons={waiveReasons}
                    providers={
                        (transferOptions?.providers as unknown as ProviderRadioListItem[]) ||
                        []
                    }
                    transferOptions={{
                        providerColumns: 2,
                        providerRows: 2,
                    }}
                    onChange={(v: PostVisitActionChange) => setAction(v)}
                />
                {errorMessage && (
                    <div className={styles.errorContainer}>
                        <ErrorIcon style={{ marginRight: '0.2em' }} />{' '}
                        {errorMessage}
                    </div>
                )}
            </>
        </ConfirmationDialog>
    );
};
