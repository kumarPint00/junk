import React, { useState } from "react";
import { useTheme } from "@mui/material";
import { CallEnd } from "@mui/icons-material";
import { useAtomValue } from "jotai";
import { endVisitTextAtom } from "@context/Invisit/state/atoms/text";
import { InCallMenuButton } from "@dexcare/video-conference";
import { EndVisitDialog } from "../components/EndVisitDialog";

export const useEndVisit = () => {
    // theme
    const theme = useTheme();
    /**
     * Atoms
     */
    const text = useAtomValue(endVisitTextAtom);

    /**
     * Local state
     */
    const [showDialog, setShowDialog] = useState(false);

    /**
     * Props munging
     */
    const {
        endVisitLabel = 'End Visit',
    } = text;

    const leaveMenuButton = (
        <>
            <InCallMenuButton
                data-testid="end-visit-button"
                key="end-visit-button"
                sx={{
                    backgroundColor: theme.palette.error.main
                }}
                icon={<CallEnd />}
                title={endVisitLabel}
                onClick={() => setShowDialog(true)}
            />
            {/* 
                Context aware always "open" dialog so that we can trigger re-request of fresh "transfer options"
                when the dialog is mounted / rerendered (e.g. when the user clicks "End Visit" button)
            */}
            {showDialog && (
                <EndVisitDialog
                    open={true}
                    onClose={() => setShowDialog(false)}
                />
            )}
        </>
    )

    return { leaveMenuButton };
}