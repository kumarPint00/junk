import React, { useState } from "react";
import { 
    Button, 
    Dialog, 
    DialogContent,
    DialogActions,
    useTheme,
} from "@mui/material";
import { CallEnd } from "@mui/icons-material";
import { useAtomValue, useSetAtom } from "jotai";
import { InCallMenuButton } from "@dexcare/video-conference";
import { leaveVisitTextAtom } from "@context/Invisit/state/atoms/text";
import { leaveVisitAction } from "@context/Invisit/state/actions/leaveVisit";
import { useNavigateAndClose } from "@context/Invisit/state/hooks/useNavigateAndClose";

export const useLeaveVisit = () => {
    // theme
    const theme = useTheme();
    /**
     * Atoms
     */
    const [showDialog, setShowDialog] = useState(false);
    const text = useAtomValue(leaveVisitTextAtom);
    const leaveCall = useSetAtom(leaveVisitAction);
    const navigateAndClose = useNavigateAndClose();

    const {
        callEndLabel = 'Leave Visit',
        callEndPrompt = 'End the call?',
        callEndConfirm = 'Confirm',
        callEndCancel = 'Cancel',
    } = text || {};

    const leaveMenuButton = (
        <>
            <InCallMenuButton
                data-testid="leave-visit-button"
                key="leave-visit-button"
                sx={{
                    backgroundColor: theme.palette.error.main
                }}
                icon={<CallEnd />}
                title={callEndLabel}
                onClick={() => setShowDialog(true)}
            />
            <Dialog
                data-testid="leave-visit-dialog"
                open={showDialog} 
                onClose={() => setShowDialog(false)}
            >
                <DialogContent
                    id="end-call-dialog-title"
                    tabIndex={0}
                >
                    {callEndPrompt}
                </DialogContent>
                <DialogActions>
                    <Button
                        id={'endCallConfirm'}
                        data-testid="leave-visit-confirm"
                        onClick={() => leaveCall(navigateAndClose)}
                        variant="contained"
                    >
                        {callEndConfirm.toLocaleUpperCase()}
                    </Button>
                    <Button
                        id={'endCallCancel'}
                        data-testid="leave-visit-cancel"
                        onClick={() => setShowDialog(false)}
                    >
                        {callEndCancel.toLocaleUpperCase()}
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );

    return { leaveMenuButton };
}
