import React, { useCallback, useEffect, useRef, useState } from "react";
import { useAtomValue } from "jotai";
import { Fullscreen, FullscreenExit } from "@mui/icons-material";
import { InCallMenuButton } from "@dexcare/video-conference";
import { injectedMenuTextAtom } from "@context/Invisit/state/atoms/text";

/**
 * Reusable hook for toggling between fullscreen modes
 */
export const useToggleFullscreen = () => {
    const injectedMenuText = useAtomValue(injectedMenuTextAtom);
    const [disableToggle, setDisableToggle] = useState<boolean>(false);
    const [fullscreen, setFullscreen] = useState<boolean>(false);

    const showRef = useRef<boolean>();
    useEffect(() => {
        showRef.current = fullscreen;
    });

    /**
     * Handle fullscreen change to set state / reenable toggle
     */
    const handleFullscreenChange = useCallback(() => {
        setFullscreen(!!document?.fullscreenElement);
        setDisableToggle(false);
    }, [setFullscreen, setDisableToggle]);

    /**
     * Add event listener for fullscreen change
     */
    useEffect(() => {
        document?.addEventListener('fullscreenchange', handleFullscreenChange);
        return () => {
            document?.removeEventListener(
                'fullscreenchange',
                handleFullscreenChange,
            );
        }
    }, [handleFullscreenChange])

    /**
     * Toggle fullscreen
     */
    const toggleFullscreen = useCallback(async (show?: boolean) => {
        // disable while we transition
        setDisableToggle(true);
        // toggle to show / exit fullscreen (using default modern API)
        // if we need to support legacy browsers here we should find a polyfill
        const shouldShow = show !== undefined ? show : !showRef.current;
        if (shouldShow && !document?.fullscreenElement) {
            await document?.documentElement?.requestFullscreen();
        } else if (!shouldShow && document?.fullscreenElement) {
            await document?.exitFullscreen();
        }
        setDisableToggle(false);
    }, [setDisableToggle]);

    /**
     * Video conference menu button
     */
    const fullscreenMenuButton = (
        <InCallMenuButton
            data-testid="incall-menu-fullscreen"
            key="incall-menu-fullscreen"
            title={injectedMenuText?.toggleFullscreenLabel || 'Toggle Fullscreen On/Off'}
            icon={fullscreen ? <FullscreenExit /> : <Fullscreen />}
            disabled={disableToggle}
            onClick={() => void toggleFullscreen()}
        />
    );

    return { fullscreen, fullscreenMenuButton, toggleFullscreen };
}