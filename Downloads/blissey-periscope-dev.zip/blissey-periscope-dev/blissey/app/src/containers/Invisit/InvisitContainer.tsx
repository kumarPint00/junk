import * as React from 'react';
import { ThemeProvider } from '@mui/material';
import { userIsProviderAtom } from '../../context/Invisit/state/atoms/userDetails';
import { haveToAcceptTermsAtom } from '@context/Invisit/state/atoms/visitDetails';
import { useAtomValue } from 'jotai';
import { ProviderInVisit } from './ProviderInVisit';
import { PatientInVisit } from './PatientInVisit';
import { ModalMessage } from './components/ModalMessage';
import { ConsentContainer } from './ConsentContainer';
import { useCustomTheme } from './hooks/useCustomTheme';

export const InvisitContainer = () => {
    // theme
    const theme = useCustomTheme();
    // atoms
    const userIsProvider = useAtomValue(userIsProviderAtom);
    const haveToAcceptTerms = useAtomValue(haveToAcceptTermsAtom);
    // render logic
    const renderVisitComponent = () => {
        if (userIsProvider) return <ProviderInVisit />;
        if (haveToAcceptTerms) return <ConsentContainer />;
        return <PatientInVisit />;
    };

    return (
        <ThemeProvider theme={theme}>
            {renderVisitComponent()}
            <ModalMessage />
        </ThemeProvider>
    );
};
