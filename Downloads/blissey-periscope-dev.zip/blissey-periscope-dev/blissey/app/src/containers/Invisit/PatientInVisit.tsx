import React, { useState, useCallback, useEffect } from 'react';
import { Button } from '@mui/material';
import {
    ConferenceStage,
    Troubleshooting,
    ConferenceStates,
    VideoBox,
} from '@dexcare/conference-stage';
import { useAtomValue, useAtom, useSetAtom } from 'jotai';
import { VideoConference, TechCheckLogic } from '@dexcare/video-conference';
import {
    hasBeenInvisitAtom,
    visitDetailsAtom,
} from '@context/Invisit/state/atoms/visitDetails';
import { VisitResponseV9 } from '@clients/VisitService/VisitInterfaces';
import { TextChat } from '@dexcare/text-chat';
import { useToggleChat } from './hooks/useToggleChat';
import { ToggleWrapperStage } from '@dexcare/toggle-wrapper';
import { useTechCheck } from './hooks/useTechCheck';
import {
    waitingRoomChatClientAtom,
    videoChatClientAtom,
    videoConferenceClientAtom,
} from '@context/Invisit/state/atoms/clients';
import { useToggleFullscreen } from './hooks/useToggleFullscreen';
import { sendGenericTechCheckEvent } from '@services/sendWaitingRoomEvent';
import { InstructionalVideo } from './components/InstructionVideo';
import {
    conferenceStageTextAtom,
    techcheckHeaderTextAtom,
    videoConferenceTextAtom,
    footerTextAndLinkAtom,
    troubleshootingTextAndLinkAtom,
    injectedMenuTextAtom,
    textChatTextAtom,
} from '@context/Invisit/state/atoms/text';
import { languageAtom } from '@context/Invisit/state/atoms/language';
import { appConfigAtom } from '@context/Invisit/state/atoms/appConfig';
import { conferenceStateAtom } from '@context/Invisit/state/atoms/conferenceState';
import { WaitOffline } from './components/WaitOffline';
import { featureFlagsAtom } from '@context/Invisit/state/atoms/featureFlags';
import { FeatureFlags } from '@utils/FeatureFlags';
import { useLeaveVisit } from './hooks/useLeaveVisit';
import { Cancel } from './components/Cancel';
import { VirtualNudge } from './components/VirtualNudge';
import * as Notification from '@utils/Notification';
import { cacheMessageAction } from '@context/Invisit/state/actions/cacheMessage';
import * as styles from './InvisitContainer.css';
import { ChatClient, ConferenceEvent } from '@dexcare/conference-client';

export const PatientInVisit = () => {
    /**
     * Atoms
     */
    const waitingRoomVideo =
        useAtomValue(featureFlagsAtom)?.[FeatureFlags.waitingRoomVideo];
    const hasBeenInvisit = useAtomValue(hasBeenInvisitAtom);
    // clients
    const videoConferenceClient = useAtomValue(videoConferenceClientAtom);
    const videoChatClient = useAtomValue(videoChatClientAtom);
    const waitingRoomChatClient = useAtomValue(waitingRoomChatClientAtom);
    // visit details
    const visitDetails = useAtomValue(visitDetailsAtom) as VisitResponseV9;
    // text
    // check useSetText for more info
    const videoConferenceText = useAtomValue(videoConferenceTextAtom);
    const techCheckHeaderText = useAtomValue(techcheckHeaderTextAtom);
    const conferenceStageText = useAtomValue(conferenceStageTextAtom);
    const footerTextAndLinks = useAtomValue(footerTextAndLinkAtom);
    const troubleshootingTextAndLink = useAtomValue(
        troubleshootingTextAndLinkAtom,
    );
    const injectedMenuText = useAtomValue(injectedMenuTextAtom);
    const textChatText = useAtomValue(textChatTextAtom);
    // language
    const language = useAtomValue(languageAtom);
    // configs for front end
    const appConfig = useAtomValue(appConfigAtom);
    // get / set conference state
    const [conferenceState, setConferenceState] = useAtom(conferenceStateAtom);
    // write message on cache
    const cacheMessage = useSetAtom(cacheMessageAction);

    /**
     * Local state
     */
    // We swap clients to go from the waiting room to the video chats
    const [textChatClient, setTextChatClient] = useState<ChatClient>(
        waitingRoomChatClient,
    );
    // bethany video
    const [showInstructionVideo, setShowInstructionVideo] =
        useState<boolean>(false);
    // pause bethany if new chat message also open the chat window if it's not
    const [forcedPause, setForcedPause] = useState(false);

    /**
     * Shared state hooks / injected compoonents
     */
    const { showChat, chatMenuButton, toggleChat } = useToggleChat();
    const { fullscreenMenuButton, toggleFullscreen } = useToggleFullscreen();
    const { techCheck, hasPassed, setTechCheck } = useTechCheck();
    const { leaveMenuButton } = useLeaveVisit();

    /**
     * Effects
     */
    // only show instructional video when tech check "hasPassed" has flipped
    // to true (see useTechCheck) and we have not been transferred back to the waiting room
    useEffect(() => {
        let timer: NodeJS.Timeout;
        if (hasPassed && !hasBeenInvisit && waitingRoomVideo) {
            timer = setTimeout(() => {
                setShowInstructionVideo(true);
            }, (appConfig?.waitingRoomVideoDelay as number) || 10000);
        }
        try {
            Notification.initNotifications();
        } catch (e) {
            console.error('Error initializing notifications', e);
        }
        return () => clearTimeout(timer);
    }, [appConfig, waitingRoomVideo, hasPassed, hasBeenInvisit]);

    /**
     * Callbacks
     * Wrap these in useCallback to prevent unnecessary re-renders
     * in our shared media components
     */
    const handleNewMessage = useCallback(() => {
        toggleChat(true);
        setForcedPause(true);

        if (!Notification.isDocumentVisible()) {
            Notification.notifyUser(
                'You have a new Chat message',
                Notification.NotificationType.chat,
            );
        }
    }, [toggleChat, setForcedPause]);

    const handleOnSentMessage = useCallback(
        (event: ConferenceEvent) => {
            cacheMessage({
                client: textChatClient,
                event,
            });
        },
        [textChatClient, cacheMessage],
    );

    const onJoinedCall = useCallback(() => {
        // set the chat session / token to the visit session
        // (this should reset the TextChat component to the new session)
        setTextChatClient(videoChatClient);
        // flip show video back to false (so bethany wont come back)
        setShowInstructionVideo(false);
        // go to invisit state
        setConferenceState(ConferenceStates.Invisit);
    }, [videoChatClient, setTextChatClient, setConferenceState]);

    const onLeftCall = useCallback(() => {
        // exit fullscreen mode (should we be in it)
        void toggleFullscreen(false);
        // set
        setTextChatClient(waitingRoomChatClient);
        // back to waiting room state / waiting room session
        setConferenceState(ConferenceStates.WaitingRoom);
    }, [
        waitingRoomChatClient,
        toggleFullscreen,
        setTextChatClient,
        setConferenceState,
    ]);

    const onTechCheck = useCallback(
        (v: TechCheckLogic) => {
            setTechCheck(v);
            sendGenericTechCheckEvent(visitDetails.visitId, v);
        },
        [visitDetails, setTechCheck],
    );

    const handleTechCheckRefresh = useCallback(() => {
        window.location.reload();
    }, []);

    const onFatalError = useCallback(() => {
        // exit fullscreen mode (should we be in it)
        void toggleFullscreen(false);
        // go back to waitingroom state while we evaluate the situation
        setConferenceState(ConferenceStates.WaitingRoom);
    }, [toggleFullscreen, setConferenceState]);

    return (
        <ToggleWrapperStage
            data-testid="patient-invisit-container"
            toggleShow={showChat}
            toggleWidth="300px"
            toggleHeight="50%"
            toggleChildren={
                <TextChat
                    data-testid="text-chat"
                    client={textChatClient}
                    text={textChatText}
                    onMessageReceived={handleNewMessage}
                    onSentMessage={handleOnSentMessage}
                    toggleChatIsVisible={() => toggleChat(false)}
                />
            }
            sx={{
                position: 'absolute',
            }}
        >
            <ConferenceStage
                text={conferenceStageText}
                conferenceState={conferenceState}
                techCheck={techCheck}
                techCheckHeaderText={techCheckHeaderText}
                footerTextAndLinks={footerTextAndLinks}
                onRefresh={handleTechCheckRefresh}
            >
                <VideoBox conferenceState={conferenceState}>
                    <VideoConference
                        data-testid="video-conference"
                        client={videoConferenceClient}
                        text={videoConferenceText}
                        onJoinedCall={onJoinedCall}
                        onLeftCall={onLeftCall}
                        onTechCheck={onTechCheck}
                        onFatalError={onFatalError}
                        joinOptions={{
                            autoJoin: true,
                            manuallyJoinAfterLeaving: false,
                            joinConditions: {
                                techCheckPassed: true,
                                moderatorJoined: true,
                            },
                        }}
                        injectedInCallMenu={[
                            fullscreenMenuButton,
                            chatMenuButton,
                        ]}
                        injectedLeaveButton={leaveMenuButton}
                        blurEnabled
                    />
                </VideoBox>
                {/* While in the waitingroom patients see an intstructional video. Bethany! */}
                {conferenceState === ConferenceStates.WaitingRoom &&
                    showInstructionVideo && (
                        <InstructionalVideo
                            visitId={visitDetails.visitId}
                            forcedPause={forcedPause}
                            onPlay={() => setForcedPause(false)}
                            onError={() => setShowInstructionVideo(false)}
                            language={language}
                            url={appConfig?.instructionalVideoDirectUrl}
                        />
                    )}
                {/* While in the waitingroom patients have the option to toggle the chat component visibility / cancel / waitoffline */}
                {conferenceState === ConferenceStates.WaitingRoom && (
                    <div className={styles.waitingRoomActions}>
                        <div data-testid="troubleshooting-link">
                            <Troubleshooting
                                troubleshootingTextAndLink={
                                    troubleshootingTextAndLink
                                }
                            />
                        </div>
                        <div className={styles.buttonRow}>
                            <div className={styles.label}>
                                {injectedMenuText.chatButtonCaption}
                            </div>
                            <Button
                                data-testid="chat-button"
                                variant="contained"
                                color="primary"
                                className={styles.callToActionButton}
                                onClick={() => toggleChat()}
                            >
                                CHAT WITH STAFF
                            </Button>
                        </div>
                        <WaitOffline />
                        <Cancel />
                        <VirtualNudge />
                    </div>
                )}
            </ConferenceStage>
        </ToggleWrapperStage>
    );
};
