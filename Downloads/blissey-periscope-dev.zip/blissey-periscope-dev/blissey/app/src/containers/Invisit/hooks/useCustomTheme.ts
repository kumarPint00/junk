import { Theme, createTheme } from '@mui/material/styles';
import { dexcareBaseTheme, generateComponentTheme } from '@dexcare/material';
import { useAtomValue } from 'jotai';
import { appConfigAtom } from '@context/Invisit/state/atoms/appConfig';
import { AppConfig } from '../../../../../server/config/configInterfaces';

export const useCustomTheme = (): Theme => {
    const config = useAtomValue(appConfigAtom) as AppConfig;
    const {
        styles: { primaryColor, secondaryColor },
    } = config || { styles: {} };

    const primary = primaryColor 
        ? { main: primaryColor } 
        : { ...dexcareBaseTheme.palette.primary };
    
    const secondary = secondaryColor 
        ? { main: secondaryColor } 
        : { ...dexcareBaseTheme.palette.secondary };

    const baseTheme = createTheme(dexcareBaseTheme, {
        palette: {
            primary,
            secondary
        }
    });

    return generateComponentTheme(baseTheme);
}