import React, { useEffect, useState } from "react";
import { useAtomValue } from "jotai";
import { modalMessageAtom } from "@context/Invisit/state/atoms/modalMessage";
import { Dialog, Typography, Button, Box }from "@mui/material";

export const ModalMessage = () => {
    const modalMessage = useAtomValue(modalMessageAtom);

    const [show, setShow] = useState<boolean>(false);

    useEffect(() => {
        if (modalMessage?.message) {
            setShow(true);
        }
    }, [modalMessage]);

    return (
        <Dialog open={show}>
            <Box
                sx={{
                    padding: '40px',
                    borderRadius: '8px',
                    backgroundColor: 'white',
                    textAlign: 'center',
                    maxWidth: '600px',
                }}
            >
                <Typography 
                    variant="h6" 
                    component="h2"
                    sx={{ marginBottom: '20px' }}
                >{modalMessage?.message}</Typography>
                <Button
                    variant="outlined"
                    color="primary"
                    onClick={() => setShow(false)}
                >{modalMessage?.dismissLabel || 'OK'}</Button>
            </Box>
        </Dialog>
    )
}
    