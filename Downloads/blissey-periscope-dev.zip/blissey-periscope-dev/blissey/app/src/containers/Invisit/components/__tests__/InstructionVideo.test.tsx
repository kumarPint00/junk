import * as React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { vi } from 'vitest';
import { InstructionalVideo } from '../InstructionVideo';
import ReactPlayer from 'react-player';

vi.mock('react-player', () => ({
    __esModule: true,
    default: vi.fn(() => <div data-testid="mock-react-player" />),
}));

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        errorEvent: vi.fn(),
    },
}));

/* beginning of code written by AI */

describe('InstructionalVideo', () => {
    const mockProps = {
        visitId: '12345',
        forcedPause: false,
        onReady: vi.fn(),
        onPlay: vi.fn(),
        onPause: vi.fn(),
        onEnded: vi.fn(),
        onError: vi.fn(),
    };

    afterEach(() => {
        vi.clearAllMocks();
    });

    it('renders the video player', () => {
        render(<InstructionalVideo {...mockProps} />);
        expect(screen.getByTestId('instructional-video')).toBeInTheDocument();
        expect(screen.getByTestId('mock-react-player')).toBeInTheDocument();
    });

    it('pauses video when forcedPause is true', () => {
        const mockedReactPlayer = vi.mocked(ReactPlayer);

        const { rerender } = render(
            <InstructionalVideo {...mockProps} forcedPause={false} />,
        );
        expect(mockedReactPlayer).toHaveBeenLastCalledWith(
            expect.objectContaining({ playing: true }),
            expect.anything(),
        );

        rerender(<InstructionalVideo {...mockProps} forcedPause={true} />);
        expect(mockedReactPlayer).toHaveBeenLastCalledWith(
            expect.objectContaining({ playing: false }),
            expect.anything(),
        );
    });
});

/* end of code written by AI */
