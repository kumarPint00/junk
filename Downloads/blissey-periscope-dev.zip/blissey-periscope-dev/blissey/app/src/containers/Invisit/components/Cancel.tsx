import React, { useState } from 'react';
import { useAtomValue, useSetAtom, useAtom } from 'jotai';
import { cancelTextAtom } from '@context/Invisit/state/atoms/text';
import {
    FeatureFlags,
    BlisseyBrowserFeatureFlagObject,
} from '@utils/FeatureFlags';
import { styles } from '../../../components/WaitingRoom/makeStyles/Dialog';
import { ConfirmationDialog } from '@components/ConfirmationDialog/ConfirmationDialog';
import {
    Grid,
    Dialog,
    Button,
    Select,
    MenuItem,
    InputLabel,
    FormControl,
    DialogTitle,
    DialogActions,
    DialogContent,
    SelectChangeEvent,
    DialogContentText,
} from '@mui/material';
import ErrorIcon from '@mui/icons-material/Error';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import {
    userActionErrorAtom,
    userActionLoadingAtom,
} from '@context/Invisit/state/atoms/userAction';
import { cancelVisitAction } from '@context/Invisit/state/actions/cancelVisit';
import { featureFlagsAtom } from '@context/Invisit/state/atoms/featureFlags';
import { canCancelVisitAtom } from '@context/Invisit/state/atoms/visitDetails';

import * as cssStyles from './WaitingRoomActions.css';
import { useNavigateAndClose } from '@context/Invisit/state/hooks/useNavigateAndClose';

export const Cancel = () => {
    /**
     * Atoms
     */
    const cancelText = useAtomValue(cancelTextAtom);
    const canCancel = useAtomValue(canCancelVisitAtom);
    const featureFlags = useAtomValue(featureFlagsAtom);
    const loading = useAtomValue(userActionLoadingAtom);
    const [errorMessage, setErrorMessage] = useAtom(userActionErrorAtom);

    const navigateAndClose = useNavigateAndClose();

    /**
     * Actions
     */
    const cancelVisit = useSetAtom(cancelVisitAction);

    /**
     * Local state
     */
    const [cancelDialogActive, setCancelDialogActive] =
        useState<boolean>(false);
    const [selectedReason, setSelectedReason] = useState<string>(
        cancelText?.reasonsForCancel?.[0]?.value || '',
    );

    /**
     * Feature flags
     */
    const enablePatientCancelFlowWithReason: BlisseyBrowserFeatureFlagObject =
        featureFlags?.[
            FeatureFlags.enablePatientCancelFlowWithReason
        ] as BlisseyBrowserFeatureFlagObject;
    const enableCancelModalWithReason =
        !!enablePatientCancelFlowWithReason?.video;

    /**
     * Callbacks
     */
    const handleReasonChange = (event: SelectChangeEvent<string>) => {
        setSelectedReason(event.target.value);
    };

    const onClose = () => {
        setErrorMessage(undefined);
        setCancelDialogActive(false);
    };

    const newCancelModal = (
        <Dialog
            open={cancelDialogActive}
            onClose={onClose}
            PaperProps={{ style: { borderRadius: '8px' } }}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth="md"
            fullWidth={true}
            data-testid="cancel-dialog"
        >
            <DialogContent tabIndex={0}>
                <DialogTitle
                    sx={styles.dialogTitle}
                    id="alert-dialog-title"
                    data-testid="cancel-dialog-title"
                >
                    {cancelText.headerText}
                </DialogTitle>
                <DialogContentText
                    sx={styles.dialogTextSmall}
                    id="alert-dialog-description"
                    data-testid="cancel-dialog-content"
                >
                    <span
                        className={cssStyles.innerText}
                        data-testid="cancel-dialog-content"
                    >
                        {cancelText.bodyText}
                    </span>
                    <span
                        className={cssStyles.innerText}
                        data-testid="cancel-dialog-instruction"
                    >
                        {cancelText.instructionText}
                    </span>
                    <span
                        className={cssStyles.innerText}
                        data-testid="cancel-dialog-reason"
                    >
                        {cancelText.reasonText}
                    </span>
                </DialogContentText>
                <FormControl fullWidth variant="outlined" margin="normal">
                    <InputLabel id="cancel-reason-label">
                        {cancelText.label}
                    </InputLabel>
                    <Select
                        labelId="cancel-reason-label"
                        id="cancel-reason"
                        value={selectedReason}
                        onChange={handleReasonChange}
                        label="Reason for cancelling"
                        IconComponent={KeyboardArrowDownIcon}
                    >
                        {Array.isArray(cancelText.reasonsForCancel) &&
                            cancelText.reasonsForCancel.map(
                                (r: { value: string; label: string }) => (
                                    <MenuItem key={r.value} value={r.value}>
                                        {r.label}
                                    </MenuItem>
                                ),
                            )}
                    </Select>
                </FormControl>
                {errorMessage && (
                    <span className={cssStyles.errorContainer}>
                        <ErrorIcon style={{ marginRight: '0.2em' }} />{' '}
                        {errorMessage}
                    </span>
                )}
                <DialogActions disableSpacing={true}>
                    <Grid
                        display="flex"
                        width="100%"
                        flexDirection="row"
                        alignItems="center"
                        justifyContent="center"
                    >
                        <Button
                            color="primary"
                            onClick={onClose}
                            data-testid="waitingroom-dialog-close"
                        >
                            {cancelText.buttonDeclineText}
                        </Button>
                        <Button
                            color="primary"
                            variant="contained"
                            onClick={() =>
                                void cancelVisit(
                                    navigateAndClose,
                                    selectedReason,
                                )
                            }
                            data-testid="waitingroom-dialog-cancel"
                        >
                            {cancelText.buttonAcceptText}
                        </Button>
                    </Grid>
                </DialogActions>
            </DialogContent>
        </Dialog>
    );

    const legacyCancelModal = (
        <ConfirmationDialog
            onCancel={onClose}
            onConfirm={() => void cancelVisit(navigateAndClose)}
            onClose={onClose}
            open={cancelDialogActive}
            loading={loading}
            confirmText={cancelText.buttonLeaveText?.toLocaleUpperCase()}
            cancelText={cancelText.buttonStayText?.toLocaleUpperCase()}
        >
            <div>
                <DialogTitle data-testid="cancel-dialog-title">
                    {cancelText.dialogTitleText}
                </DialogTitle>
                <DialogContentText data-testid="cancel-dialog-content">
                    {cancelText.dialogContentText}
                </DialogContentText>
                {errorMessage && (
                    <DialogContent>
                        <span className={cssStyles.errorContainer}>
                            <ErrorIcon style={{ marginRight: '0.2em' }} />{' '}
                            {errorMessage}
                        </span>
                    </DialogContent>
                )}
            </div>
        </ConfirmationDialog>
    );

    return (
        <>
            {canCancel && (
                <>
                    <div className={cssStyles.actionContainer}>
                        <Button
                            data-testid="cancel-button"
                            variant="outlined"
                            onClick={() => setCancelDialogActive(true)}
                        >
                            {cancelText.cancelVisitButtonText}
                        </Button>
                    </div>
                    {enableCancelModalWithReason
                        ? newCancelModal
                        : legacyCancelModal}
                </>
            )}
        </>
    );
};
