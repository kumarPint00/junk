import { TechCheckLogic } from '@dexcare/video-conference';
import { useState } from 'react';

export const useTechCheck = () => {
    const [techCheck, setTechCheck] = useState<TechCheckLogic>();
    const [hasPassed, setHasPassed] = useState<boolean>(false);

    const setNewTechCheck = (newTechCheck: TechCheckLogic) => {
        if (newTechCheck.passed) {
            setHasPassed(true);
        }
        setTechCheck(newTechCheck);
    };

    return {
        techCheck,
        hasPassed,
        setTechCheck: setNewTechCheck,
    };
};
