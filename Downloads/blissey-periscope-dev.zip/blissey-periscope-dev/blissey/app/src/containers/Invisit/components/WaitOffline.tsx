import React, { useState } from 'react';
import { useAtomValue, useSetAtom } from 'jotai';
import { canWaitOfflineAtom } from '@context/Invisit/state/atoms/visitDetails';
import { waitOfflineTextAtom } from '@context/Invisit/state/atoms/text';
import { ConfirmationDialog } from '@components/ConfirmationDialog/ConfirmationDialog';
import { userActionErrorAtom, userActionLoadingAtom } from '@context/Invisit/state/atoms/userAction';
import { patientEnterWaitOfflineAction } from '@context/Invisit/state/actions/enterWaitOffline';
import ErrorIcon from '@mui/icons-material/Error';
import { Button, DialogTitle, DialogContentText } from '@mui/material';

import * as styles from './WaitingRoomActions.css';

export const WaitOffline = () => {
    /**
     * Atoms
     */
    const loading = useAtomValue(userActionLoadingAtom);
    const errorMessage = useAtomValue(userActionErrorAtom);
    const waitOfflineText = useAtomValue(waitOfflineTextAtom);
    const canWaitOffline = useAtomValue(canWaitOfflineAtom);

    // get default or (custom if that happens to happen) error message
    const errMessage = errorMessage === 'failure'
        ? waitOfflineText.enterWaitOfflineFailureText
        : errorMessage;
    
    /**
     * Actions
     */
    const enterWaitOffline = useSetAtom(patientEnterWaitOfflineAction);

    /**
     * Local state
     */
    const [waitOfflineDialogActive, setWaitOfflineDialogActive] =
        useState<boolean>(false);

    return (
        <>
            {canWaitOffline && (
                <>
                    <div className={styles.actionContainer}>
                        <div
                            className={styles.clickMeText}
                            data-testid="wait-offline-click-me-text"
                        >
                            {waitOfflineText.waitOfflineClickText}
                        </div>
                        <Button
                            data-testid="wait-offline-button"
                            variant="outlined"
                            onClick={() => setWaitOfflineDialogActive(true)}
                        >
                            {waitOfflineText.waitOfflineButtonText}
                        </Button>
                    </div>
                    <ConfirmationDialog
                        onCancel={() => setWaitOfflineDialogActive(false)}
                        onConfirm={() => void enterWaitOffline()}
                        onClose={() => setWaitOfflineDialogActive(false)}
                        open={waitOfflineDialogActive}
                        loading={loading}
                        confirmText={waitOfflineText.buttonAcceptText}
                        cancelText={waitOfflineText.buttonDeclineText}
                    >
                        <div>
                            <DialogTitle>
                                {waitOfflineText.dialogTitleText}
                            </DialogTitle>
                            <DialogContentText>
                                {waitOfflineText.dialogContentText}
                            </DialogContentText>
                            {errMessage && (
                                <div className={styles.errorContainer}>
                                    <ErrorIcon style={{ marginRight: '0.2em' }} />{' '}
                                    {errMessage}
                                </div>
                            )}
                        </div>
                    </ConfirmationDialog>
                </>
            )}
        </>
    );
};
