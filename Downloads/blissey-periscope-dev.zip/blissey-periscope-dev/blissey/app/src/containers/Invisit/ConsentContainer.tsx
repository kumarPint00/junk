import React, { useState } from 'react';
import { useAtomValue, useSetAtom } from 'jotai';
import {
    consentAcceptedErrorMessageAtom,
    acceptTermsAction,
} from '@context/Invisit/state/actions/acceptTerms';
import { consentFormTextAtom } from '@context/Invisit/state/atoms/text';
import { footerTextAndLinkAtom } from '@context/Invisit/state/atoms/text';
import { StageFooter } from '@dexcare/conference-stage';
import Checkbox from '@mui/material/Checkbox';
import { MessageModal } from '@components/MessageModal/MessageModal';
import { PillButton } from '@components/Button';
import { userActionLoadingAtom } from '@context/Invisit/state/atoms/userAction';

import * as styles from './ConsentContainer.css';
import { Cancel } from './components/Cancel';

export const ConsentContainer = () => {
    /**
     * Atoms
     */
    const consentFormText = useAtomValue(consentFormTextAtom);
    const consentAcceptedErrorMessage = useAtomValue(
        consentAcceptedErrorMessageAtom,
    );
    const setConsentAcceptedErrorMessage = useSetAtom(
        consentAcceptedErrorMessageAtom,
    );
    const footerTextAndLinks = useAtomValue(footerTextAndLinkAtom);
    const userActionLoading = useAtomValue(userActionLoadingAtom);

    /**
     * Callbacks
     */
    const handleAcceptTerms = useSetAtom(acceptTermsAction);

    /**
     * Local state
     */
    const [checked, setChecked] = useState(false);
    const onCheckboxChange = (evt: React.ChangeEvent<HTMLInputElement>) => {
        const {
            target: { checked },
        } = evt;
        setChecked(checked);
    };
    const handleModalClose = () => {
        setConsentAcceptedErrorMessage(null);
    };

    return (
        <>
            <div data-testid="consent-container" className={styles.window}>
                <div className={styles.instructions}>
                    <div>
                        <b>{consentFormText.consentHeaderText}</b>
                    </div>
                    <div>{consentFormText.consentInstructionText}</div>
                </div>
                <div className={styles.inputBox}>
                    <div>
                        <Checkbox
                            checked={checked}
                            onChange={onCheckboxChange}
                            inputProps={
                                {
                                    'data-testid': 'consent-checkbox',
                                } as React.InputHTMLAttributes<HTMLInputElement>
                            }
                        />
                        <span
                            dangerouslySetInnerHTML={{
                                __html:
                                    consentFormText.consentCheckboxLabelText ??
                                    '',
                            }}
                        />
                    </div>
                </div>
                <div>
                    <PillButton
                        data-uitest="accept-terms-button"
                        variant="contained"
                        color="grey"
                        onClick={() => void handleAcceptTerms()}
                        disabled={!checked || userActionLoading}
                    >
                        {consentFormText.consentButtonText}
                    </PillButton>
                </div>
                <div className={styles.cancel}>
                    <Cancel />
                </div>
                <MessageModal
                    isOpen={!!consentAcceptedErrorMessage}
                    messageText={consentAcceptedErrorMessage ?? ''}
                    dismissButtonText={
                        consentFormText.dismissErrorModalText ?? ''
                    }
                    onModalClosed={handleModalClose}
                />
            </div>
            <div className={styles.footerContainer}>
                <StageFooter footerTextAndLinks={footerTextAndLinks}></StageFooter>
            </div>
        </>
    );
};
