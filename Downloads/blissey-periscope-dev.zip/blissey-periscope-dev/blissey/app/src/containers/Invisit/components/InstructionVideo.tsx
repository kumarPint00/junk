import * as React from 'react';
import { useState, useEffect } from 'react';
import LegacyReactPlayer from '@components/common/LegacyReactPlayer';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { FlexBox } from '@dexcare/material';
import { Box } from '@mui/material';

const DEFAULT_VIDEO_URL = 'https://vimeo.com/761626618/6bd48bd2e9';

export interface InstructionalVideoProps {
    visitId: string;
    forcedPause: boolean;
    onReady?: () => void;
    onPlay?: () => void;
    onPause?: () => void;
    onEnded?: () => void;
    onError?: () => void;
    url?: string;
    language?: string;
}

export const InstructionalVideo = ({
    visitId,
    forcedPause,
    onReady,
    onPlay,
    onPause,
    onEnded,
    onError,
    url = DEFAULT_VIDEO_URL,
    language = 'en',
}: InstructionalVideoProps) => {
    // react player configs
    const reactPlayerConfig: any = {
        vimeo: {
            playerOptions: {
                texttrack: language,
            },
        },
        youtube: {
            playerVars: {
                cc_lang_pref: language,
            },
        },
    };

    // analytics
    const sendAnalyticsInstructionVideo = (
        eventName: string,
        error?: Error,
    ) => {
        V2Analytics.interactionEvent({
            eventName: `virtual-waitingroom-videoroll-${eventName}`,
            visit_id: visitId,
            error: error ? error : null,
        });
    };

    // local video state
    const [playing, setPlaying] = useState(true);

    // if new chat message, pause the video
    useEffect(() => {
        if (forcedPause) {
            setPlaying(false);
        }
    }, [forcedPause]);

    // add analytics then execute any callbacks
    const handleOnReady = () => {
        sendAnalyticsInstructionVideo('ready');
        setPlaying(true);
        onReady && onReady();
    };
    const handleOnPlay = () => {
        sendAnalyticsInstructionVideo('play');
        setPlaying(true);
        onPlay && onPlay();
    };
    const handleOnPause = () => {
        sendAnalyticsInstructionVideo('pause');
        setPlaying(false);
        onPause && onPause();
    };
    const handleOnEnded = () => {
        sendAnalyticsInstructionVideo('end');
        onEnded && onEnded();
    };
    const handleOnError = (error: any) => {
        sendAnalyticsInstructionVideo('error', error);
        onError && onError();
    };

    return (
        <FlexBox 
            variant="centeredColumn"
            data-testid="instructional-video"
            sx={{ width: '100%' }}
        >
            <Box
                sx={{
                    width: '100%',
                    maxWidth: '640px'
                }}
            >
                <LegacyReactPlayer
                    url={url as any}
                    playing={playing}
                    controls={true}
                    config={reactPlayerConfig}
                    onReady={handleOnReady}
                    onPlay={handleOnPlay}
                    onPause={handleOnPause}
                    onEnded={handleOnEnded}
                    onError={handleOnError as any}
                    width='100%'
                    playsinline
                />
            </Box>
        </FlexBox>
    );
};
