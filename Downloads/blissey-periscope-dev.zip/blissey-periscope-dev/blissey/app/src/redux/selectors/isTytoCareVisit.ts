import { Store } from '../modules/index';

export const isTytoCareVisit = (state: Store['All']) =>
    state.tytoCare.isTytoCareVisit;
