import { isProvider, UserDetails } from '@dexcare/circus-saturn';
import { createSelector } from 'reselect';
import { Store } from '../modules/index';

const selectCurrentUser = (state: Store['All']) => state.user.userDetails;

export const isUserProvider = createSelector(
    selectCurrentUser,
    (userDetails: UserDetails) => userDetails && isProvider(userDetails),
);
