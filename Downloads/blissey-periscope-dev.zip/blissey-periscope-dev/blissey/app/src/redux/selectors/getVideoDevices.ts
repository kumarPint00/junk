import { createSelector } from 'reselect';
import { Store } from '../modules/index';

const selectVideoDevices = (state: Store['All']) =>
    state.usersettings.videoDevices;

export const videoDevices = createSelector(
    selectVideoDevices,
    (videoDevices) => videoDevices,
);
