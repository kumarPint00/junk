import { createSelector } from 'reselect';
import { TState } from '../modules/health';
import { HealthInfo } from '../../common/ConnectionTest/HealthInfo';
import { HealthCheckStatus } from '../../common/ConnectionTest/HealthCheckStatus';
import { TestStatus } from '@common/video';

const healthState = (state: TState) => state;

export const getHealthInfo = createSelector([healthState], (state: TState) => {
    const healthInfo: HealthInfo = {
        healthCheckStatus: HealthCheckStatus.Unknown,
    };

    if (
        (state.networkStatus === TestStatus.Passed ||
            state.networkStatus === TestStatus.NotRun) &&
        state.camStatus === TestStatus.Passed &&
        state.micStatus === TestStatus.Passed
    ) {
        healthInfo.healthCheckStatus = HealthCheckStatus.Healthy;
    } else {
        healthInfo.healthCheckStatus = HealthCheckStatus.Unhealthy;
    }
    return healthInfo;
});
