export enum PaymentStatus {
    none = 0,
    charged = 1,
    waived = 2,
}
