import { ErrorCode } from '@common/techCheckErrorMessages';

export interface PublishResults {
    success: boolean;
    error?: ErrorCode;
}
