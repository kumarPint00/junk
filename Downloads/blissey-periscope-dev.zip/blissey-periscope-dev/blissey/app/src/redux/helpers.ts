import * as Redux from 'redux';
import { Action } from 'redux';
import { Store } from './modules';
import { ThunkDispatch } from 'types/redux';

export interface ActionCreatorCreator<P, R> {
    (params: P): R;
}
// tslint:disable-next-line
export type IAction = Redux.Action;
export interface IActionWithPayload<T> extends IAction {
    readonly payload: T;
}

export interface IActionCreator<T> {
    readonly type: string;
    (payload: T): IActionWithPayload<T>;

    test(action: IAction): action is IActionWithPayload<T>;
}

export interface IActionCreatorVoid extends IActionCreator<void> {
    (): IAction;
}

export interface ActionsObject {
    [key: string]: (...args: unknown[]) => unknown;
}

export type ActionType<T extends ActionsObject> = ReturnType<T[keyof T]>;

export type BlisseyDispatch = ThunkDispatch<Store['All'], unknown, Action>;
export type BlisseyGetState = () => Store['All'];

export const actionCreator = <T>(type: string): IActionCreator<T> =>
    Object.assign((payload: T) => ({ type, payload }), {
        type,
        test(action: IAction): action is IActionWithPayload<T> {
            return action.type === type;
        },
    });

export const actionCreatorVoid = (type: string) =>
    Object.assign(() => ({ type }), {
        type,
        test(action: IAction): action is IActionWithPayload<void> {
            return action.type === type;
        },
    });
