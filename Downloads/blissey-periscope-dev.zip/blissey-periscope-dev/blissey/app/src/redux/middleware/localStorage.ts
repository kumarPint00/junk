import { MiddlewareAPI } from 'redux';
import { Store } from '../modules';
import { Logger as BlisseyLogger } from '../../utils';

const THROTTLE_TIME = 200;
let updateLocalStorageId:
    | string
    | number
    | ReturnType<typeof setInterval>
    | null = null;
const localStorageKeys: string[] = [];
let latestStore: MiddlewareAPI | null = null;

interface IStorage {
    getItem: (key: string) => string | null;
    setItem: (key: string, value: string) => void;
    clear: () => void;
}

let storage: IStorage;

function localStorageIsAvailable() {
    try {
        const key = `__blissey_local_storage_test__`;
        window.localStorage.setItem(key, '');
        window.localStorage.removeItem(key);
        return true;
    } catch (e) {
        return false;
    }
}

export function _createInMemoryStore(): IStorage {
    let memoryStore: Record<string, string> = {};
    return {
        name: 'in-memory',
        getItem: (key: string) => memoryStore[key] ?? null,
        setItem: (key: string, value: string) => {
            memoryStore[key] = value;
        },
        clear: () => {
            memoryStore = {};
        },
    } as IStorage;
}

export function _initStorage(impl?: IStorage): IStorage {
    if (impl) {
        return (storage = impl);
    } else if (localStorageIsAvailable()) {
        return (storage = localStorage);
    } else {
        BlisseyLogger.warn(
            {},
            'Local storage is not available. Using memory store instead.',
        );
        return (storage = _createInMemoryStore());
    }
}

function getValueForPath(tree: unknown, path: string) {
    let item = tree;
    path.split('.').forEach((p: string) => {
        if (item && p in (item as object)) {
            item = (item as Record<string, unknown>)[p];
        } else {
            item = undefined;
        }
    });
    return item;
}

function addValueToPath(tree: unknown, path: string, value: object) {
    let item = tree;
    const subpaths = path.split('.');
    for (let i = 0; i < subpaths.length - 1; i++) {
        const p = subpaths[i];
        if (!(p in (item as object))) {
            (item as Record<string, unknown>)[p] = {};
        }
        item = (item as Record<string, unknown>)[p];
    }
    (item as Record<string, unknown>)[subpaths[subpaths.length - 1]] = value;
}

function updateLocalStorage(store: MiddlewareAPI) {
    latestStore = store;
    if (!updateLocalStorageId) {
        updateLocalStorageId = setTimeout(() => {
            const state = (latestStore as MiddlewareAPI).getState() as object;
            localStorageKeys.forEach((key: string) => {
                const result = getValueForPath(state, key) as object;
                storage.setItem(key, JSON.stringify(result));
            });
            updateLocalStorageId = null;
            latestStore = null;
        }, THROTTLE_TIME);
    }
}

export const getLocalState = (initialState: Store['All']) => {
    const localState = (
        initialState ? JSON.parse(JSON.stringify(initialState)) : {}
    ) as Store['All'];
    localStorageKeys.forEach((key: string) => {
        const value = storage.getItem(key);
        if (value) {
            try {
                const result = JSON.parse(value) as object;
                addValueToPath(localState, key, result);
            } catch (err: unknown) {
                BlisseyLogger.warn(
                    {
                        err,
                        details: { key },
                    },
                    `error retrieving localStorage value`,
                );
            }
        }
    });
    return localState;
};

export const localStorageMiddleware =
    (store: MiddlewareAPI) =>
    (next: (action: unknown) => object) =>
    (action: unknown) => {
        const value = next(action);
        updateLocalStorage(store);
        return value;
    };

export const addPath = (path: string) => {
    localStorageKeys.push(path);
};

_initStorage();
