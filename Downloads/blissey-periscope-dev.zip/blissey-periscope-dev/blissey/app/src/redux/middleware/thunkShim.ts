// Temporary shim to ease redux-thunk v3 type migration in stories/tests
import thunk from 'redux-thunk';
export default (thunk as unknown) as any;