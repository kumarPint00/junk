import { actionCreator } from '../helpers';
import { UserDetails } from '../../types/UserDetails';
import { Action } from 'types/global';

// Action Types
const SET_USER_DETAILS = 'userDetails/SET_USER_DETAILS';

export const actionTypes = {
    SET_USER_DETAILS,
};

// Action Creators
export const setUserDetails = actionCreator<UserDetails>(SET_USER_DETAILS);

// Note :: It seems that this UserDetails type is pretty central. does this need an extension
// for "guest" type details (i.e. redacted "sms" and "email")

// Define state
export type TState = {
    userDetails: UserDetails;
};

export const initialState: TState = {
    userDetails: {
        id: '',
        displayName: '',
        givenName: '',
        familyName: '',
        email: '',
        token: '',
        expiration: -1,
        roles: [],
        sharedSessionStoreEnabled: false,
    },
};

// Reducers
export function reducer(
    state = initialState,
    action: Action<UserDetails>,
): TState {
    switch (action.type) {
        case SET_USER_DETAILS:
            return { ...state, userDetails: action.payload };
        default:
            return state;
    }
}
