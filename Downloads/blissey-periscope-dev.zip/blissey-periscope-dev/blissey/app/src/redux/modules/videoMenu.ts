import { Dispatch } from 'react';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

import { IActionWithPayload, actionCreator } from '../helpers';
import { Logger } from '../../utils';
import { Action, Doc } from 'types/global';

// Action Types
const RESET_VIDEO_CONTROLS = 'videoMenu/RESET_VIDEO_CONTROLS';
const SET_REMOTE_PARTICIPANT = 'videoMenu/SET_REMOTE_PARTICIPANTS';
const SET_LOCAL_MIC_EXISTS = 'videoMenu/SET_LOCAL_MIC_EXISTS';
const SET_LOCAL_CAM_EXISTS = 'videoMenu/SET_LOCAL_CAM_EXISTS';
const SET_IS_FULL_SCREEN = 'videoMenu/SET_IS_FULL_SCREEN';
const SET_IS_MIC_ENABLED = 'videoMenu/SET_IS_MIC_ENABLED';
const SET_IS_CAM_ENABLED = 'videoMenu/SET_IS_CAM_ENABLED';
const SET_SWITCH_CAMERA = 'videoMenu/SET_SWITCH_CAMERA';
const SET_IS_CHAT_VISIBLE = 'videoMenu/SET_IS_CHAT_VISIBLE';
const TOGGLE_IS_CHAT_VISIBLE = 'videoMenu/TOGGLE_IS_CHAT_VISIBLE';
const SET_END_CALL_CONFIRMATION = 'videoMenu/SET_END_CALL_CONFIRMATION';
const SET_LOCAL_BLUR_EXISTS = 'videoMenu/SET_LOCAL_BLUR_EXISTS';
const SET_IS_BLUR_ENABLED = 'videoMenu/SET_IS_BLUR_ENABLED';
const SET_INSTRUCTION_VIDEO_VISIBLE = 'videoMenu/SET_INSTRUCTION_VIDEO_VISIBLE';
const SET_CANCEL_BUTTON_VISIBLE = 'videoMenu/SET_CANCEL_BUTTON_VISIBLE';

export const actionTypes = {
    RESET_VIDEO_CONTROLS,
    SET_REMOTE_PARTICIPANT,
    SET_LOCAL_CAM_EXISTS,
    SET_LOCAL_MIC_EXISTS,
    SET_IS_FULL_SCREEN,
    SET_IS_MIC_ENABLED,
    SET_IS_CAM_ENABLED,
    SET_SWITCH_CAMERA,
    SET_IS_CHAT_VISIBLE,
    SET_END_CALL_CONFIRMATION,
    TOGGLE_IS_CHAT_VISIBLE,
    SET_LOCAL_BLUR_EXISTS,
    SET_IS_BLUR_ENABLED,
    SET_INSTRUCTION_VIDEO_VISIBLE,
    SET_CANCEL_BUTTON_VISIBLE,
};

// Action Creators
export const resetVideoControls = actionCreator<void>(RESET_VIDEO_CONTROLS);
export const setLocalMicExists = actionCreator<boolean>(SET_LOCAL_MIC_EXISTS);
export const setLocalCamExists = actionCreator<boolean>(SET_LOCAL_CAM_EXISTS);
export const setIsFullScreen = actionCreator<boolean>(SET_IS_FULL_SCREEN);
export const setIsMicEnabled = actionCreator<boolean>(SET_IS_MIC_ENABLED);
export const setIsCamEnabled = actionCreator<boolean>(SET_IS_CAM_ENABLED);
export const setSwitchCamera = actionCreator<void>(SET_SWITCH_CAMERA);
export const setIsChatVisible = actionCreator<boolean>(SET_IS_CHAT_VISIBLE);
export const toggleIsChatVisible = actionCreator<void>(TOGGLE_IS_CHAT_VISIBLE);
export const setEndCallConfirmation = actionCreator<boolean>(
    SET_END_CALL_CONFIRMATION,
);
export const setIsBlurEnabled = actionCreator<boolean>(SET_IS_BLUR_ENABLED);
export const setInstructionVideoVisible = actionCreator<boolean>(
    SET_INSTRUCTION_VIDEO_VISIBLE,
);
export const setCancelButtonVisible = actionCreator<boolean>(
    SET_CANCEL_BUTTON_VISIBLE,
);

// Define state
export type TState = {
    localMicExists: boolean;
    localCamExists: boolean;
    isFullScreen: boolean;
    isMicEnabled: boolean;
    isCamEnabled: boolean;
    isChatVisible: boolean;
    endCallConfirmation: boolean;
    isBlurEnabled: boolean;
    isInstructionVideoVisible: boolean;
    isCancelButtonVisible: boolean;
};

export const initialState: TState = {
    localMicExists: true,
    localCamExists: true,
    isFullScreen: false,
    isMicEnabled: true,
    isCamEnabled: true,
    isChatVisible: false,
    endCallConfirmation: false,
    isBlurEnabled: false,
    isInstructionVideoVisible: true,
    isCancelButtonVisible: true,
};

// Reducers
export function reducer(state = initialState, action: Action<boolean>) {
    switch (action.type) {
        case RESET_VIDEO_CONTROLS:
            return {
                ...state,
                isFullScreen: initialState.isFullScreen,
                isChatVisible: initialState.isChatVisible,
                isMicEnabled: initialState.isMicEnabled,
                isCamEnabled: initialState.isCamEnabled,
                isBlurEnabled: initialState.isBlurEnabled,
            };
        case SET_LOCAL_MIC_EXISTS:
            return { ...state, localMicExists: action.payload };
        case SET_LOCAL_CAM_EXISTS:
            return { ...state, localCamExists: action.payload };
        case SET_IS_FULL_SCREEN:
            return { ...state, isFullScreen: action.payload };
        case SET_IS_MIC_ENABLED:
            return { ...state, isMicEnabled: action.payload };
        case SET_IS_CAM_ENABLED:
            return { ...state, isCamEnabled: action.payload };
        case SET_IS_CHAT_VISIBLE:
            return { ...state, isChatVisible: action.payload };
        case SET_SWITCH_CAMERA:
            return { ...state, isCamEnabled: !state.isCamEnabled };
        case TOGGLE_IS_CHAT_VISIBLE:
            return { ...state, isChatVisible: !state.isChatVisible };
        case SET_END_CALL_CONFIRMATION:
            Logger.info(
                {
                    eventType: 'userAction',
                    eventName: 'endCallClick',
                },
                'End call clicked',
            );

            return { ...initialState, endCallConfirmation: action.payload };
        case SET_IS_BLUR_ENABLED:
            return { ...state, isBlurEnabled: action.payload };
        case SET_INSTRUCTION_VIDEO_VISIBLE:
            return { ...state, isInstructionVideoVisible: action.payload };
        case SET_CANCEL_BUTTON_VISIBLE:
            return { ...state, isCancelButtonVisible: action.payload };
        default:
            return state;
    }
}

interface DocumentElement extends HTMLElement {
    webkitRequestFullScreen?: FullscreenOptions;
    mozRequestFullScreen?: FullscreenOptions;
}

export const toggleFullScreen = (
    dispatch: Dispatch<IActionWithPayload<boolean>>,
) => {
    const doc: Doc = window.document;
    const documentElement = doc.documentElement as DocumentElement;
    const requestFullscreen = async () => documentElement.requestFullscreen();
    const exitFullscreen = async () => doc.exitFullscreen();
    const requestFullScreen =
        requestFullscreen ||
        documentElement.webkitRequestFullScreen ||
        documentElement.mozRequestFullScreen;
    const cancelFullScreen =
        exitFullscreen || doc.webkitExitFullscreen || doc.mozCancelFullScreen;

    if (
        !doc.fullscreenElement &&
        !doc.webkitFullscreenElement &&
        !doc.mozFullScreenElement
    ) {
        requestFullScreen.call(documentElement);
        V2Analytics.interactionEvent({
            eventName: 'toggle',
            new_screen_size: 'full screen',
        });

        dispatch(setIsFullScreen(true));
    } else {
        cancelFullScreen.call(doc);
        V2Analytics.interactionEvent({
            eventName: 'toggle',
            new_screen_size: 'player view',
        });

        dispatch(setIsFullScreen(false));
    }
};
