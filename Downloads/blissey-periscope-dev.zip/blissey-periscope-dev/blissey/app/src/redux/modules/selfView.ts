import { Publisher, TestStatus } from '@common/video';
import { BlisseyLogger } from '@utils/Logger';
import { BlisseyDispatch, BlisseyGetState, ActionType } from '@redux/helpers';
import { setMediaPermissionStatus, setPublishStatus } from './health';
import {
    setAudioDeviceId,
    setVideoDeviceId,
    updateDevicesList,
} from './userSettings';
import {
    Dimensions,
    Publisher as OTPublisher,
    VideoDimensionsChangedEvent,
} from '@dexcare/yak';
import { PublishResults } from '@redux/utils/PublishResults';
import { ErrorCode } from '@common/techCheckErrorMessages';

export type Status = 'started' | 'success' | 'failure' | undefined;

export const selfViewActions = {
    setVideoDimensions: (dimensions: Dimensions) =>
        ({
            type: 'SELF_VIEW_SET_VIDEO_DIMENSIONS',
            videoDimensions: dimensions,
        } as const),
} as const;

export type SelfViewAction = ActionType<typeof selfViewActions>;

export const makeDefaultSelfViewState = () => ({
    selfViewStreamStatus: undefined as Status,
    videoDimensions: {} as Dimensions,
});

export type SelfViewState = Readonly<
    ReturnType<typeof makeDefaultSelfViewState>
>;

export function selfViewReducer(
    state: SelfViewState = makeDefaultSelfViewState(),
    action: SelfViewAction,
): SelfViewState {
    switch (action.type) {
        case 'SELF_VIEW_SET_VIDEO_DIMENSIONS':
            return {
                ...state,
                videoDimensions: action.videoDimensions,
            };
        default:
            return state;
    }
}

function onVideoElementCreated(publisher: Publisher) {
    return (dispatch: BlisseyDispatch, getState: BlisseyGetState) => {
        const initialVideoDeviceId = publisher.getVideoDeviceId();
        const initialAudioDeviceId = publisher.getAudioDeviceId();
        const { usersettings: { videoDevices = [], audioDevices = [] } = {} } =
            getState();

        BlisseyLogger.info(
            {
                details: {
                    initialAudioDeviceId,
                    initialVideoDeviceId,
                },
            },
            'video element created.  updating localStorage with deviceIds',
        );
        if (
            (initialVideoDeviceId &&
                !videoDevices?.some((d) => d.value === initialVideoDeviceId)) ||
            (initialAudioDeviceId &&
                !audioDevices?.some((d) => d.value === initialAudioDeviceId))
        ) {
            void dispatch(updateDevicesList());
        }
        if (initialVideoDeviceId) {
            dispatch(setVideoDeviceId(initialVideoDeviceId));
        }
        if (initialAudioDeviceId) {
            dispatch(setAudioDeviceId(initialAudioDeviceId));
        }
        dispatch(setPublishStatus(TestStatus.Passed));
    };
}

function onMediaAccessChanged(status: 'denied' | 'allowed') {
    return (dispatch: BlisseyDispatch) => {
        BlisseyLogger.info(`media access changed to: ${status}`);
        dispatch(setMediaPermissionStatus(status));
    };
}

function onEvent(eventName: string) {
    return (event: unknown) => {
        try {
            // some tokbox events are circular, causing an error in logging
            BlisseyLogger.info(
                { details: { event, eventName } },
                'publisher callback',
            );
        } catch (e) {
            BlisseyLogger.info(
                { details: { eventName } },
                'publisher callback',
            );
        }
    };
}

function onVideoDimensionsChanged(
    event: VideoDimensionsChangedEvent<OTPublisher>,
) {
    return (dispatch: BlisseyDispatch, getState: BlisseyGetState) => {
        const {
            newValue: { height, width },
            oldValue,
        } = event;
        const {
            selfView: {
                videoDimensions: { width: oldWidth, height: oldHeight },
            },
        } = getState();
        if (height && width && (height !== oldHeight || width !== oldWidth)) {
            BlisseyLogger.debug(
                {
                    details: {
                        dimensionsInState: { oldWidth, oldHeight },
                        incomingDimensions: { height, width },
                        opentokOldValue: oldValue,
                    },
                },
                'video dimensions updating',
            );
            dispatch(selfViewActions.setVideoDimensions({ width, height }));
        }
    };
}

function initSelfViewWithOverrides(
    publisher: Publisher | null,
    isBlurEnabled: boolean,
    mediaSources: OT.PublisherProperties,
    otherOverrides: OT.PublisherProperties = {},
) {
    return async (dispatch: BlisseyDispatch) => {
        const publisherOverrides: OT.PublisherProperties = {};
        // carefully constructed to make sure nothing is getting set
        // to null, otherwise OT will assume the intent is to be muted
        if (mediaSources.videoSource && otherOverrides.publishVideo) {
            publisherOverrides.videoSource = mediaSources.videoSource;
        }

        if (mediaSources.audioSource && otherOverrides.publishAudio) {
            publisherOverrides.audioSource = mediaSources.audioSource;
        }

        if (isBlurEnabled) {
            const blurVideoFilter: OT.BackgroundBlurFilter = {
                type: 'backgroundBlur',
                blurStrength: 'high',
            };
            publisherOverrides.videoFilter = blurVideoFilter;
        }

        await publisher?.initVideoElement({
            publisherOverrides: { ...publisherOverrides, ...otherOverrides },
            callbacks: {
                accessDenied: () => dispatch(onMediaAccessChanged('denied')),
                accessAllowed: () => dispatch(onMediaAccessChanged('allowed')),
                videoDimensionsChanged: (
                    event: VideoDimensionsChangedEvent<OTPublisher>,
                ) => dispatch(onVideoDimensionsChanged(event)),
                videoElementCreated: () =>
                    dispatch(onVideoElementCreated(publisher)),
                streamCreated: onEvent('streamCreated'),
                streamDestroyed: onEvent('streamDestroyed'),
                accessDialogClosed: onEvent('accessDialogClosed'),
                accessDialogOpened: onEvent('accessDialogOpened'),
                mediaStopped: onEvent('mediaStopped'),
                muteForced: onEvent('muteForced'),
            },
        });
    };
}

interface MediaError extends Error {
    name: ErrorCode;
}

export function initSelfView(
    publisher: Publisher | null,
    { publishVideo, publishAudio } = { publishVideo: true, publishAudio: true },
) {
    return async (
        dispatch: BlisseyDispatch,
        getState: BlisseyGetState,
    ): Promise<PublishResults> => {
        const {
            usersettings: { videoDeviceId, audioDeviceId },
            video: { isBlurEnabled },
        } = getState();
        try {
            await dispatch(
                initSelfViewWithOverrides(
                    publisher,
                    isBlurEnabled,
                    {
                        videoSource: videoDeviceId,
                        audioSource: audioDeviceId,
                    },
                    {
                        publishAudio,
                        publishVideo,
                    },
                ),
            );
            return { success: true };
        } catch (err: unknown) {
            BlisseyLogger.warn(
                {
                    details: {
                        err,
                    },
                },
                'error in initial publish attempt',
            );
            if ((err as MediaError)?.name === ErrorCode.mediaAccessDenied) {
                return { success: false, error: (err as MediaError).name };
            }

            try {
                BlisseyLogger.info('retrying publish with default devices');
                dispatch(setVideoDeviceId(''));
                dispatch(setAudioDeviceId(''));
                await dispatch(initSelfViewWithOverrides(publisher, false, {}));
                return { success: true };
            } catch (err: unknown) {
                BlisseyLogger.error(
                    {
                        details: { err },
                    },
                    'publish failed',
                );
                return {
                    success: false,
                    error: (err as MediaError)?.name || 'UNKNOWN',
                };
            }
        }
    };
}
