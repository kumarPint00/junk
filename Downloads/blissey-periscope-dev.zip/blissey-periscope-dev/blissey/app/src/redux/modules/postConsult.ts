import { location } from '@dexcare/circus-jupiter';
import {
    isProvider as isSaturnProvider,
    PostVisitActionChange,
} from '@dexcare/circus-saturn';
import { ActionCreator } from 'redux';
import { ThunkAction } from 'redux-thunk';
import { backendFacade } from '../../clients/Backend/BackendFacade';
import {
    VisitDetails,
    VisitStatus,
} from '../../clients/VisitService/VisitInterfaces';
import { visitServiceClient } from '../../clients/VisitService/VisitServiceClient';
import { Logger, getClosedVisitRoute } from '../../utils';
import { actionCreator, ActionCreatorCreator } from '../helpers';
import { addPath } from '../middleware/localStorage';
import { PaymentStatus } from '../utils/PaymentStatus';
import { Store } from './index';
import { setIsTytoCareVisit } from './tytoCare';
import { Action } from 'types/global';
import { ThunkDispatch } from 'types/redux';
import { navigate } from '../../routes';

// Convenience alias for newer redux-thunk signature (ReturnType, State, ExtraArg, BasicAction)
type AppThunk<ReturnType = Promise<void>> = ThunkAction<
    ReturnType,
    Store['All'],
    unknown,
    Action
>;

// Add to local storage middleware
addPath('postconsult.visitId');
addPath('postconsult.callStartTime');

// Action Types
const SET_CALL_START_TIME = 'postconsult/SET_CALL_START_TIME';
const SET_CALL_END_TIME = 'postconsult/SET_CALL_END_TIME';
const SET_VISIT_ID = 'postconsult/SET_VISIT_ID';
const SET_INVALID_VISIT_ID = 'postconsult/SET_INVALID_VISIT_ID';
const SET_INVALID_VISIT_REASON = 'postconsult/SET_INVALID_VISIT_REASON';
const SET_IS_TEST_VISIT = 'postconsult/SET_IS_TEST_VISIT';
const SET_CHARGED_STATUS = 'postconsult/SET_CHARGED_STATUS';
const SET_PATIENT_GUID = 'postconsult/SET_PATIENT_GUID';
const SET_PROVIDER_ID = 'postconsult/SET_PROVIDER_ID';
const SET_PRACTICE_ID = 'postconsult/SET_PRACTICE_ID';
const SET_VISIT_STATUS = 'postconsult/SET_VISIT_STATUS_ID';
const SET_IS_TRAVELING_FROM_CALL_CENTER =
    'postconsult/SET_IS_TRAVELING_FROM_CALL_CENTER';

const SET_TOKBOX_VIDEO_SESSION_ID = 'postconsult/SET_TOKBOX_VIDEO_SESSION_ID';
const SET_TOKBOX_VIDEO_TOKEN = 'postconsult/SET_TOKBOX_VIDEO_TOKEN';
const SET_TOKBOX_WAITING_ROOM_SESSION_ID =
    'postconsult/SET_TOKBOX_WAITING_ROOM_SESSION_ID';
const SET_TOKBOX_WAITING_ROOM_TOKEN =
    'postconsult/SET_TOKBOX_WAITING_ROOM_TOKEN';
const SET_TOKBOX_TOKEN_ERROR = 'postconsult/SET_TOKBOX_TOKEN_ERROR';
const SET_TOKBOX_TOKEN_ERROR_MESSAGE =
    'postconsult/SET_TOKBOX_TOKEN_ERROR_MESSAGE';
const SET_TOKBOX_TOKEN_LOADING = 'postconsult/SET_TOKBOX_TOKEN_LOADING';

const SET_CONSENT_TERMS_ACCEPTED = 'postconsult/SET_CONSENT_TERMS_ACCEPTED';
const SET_CONSENT_ERROR_MESSAGE = 'postconsult/SET_CONSENT_ERROR_MESSAGE';
const SET_IS_LOADING_CONSENT_TERMS = 'postconsult/SET_IS_LOADING_CONSENT_TERMS';

const SET_MESSAGE_DIALOG = 'postconsult/SET_MESSAGE_DIALOG';
const SET_POST_VISIT_ACTION = 'videoMenu/SET_POST_VISIT_ACTION';
const SET_POST_VISIT_ACTION_ERROR_MESSAGE =
    'videoMenu/SET_POST_VISIT_ACTION_ERROR_MESSAGE';

const SET_VISIT_TIMESTAMPS = 'postconsult/SET_VISIT_TIMESTAMPS';

export const actionTypes = {
    SET_CALL_START_TIME,
    SET_CALL_END_TIME,
    SET_TOKBOX_VIDEO_SESSION_ID,
    SET_TOKBOX_VIDEO_TOKEN,
    SET_TOKBOX_TOKEN_LOADING,
    SET_TOKBOX_TOKEN_ERROR,
    SET_TOKBOX_TOKEN_ERROR_MESSAGE,
    SET_TOKBOX_WAITING_ROOM_SESSION_ID,
    SET_TOKBOX_WAITING_ROOM_TOKEN,
    SET_VISIT_ID,
    SET_INVALID_VISIT_ID,
    SET_INVALID_VISIT_REASON,
    SET_IS_TEST_VISIT,
    SET_CHARGED_STATUS,
    SET_PATIENT_GUID,
    SET_PROVIDER_ID,
    SET_CONSENT_TERMS_ACCEPTED,
    SET_CONSENT_ERROR_MESSAGE,
    SET_IS_LOADING_CONSENT_TERMS,
    SET_MESSAGE_DIALOG,
    SET_POST_VISIT_ACTION,
    SET_POST_VISIT_ACTION_ERROR_MESSAGE,
    SET_VISIT_TIMESTAMPS,
    SET_PRACTICE_ID,
    SET_VISIT_STATUS,
    SET_IS_TRAVELING_FROM_CALL_CENTER,
};

// Action Creators
export const setCallStartTime = actionCreator<number | null>(
    SET_CALL_START_TIME,
);
export const setCallEndTime = actionCreator<number | null>(SET_CALL_END_TIME);
export const setVisitId = actionCreator<string>(SET_VISIT_ID);
export const setInvalidVisitId = actionCreator<boolean>(SET_INVALID_VISIT_ID);
export const setInvalidVisitReason = actionCreator<string | null>(
    SET_INVALID_VISIT_REASON,
);
export const setIsTestVisit = actionCreator<boolean>(SET_IS_TEST_VISIT);
export const setChargedStatus =
    actionCreator<PaymentStatus>(SET_CHARGED_STATUS);
export const setPatientGuid = actionCreator<string>(SET_PATIENT_GUID);
export const setProviderId = actionCreator<string | null>(SET_PROVIDER_ID);

export const setTokBoxWaitingRoomSessionId = actionCreator<string>(
    SET_TOKBOX_WAITING_ROOM_SESSION_ID,
);
export const setTokBoxWaitingRoomToken = actionCreator<string>(
    SET_TOKBOX_WAITING_ROOM_TOKEN,
);
export const setTokBoxVideoSessionId = actionCreator<string>(
    SET_TOKBOX_VIDEO_SESSION_ID,
);
export const setTokBoxVideoToken = actionCreator<string>(
    SET_TOKBOX_VIDEO_TOKEN,
);
export const setTokBoxTokenLoading = actionCreator<void>(
    SET_TOKBOX_TOKEN_LOADING,
);
export const setTokBoxTokenError = actionCreator<boolean>(
    SET_TOKBOX_TOKEN_ERROR,
);
export const setTokBoxTokenErrorMessage = actionCreator<string | null>(
    SET_TOKBOX_TOKEN_ERROR_MESSAGE,
);
// Plain action creator (was incorrectly converted to thunk earlier)
export const setConsentTermsAccepted = actionCreator<boolean>(
    SET_CONSENT_TERMS_ACCEPTED,
);
export const setConsentErrorMessage = actionCreator<string | null>(
    SET_CONSENT_ERROR_MESSAGE,
);
export const setIsLoadingConsentTerms = actionCreator<boolean>(
    SET_IS_LOADING_CONSENT_TERMS,
);
export const setMessageDialog = actionCreator<string | null>(
    SET_MESSAGE_DIALOG,
);
export const setPostVisitAction = actionCreator<PostVisitActionChange | null>(
    SET_POST_VISIT_ACTION,
);
export const setPostVisitActionErrorMessage = actionCreator<string | null>(
    SET_POST_VISIT_ACTION_ERROR_MESSAGE,
);
export const setVisitTimestamps = actionCreator<object | null>(
    SET_VISIT_TIMESTAMPS,
);
export const setPracticeId = actionCreator<string | null>(SET_PRACTICE_ID);
export const setVisitStatus = actionCreator<string | null>(SET_VISIT_STATUS);
export const setIsTravelingFromCallCenter = actionCreator<boolean>(
    SET_IS_TRAVELING_FROM_CALL_CENTER,
);

// Define state
export type TState = {
    callStartTime: number | null;
    callEndTime: number | null;
    visitId: string;
    visitStatus: string;
    patientGuid: string;
    providerId: string | null;
    practiceId: string;
    invalidVisitId: boolean;
    invalidVisitReason: string | null;
    isTestVisit: boolean;
    chargedStatus: PaymentStatus;
    tokBoxVideoSessionId?: string;
    tokBoxVideoToken: string;
    isTokBox: boolean;
    tokBoxTokenError: boolean;
    tokBoxTokenErrorMessage: string | null;
    tokBoxWaitingRoomSessionId?: string;
    tokBoxWaitingRoomToken: string;
    consentTermsAccepted: boolean;
    isLoadingConsentTerms: boolean;
    consentTermsErrorMessage: string | null;
    messageDialog: string | null;
    postVisitAction: PostVisitActionChange | null;
    postVisitActionErrorMessage: string | null;
    timestamps: {
        created: string | undefined;
        requested: string | undefined;
        waitingroom: string | undefined;
        invisit: string | undefined;
        done: string | undefined;
        staffdeclined: string | undefined;
        cancelled: string | undefined;
        waitoffline: string | undefined;
        caregiverassigned: string | undefined;
    };
    isTravelingFromCallCenter: boolean;
};

export const initialState: TState = {
    callStartTime: null,
    callEndTime: null,
    visitId: '',
    visitStatus: '',
    patientGuid: '',
    providerId: null,
    practiceId: '',
    invalidVisitId: false,
    invalidVisitReason: null,
    isTestVisit: false,
    chargedStatus: PaymentStatus.none,
    isTokBox: false,
    tokBoxVideoToken: '',
    tokBoxWaitingRoomToken: '',
    tokBoxTokenError: false,
    tokBoxTokenErrorMessage: null,
    consentTermsAccepted: false,
    isLoadingConsentTerms: false,
    consentTermsErrorMessage: null,
    messageDialog: null,
    postVisitAction: null,
    postVisitActionErrorMessage: null,
    timestamps: {
        created: undefined,
        requested: undefined,
        waitingroom: undefined,
        invisit: undefined,
        done: undefined,
        staffdeclined: undefined,
        cancelled: undefined,
        waitoffline: undefined,
        caregiverassigned: undefined,
    },
    isTravelingFromCallCenter: false,
};

interface FetchVisitDetailsParams {
    visitId: string;
    isProvider: boolean;
    isSurvey?: boolean;
}

function setVerifiedVisitId(
    dispatch: ThunkDispatch<TState, unknown, Action>,
    getState: () => Store['All'],
    visitId: string,
): void {
    const state = getState?.();
    if (state?.postconsult?.visitId && visitId !== state.postconsult.visitId) {
        dispatch(setCallStartTime(null));
    }
    dispatch(setVisitId(visitId));
}

export const chargeVisit: ActionCreator<
    ThunkAction<Promise<void>, TState, void, Action>
> = (visitId: string) => {
    return async (
        dispatch: ThunkDispatch<TState, unknown, Action>,
    ): Promise<void> => {
        return visitServiceClient
            .chargeVisit(visitId)
            .then(() => {
                dispatch(setChargedStatus(PaymentStatus.charged));
                Logger.info({
                    eventSource: 'redux/modules/postConsult',
                    eventType: 'charge visit success',
                    visitId,
                });
            })
            .catch((error: unknown) => {
                Logger.error(
                    {
                        eventSource: 'redux/modules/postConsult',
                        eventType: 'charge visit',
                        visitId,
                        error,
                    },
                    'Failed to charge current visit',
                );
                throw error;
            });
    };
};

export const waiveVisit: ActionCreator<
    ThunkAction<Promise<void>, TState, void, Action>
> = (visitId: string, waiveReason: string) => {
    return async (
        dispatch: ThunkDispatch<TState, unknown, Action>,
    ): Promise<void> => {
        return visitServiceClient
            .waiveVisit(visitId, waiveReason)
            .then(() => {
                dispatch(setChargedStatus(PaymentStatus.waived));
                Logger.info({
                    eventSource: 'redux/modules/postConsult',
                    eventType: 'waive visit success',
                    visitId,
                    waiveReason,
                });
            })
            .catch((error: unknown) => {
                Logger.error(
                    {
                        eventSource: 'redux/modules/postConsult',
                        eventType: 'waive visit',
                        visitId,
                        error,
                    },
                    'Failed to waive current visit',
                );
                throw error;
            });
    };
};

export const transferBackToQueue: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = (visitId: string) => {
    return async (
    _dispatch: ThunkDispatch<Store['All'], unknown, Action>,
    getState: () => Store['All'],
    ): Promise<void> => {
        const {
            user: {
                userDetails: { id: currentProviderId },
            },
        } = getState();
        const loggerData = {
            eventSource: 'postConsult',
            eventType: 'transferBackToQueue',
            visitId,
        };
        return backendFacade
            .transferBackToQueue(visitId, currentProviderId)
            .then(() => {
                Logger.info(
                    { ...loggerData },
                    'successfully transferred visit back to queue',
                );
            })
            .catch((error: unknown) => {
                Logger.error(
                    {
                        ...loggerData,
                        error,
                    },
                    'Failed to transfer visit back to queue',
                );
            });
    };
};

export const transferToAnotherProvider: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = (visitId: string, newProviderId: string) => {
    return async (
    _dispatch: ThunkDispatch<Store['All'], unknown, Action>,
    getState: () => Store['All'],
    ): Promise<void> => {
        const {
            user: {
                userDetails: { id: currentProviderId },
            },
        } = getState();
        const loggerData = {
            eventSource: 'postConsult',
            eventType: 'transferToAnotherProvider',
            visitId,
            providerId: newProviderId,
        };
        return backendFacade
            .transferToAnotherProvider(
                visitId,
                newProviderId,
                currentProviderId,
            )
            .then(() => {
                Logger.info(
                    { ...loggerData },
                    'successfully transferred visit to another provider',
                );
            })
            .catch((error: unknown) => {
                Logger.error(
                    {
                        ...loggerData,
                        error,
                    },
                    'failed to transfer visit to another provider',
                );
            });
    };
};

export const convertModality: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = (visitId: string, conversionReason: string) => {
    return async (
    _dispatch: ThunkDispatch<Store['All'], unknown, Action>,
    getState: () => Store['All'],
    ): Promise<void> => {
        const {
            user: {
                userDetails: { id: actorId },
            },
        } = getState();
        const loggerData = {
            eventSource: 'postConsult',
            eventType: 'modalityConversion',
            visitId,
            conversionReason,
            originalModality: 'virtual',
            targetModality: 'phone',
            actorId,
        };
        return backendFacade
            .convertModality(
                visitId,
                conversionReason,
                'virtual',
                'phone',
                actorId,
            )
            .then(() => {
                Logger.info(
                    { ...loggerData },
                    'successfully converted modality from video to phone',
                );
            })
            .catch((error: unknown) => {
                Logger.error(
                    {
                        ...loggerData,
                        error,
                    },
                    'failed to convert modality from video to phone',
                );
            });
    };
};

export const checkPhoneVisitStatusAndRedirect: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = (visitId: string) => {
    return async (): Promise<void> => {
        try {
            const visitStatus = await visitServiceClient.getVisitStatus(
                visitId,
            );
            if (['done', 'staffdeclined', 'cancelled'].includes(visitStatus)) {
                void navigate(`/publicvisit/closed/${visitStatus}`, {
                    replace: true,
                });
            }
            if (['invisit'].includes(visitStatus)) {
                void navigate(`/publicvisit/cannotcancel/${visitId}`, {
                    replace: true,
                });
            }
        } catch (err) {
            Logger.error(
                {
                    visitId,
                },
                'checkPhoneVisitStatusAndRedirect failed to check visit status and redirect',
            );
        }
    };
};

// Async redux-thunk action creators
export const fetchVisitDetailsByVisitId: ActionCreatorCreator<
    FetchVisitDetailsParams,
    ThunkAction<
        Promise<VisitDetails | undefined>,
        Store['All'],
        void,
        Action
    >
> = ({ visitId, isProvider, isSurvey = false }) => {
    return async (
    dispatch: ThunkDispatch<TState, unknown, Action>,
    getState: () => Store['All'],
    ): Promise<VisitDetails | undefined> => {
        return visitServiceClient
            .getVisitSummary(visitId)
            .then((result: VisitDetails) => {
                const {
                    visitId,
                    visitStatus,
                    patientGuid,
                    providerId,
                    practiceId,
                    isTokBox,
                    tokBoxVisit,
                    acceptTerms,
                    timestamps,
                    integrations: {
                        tytoCare: {
                            enabled: tytoCareEnabled,
                            account: tytoCareAccount,
                        } = {},
                    } = {},
                    modality,
                    origin,
                    traveling,
                } = result;
                Logger.addApplicationContext({
                    visitId,
                    isTokBox,
                });
                if (!isTokBox) {
                    throw new Error('invalid conference type');
                }
                if (!tokBoxVisit) {
                    throw new Error('tokboxVisit unexpected empty');
                }
                Logger.addApplicationContext({
                    tokBoxSessionId:
                        tokBoxVisit.videoConferenceSession.sessionId,
                    tokBoxWaitingRoomSessionId:
                        tokBoxVisit.waitingRoomSession.sessionId,
                });
                setVerifiedVisitId(dispatch, getState, visitId);
                dispatch(
                    setTokBoxVideoSessionId(
                        tokBoxVisit.videoConferenceSession.sessionId,
                    ),
                );
                dispatch(
                    setTokBoxWaitingRoomSessionId(
                        tokBoxVisit.waitingRoomSession.sessionId,
                    ),
                );
                dispatch(setPatientGuid(patientGuid));
                dispatch(setConsentTermsAccepted(Boolean(acceptTerms)));
                dispatch(setVisitTimestamps(timestamps));
                dispatch(setPracticeId(practiceId));
                dispatch(setVisitStatus(visitStatus));
                if (providerId) dispatch(setProviderId(providerId));
                if (tytoCareEnabled && tytoCareAccount) {
                    dispatch(setIsTytoCareVisit(true));
                    Logger.info(
                        {
                            visitId,
                            details: {
                                tytoCareAccount,
                            },
                        },
                        'TytoCare visit true',
                    );
                }
                dispatch(
                    setIsTravelingFromCallCenter(
                        origin === 'agent' && !!traveling,
                    ),
                );
                Logger.info(
                    {
                        eventSource: 'redux/modules/postConsult',
                        eventType: 'network',
                        eventName: 'fetchVisitDetailsByVisitId.getVisitSummary',
                        response: { statusCode: 200 },
                        visitId,
                        patientGuid,
                        providerId,
                        details: {
                            waitingConferenceId: result.waitingConferenceId,
                            videoConferenceId: result.videoConferenceId,
                        },
                        acceptTerms,
                        timestamps,
                        modality,
                        origin,
                        traveling,
                    },
                    'Data returned from scheduling service.',
                );

                return result;
            })
            .then((result: VisitDetails) => {
                const visitConverted = result.modality === 'phone';

                //do not go to closed route if it is the survey, you need to be able to hit it directly
                //unless the visit is already converted to phone
                if (!isSurvey || visitConverted) {
                    const redirect = getClosedVisitRoute(
                        result.visitStatus,
                        false,
                        visitConverted,
                    );
                    if (redirect) {
                        if (isProvider) {
                            dispatch(setInvalidVisitId(true));
                            dispatch(setInvalidVisitReason('VISIT_CONVERTED'));
                        } else {
                            // if the visit is not a provider, navigate to the closed route
                            // this is to prevent the provider from being redirected to the closed route
                            // when the visit is not valid
                            void navigate(redirect);
                        }
                    }
                }
                return result;
            })
            .then((result: VisitDetails) => {
                return result;
            })
            .catch((err: unknown) => {
                dispatch(setInvalidVisitId(true));
                dispatch(
                    setInvalidVisitReason(
                        (err as Error).message ??
                            (err as { error: string }).error ??
                            null,
                    ),
                );
                Logger.error(
                    {
                        eventSource: 'redux/modules/postConsult',
                        eventType: 'network',
                        eventName: 'fetchConferenceByVisitId.getVisitSummary',
                        visitId,
                        err,
                    },
                    'Failed with error during request.',
                );
                return undefined;
            });
    };
};

const genPatientToken = async (visitId: string, sessionId?: string) => {
    if (sessionId) {
        return await visitServiceClient.generateTokboxPatientToken(
            sessionId,
            visitId,
        );
    }
    return undefined;
};

export interface FetchTokensData {
    videoSessionId: string;
    waitingRoomSessionId: string;
}
export const fetchTokBoxTokens: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = (params: FetchTokensData) => {
    return async (
    dispatch: ThunkDispatch<Store['All'], unknown, Action>,
    getState: () => Store['All'],
    ): Promise<void> => {
        const {
            postconsult: { visitId },
            user: { userDetails },
        } = getState();
        const { videoSessionId, waitingRoomSessionId } = params;
        try {
            dispatch(setTokBoxTokenLoading());
            Logger.info(
                {
                    eventSource: 'redux/modules/postConsult',
                    eventType: 'network',
                    eventName: 'fetchTokBoxVideoToken',
                    visitId,
                },
                'fetching tokbox token',
            );
            if (isSaturnProvider(userDetails)) {
                const userId = userDetails.id;
                const { token } =
                    await backendFacade.generateTokboxProviderToken(
                        videoSessionId,
                        visitId,
                        userId,
                    );
                dispatch(setTokBoxVideoToken(token));
            } else {
                const [videoToken, waitingRoomToken] = await Promise.all([
                    genPatientToken(visitId, videoSessionId),
                    genPatientToken(visitId, waitingRoomSessionId),
                ]);
                if (waitingRoomToken) {
                    dispatch(setTokBoxWaitingRoomToken(waitingRoomToken.token));
                }
                if (videoToken) {
                    dispatch(setTokBoxVideoToken(videoToken.token));
                }
            }
            Logger.info(
                {
                    eventSource: 'redux/modules/postConsult',
                    eventType: 'network',
                    eventName: 'fetchTokBoxVideoToken',
                    visitId,
                },
                'retrieved tokbox token(s)',
            );
        } catch (error: unknown) {
            dispatch(setTokBoxTokenError(true));
            // v6 getPatientTokboxTokens error comes back as res.json({ error: 'Forbidden' });
            // this doesn't get handled in the checkStatus method until after this log
            dispatch(
                setTokBoxTokenErrorMessage(
                    (error as Error).message ??
                        (error as { error: string }).error ??
                        null,
                ),
            );
            Logger.error(
                {
                    eventSource: 'redux/modules/postConsult',
                    eventType: 'network',
                    eventName: 'fetchTokBoxVideoToken',
                    visitId,
                    error,
                },
                'error fetching tokbox token',
            );
        }
    };
};

export const fetchTestVisitDetailsByVisitId: ActionCreator<
    ThunkAction<
        { visitDetails: VisitDetails; redirect?: string },
        Store['All'],
        void,
        Action
    >
> = (visitId: string, providerId?: string) => {
    return (
    dispatch: ThunkDispatch<TState, unknown, Action>,
    getState: () => Store['All'],
    ): { visitDetails: VisitDetails; redirect?: string } => {
        const {
            postconsult: { tokBoxVideoSessionId, tokBoxWaitingRoomSessionId },
        } = getState();

        const visitDetails: VisitDetails = {
            visitId,
            visitStatus: 'requested',
            patientGuid: 'patientGuid',
            providerId: providerId ?? 'providerId',
            practiceId: 'practiceId',
            acceptTerms: true,
            integrations: {
                tytoCare: {
                    enabled: false,
                },
            },
            timestamps: {
                created: undefined,
                requested: undefined,
                waitingroom: undefined,
                invisit: undefined,
                done: undefined,
                staffdeclined: undefined,
                cancelled: undefined,
                waitoffline: undefined,
                caregiverassigned: undefined,
            },
            modality: 'video',
        };
        const chunks: string[] = visitId.split('-');
        Logger.addApplicationContext({ visitId });
        setVerifiedVisitId(dispatch, getState, visitId);
        dispatch(setPatientGuid(visitDetails.patientGuid));
        if (visitDetails.providerId)
            dispatch(setProviderId(visitDetails.providerId));

        visitDetails.isTokBox = true;
        visitDetails.tokBoxVisit = {
            apiKey: 'test', // placeholder to satisfy type in test context
            waitingRoomSession: { sessionId: tokBoxWaitingRoomSessionId || '' },
            videoConferenceSession: { sessionId: tokBoxVideoSessionId || '' },
        } as typeof visitDetails.tokBoxVisit;
        visitDetails.visitStatus = chunks[3] as VisitStatus;
        const redirect = getClosedVisitRoute(visitDetails.visitStatus, false);
        return { visitDetails, redirect };
    };
};

export const acceptConsentTerms: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = () => {
    return async (
    dispatch: ThunkDispatch<Store['All'], unknown, Action>,
    getState: () => Store['All'],
    ): Promise<void> => {
        const state = getState?.();
        const {
            postconsult: { visitId },
        } = state;
        dispatch(setIsLoadingConsentTerms(true));
        return visitServiceClient
            .acceptConsentTerms(visitId)
            .then(() => {
                Logger.info(
                    {
                        eventSource: 'redux/modules/postConsult',
                        eventType: 'network',
                        eventName: 'acceptConsentTerms',
                        visitId,
                    },
                    'Success accepting terms',
                );
                dispatch(setConsentTermsAccepted(true));
            })
            .catch((error: unknown) => {
                Logger.error(
                    {
                        eventSource: 'redux/modules/postConsult',
                        eventType: 'network',
                        eventName: 'acceptConsentTerms',
                        visitId,
                        error,
                    },
                    'error fetching tokbox token',
                );
                dispatch(setConsentTermsAccepted(false));
                dispatch(setConsentErrorMessage((error as Error).message));
            })
            .finally(() => {
                dispatch(setIsLoadingConsentTerms(false));
            });
    };
};

export const cancelVisit: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = () => {
    return async (
        _dispatch: ThunkDispatch<Store['All'], unknown, Action>,
        getState,
    ): Promise<void> => {
        const state = getState?.();
        const {
            postconsult: { visitId },
        } = state;
        return visitServiceClient
            .cancelVisit(visitId)
            .then(() => {
                Logger.info(
                    {
                        eventSource: 'redux/modules/postConsult',
                        eventType: 'network',
                        eventName: 'cancelVisit',
                        visitId,
                    },
                    'Success with canceling visit',
                );
            })
            .catch((error: unknown) => {
                Logger.error(
                    {
                        eventSource: 'redux/modules/postConsult',
                        eventType: 'network',
                        eventName: 'cancelVisit',
                        visitId,
                        error,
                    },
                    'Error with canceling visit',
                );
            })
            .finally(() => {
                // redirect to logout
                location.setLocationPathname('/patientauth/end');
            });
    };
};

export const cancelPhoneWithReason: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = (visitId: string, cancelReason: string, email: string) => {
    return async (): Promise<void> => {
        try {
            await visitServiceClient.cancelPhoneWithReason(
                visitId,
                cancelReason,
                email,
            );
        } catch (err: unknown) {
            Logger.error(
                {
                    eventSource: 'redux/modules/postConsult',
                    eventType: 'network',
                    eventName: 'cancelPhoneWithReason',
                    visitId,
                    err,
                },
                'Error with cancelling visit with reason',
            );
        }
    };
};

export const cancelVideoWithReason: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = (visitId: string, cancelReason: string) => {
    return async (): Promise<void> => {
        try {
            await visitServiceClient.cancelVideoWithReason(
                visitId,
                cancelReason,
            );
        } catch (err: unknown) {
            Logger.error(
                {
                    eventSource: 'redux/modules/postConsult',
                    eventType: 'network',
                    eventName: 'cancelVideoWithReason',
                    visitId,
                    err,
                },
                'Error with cancelling visit with reason',
            );
        }
    };
};

// Reducers
export function reducer(state = initialState, action: Action): TState {
    switch (action.type) {
        case SET_CALL_START_TIME:
            return { ...state, callStartTime: action.payload as number | null };
        case SET_CALL_END_TIME:
            return { ...state, callEndTime: action.payload as number | null };
        case SET_TOKBOX_VIDEO_SESSION_ID:
            return {
                ...state,
                tokBoxVideoSessionId: action.payload as string | undefined,
            };
        case SET_TOKBOX_WAITING_ROOM_SESSION_ID:
            return {
                ...state,
                tokBoxWaitingRoomSessionId: action.payload as
                    | string
                    | undefined,
            };
        case SET_TOKBOX_VIDEO_TOKEN:
            return { ...state, tokBoxVideoToken: action.payload as string };
        case SET_TOKBOX_WAITING_ROOM_TOKEN:
            return {
                ...state,
                tokBoxWaitingRoomToken: action.payload as string,
            };
        case SET_TOKBOX_TOKEN_LOADING:
            return { ...state, tokBoxTokenError: false };
        case SET_TOKBOX_TOKEN_ERROR:
            return { ...state, tokBoxTokenError: action.payload as boolean };
        case SET_TOKBOX_TOKEN_ERROR_MESSAGE:
            return {
                ...state,
                tokBoxTokenErrorMessage: action.payload as string,
            };
        case SET_VISIT_ID:
            return { ...state, visitId: action.payload as string };
        case SET_PATIENT_GUID:
            return { ...state, patientGuid: action.payload as string };
        case SET_PROVIDER_ID:
            return { ...state, providerId: action.payload as string | null };
        case SET_INVALID_VISIT_ID:
            return { ...state, invalidVisitId: action.payload as boolean };
        case SET_INVALID_VISIT_REASON:
            return {
                ...state,
                invalidVisitReason: action.payload as string | null,
            };
        case SET_IS_TEST_VISIT:
            return { ...state, isTestVisit: action.payload as boolean };
        case SET_CHARGED_STATUS:
            return { ...state, chargedStatus: action.payload as PaymentStatus };
        case SET_CONSENT_TERMS_ACCEPTED:
            return {
                ...state,
                consentTermsAccepted: action.payload as boolean,
            };
        case SET_CONSENT_ERROR_MESSAGE:
            return {
                ...state,
                consentTermsErrorMessage: action.payload as string | null,
            };
        case SET_IS_LOADING_CONSENT_TERMS:
            return {
                ...state,
                isLoadingConsentTerms: action.payload as boolean,
            };
        case SET_MESSAGE_DIALOG:
            return { ...state, messageDialog: action.payload as string | null };
        case SET_POST_VISIT_ACTION:
            return {
                ...state,
                postVisitAction: action.payload as PostVisitActionChange | null,
            };
        case SET_POST_VISIT_ACTION_ERROR_MESSAGE:
            return {
                ...state,
                postVisitActionErrorMessage: action.payload as string | null,
            };
        case SET_VISIT_TIMESTAMPS:
            return {
                ...state,
                timestamps: action.payload as TState['timestamps'],
            };
        case SET_PRACTICE_ID:
            return { ...state, practiceId: action.payload as string };
        case SET_VISIT_STATUS:
            return { ...state, visitStatus: action.payload as string };
        case SET_IS_TRAVELING_FROM_CALL_CENTER:
            return {
                ...state,
                isTravelingFromCallCenter: action.payload as boolean,
            };
        default:
            return state;
    }
}
