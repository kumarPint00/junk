import { combineReducers } from 'redux';
import { reducer as healthReducer } from './health';
import { reducer as videoReducer } from './videoMenu';
import { reducer as instantMessageReducer } from './instantMessage';
import { reducer as userDetailsReducer } from './userDetails';
import {
    selfViewReducer,
    SelfViewState,
    makeDefaultSelfViewState,
} from './selfView';
import { reducer as postConsultReducer } from './postConsult';
import { reducer as tytoCareReducer } from './tytoCare';
import { reducer as userSettingsReducer } from './userSettings';
import { reducer as otpReducer } from './otp';
import { reducer as transferOptionsReducer } from './transferOptions';

import { TState as THealthState } from './health';
import { TState as TVideoState } from './videoMenu';
import { TState as TInstantMessageState } from './instantMessage';
import { TState as TUserDetailsState } from './userDetails';
import { TState as TPostConsultState } from './postConsult';
import { TState as TTytoCareState } from './tytoCare';
import { TState as TUserSettingsState } from './userSettings';
import { TState as TOTPState } from './otp';
import { TransferOptionsState } from './transferOptions';

import { initialState as healthInitialState } from './health';
import { initialState as videoInitialState } from './videoMenu';
import { initialState as instantMessageInitialState } from './instantMessage';
import { initialState as userDetailsInitialState } from './userDetails';
import { initialState as postconsultInitialState } from './postConsult';
import { initialState as tytoCareInitialState } from './tytoCare';
import { initialState as usersettingsInitialState } from './userSettings';
import { initialState as otpInitialState } from './otp';
import { initialTransferOptionsState } from './transferOptions';

export interface Store {
    All: {
        health: THealthState;
        postconsult: TPostConsultState;
        usersettings: TUserSettingsState;
        selfView: SelfViewState;
        video: TVideoState;
        user: TUserDetailsState;
        instantMessage: TInstantMessageState;
        tytoCare: TTytoCareState;
        otp: TOTPState;
        transferOptions: TransferOptionsState;
    };
}

export const initialState = {
    health: healthInitialState,
    postconsult: postconsultInitialState,
    usersettings: usersettingsInitialState,
    video: videoInitialState,
    user: userDetailsInitialState,
    instantMessage: instantMessageInitialState,
    tytoCare: tytoCareInitialState,
    selfView: makeDefaultSelfViewState(),
    otp: otpInitialState,
    transferOptions: initialTransferOptionsState,
};

export const rootReducer = combineReducers({
    health: healthReducer,
    postconsult: postConsultReducer,
    usersettings: userSettingsReducer,
    video: videoReducer,
    user: userDetailsReducer,
    instantMessage: instantMessageReducer,
    tytoCare: tytoCareReducer,
    selfView: selfViewReducer,
    otp: otpReducer,
    transferOptions: transferOptionsReducer,
});

export type RootState = ReturnType<typeof rootReducer>;
