import { actionCreator } from '../helpers';
import { BlisseyLogger } from '@utils/Logger';
import { ActionCreator } from 'redux';
import { ThunkAction } from 'redux-thunk';
import { Store } from '.';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import {
    TYTO_CARE_GENERIC_ERROR,
    TYTO_CARE_ERROR_MAP,
} from '@common/tytoCareErrorMessages';
import { Action } from 'types/global';
import { ThunkDispatch } from 'types/redux';

// Action Types
const SET_IS_TYTO_CARE_VISIT = 'tytoCare/SET_IS_TYTO_CARE_VISIT';
const SET_IS_LOADING_TYTO_CARE = 'tytoCare/SET_IS_LOADING_TYTO_CARE';
const SET_TYTO_CARE_VISIT_ERROR = 'tytoCare/SET_TYTO_CARE_VISIT_ERROR';
const SET_TYTO_CARE_PROVIDER_URL = 'tytoCare/SET_TYTO_CARE_PROVIDER_URL';
const SET_TYTO_CARE_WIDGET_VISIBLE = 'tytoCare/SET_TYTO_CARE_WIDGET_VISIBLE';
const CLEAR_TYTO_CARE_ERROR = 'tytoCare/CLEAR_TYTO_CARE_ERROR';

export const actionTypes = {
    SET_IS_TYTO_CARE_VISIT,
    SET_IS_LOADING_TYTO_CARE,
    SET_TYTO_CARE_VISIT_ERROR,
    SET_TYTO_CARE_PROVIDER_URL,
    SET_TYTO_CARE_WIDGET_VISIBLE,
    CLEAR_TYTO_CARE_ERROR,
};

// Action Creators
export const setIsTytoCareVisit = actionCreator<boolean>(
    SET_IS_TYTO_CARE_VISIT,
);
export const loadingTytoCareVisit = actionCreator<boolean>(
    SET_IS_LOADING_TYTO_CARE,
);
export const setTytoCareVisitError = actionCreator<string | undefined>(
    SET_TYTO_CARE_VISIT_ERROR,
);
export const setTytoCareProviderUrl = actionCreator<string | undefined>(
    SET_TYTO_CARE_PROVIDER_URL,
);
export const clearTytoCareError = actionCreator<void>(CLEAR_TYTO_CARE_ERROR);

// Define state
export type TState = {
    isTytoCareVisit: boolean;
    providerVisitUrl: string | undefined;
    error: string | undefined;
    loading: boolean;
};

export const initialState: TState = {
    isTytoCareVisit: false,
    providerVisitUrl: undefined,
    error: undefined,
    loading: false,
};

// Reducers
export function reducer(state = initialState, action: Action) {
    switch (action.type) {
        case SET_IS_TYTO_CARE_VISIT:
            BlisseyLogger.info({ msg: 'received tytocare visit notification' });
            return { ...state, isTytoCareVisit: action.payload as boolean };
        case SET_IS_LOADING_TYTO_CARE:
            return { ...state, loading: action.payload as boolean };
        case SET_TYTO_CARE_VISIT_ERROR:
            return { ...state, error: action.payload as string | undefined };
        case SET_TYTO_CARE_PROVIDER_URL:
            return {
                ...state,
                providerVisitUrl: action.payload as string | undefined,
            };
        case CLEAR_TYTO_CARE_ERROR:
            return { ...state, error: undefined };
        default:
            return state;
    }
}

// TytoCare has an expiration on the iFrame url, so on hiding, just clear the URL and the client will
// make a request to regenerate the URL if the url is toggled on again
export const hideTytoCareWidet: ActionCreator<
    ThunkAction<void, Store['All'], void, Action>
> = () => {
    return (dispatch: ThunkDispatch<Store['All'], unknown, Action>): void => {
        BlisseyLogger.info({ msg: 'hiding tytocare widget' });
        dispatch(setTytoCareProviderUrl(undefined));
    };
};

export const loadTytoCareWidget: ActionCreator<
    ThunkAction<Promise<void>, Store['All'], void, Action>
> = () => {
    return async (
    dispatch: ThunkDispatch<Store['All'], unknown, Action>,
    getState: () => Store['All'],
    ): Promise<void> => {
        BlisseyLogger.info({ msg: 'creating TytoCare visit' });
        const {
            postconsult: { visitId },
        } = getState();
        dispatch(loadingTytoCareVisit(true));
        dispatch(setTytoCareVisitError(undefined));
        try {
            const {
                tytoCare: { visitUrl },
            } = await visitServiceClient.startTytoCareVisit(visitId);
            dispatch(setTytoCareProviderUrl(visitUrl));
        } catch (error) {
            const err = error as Error;
            BlisseyLogger.info({
                msg: 'error creating TytoCare visit',
                details: { err },
            });

            let userError = TYTO_CARE_GENERIC_ERROR;
            if (err?.message && TYTO_CARE_ERROR_MAP[err.message]) {
                userError = TYTO_CARE_ERROR_MAP[err.message];
            }
            dispatch(setTytoCareVisitError(userError));
        } finally {
            dispatch(loadingTytoCareVisit(false));
        }
    };
};
