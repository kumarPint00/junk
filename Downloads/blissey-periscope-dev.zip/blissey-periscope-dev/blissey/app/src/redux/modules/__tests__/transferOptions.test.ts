import {
    reducer,
    initialTransferOptionsState,
    setLoadingTransferOptions,
    TransferOptionsState,
    setTransferOptions,
    actionTypes,
    setTransferOptionsError,
    getTransferOptions,
} from '../transferOptions';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import thunk from '@redux/middleware/thunkShim';
import configureMockStore from 'redux-mock-store';
import { IActionWithPayload } from '@redux/helpers';
import { Mocked, vi } from 'vitest';
import { MockStoreType } from '../../../../src/types/redux';
vi.mock('@clients/VisitService/VisitServiceClient');

const mockVisitServiceClient = visitServiceClient as Mocked<
    typeof visitServiceClient
>;

const singleProvider = {
    id: '32069188-fc7d-4489-90c8-3dec0b36111c1',
    overflowDepartmentId: 'org.providence.dig.epic.provorca|4111104000',
    smsNumber: '2025551212',
    displayInfo: {
        name: 'DexCare Provider.121',
        specialty: 'ECV',
    },
    oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
    practiceRegions: [
        {
            id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
            regionCode: 'MT',
            practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
            market: {
                id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                name: 'Default',
                description: 'default',
            },
        },
    ],
    assignmentQualifiers: [
        {
            id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
            name: 'pediatric',
        },
        {
            id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
            name: 'adult',
        },
    ],
    modalities: [
        {
            id: '57ffd934-1226-41be-b93a-30af16c056e4',
            name: 'virtual',
        },
        {
            id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
            name: 'phone',
        },
    ],
    visitId: null,
};

const singlePracticeRegion = {
    id: '2dfdc1bf-ff7f-4e3f-a25f-c546aa5fcfbc',
    practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
    displayName: 'Washington Backup',
    regionCode: 'WA',
    active: true,
    availability: [
        {
            start: '2023-09-17T07:00:00.000Z',
            end: '2023-09-18T06:59:00.000Z',
        },
        {
            start: '2023-09-18T07:00:00.000Z',
            end: '2023-09-19T06:59:00.000Z',
        },
        {
            start: '2023-09-19T07:00:00.000Z',
            end: '2023-09-20T06:59:00.000Z',
        },
        {
            start: '2023-09-20T07:00:00.000Z',
            end: '2023-09-21T06:59:00.000Z',
        },
        {
            start: '2023-09-21T07:00:00.000Z',
            end: '2023-09-22T06:59:00.000Z',
        },
        {
            start: '2023-09-22T07:00:00.000Z',
            end: '2023-09-23T06:59:00.000Z',
        },
        {
            start: '2023-09-23T07:00:00.000Z',
            end: '2023-09-24T06:59:00.000Z',
        },
    ],
    busy: false,
    busyMessage: 'Providers are currently at capacity and closed',
    paymentAccountId: '3faed309-efd8-45ab-a9de-1bc149745bb2',
    visitPrice: 4900,
    orderWeight: 0,
    departments: [
        {
            id: '4d2a72d5-41d5-462d-985b-9e2ce41c1570',
            epicDepartmentId: '405772000',
            ehrSystemName: 'org.providence.dig.epic.provorca',
            defaultDepartmentName: 'Interstate',
        },
    ],
    market: {
        id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
        name: 'Backup',
        description: 'Backup',
    },
    transferOptionBufferInMinutes: 700,
};

describe('redux transfer options', () => {
    const middlewares = [thunk];
    const mockStore = configureMockStore<{
        transferOptions: TransferOptionsState;
    }>(middlewares);
    let store: MockStoreType;
    afterEach(() => {
        vi.resetAllMocks();
    });

    beforeEach(() => {
        store = mockStore({ transferOptions: initialTransferOptionsState } as {
            transferOptions: TransferOptionsState;
        });
    });

    describe('loading state', () => {
        it('dispatches loading state action', () => {
            store.dispatch(setLoadingTransferOptions());
            expect(store.getActions()).toMatchInlineSnapshot(`
                [
                  {
                    "type": "transferOptions/SET_LOADING_TRANSFER_OPTIONS",
                  },
                ]
            `);
        });

        it('set loading to true', () => {
            const state = reducer(
                initialTransferOptionsState,
                setLoadingTransferOptions() as IActionWithPayload<void>,
            );
            expect(state.loading).toEqual(true);
        });
    });

    describe('set error', () => {
        it('dispatches error action', () => {
            store.dispatch(setTransferOptionsError(new Error('whoops')));
            expect(store.getActions()).toMatchInlineSnapshot(`
                [
                  {
                    "payload": [Error: whoops],
                    "type": "transferOptions/SET_TRANSFER_OPTIONS_ERROR",
                  },
                ]
            `);
        });

        it('sets error and clears loading state and providers and practice regions', () => {
            const result = reducer(
                {
                    ...initialTransferOptionsState,
                    providers: [singleProvider],
                    practiceRegions: [singlePracticeRegion],
                },
                setTransferOptionsError(new Error('whoops')),
            );
            expect(result.loading).toEqual(false);
            expect(result.error).toEqual(new Error('whoops'));
            expect(result.practiceRegions).toEqual([]);
            expect(result.providers).toEqual([]);
        });
    });

    describe('set transfer options', () => {
        it('dispatches set transfer options action', () => {
            store.dispatch(
                setTransferOptions({
                    providers: [singleProvider],
                    practiceRegions: [singlePracticeRegion],
                }),
            );
            expect(store.getActions()).toEqual(
                expect.arrayContaining([
                    expect.objectContaining({
                        type: actionTypes.SET_TRANSFER_OPTIONS,
                    }),
                ]),
            );
        });
        it('sets providers and practice regions and clears loading and errors', () => {
            const result = reducer(
                initialTransferOptionsState,
                setTransferOptions({
                    providers: [singleProvider],
                    practiceRegions: [singlePracticeRegion],
                }),
            );

            expect(result.loading).toEqual(false);
            expect(result.error).toEqual(undefined);
            expect(result.providers).toEqual([singleProvider]);
            expect(result.practiceRegions).toEqual([singlePracticeRegion]);
        });
    });

    describe('get transfer options', () => {
        it('dispatches set transfer options on success', async () => {
            mockVisitServiceClient.getTransferOptions.mockResolvedValueOnce({
                providers: [singleProvider],
                practiceRegions: [singlePracticeRegion],
            });
            await store.dispatch(getTransferOptions('some-visit-id'));
            const actions = store.getActions();
            expect(actions).toMatchSnapshot();
        });

        it('dispatches set error on failure', async () => {
            mockVisitServiceClient.getTransferOptions.mockRejectedValueOnce(
                new Error('whoops'),
            );
            await store.dispatch(getTransferOptions('some-visit-id'));
            const actions = store.getActions();
            expect(actions).toMatchSnapshot();
        });
    });
});
