import thunk from '@redux/middleware/thunkShim';
import configureMockStore from 'redux-mock-store';
import { MockedFunction, vi } from 'vitest';
import * as otp from '../otp';
import { otpAuthClient } from '@clients/OTPAuth/OTPAuthClient';
import { MockStoreType } from '../../../../src/types/redux';

const middlewares = [thunk];
const mockStore: (state?: unknown) => MockStoreType =
    configureMockStore(middlewares);

vi.mock('@clients/OTPAuth/OTPAuthClient', () => ({
    otpAuthClient: {
        verifyPasscode: vi.fn(),
    },
}));

describe('otp module', () => {
    let mockOTPAuthClient;
    const initialState: otp.TState = {
        windowToDisplay: 'get',
        isLoading: false,
        errorMessage: undefined,
    };
    beforeEach(async () => {
        mockOTPAuthClient = await import('@clients/OTPAuth/OTPAuthClient');
        mockOTPAuthClient.otpAuthClient.requestPasscode = vi
            .fn()
            .mockResolvedValue({});
        mockOTPAuthClient.otpAuthClient.verifyPasscode = vi
            .fn()
            .mockResolvedValue({});
    });
    afterEach(() => {
        vi.clearAllMocks();
    });
    describe('getOTPCode', () => {
        it('successfully requests an otp code', () => {});
        it('fails to request an otp code', () => {});
    });

    describe('otp', () => {
        test('initial state', () => {
            expect(
                otp.reducer(undefined, {
                    type: '',
                    payload: undefined,
                }),
            ).toEqual(initialState);
        });
        test('windowToDisplay', () => {
            const newState = otp.reducer(
                undefined,
                otp.setWindowToDisplay('get'),
            );
            expect(newState.windowToDisplay).toEqual('get');
        });
        test('isLoading', () => {
            const newState = otp.reducer(undefined, otp.setIsLoading(true));
            expect(newState.isLoading).toEqual(true);
        });
        test('errorMessage', () => {
            const newState = otp.reducer(
                undefined,
                otp.setErrorMessage('Error'),
            );
            expect(newState.errorMessage).toEqual('Error');
        });
    });

    describe('submitOTPCode', () => {
        test('successfully submits an otp code', async () => {
            const store = mockStore({});
            const reRoute = '/dashboard';
            (
                otpAuthClient.verifyPasscode as unknown as MockedFunction<
                    typeof otpAuthClient.verifyPasscode
                >
            ).mockResolvedValueOnce({ reRoute });
            await store.dispatch(otp.submitOTPCode('123456', 'email'));
            const expectedActions = [
                { type: 'otp/SET_IS_LOADING', payload: true },
                { type: 'otp/SET_ERROR_MESSAGE', payload: undefined },
                {
                    payload: false,
                    type: 'otp/SET_IS_LOADING',
                },
            ];

            expect(store.getActions()).toEqual(expectedActions);
        });

        test('fails to submit otp code', async () => {
            const store = mockStore({});
            const errorMessage = 'Invalid OTP code';
            (
                otpAuthClient.verifyPasscode as unknown as MockedFunction<
                    typeof otpAuthClient.verifyPasscode
                >
            ).mockRejectedValueOnce(new Error(errorMessage));
            await store.dispatch(otp.submitOTPCode('123456', 'email'));
            const expectedActions = [
                {
                    payload: true,
                    type: 'otp/SET_IS_LOADING',
                },
                {
                    payload: 'Invalid OTP code',
                    type: 'otp/SET_ERROR_MESSAGE',
                },
                {
                    payload: false,
                    type: 'otp/SET_IS_LOADING',
                },
            ];

            expect(store.getActions()).toEqual(expectedActions);
        });

        test('fails to submit otp code without err.message', async () => {
            const store = mockStore({});
            const errorMessage = 'Something went wrong. Please try again';
            (
                otpAuthClient.verifyPasscode as unknown as MockedFunction<
                    typeof otpAuthClient.verifyPasscode
                >
            ).mockRejectedValueOnce(new Error());
            await store.dispatch(otp.submitOTPCode('123456', 'email'));
            const expectedActions = [
                {
                    payload: true,
                    type: 'otp/SET_IS_LOADING',
                },
                {
                    payload: errorMessage,
                    type: 'otp/SET_ERROR_MESSAGE',
                },
                {
                    payload: false,
                    type: 'otp/SET_IS_LOADING',
                },
            ];

            expect(store.getActions()).toEqual(expectedActions);
        });
    });

    describe('getOTPCode', () => {
        test('successfully gets an otp code', async () => {
            const store = mockStore({});
            (
                otpAuthClient.requestPasscode as unknown as MockedFunction<
                    typeof otpAuthClient.requestPasscode
                >
            ).mockResolvedValueOnce({} as Response);
            await store.dispatch(otp.getOTPCode('email'));
            const expectedActions = [
                { type: 'otp/SET_IS_LOADING', payload: true },
                { type: 'otp/SET_ERROR_MESSAGE', payload: undefined },
                { type: 'otp/SET_WINDOW_TO_DISPLAY', payload: 'verify' },
                {
                    payload: false,
                    type: 'otp/SET_IS_LOADING',
                },
            ];

            expect(store.getActions()).toEqual(expectedActions);
        });

        test('fails to get otp code', async () => {
            const store = mockStore({});
            const errorMessage = 'OTPAuthClient: getPasscode failed';
            (
                otpAuthClient.requestPasscode as unknown as MockedFunction<
                    typeof otpAuthClient.requestPasscode
                >
            ).mockRejectedValueOnce(new Error(errorMessage));
            await store.dispatch(otp.getOTPCode('email1'));
            const expectedActions = [
                {
                    payload: true,
                    type: 'otp/SET_IS_LOADING',
                },
                {
                    payload: errorMessage,
                    type: 'otp/SET_ERROR_MESSAGE',
                },
                {
                    payload: false,
                    type: 'otp/SET_IS_LOADING',
                },
            ];

            expect(store.getActions()).toEqual(expectedActions);
        });

        test('fails to get otp code without err.message', async () => {
            const store = mockStore({});
            const errorMessage = 'Code could not be sent. Please try again';
            (
                otpAuthClient.requestPasscode as unknown as MockedFunction<
                    typeof otpAuthClient.requestPasscode
                >
            ).mockRejectedValueOnce(new Error());
            await store.dispatch(otp.getOTPCode('email1'));
            const expectedActions = [
                {
                    payload: true,
                    type: 'otp/SET_IS_LOADING',
                },
                {
                    payload: errorMessage,
                    type: 'otp/SET_ERROR_MESSAGE',
                },
                {
                    payload: false,
                    type: 'otp/SET_IS_LOADING',
                },
            ];

            expect(store.getActions()).toEqual(expectedActions);
        });
    });

    describe('resendOTPCode', () => {
        test('successfully submits an otp code', async () => {
            const store = mockStore({});

            await store.dispatch(otp.resendOTPCode());
            const expectedActions = [
                { type: 'otp/SET_WINDOW_TO_DISPLAY', payload: 'get' },
                { type: 'otp/SET_ERROR_MESSAGE', payload: undefined },
            ];

            expect(store.getActions()).toEqual(expectedActions);
        });
    });
});
