import { actionCreator } from '../helpers';

import { InstantMessageItemProps } from '@dexcare/circus-saturn';

// Action Types
const ADD_WAITING_ROOM_MESSAGE = 'instantMessage/ADD_WAITING_ROOM_MESSAGE';
const ADD_VIDEO_MESSAGE = 'instantMessage/ADD_VIDEO_MESSAGE';
const SET_VIDEO_HAS_UNREAD = 'instantMessage/SET_VIDEO_HAS_UNREAD';
const SET_WAITING_ROOM_HAS_UNREAD =
    'instantMessage/SET_WAITING_ROOM_HAS_UNREAD';

export const actionTypes = {
    ADD_WAITING_ROOM_MESSAGE,
    ADD_VIDEO_MESSAGE,
    SET_VIDEO_HAS_UNREAD,
    SET_WAITING_ROOM_HAS_UNREAD,
};

// Action Creators
export const addWaitingInstantMessage = actionCreator<InstantMessageItemProps>(
    ADD_WAITING_ROOM_MESSAGE,
);
export const addVideoInstantMessage =
    actionCreator<InstantMessageItemProps>(ADD_VIDEO_MESSAGE);
export const setVideoHasUnread = actionCreator<boolean>(SET_VIDEO_HAS_UNREAD);
export const setWaitingRoomHasUnread = actionCreator<boolean>(
    SET_WAITING_ROOM_HAS_UNREAD,
);

// Define state
export type TState = {
    waitingInstantMessages: InstantMessageItemProps[];
    videoInstantMessages: InstantMessageItemProps[];
    videoHasUnread: boolean;
    waitingRoomHasUnread: boolean;
};

export const initialState: TState = {
    waitingInstantMessages: [],
    videoInstantMessages: [],
    videoHasUnread: false,
    waitingRoomHasUnread: false,
};

export type Action =
    | {
          type: typeof ADD_WAITING_ROOM_MESSAGE;
          payload: InstantMessageItemProps;
      }
    | { type: typeof ADD_VIDEO_MESSAGE; payload: InstantMessageItemProps }
    | { type: typeof SET_VIDEO_HAS_UNREAD; payload: boolean }
    | { type: typeof SET_WAITING_ROOM_HAS_UNREAD; payload: boolean };

// Reducers
export function reducer(state = initialState, action: Action) {
    switch (action.type) {
        case ADD_WAITING_ROOM_MESSAGE: {
            const duplicateWaitingMessage = isKeyInInstantMessages(
                state.waitingInstantMessages,
                action.payload.key,
            );
            // when the bot option is selected, replace the last message
            if (duplicateWaitingMessage && action.payload.botSelectedOption) {
                return {
                    ...state,
                    waitingInstantMessages: [
                        ...state.waitingInstantMessages.slice(0, -1),
                        action.payload,
                    ],
                };
                // when the bot option is not selected, and the message is a duplicate, do not add it
            } else if (duplicateWaitingMessage) {
                return state;
                // when the message is not a duplicate, add it
            } else {
                return {
                    ...state,
                    waitingInstantMessages: [
                        ...state.waitingInstantMessages,
                        action.payload,
                    ],
                };
            }
        }
        case ADD_VIDEO_MESSAGE: {
            const duplicateVideoMessage = isKeyInInstantMessages(
                state.videoInstantMessages,
                action.payload.key,
            );
            if (duplicateVideoMessage) {
                return state;
            }
            return {
                ...state,
                videoInstantMessages: [
                    ...state.videoInstantMessages,
                    action.payload,
                ],
            };
        }
        case SET_VIDEO_HAS_UNREAD:
            return { ...state, videoHasUnread: action.payload };
        case SET_WAITING_ROOM_HAS_UNREAD:
            return { ...state, waitingRoomHasUnread: action.payload };
        default:
            return state;
    }
}

const isKeyInInstantMessages = (
    messageList: InstantMessageItemProps[],
    newMessageKey: string,
) => {
    return messageList.some((message) => {
        return message.key === newMessageKey;
    });
};
