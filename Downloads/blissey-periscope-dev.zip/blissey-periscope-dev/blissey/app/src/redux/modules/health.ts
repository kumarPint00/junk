import {
    actionCreatorVoid,
    actionCreator,
    BlisseyDispatch,
    BlisseyGetState,
    IActionCreator,
    IActionCreatorVoid,
} from '../helpers';
import {
    camAndMicCheck,
    TestStatus,
    networkCheck,
    Publisher,
    NetworkTestError,
    NetworkTestResults,
} from '@common/video';
import { setAudioDevices, setVideoDevices } from './userSettings';
import { BlisseyLogger as Logger } from '@utils/Logger';
import { initSelfView } from './selfView';
import { sendWaitingRoomEvent } from '@services/sendWaitingRoomEvent';
import { ErrorCode } from '@common/techCheckErrorMessages';
import { PublishResults } from '@redux/utils/PublishResults';
import { getTestSession } from '@services/getTestSession';

// Action Types
const UPDATE_PROGRESS = 'blissey/health/UPDATE_PROGRESS';
const WIPE_PROGRESS = 'blissey/health/WIPE_PROGRESS';
const SET_NETWORK_STATUS = 'blissey/health/SET_NETWORK_STATUS';
const SET_MEDIA_PERMISSION_STATUS =
    'blissey/health/SET_MEDIA_PERMISSION_STATUS';
const SET_CAM_STATUS = 'blissey/health/SET_CAM_STATUS';
const SET_MIC_STATUS = 'blissey/health/SET_MIC_STATUS';
const SET_CAM_ERROR = 'blissey/health/SET_CAM_ERROR';
const SET_MIC_ERROR = 'blissey/health/SET_MIC_ERROR';
const CLEAR_CAM_ERROR = 'blissey/health/CLEAR_CAM_ERROR';
const CLEAR_MIC_ERROR = 'blissey/health/CLEAR_MIC_ERROR';
const SET_PUBLISH_STATUS = 'blissey/health/SET_PUBLISH_STATUS';

export type MediaPermissionStatus = undefined | 'denied' | 'allowed';
export const actionTypes = {
    UPDATE_PROGRESS,
    WIPE_PROGRESS,
    SET_NETWORK_STATUS,
    SET_CAM_STATUS,
    SET_MIC_STATUS,
    SET_MEDIA_PERMISSION_STATUS,
    SET_PUBLISH_STATUS,
    SET_CAM_ERROR,
    SET_MIC_ERROR,
    CLEAR_CAM_ERROR,
    CLEAR_MIC_ERROR,
};

// Action Creators
export const updateProgress = actionCreator<number>(UPDATE_PROGRESS);
export const wipeProgress = actionCreatorVoid(WIPE_PROGRESS);
export const setNetworkStatus = actionCreator<TestStatus>(SET_NETWORK_STATUS);
export const setCamStatus = actionCreator<TestStatus>(SET_CAM_STATUS);
export const setMicStatus = actionCreator<TestStatus>(SET_MIC_STATUS);
export const setCamError = actionCreator<ErrorCode>(SET_CAM_ERROR);
export const setMicError = actionCreator<ErrorCode>(SET_MIC_ERROR);
export const clearMicError = actionCreatorVoid(CLEAR_MIC_ERROR);
export const clearCamError = actionCreatorVoid(CLEAR_CAM_ERROR);
export const setPublishStatus = actionCreator<TestStatus>(SET_PUBLISH_STATUS);
export const setMediaPermissionStatus = actionCreator<MediaPermissionStatus>(
    SET_MEDIA_PERMISSION_STATUS,
);

// this is about the cleanest way at the moment to get a union type of the results
// of the action creator functions above
type HealthActions =
    | ReturnType<IActionCreator<number>> // typeof updateProgress
    | ReturnType<IActionCreatorVoid> // typeof wipeProgress | clearMicError | clearCamError
    | ReturnType<IActionCreator<TestStatus>> // typeof setNetworkStatus | setCamStatus | setMicError | setPublishStatus
    | ReturnType<IActionCreator<ErrorCode>> // typeof setCamError | setMicErro
    | ReturnType<IActionCreator<MediaPermissionStatus>>; // typeof setMediaPermissionStatus

// Define state
export type TState = {
    healthCheckProgress: number;
    networkStatus: TestStatus;
    camStatus: TestStatus;
    camError?: ErrorCode;
    micStatus: TestStatus;
    micError?: ErrorCode;
    mediaPermissionStatus: MediaPermissionStatus;
    // TODO: move this to selfView
    publishStatus: TestStatus;
};

export const initialState: TState = {
    healthCheckProgress: 0,
    networkStatus: TestStatus.NotRun,
    camStatus: TestStatus.NotRun,
    micStatus: TestStatus.NotRun,
    mediaPermissionStatus: undefined,
    publishStatus: TestStatus.NotRun,
};

export const isHealthCheckRunning = (healthCheckProgress: number) =>
    healthCheckProgress !== 0;
export const healthCheckCompleted = (
    previousProgress: number,
    currentProgress: number,
) => {
    return (
        isHealthCheckRunning(previousProgress) &&
        !isHealthCheckRunning(currentProgress)
    );
};
export const hasDeniedMediaPermissions = (
    mediaPermissionStatus?: MediaPermissionStatus,
) => mediaPermissionStatus === 'denied';

type HealthReducerFunction = (state: TState, action: HealthActions) => TState;

// it'd be nice to have types where we can use the action type string
// here, but it's a bit too roundabout to accomplish right now
const reducerMap: Record<string, HealthReducerFunction> = {
    [UPDATE_PROGRESS]: (state, action: ReturnType<typeof updateProgress>) =>
        Object.assign({}, state, {
            healthCheckProgress: state.healthCheckProgress + action.payload,
        }),
    [WIPE_PROGRESS]: (state) =>
        Object.assign({}, state, {
            healthCheckProgress: 0,
        }),
    [SET_NETWORK_STATUS]: (
        state,
        action: ReturnType<typeof setNetworkStatus>,
    ) =>
        Object.assign({}, state, {
            networkStatus: action.payload,
        }),
    [SET_CAM_STATUS]: (state, action: ReturnType<typeof setCamStatus>) =>
        Object.assign({}, state, {
            camStatus: action.payload,
        }),
    [SET_MIC_STATUS]: (state, action: ReturnType<typeof setMicStatus>) =>
        Object.assign({}, state, {
            micStatus: action.payload,
        }),
    [SET_MEDIA_PERMISSION_STATUS]: (
        state,
        action: ReturnType<typeof setMediaPermissionStatus>,
    ) => ({
        ...state,
        mediaPermissionStatus: action.payload,
    }),
    [SET_PUBLISH_STATUS]: (
        state,
        action: ReturnType<typeof setPublishStatus>,
    ) => ({
        ...state,
        publishStatus: action.payload,
    }),
    [SET_CAM_ERROR]: (state, action: ReturnType<typeof setCamError>) =>
        Object.assign({}, state, {
            camError: action.payload,
        }),
    [SET_MIC_ERROR]: (state, action: ReturnType<typeof setMicError>) =>
        Object.assign({}, state, {
            micError: action.payload,
        }),
    [CLEAR_CAM_ERROR]: (state) =>
        Object.assign({}, state, {
            camError: undefined,
        }),
    [CLEAR_MIC_ERROR]: (state) =>
        Object.assign({}, state, {
            micError: undefined,
        }),
};

// Reducers
export function reducer(state = initialState, action: HealthActions) {
    return typeof reducerMap[action.type as string] === 'function'
        ? reducerMap[action.type as string](state, action)
        : state;
}

export function runTests(publisher: Publisher | null) {
    Logger.info(
        {
            eventType: 'ConnectionTest',
            eventSource: 'redux/modules/health',
        },
        'Start health check',
    );
    return runAllTests(publisher);
}

function publishDeviceCheck(
    publisher: Publisher | null,
    { tryVideo, tryAudio }: { tryVideo: boolean; tryAudio: boolean },
) {
    return async (
        dispatch: BlisseyDispatch,
    ): Promise<{
        videoResults?: PublishResults;
        audioResults?: PublishResults;
    }> => {
        let publishResults: {
            videoResults?: PublishResults;
            audioResults?: PublishResults;
        } = {};
        if (tryVideo && tryAudio) {
            const results = await dispatch(
                initSelfView(publisher, {
                    publishAudio: true,
                    publishVideo: true,
                }),
            );
            publishResults = { videoResults: results, audioResults: results };
            if (results.success) {
                return publishResults;
            }
        }

        if (tryVideo) {
            publishResults.videoResults = await dispatch(
                initSelfView(publisher, {
                    publishAudio: false,
                    publishVideo: true,
                }),
            );
        }

        if (tryAudio) {
            publishResults.audioResults = await dispatch(
                initSelfView(publisher, {
                    publishAudio: true,
                    publishVideo: false,
                }),
            );
        }
        return publishResults;
    };
}

function basicDeviceCheck() {
    return async (dispatch: BlisseyDispatch) => {
        const {
            hasCamera,
            hasMic,
            videoDevices = [],
            audioDevices = [],
        } = await camAndMicCheck();
        // update devices on every tech check run in case the user plugs in a device and re-runs the test
        dispatch(setVideoDevices(videoDevices));
        dispatch(setAudioDevices(audioDevices));

        Logger.info(
            {
                details: {
                    videoDevices: JSON.stringify(videoDevices),
                    audioDevices: JSON.stringify(audioDevices),
                },
            },
            `Audio devices found ${audioDevices.length}, ` +
                `video devices found ${videoDevices.length}`,
        );

        return { hasCamera, hasMic };
    };
}

function aggregateResult(
    mediaType: 'cam' | 'mic',
    hasDevice: boolean,
    results: PublishResults | undefined,
) {
    let aggregateResults;
    if (!hasDevice) {
        aggregateResults = {
            status: TestStatus.Failed,
            error: ErrorCode.missingDevice,
        };
    } else {
        aggregateResults = {
            status: results?.success ? TestStatus.Passed : TestStatus.Failed,
            error: results?.success
                ? undefined
                : (results?.error as ErrorCode) || ErrorCode.unknown,
        };
    }

    Logger.info(
        {
            eventType: 'ConnectionTest',
            eventSource: 'redux/modules/health',
            details: {
                mediaType,
                hasDevice,
                publishResults: results,
                aggregateResults,
            },
        },
        'Media check results',
    );
    return aggregateResults;
}

function resetState(publisher: Publisher | null) {
    return (dispatch: BlisseyDispatch) => {
        publisher?.cleanup();
        dispatch(setPublishStatus(TestStatus.NotRun));
        dispatch(clearCamError());
        dispatch(clearMicError());
    };
}

function getAdjustedNetworkStatus(results: NetworkTestResults) {
    const ignoreError: (keyof NetworkTestError)[] = ['loggingServerError'];
    const errors = results?.error;

    let networkStatus = TestStatus.Passed;
    networkStatus = results?.networkStatus;

    // ENG-1885 it's not really a failure if the error should be ignored
    if (networkStatus === TestStatus.Failed && errors) {
        const reallyFailed = Object.keys(errors).reduce(
            (acc: boolean, cur: keyof NetworkTestError) => {
                if (errors[cur] && !ignoreError.includes(cur)) {
                    return true;
                } else {
                    Logger.warn(
                        {
                            eventType: 'ConnectionTest',
                            eventSource: 'redux/modules/health',
                            details: { error: errors[cur], ignoredError: cur },
                        },
                        'Network status check: Ignored error',
                    );
                    return acc;
                }
            },
            false,
        );

        if (!reallyFailed) {
            networkStatus = TestStatus.Passed;
        }
    }

    Logger.info(
        {
            eventType: 'ConnectionTest',
            eventSource: 'redux/modules/health',
            details: { networkStatus, error: results?.error, ignoreError },
        },
        'adjusted network status',
    );

    return networkStatus;
}

function networkTest() {
    return async (dispatch: BlisseyDispatch) => {
        const testSession = await getTestSession();
        let networkStatus = TestStatus.Passed;
        if (testSession) {
            // skip network test if we can't get a session
            let results = await networkCheck(testSession);
            networkStatus = getAdjustedNetworkStatus(results);

            Logger.info(
                {
                    eventType: 'ConnectionTest',
                    eventSource: 'redux/modules/health',
                    details: {
                        networkStatus,
                        error: results?.error,
                        testSession,
                        attempt: 1,
                    },
                },
                'network check results',
            );

            if (networkStatus === TestStatus.Failed) {
                Logger.info(
                    {
                        eventType: 'ConnectionTest',
                        eventSource: 'redux/modules/health',
                    },
                    'network check failed the first time - retrying',
                );

                results = await networkCheck(testSession);
                networkStatus = getAdjustedNetworkStatus(results);
                Logger.info(
                    {
                        eventType: 'ConnectionTest',
                        eventSource: 'redux/modules/health',
                        details: {
                            networkStatus,
                            error: results?.error,
                            testSession,
                            attempt: 2,
                        },
                    },
                    'network check results',
                );
            }
        } else {
            networkStatus = TestStatus.Failed;
        }
        Logger.info(
            {
                eventType: 'ConnectionTest',
                eventSource: 'redux/modules/health',
            },
            'Completed health check',
        );

        dispatch(setNetworkStatus(networkStatus));
        return networkStatus;
    };
}

function deepDevicesCheck(publisher: Publisher | null) {
    return async (dispatch: BlisseyDispatch) => {
        const { hasCamera, hasMic } = await dispatch(basicDeviceCheck());
        const { videoResults, audioResults } = await dispatch(
            publishDeviceCheck(publisher, {
                tryAudio: hasMic,
                tryVideo: hasCamera,
            }),
        );

        const { status: camStatus, error: camError } = aggregateResult(
            'cam',
            hasCamera,
            videoResults,
        );
        const { status: micStatus, error: micError } = aggregateResult(
            'mic',
            hasMic,
            audioResults,
        );
        dispatch(setCamStatus(camStatus));
        if (camError) dispatch(setCamError(camError));
        dispatch(setMicStatus(micStatus));
        if (micError) dispatch(setMicError(micError));

        const results = {
            camStatus,
            micStatus,
            hasCamera,
            hasMic,
            mediaPermissionStatus:
                videoResults?.error === ErrorCode.mediaAccessDenied ||
                audioResults?.error === ErrorCode.mediaAccessDenied
                    ? TestStatus.Failed
                    : TestStatus.Passed,
        };

        Logger.info(
            {
                eventType: 'ConnectionTest',
                eventSource: 'redux/modules/health',
                details: results,
            },
            'Completed deep devices check',
        );
        return results;
    };
}

function runAllTests(publisher: Publisher | null) {
    return async (dispatch: BlisseyDispatch, getState: BlisseyGetState) => {
        dispatch(resetState(publisher));
        try {
            const {
                user: { userDetails },
                postconsult: { visitId, isTestVisit },
            } = getState();
            // Run network test first because on iOS Safari it causes the video stream
            // to be muted if it runs while the self-view is initialized.  By running it first,
            // we re-initialize the self-view in the camera and mic checks after.
            // it may seem like too much responsibility for the healthcheck to initialize the self-view,
            // but iOS Safari is fragile and does not work well when we try to initialize too many publishers
            dispatch(updateProgress(25));
            const networkStatus = await dispatch(networkTest());

            dispatch(updateProgress(25));
            const { camStatus, micStatus, mediaPermissionStatus } =
                await dispatch(deepDevicesCheck(publisher));

            dispatch(updateProgress(25));
            sendWaitingRoomEvent(userDetails, visitId, isTestVisit, {
                camStatus,
                micStatus,
                mediaPermissionStatus,
                networkStatus,
            });

            dispatch(wipeProgress());
        } catch (error: unknown) {
            Logger.error(
                {
                    eventType: 'ConnectionTest',
                    eventSource: 'redux/modules/health',
                    error,
                },
                'Error running health check',
            );
            dispatch(wipeProgress());
            throw error;
        }
    };
}
