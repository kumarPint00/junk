import thunk from '@redux/middleware/thunkShim';
import configureMockStore from 'redux-mock-store';
import {
    Publisher as OTPublisher,
    VideoDimensionsChangedEvent,
} from '@dexcare/yak';
import { Publisher, TestStatus } from '@common/video';
import {
    selfViewReducer,
    selfViewActions,
    SelfViewAction,
    initSelfView,
} from '../selfView';
import { initialState } from '..';
import { vi, Mock } from 'vitest';
import { MockStoreType } from '../../../../src/types/redux';

vi.mock('@common/video');
vi.mock('@clients/VisitService/VisitServiceClient');

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

const runReducer = (action: SelfViewAction, initialState = undefined) => {
    return selfViewReducer(initialState, action);
};

interface InitVideoElementCalls {
    publisherOverrides: OT.PublisherProperties;
    callbacks: {
        accessDenied: Mock;
        accessAllowed: Mock;
        videoDimensionsChanged: Mock;
        videoElementCreated: Mock;
    };
}

describe('selfView reducer', () => {
    describe('actions', () => {
        let store: MockStoreType;
        let publisher: Publisher;
        let initVideoElement: Mock<
            InitVideoElementCalls[],
            InitVideoElementCalls[]
        >;

        beforeEach(async () => {
            const videoLib = await import('@common/video');

            (videoLib.camAndMicCheck as Mock).mockResolvedValue({
                videoDevices: [{ label: 'Test Cam 1', value: 'cam1' }],
                audioDevices: [{ label: 'Test Mic 1', value: 'mic1' }],
            });
            publisher = new Publisher({
                id: 'publisherId',
                callbacks: {},
            });
            initVideoElement = vi.fn();
            publisher.getAudioDeviceId = vi
                .fn()
                .mockReturnValue('audioDevice1');
            publisher.getVideoDeviceId = vi
                .fn()
                .mockReturnValue('videoDevice1');
            publisher.initVideoElement =
                initVideoElement as unknown as typeof publisher.initVideoElement;
            store = mockStore(initialState);
        });
        afterEach(() => {
            vi.clearAllMocks();
        });
        it('sets initial state', () => {
            expect(runReducer({} as SelfViewAction)).toEqual({
                videoDimensions: {},
            });
        });
        it('sets video dimensions', () => {
            const videoDimensions = {
                width: 20,
                height: 20,
            };
            const newState = runReducer(
                selfViewActions.setVideoDimensions(videoDimensions),
            );
            expect(newState).toMatchInlineSnapshot(`
                {
                  "selfViewStreamStatus": undefined,
                  "videoDimensions": {
                    "height": 20,
                    "width": 20,
                  },
                }
            `);
        });
        it('tries to init self view twice if the first time errors', async () => {
            publisher.initVideoElement = vi.fn().mockRejectedValue('oops!');

            await store.dispatch(initSelfView(publisher));
            expect(publisher.initVideoElement).toHaveBeenCalledTimes(2);
        });
        it('does not retry if error is OT_USER_MEDIA_ACCESS_DENIED', async () => {
            publisher.initVideoElement = vi.fn().mockRejectedValue({
                name: 'OT_USER_MEDIA_ACCESS_DENIED',
            });

            await store.dispatch(initSelfView(publisher));

            expect(publisher.initVideoElement).toHaveBeenCalledTimes(1);
        });

        it('listens for access denied', async () => {
            await store.dispatch(initSelfView(publisher));
            initVideoElement.mock.calls[0][0].callbacks.accessDenied({});

            expect(store.getActions()).toMatchInlineSnapshot(`
                [
                  {
                    "payload": "denied",
                    "type": "blissey/health/SET_MEDIA_PERMISSION_STATUS",
                  },
                ]
            `);
        });
        it('listens for access allowed', async () => {
            await store.dispatch(initSelfView(publisher));
            initVideoElement.mock.calls[0][0].callbacks.accessAllowed({});

            expect(store.getActions()).toMatchInlineSnapshot(`
                [
                  {
                    "payload": "allowed",
                    "type": "blissey/health/SET_MEDIA_PERMISSION_STATUS",
                  },
                ]
            `);
        });
        it('listens for video dimensions changed', async () => {
            await store.dispatch(initSelfView(publisher));
            const newDimensions = { height: 22, width: 33 };
            initVideoElement.mock.calls[0][0].callbacks.videoDimensionsChanged({
                newValue: { ...newDimensions },
                oldValue: { height: 0, width: 0 },
            } as VideoDimensionsChangedEvent<OTPublisher>);

            expect(store.getActions()).toMatchInlineSnapshot(`
                [
                  {
                    "type": "SELF_VIEW_SET_VIDEO_DIMENSIONS",
                    "videoDimensions": {
                      "height": 22,
                      "width": 33,
                    },
                  },
                ]
            `);
        });
        it('listens for video element created', async () => {
            store = mockStore({
                ...initialState,
                health: {
                    camStatus: TestStatus.Passed,
                    micStatus: TestStatus.Passed,
                    networkStatus: TestStatus.Passed,
                },
            });
            await store.dispatch(initSelfView(publisher));
            initVideoElement.mock.calls[0][0].callbacks.videoElementCreated({});
            expect(store.getActions()).toMatchInlineSnapshot(`
                [
                  {
                    "payload": "videoDevice1",
                    "type": "usersettings/SET_VIDEO_DEVICE_ID",
                  },
                  {
                    "payload": "audioDevice1",
                    "type": "usersettings/SET_AUDIO_DEVICE_ID",
                  },
                  {
                    "payload": 2,
                    "type": "blissey/health/SET_PUBLISH_STATUS",
                  },
                ]
            `);
        });
        it('correctly sends failed test results', async () => {
            store = mockStore({
                ...initialState,
                health: {
                    camStatus: TestStatus.Failed,
                    micStatus: TestStatus.Passed,
                    networkStatus: TestStatus.Passed,
                },
            });
            await store.dispatch(initSelfView(publisher));
            initVideoElement.mock.calls[0][0].callbacks.videoElementCreated({});
        });
        it('does not communicate healthcheck results for provider', async () => {
            store = mockStore({
                ...initialState,
                user: {
                    userDetails: {
                        ...initialState.user.userDetails,
                        roles: ['telehealth_provider'],
                    },
                },
            });
            await store.dispatch(initSelfView(publisher));
            initVideoElement.mock.calls[0][0].callbacks.videoElementCreated({});
        });
    });
});
