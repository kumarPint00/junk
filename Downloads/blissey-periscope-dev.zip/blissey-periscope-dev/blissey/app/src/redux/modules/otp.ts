import { ActionCreator } from 'redux';
import { ThunkAction } from 'redux-thunk';
import { actionCreator } from '../helpers';
import { navigate } from '../../routes';
import { otpAuthClient } from '@clients/OTPAuth/OTPAuthClient';
import { Action } from 'types/global';
import { ThunkDispatch } from 'types/redux';

// Action Types
const SET_WINDOW_TO_DISPLAY = 'otp/SET_WINDOW_TO_DISPLAY';
const SET_IS_LOADING = 'otp/SET_IS_LOADING';
const SET_ERROR_MESSAGE = 'otp/SET_ERROR_MESSAGE';

export const actionTypes = {
    SET_WINDOW_TO_DISPLAY,
    SET_IS_LOADING,
    SET_ERROR_MESSAGE,
};

// Action Creators
export const setWindowToDisplay = actionCreator<string>(SET_WINDOW_TO_DISPLAY);
export const setIsLoading = actionCreator<boolean>(SET_IS_LOADING);
export const setErrorMessage = actionCreator<string | undefined>(
    SET_ERROR_MESSAGE,
);

// Define state
export type TState = {
    windowToDisplay: string;
    isLoading: boolean;
    errorMessage: string | undefined;
};

export const initialState: TState = {
    windowToDisplay: 'get',
    isLoading: false,
    errorMessage: undefined,
};

export const getOTPCode: ActionCreator<
    ThunkAction<Promise<void>, TState, void, Action>
> = (otpMethod: string) => {
    return async (
        dispatch: ThunkDispatch<TState, unknown, Action>,
    ): Promise<void> => {
        // call service to request the code be sent (via otpMethod)
        dispatch(setIsLoading(true));
        return otpAuthClient
            .requestPasscode(otpMethod)
            .then(() => {
                // on success show the verify screen
                dispatch(setErrorMessage(undefined));
                dispatch(setWindowToDisplay('verify'));
            })
            .catch((err: Error) => {
                // on fail show error (how to determine translation string?)
                dispatch(
                    setErrorMessage(
                        err.message ||
                            'Code could not be sent. Please try again',
                    ),
                );
            })
            .finally(() => {
                dispatch(setIsLoading(false));
            });
    };
};

export const submitOTPCode: ActionCreator<
    ThunkAction<Promise<void>, TState, void, Action>
> = (otpCode: string, otpMethod: string) => {
    return async (
        dispatch: ThunkDispatch<TState, unknown, Action>,
    ): Promise<void> => {
        // post code to auth service for guest user
        dispatch(setIsLoading(true));
        return otpAuthClient
            .verifyPasscode(otpCode, otpMethod)
            .then(({ reRoute }: { reRoute: string }) => {
                // on success redirect to response reroute
                dispatch(setErrorMessage(undefined));
                // use forced refresh browser history to reset with the
                // newly logged in user so that they can access the waiting room
                void navigate(reRoute, { forceRefresh: true });
            })
            .catch((err: Error) => {
                // on fail show error (how to determine translation string?)
                dispatch(
                    setErrorMessage(
                        err.message || 'Something went wrong. Please try again',
                    ),
                );
            })
            .finally(() => {
                dispatch(setIsLoading(false));
            });
    };
};

export const resendOTPCode: ActionCreator<
    ThunkAction<Promise<void>, TState, void, Action>
> = () => {
    return async (
        dispatch: ThunkDispatch<TState, unknown, Action>,
    ): Promise<void> => {
        // go back to get screen
        dispatch(setWindowToDisplay('get'));
        dispatch(setErrorMessage(undefined));
        return Promise.resolve();
    };
};

// Reducers
export function reducer(state = initialState, action: Action): TState {
    switch (action.type) {
        case SET_WINDOW_TO_DISPLAY:
            return { ...state, windowToDisplay: action.payload as string };
        case SET_IS_LOADING:
            return { ...state, isLoading: action.payload as boolean };
        case SET_ERROR_MESSAGE:
            return {
                ...state,
                errorMessage: action.payload as string | undefined,
            };
        default:
            return state;
    }
}
