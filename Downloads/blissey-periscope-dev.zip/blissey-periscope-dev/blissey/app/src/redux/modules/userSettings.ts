import { addPath } from '../middleware/localStorage';
import { actionCreator } from '../helpers';
import { camAndMicCheck, MediaDevice } from '@common/video';
import { Action } from 'types/global';
import { Dispatch } from 'react';
import { AnyAction } from 'redux';

// Add to local storage middleware
addPath('usersettings.audioDeviceId');
addPath('usersettings.videoDeviceId');

// Action Types
const SET_AUDIO_DEVICE_ID = 'usersettings/SET_AUDIO_DEVICE_ID';
const SET_VIDEO_DEVICE_ID = 'usersettings/SET_VIDEO_DEVICE_ID';
const SET_VIDEO_DEVICES = 'usersettings/SET_VIDEO_DEVICES';
const SET_AUDIO_DEVICES = 'usersettings/SET_AUDIO_DEVICES';

export const actionTypes = {
    SET_AUDIO_DEVICE_ID,
    SET_VIDEO_DEVICE_ID,
    SET_VIDEO_DEVICES,
    SET_AUDIO_DEVICES,
};

// Action Creators
export const setAudioDeviceId = actionCreator<string>(SET_AUDIO_DEVICE_ID);
export const setVideoDeviceId = actionCreator<string>(SET_VIDEO_DEVICE_ID);
export const setVideoDevices = actionCreator<MediaDevice[]>(SET_VIDEO_DEVICES);
export const setAudioDevices = actionCreator<MediaDevice[]>(SET_AUDIO_DEVICES);

// Define state
export type TState = {
    audioDeviceId: string;
    videoDeviceId: string;
    videoDevices: MediaDevice[];
    audioDevices: MediaDevice[];
};

export const initialState: TState = {
    audioDeviceId: '',
    videoDeviceId: '',
    videoDevices: [],
    audioDevices: [],
};

// Reducers
export function reducer(state = initialState, action: Action) {
    switch (action.type) {
        case SET_AUDIO_DEVICE_ID:
            return { ...state, audioDeviceId: action.payload as string };
        case SET_VIDEO_DEVICE_ID:
            return { ...state, videoDeviceId: action.payload as string };
        case SET_VIDEO_DEVICES:
            return { ...state, videoDevices: action.payload as MediaDevice[] };
        case SET_AUDIO_DEVICES:
            return { ...state, audioDevices: action.payload as MediaDevice[] };
        default:
            return state;
    }
}

export function updateDevicesList() {
    return async (dispatch: Dispatch<AnyAction>) => {
        const { videoDevices = [], audioDevices = [] } = await camAndMicCheck();
        dispatch(setVideoDevices(videoDevices));
        dispatch(setAudioDevices(audioDevices));
    };
}
