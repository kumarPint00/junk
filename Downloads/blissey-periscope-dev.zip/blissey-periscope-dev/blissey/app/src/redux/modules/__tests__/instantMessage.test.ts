import * as instantMessage from '../instantMessage';
import { InstantMessageItemProps } from '@dexcare/instant-message';

describe('instantMessage module', () => {
    const initialState: instantMessage.TState = {
        waitingInstantMessages: [],
        videoInstantMessages: [],
        videoHasUnread: false,
        waitingRoomHasUnread: false,
    };

    describe('instantMessage', () => {
        test('initial state', () => {
            expect(
                instantMessage.reducer(undefined, {
                    type: '',
                    payload: undefined,
                } as unknown as instantMessage.Action),
            ).toEqual(initialState);
        });
        test('addWaitingRoomMessage - add new message', () => {
            const message: InstantMessageItemProps = {
                key: 'key1',
                content: 'text1',
                timeSent: 123,
                isOutgoing: true,
                senderName: 'Provider',
            };
            const newState = instantMessage.reducer(initialState, {
                type: instantMessage.actionTypes.ADD_WAITING_ROOM_MESSAGE,
                payload: message,
            } as instantMessage.Action);
            expect(newState.waitingInstantMessages).toEqual([message]);
        });
        test('addWaitingRoomMessage - change message on response to bot prompt', () => {
            const message: InstantMessageItemProps = {
                key: 'key1',
                content: 'text1',
                timeSent: 123,
                isOutgoing: true,
                senderName: 'Patient',
            };
            const newState = instantMessage.reducer(
                {
                    ...initialState,
                    waitingInstantMessages: [message],
                },
                {
                    type: instantMessage.actionTypes.ADD_WAITING_ROOM_MESSAGE,
                    payload: {
                        ...message,
                        botSelectedOption: 'option1',
                    },
                } as instantMessage.Action,
            );
            expect(newState.waitingInstantMessages).toEqual([
                {
                    ...message,
                    botSelectedOption: 'option1',
                },
            ]);
        });
        test('addWaitingRoomMessage - add duplicate message', () => {
            const message: InstantMessageItemProps = {
                key: 'key1',
                content: 'text1',
                timeSent: 123,
                isOutgoing: true,
                senderName: 'Provider',
            };
            const newState = instantMessage.reducer(
                {
                    ...initialState,
                    waitingInstantMessages: [message],
                },
                {
                    type: instantMessage.actionTypes.ADD_WAITING_ROOM_MESSAGE,
                    payload: message,
                } as instantMessage.Action,
            );
            expect(newState.waitingInstantMessages).toEqual([message]);
        });
        test('addVideoMessage - add new message', () => {
            const message: InstantMessageItemProps = {
                key: 'key1',
                content: 'text1',
                timeSent: 123,
                isOutgoing: true,
                senderName: 'Provider',
            };
            const newState = instantMessage.reducer(initialState, {
                type: instantMessage.actionTypes.ADD_VIDEO_MESSAGE,
                payload: message,
            } as instantMessage.Action);
            expect(newState.videoInstantMessages).toEqual([message]);
        });
        test('addVideoMessage - add duplicate message', () => {
            const message: InstantMessageItemProps = {
                key: 'key1',
                content: 'text1',
                timeSent: 123,
                isOutgoing: true,
                senderName: 'Provider',
            };
            const newState = instantMessage.reducer(
                {
                    ...initialState,
                    videoInstantMessages: [message],
                },
                {
                    type: instantMessage.actionTypes.ADD_VIDEO_MESSAGE,
                    payload: message,
                } as instantMessage.Action,
            );
            expect(newState.videoInstantMessages).toEqual([message]);
        });
        test('setVideoHasUnread', () => {
            const newState = instantMessage.reducer(initialState, {
                type: instantMessage.actionTypes.SET_VIDEO_HAS_UNREAD,
                payload: true,
            } as instantMessage.Action);
            expect(newState.videoHasUnread).toEqual(true);
        });
        test('setWaitingRoomHasUnread', () => {
            const newState = instantMessage.reducer(initialState, {
                type: instantMessage.actionTypes.SET_WAITING_ROOM_HAS_UNREAD,
                payload: true,
            } as instantMessage.Action);
            expect(newState.waitingRoomHasUnread).toEqual(true);
        });
    });
});
