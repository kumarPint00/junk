import thunk from '@redux/middleware/thunkShim';
import configureMockStore from 'redux-mock-store';

import {
    runTests,
    reducer,
    TState,
    updateProgress,
    wipeProgress,
    setNetworkStatus,
    setCamStatus,
    setMicStatus,
    setCamError,
    clearMicError,
    clearCamError,
    setPublishStatus,
    setMediaPermissionStatus,
    setMicError,
    MediaPermissionStatus,
} from '../health';
import { networkCheck, Publisher, TestStatus } from '@common/video';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { initialState as initialUserState } from '../userDetails';
import { initialState as initialPostconsultState } from '../postConsult';
import { initialState as userSettingsInitialState } from '../userSettings';
import { ErrorCode } from '@common/techCheckErrorMessages';
import { IActionWithPayload, actionCreator } from '@redux/helpers';
import { getFeatureFlag } from '@utils/FeatureFlags';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { Mocked, MockedFunction, vi } from 'vitest';
import { MockStoreType } from '../../../../src/types/redux';

type MockedSelfView = Mocked<typeof import('../selfView')>;
let selfViewMock: MockedSelfView;

vi.mock('@clients/VisitService/VisitServiceClient');
vi.mock('@common/video');
vi.mock('@redux/modules/selfView');
vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { interactionEvent: vi.fn() },
}));
vi.mock('@utils/FeatureFlags');
const mockGetFeatureFlag = getFeatureFlag as MockedFunction<
    typeof getFeatureFlag
>;

type MockedVideoLib = Mocked<typeof import('@common/video')>;
let mockVideoLib: MockedVideoLib;

type MockedVisitServiceClient = Mocked<
    typeof import('@clients/VisitService/VisitServiceClient')
>;
let mockVisitServiceClient: MockedVisitServiceClient;

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

const mockVideoDevice = {
    label: 'camera 1',
    value: 'val',
};
const mockAudioDevice = {
    label: 'mic 1',
    value: 'woot',
};

describe('health module', () => {
    beforeEach(async () => {
        mockVisitServiceClient = (await import(
            '@clients/VisitService/VisitServiceClient'
        )) as MockedVisitServiceClient;
        mockVisitServiceClient.visitServiceClient.getTestSession = vi
            .fn()
            .mockResolvedValue({
                apiKey: 'test-apiKey',
                sessionId: 'test-sessionId',
                token: 'test-token',
            });
    });
    describe('health', () => {
        let store: MockStoreType;
        let mockPublisher: Publisher;
        beforeEach(async () => {
            vi.clearAllMocks();
            selfViewMock = (await import('../selfView')) as MockedSelfView;
            mockVideoLib = (await import('@common/video')) as MockedVideoLib;
            mockPublisher = new mockVideoLib.Publisher({
                id: 'mockPublisher',
                callbacks: {},
            });
            selfViewMock.initSelfView.mockReturnValue(
                vi.fn().mockResolvedValue({
                    success: true,
                }),
            );
            (
                mockPublisher.initVideoElement as MockedFunction<
                    (typeof Publisher.prototype)['initVideoElement']
                >
            ).mockResolvedValue();
            mockVideoLib.camAndMicCheck.mockResolvedValue({
                hasCamera: true,
                hasMic: true,
                videoDevices: [mockVideoDevice],
                audioDevices: [mockAudioDevice],
            });
            mockVideoLib.networkCheck.mockResolvedValue({
                networkStatus: TestStatus.Passed,
            });
            store = mockStore({
                user: initialUserState,
                postconsult: initialPostconsultState,
                usersettings: userSettingsInitialState,
            });
        });
        it('dispatches success actions', async () => {
            await store.dispatch(runTests(mockPublisher));
            expect(store.getActions()).toMatchSnapshot();
        });
        it('sends waitingroomevent on success', async () => {
            await store.dispatch(runTests(mockPublisher));
            expect(networkCheck).toHaveBeenCalledTimes(1);
            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'pass',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'pass',
                    micStatus: 'pass',
                    networkStatus: 'pass',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'media_permission_check',
                visit_id: '',
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'camera_check',
                visit_id: '',
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'mic_check',
                visit_id: '',
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_complete',
                visit_id: '',
            });
        });
        it('fails on no test session', async () => {
            mockVisitServiceClient.visitServiceClient.getTestSession = vi
                .fn()
                .mockResolvedValue(null);
            await store.dispatch(runTests(mockPublisher));

            expect(store.getActions()).toMatchSnapshot();
            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'fail',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'pass',
                    micStatus: 'pass',
                    networkStatus: 'fail',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_fail',
                visit_id: '',
            });
        });
        it('fails on no cam', async () => {
            mockVideoLib.camAndMicCheck.mockResolvedValue({
                hasCamera: false,
                hasMic: true,
                videoDevices: [],
                audioDevices: [mockAudioDevice],
            });
            await store.dispatch(runTests(mockPublisher));

            expect(store.getActions()).toMatchSnapshot();
            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'fail',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'fail',
                    micStatus: 'pass',
                    networkStatus: 'pass',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_fail',
                visit_id: '',
            });
        });
        it('fails on no mic', async () => {
            mockVideoLib.camAndMicCheck.mockResolvedValue({
                hasCamera: true,
                hasMic: false,
                videoDevices: [mockVideoDevice],
                audioDevices: [],
            });
            await store.dispatch(runTests(mockPublisher));

            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'fail',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'pass',
                    micStatus: 'fail',
                    networkStatus: 'pass',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_fail',
                visit_id: '',
            });
        });
        it('fails on initSelfView total failure', async () => {
            selfViewMock.initSelfView.mockReturnValue(
                vi.fn().mockResolvedValue({
                    success: false,
                }),
            );
            await store.dispatch(runTests(mockPublisher));

            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'fail',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'fail',
                    micStatus: 'fail',
                    networkStatus: 'pass',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_fail',
                visit_id: '',
            });
        });
        it('fails on initSelfView cam failure but shows mic as success', async () => {
            selfViewMock.initSelfView.mockReturnValue(
                vi
                    .fn()
                    .mockResolvedValueOnce({
                        success: false,
                        error: 'error',
                    })
                    .mockResolvedValueOnce({
                        sucess: false,
                        error: 'cam error',
                    })
                    .mockResolvedValueOnce({
                        success: true,
                    }),
            );
            await store.dispatch(runTests(mockPublisher));

            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'fail',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'fail',
                    micStatus: 'pass',
                    networkStatus: 'pass',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_fail',
                visit_id: '',
            });
        });
        it('fails on initSelfView mic failure but shows cam as success', async () => {
            selfViewMock.initSelfView.mockReturnValue(
                vi
                    .fn()
                    .mockResolvedValueOnce({
                        success: false,
                        error: 'error',
                    })
                    .mockResolvedValueOnce({
                        success: true,
                    })
                    .mockResolvedValueOnce({
                        sucess: false,
                        error: 'mic error',
                    }),
            );
            await store.dispatch(runTests(mockPublisher));

            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'fail',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'pass',
                    micStatus: 'fail',
                    networkStatus: 'pass',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_fail',
                visit_id: '',
            });
        });
        it('fails on mediaPermissions denied', async () => {
            selfViewMock.initSelfView.mockReturnValue(
                vi.fn().mockResolvedValue({
                    success: false,
                    error: ErrorCode.mediaAccessDenied,
                }),
            );
            await store.dispatch(runTests(mockPublisher));

            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'fail',
                    mediaPermissionStatus: 'fail',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_fail',
                visit_id: '',
            });
        });
        it('fails on network test failure', async () => {
            selfViewMock.initSelfView.mockReturnValue(
                vi.fn().mockResolvedValueOnce({ success: true }),
            );
            mockVideoLib.networkCheck.mockResolvedValue({
                networkStatus: TestStatus.Failed,
            });
            await store.dispatch(runTests(mockPublisher));

            expect(networkCheck).toHaveBeenCalledTimes(2);
            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'fail',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'pass',
                    micStatus: 'pass',
                    networkStatus: 'fail',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_fail',
                visit_id: '',
            });
        });
        it('succeeds if second network test failure succeeds', async () => {
            selfViewMock.initSelfView.mockReturnValue(
                vi.fn().mockResolvedValueOnce({ success: true }),
            );
            mockVideoLib.networkCheck.mockResolvedValueOnce({
                networkStatus: TestStatus.Failed,
            });
            mockVideoLib.networkCheck.mockResolvedValueOnce({
                networkStatus: TestStatus.Passed,
            });
            await store.dispatch(runTests(mockPublisher));

            expect(networkCheck).toHaveBeenCalledTimes(2);
            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'pass',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'pass',
                    micStatus: 'pass',
                    networkStatus: 'pass',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'media_permission_check',
                visit_id: '',
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'camera_check',
                visit_id: '',
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'mic_check',
                visit_id: '',
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'tech_check_complete',
                visit_id: '',
            });
        });

        // ENG-1885
        it('succeeds when logging error occurred', async () => {
            selfViewMock.initSelfView.mockReturnValue(
                vi.fn().mockResolvedValueOnce({ success: true }),
            );
            mockVideoLib.networkCheck.mockResolvedValueOnce({
                networkStatus: TestStatus.Failed,
                error: {
                    camError: false,
                    micError: false,
                    mediaPermissionsError: false,
                    unknownError: false,
                    connectionError: false,
                    publishError: false,
                    loggingServerError: true,
                },
            });
            await store.dispatch(runTests(mockPublisher));

            expect(mockVideoLib.networkCheck).toHaveBeenCalledTimes(1);
            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'pass',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'pass',
                    micStatus: 'pass',
                    networkStatus: 'pass',
                },
            });
        });

        // ENG-1885
        it('fails when logging error flag true and multiple errors occrueda', async () => {
            mockGetFeatureFlag.mockReturnValueOnce(true);
            mockGetFeatureFlag.mockReturnValueOnce(true);

            selfViewMock.initSelfView.mockReturnValue(
                vi.fn().mockResolvedValueOnce({ success: true }),
            );
            mockVideoLib.networkCheck.mockResolvedValueOnce({
                networkStatus: TestStatus.Failed,
                error: {
                    camError: false,
                    micError: false,
                    mediaPermissionsError: false,
                    unknownError: false,
                    connectionError: false,
                    publishError: true,
                    loggingServerError: true,
                },
            });
            mockVideoLib.networkCheck.mockResolvedValueOnce({
                networkStatus: TestStatus.Failed,
                error: {
                    camError: false,
                    micError: false,
                    mediaPermissionsError: false,
                    unknownError: false,
                    connectionError: false,
                    publishError: true,
                    loggingServerError: true,
                },
            });
            await store.dispatch(runTests(mockPublisher));

            expect(mockVideoLib.networkCheck).toHaveBeenCalledTimes(2);
            expect(
                visitServiceClient.sendWaitingRoomEvent,
            ).toHaveBeenCalledWith('', {
                techCheck: {
                    status: 'fail',
                    mediaPermissionStatus: 'pass',
                    camStatus: 'pass',
                    micStatus: 'pass',
                    networkStatus: 'fail',
                },
            });
        });
    });

    describe('reducer', () => {
        const getInitialState = (): TState => ({
            healthCheckProgress: 0,
            networkStatus: TestStatus.NotRun,
            camStatus: TestStatus.NotRun,
            micStatus: TestStatus.NotRun,
            mediaPermissionStatus: undefined,
            // TODO: move this to selfView
            publishStatus: TestStatus.NotRun,
        });

        it('should return current state for unknown action', () => {
            const initialState = getInitialState();
            const action = actionCreator<TestStatus>('not_real_action')(
                TestStatus.Failed,
            );
            const result = reducer(initialState, action);
            expect(result).toMatchSnapshot();
        });

        it.each([
            ['updateProgress', updateProgress(20)],
            ['wipeProgress', wipeProgress()],
            ['setNetworkStatus', setNetworkStatus(TestStatus.Passed)],
            ['setCamStatus', setCamStatus(TestStatus.Passed)],
            ['setMicStatus', setMicStatus(TestStatus.Passed)],
            ['setCamError', setCamError(ErrorCode.mediaAccessDenied)],
            ['setMicError', setMicError(ErrorCode.mediaAccessDenied)],
            ['clearMicError', clearMicError()],
            ['clearCamError', clearCamError()],
            ['setPublishStatus', setPublishStatus(TestStatus.Passed)],
            ['setMediaPermissionStatus', setMediaPermissionStatus('denied')],
        ])(
            'returns updated state for action "%s"',
            (_, action: IActionWithPayload<MediaPermissionStatus>) => {
                const initialState = getInitialState();
                const result = reducer(initialState, action);
                expect(result).toMatchSnapshot();
            },
        );
    });
});
