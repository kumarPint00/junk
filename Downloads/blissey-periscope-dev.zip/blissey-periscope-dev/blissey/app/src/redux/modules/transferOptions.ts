import { TransferOptions } from '@clients/VisitService/VisitInterfaces';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { actionCreator, actionCreatorVoid, BlisseyDispatch } from '../helpers';
import { BlisseyLogger as Logger } from '@utils/Logger';

// Action Types
const SET_TRANSFER_OPTIONS = 'transferOptions/SET_TRANSFER_OPTIONS';
const SET_LOADING_TRANSFER_OPTIONS =
    'transferOptions/SET_LOADING_TRANSFER_OPTIONS';
const SET_TRANSFER_OPTIONS_ERROR = 'transferOptions/SET_TRANSFER_OPTIONS_ERROR';

export const actionTypes = {
    SET_TRANSFER_OPTIONS,
    SET_LOADING_TRANSFER_OPTIONS,
    SET_TRANSFER_OPTIONS_ERROR,
};

// Action creators
export const setTransferOptions =
    actionCreator<TransferOptions>(SET_TRANSFER_OPTIONS);
export const setLoadingTransferOptions = actionCreatorVoid(
    SET_LOADING_TRANSFER_OPTIONS,
);
export const setTransferOptionsError = actionCreator<unknown>(
    SET_TRANSFER_OPTIONS_ERROR,
);

type TransferOptionsActions =
    | ReturnType<typeof setTransferOptions>
    | ReturnType<typeof setLoadingTransferOptions>
    | ReturnType<typeof setTransferOptionsError>;

export type TransferOptionsState = TransferOptions & {
    loading: boolean;
    error?: Error;
};

export const getTransferOptions = (visitId: string) => {
    return async (dispatch: BlisseyDispatch) => {
        dispatch(setLoadingTransferOptions());

        try {
            const transferOptions: TransferOptions =
                await visitServiceClient.getTransferOptions(visitId);
            dispatch(setTransferOptions(transferOptions));
        } catch (err: unknown) {
            Logger.error(
                { error: err, visitId },
                'error fetching transfer options',
            );
            dispatch(setTransferOptionsError(err));
        }
    };
};

export const initialTransferOptionsState: TransferOptionsState = {
    loading: false,
    error: undefined,
    providers: [],
    practiceRegions: [],
};

type TransferOptionsReducerFunction = (
    state: TransferOptionsState,
    action: TransferOptionsActions,
) => TransferOptionsState;

const reducerMap: Record<string, TransferOptionsReducerFunction> = {
    [SET_LOADING_TRANSFER_OPTIONS]: (state) =>
        Object.assign({}, state, {
            loading: true,
        }),
    [SET_TRANSFER_OPTIONS]: (
        state,
        action: ReturnType<typeof setTransferOptions>,
    ) => {
        const {
            payload: { providers, practiceRegions },
        } = action;
        return Object.assign({}, state, {
            providers,
            practiceRegions,
            loading: false,
            error: undefined,
        });
    },
    [SET_TRANSFER_OPTIONS_ERROR]: (
        state,
        action: ReturnType<typeof setTransferOptionsError>,
    ) =>
        Object.assign({}, state, {
            loading: false,
            error: action.payload as Error,
            providers: [],
            practiceRegions: [],
        }),
};

export function reducer(
    state = initialTransferOptionsState,
    action: TransferOptionsActions,
) {
    return typeof reducerMap[action.type as string] === 'function'
        ? reducerMap[action.type as string](state, action)
        : state;
}
