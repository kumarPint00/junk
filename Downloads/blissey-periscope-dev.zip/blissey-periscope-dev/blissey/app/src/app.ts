import { backendFacade } from './clients/Backend/BackendFacade';
import { parsePatientAccessCodeFromUrl } from './utils';

export async function recoverGuestSessionFromAccessCode(location: Location) {
    const accessCode = parsePatientAccessCodeFromUrl(location);
    if (accessCode?.length) {
        await backendFacade.recoverGuestSession(accessCode);
    }
}
