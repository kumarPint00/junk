import * as React from 'react';
import { Helmet } from 'react-helmet';

interface Props {
    siteTitle: string;
    favicon: string;
    reasons: unknown;
    children?: React.ReactNode;
}

export class UserNotAuthenticated extends React.Component<Props> {
    constructor(props: Props) {
        super(props);
    }

    public render() {
        const { siteTitle, favicon } = this.props;
        return (
            <>
                <Helmet>
                    <title>{siteTitle}</title>
                    <link rel="icon" type="image/png" href={favicon} />
                    <meta
                        name="viewport"
                        content="width=device-width, user-scalable=no"
                    />
                </Helmet>
                {this.props.children}
            </>
        );
    }
}

export default UserNotAuthenticated;
