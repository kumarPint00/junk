import * as React from 'react';
import { Helmet } from 'react-helmet';
import { config } from '@dexcare/circus-jupiter';

import { LogManager, Logger } from '@dexcare/circus-jupiter';
import * as conferenceErrorMessage from '@common/ConferenceErrorMessage';
import { OwnProps } from './AppStageContainerInterfaces';
import { Configuration } from 'types/configuration';
import { addBrowserActivityAnalyticsListeners } from '@services/analytics';

export class AppStageContainer extends React.Component<OwnProps> {
    private logger: Logger;

    constructor(props: OwnProps) {
        super(props);

        this.logger = LogManager.getLogger().child({
            eventSource: 'AppStageContainer',
            userId: this.props.user.id,
        });

        addBrowserActivityAnalyticsListeners();
    }

    public render() {
        return (
            <>
                <Helmet>
                    <title>
                        {(config as Configuration).getConfig().siteTitle}
                    </title>
                    <link
                        rel="icon"
                        type="image/png"
                        href={(config as Configuration).getConfig().favicon}
                    />
                    <meta
                        name="viewport"
                        content="width=device-width, user-scalable=no"
                    />
                </Helmet>
                {this.props.children}
            </>
        );
    }

    public componentDidMount() {
        conferenceErrorMessage.init();
        this.logger.info({ eventName: 'constructor' }, 'Starting up the app');
    }
}

export default AppStageContainer;
