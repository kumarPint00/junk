import { PropsWithChildren } from 'react';
import { UserDetails } from 'types/UserDetails';

export type OwnProps = PropsWithChildren<{
    user: UserDetails;
    brand?: string;
}>;
