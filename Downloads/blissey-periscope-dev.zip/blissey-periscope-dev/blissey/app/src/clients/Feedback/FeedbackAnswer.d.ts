export interface FeedbackAnswer {
    id: string;
    text?: string;
    type: FeedbackQuestionType;
    value: string | boolean | number | undefined;
}
