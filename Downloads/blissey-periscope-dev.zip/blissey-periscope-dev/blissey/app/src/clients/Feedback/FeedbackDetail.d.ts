import { FeedbackQuestion } from './FeedbackQuestion';

export interface FeedbackDetail {
    feedbackId?: string;
    appId: string;
    appVersion?: string;
    appHostEnvironment?: string;
    userIdentifier: string;
    conferenceId: string;
    conferenceSessionId: string;
    visitId: string;
    userDisplayName: string;
    userRole: string;
    startTime: string;
    endTime: string;
    feedbacks?: FeedbackQuestion[];
    rating: number;
}
