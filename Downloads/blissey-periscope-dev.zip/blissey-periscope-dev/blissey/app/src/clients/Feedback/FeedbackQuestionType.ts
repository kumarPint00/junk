export enum FeedbackQuestionType {
    MultipleChoice = 'choice',
    Text = 'string',
    Number = 'number',
    Boolean = 'boolean',
}
