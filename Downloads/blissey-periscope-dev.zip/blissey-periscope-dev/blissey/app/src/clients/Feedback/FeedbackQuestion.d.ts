import { FeedbackAnswer } from './FeedbackAnswer';
import { FeedbackQuestionType } from './FeedbackQuestionType';

export interface FeedbackQuestion {
    id: string;
    text: string;
    type: FeedbackQuestionType;
    answers: FeedbackAnswer[];
}
