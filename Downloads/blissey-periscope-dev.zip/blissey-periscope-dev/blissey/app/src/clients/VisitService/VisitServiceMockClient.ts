import { VisitDetails } from './VisitInterfaces';

/**
 * This class allows you to mock the scheduling API when testing locally
 * removing the dependency on the external services.
 * Update postconsult.ts to import the mock client by adding the following line
 * import { visitServiceMockClient } from '@clients/VisitService/VisitServiceMockClient';
 * and the change the visitServiceClient to visitServiceMockClient for this method fetchVisitDetailsByVisitId
 */
class VisitServiceMockClient {
    public async getVisitSummary(
        visitId: string,
    ): Promise<Partial<VisitDetails>> {
        console.warn('VisitServiceClient: MOCK CLIENT IS BEING USED');

        return new Promise((resolve) => {
            const result: Partial<VisitDetails> = {
                waitingConferenceId: '9UqDEwg9',
                videoConferenceId: '9UqDnNDr',
                visitId,
                visitStatus: 'requested',
                patientGuid: 'mockPatientGuid',
                providerId: 'mockProviderId',
                practiceId: 'mockPracticeId',
                integrations: {
                    tytoCare: {
                        enabled: false,
                    },
                },
                timestamps: {
                    cancelled: '2021-03-03T23:49:50.655Z',
                    caregiverassigned: '2021-03-03T23:49:50.655Z',
                    created: '2021-03-03T23:49:50.655Z',
                    done: '2021-03-03T23:49:50.655Z',
                    invisit: '2021-03-03T23:49:50.655Z',
                    requested: '2021-03-03T23:49:50.655Z',
                    staffdeclined: '2021-03-03T23:49:50.655Z',
                    waitingroom: '2021-03-03T23:49:50.655Z',
                    waitoffline: '2021-03-03T23:49:50.655Z',
                },
            };
            return resolve(result);
        });
    }
}

export const visitServiceMockClient = new VisitServiceMockClient();
