import 'whatwg-fetch';

import { config } from '@dexcare/circus-jupiter';
import { FeedbackDetail } from '@clients/Feedback/FeedbackDetail';
import { createCorrelationId } from '@utils/requestUtils';
import {
    VisitDetails,
    VisitStatus,
    VisitResponseV9,
    TransferOptions,
    PatientEnterWaitOffline,
    PostVisitSurvey,
} from './VisitInterfaces';
import { BlisseyLogger } from '@utils/Logger';
import { Configuration } from 'types/configuration';
import { authHeaders, getStandardHeaders } from '@utils/auth';
import { ReasonData } from 'data/VisitReasons';
import { VisitParticipantType } from '@dexcare/visit-participants';

export const VisitServiceV1Actions = {
    PatientEnterWaitOffline: 'patientEnterWaitOffline',
};

export interface TestSessionInfo {
    readonly apiKey: string;
    readonly sessionId: string;
    readonly token: string;
}

export type TechCheckStatus = 'pass' | 'fail';
export interface TechCheckResults {
    status: TechCheckStatus;
    camStatus?: TechCheckStatus;
    micStatus?: TechCheckStatus;
    networkStatus?: TechCheckStatus;
    mediaPermissionStatus?: TechCheckStatus;
}
export interface WaitTime {
    estimatedWaitTimeSeconds: number;
    estimatedWaitTimeMessage: string;
    estimateGeneratedAt: string;
    waitTimeLocalizationInfo: {
        waitTimeMapKey: string;
        timeMinSeconds?: number;
        timeMaxSeconds?: number;
        modality: string;
    };
}

export interface VisitServiceV6SavePatientChatMessageBody {
    type: 'botPromptMessage';
    data: {
        fromParticipant: string;
        senderId: string;
        creationTime: string;
        uniqueId: string;
        prompt: string;
        selectedOption?: string;
    };
}

const visitServiceProxyBaseUri = '/proxy' as const;

export class VisitServiceClient {
    private visitServiceUrl: string;
    private getSvcCallBaseUri = () => {
        if (this.sharedSessionStoreEnabled) {
            return visitServiceProxyBaseUri;
        }

        if (!this.visitServiceUrl) {
            this.visitServiceUrl = (
                config as Configuration
            ).getConfig().atHomeVisitServer;
        }
        return this.visitServiceUrl;
    };

    constructor(private sharedSessionStoreEnabled = false) {}

    public async startTytoCareVisit(
        visitId: string,
    ): Promise<{ tytoCare: { visitUrl: string } }> {
        const correlationId = createCorrelationId();
        return fetch(
            `${this.getSvcCallBaseUri()}/api/8/visits/${visitId}/integrations/tytoCare`,
            {
                method: 'POST',
                headers: getStandardHeaders({
                    correlationId,
                    sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
                }),
            },
        )
            .then(this.checkStatus(correlationId))
            .then(async (response) =>
                this.parseJSON<{ tytoCare: { visitUrl: string } }>(response),
            );
    }

    public async generateTytoCareQRCode(
        visitId: string,
        domain: string,
    ): Promise<{
        tytoCare: {
            pairingDetails: object;
        };
    }> {
        const correlationId = createCorrelationId();
        return fetch(
            `${this.getSvcCallBaseUri()}/api/8/visits/${visitId}/integrations/tytoCare/devices`,
            {
                method: 'POST',
                headers: {
                    ...getStandardHeaders({
                        correlationId,
                        sharedSessionStoreEnabled:
                            this.sharedSessionStoreEnabled,
                    }),
                    domain,
                },
            },
        )
            .then(this.checkStatus(correlationId))
            .then(async (response) =>
                this.parseJSON<{ tytoCare: { pairingDetails: object } }>(
                    response,
                ),
            );
    }

    // NOTE: https://github.com/DexCare/visit-service/blob/96d9f2922c9928548ce413fdee6b6f11a8f39568/charts/visit-service/values.yaml#L153
    public async getTestSession(): Promise<TestSessionInfo> {
        const correlationId = createCorrelationId();
        return fetch(
            `${this.getSvcCallBaseUri()}/api/6/visits/virtual/connectiontest`,
            {
                headers: {
                    correlationId: createCorrelationId(),
                },
            },
        )
            .then(this.checkStatus(correlationId))
            .then(async (response) =>
                this.parseJSON<TestSessionInfo>(response),
            );
    }

    public async sendWaitingRoomEvent(
        visitId: string,
        event: {
            techCheck: TechCheckResults;
        },
    ): Promise<Response> {
        const correlationId = createCorrelationId();
        return fetch(
            `${this.getSvcCallBaseUri()}/api/8/visits/virtual/${visitId}/waitingRoomEvents`,
            {
                method: 'POST',
                body: JSON.stringify({ ...event }),
                headers: getStandardHeaders({
                    correlationId,
                    sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
                }),
            },
        ).then(this.checkStatus(correlationId));
        // 202 no body response
    }

    public async generateTokboxPatientToken(
        sessionId: string,
        visitId: string,
    ): Promise<{ token: string }> {
        const correlationId = createCorrelationId();
        return fetch(
            `${this.getSvcCallBaseUri()}/api/6/visit/${visitId}/token/${sessionId}`,
            {
                method: 'GET',
                headers: getStandardHeaders({
                    correlationId,
                    sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
                }),
            },
        )
            .then(this.checkStatus(correlationId))
            .then(async (response) =>
                this.parseJSON<{ token: string }>(response),
            );
    }

    public async waiveVisit(
        visitId: string,
        waiveReason: string,
    ): Promise<unknown> {
        const correlationId = createCorrelationId();
        return fetch(
            `${this.getSvcCallBaseUri()}/api/8/visits/virtual/waive/${visitId}`,
            {
                method: 'POST',
                body: JSON.stringify({ waiveReason }),
                headers: getStandardHeaders({
                    correlationId,
                    sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
                }),
            },
        ).then(this.checkStatus(correlationId));
        // 202 no body response
    }

    public async chargeVisit(visitId: string): Promise<unknown> {
        const correlationId = createCorrelationId();
        return fetch(
            `${this.getSvcCallBaseUri()}/api/8/visits/virtual/charge/${visitId}`,
            {
                method: 'POST',
                headers: getStandardHeaders({
                    correlationId,
                    sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
                }),
            },
        ).then(this.checkStatus(correlationId));
        // 202 no body response
    }

    public getWaitTimeEstimateV9 = async (
        visitId: string,
    ): Promise<WaitTime | null> => {
        const correlationId = createCorrelationId();
        return fetch(
            `${this.getSvcCallBaseUri()}/api/9/visits/${visitId}/waittime`,
            {
                method: 'GET',
                headers: getStandardHeaders({
                    correlationId,
                    sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
                }),
            },
        )
            .then(this.checkStatus(correlationId))
            .then(async (response) =>
                this.parseJSON<WaitTime | null>(response),
            );
    };

    // TODO Change to use kong endpoint instead of going thru blissey server
    public async saveFeedback(
        visitId: string,
        feedback: FeedbackDetail,
    ): Promise<void> {
        const correlationId = createCorrelationId();
        await fetch(`/feedback?visitId=${visitId}`, {
            method: 'POST',
            body: JSON.stringify(feedback),
            headers: {
                ...authHeaders(this.sharedSessionStoreEnabled),
                'Content-Type': 'application/json; charset=utf-8',
                'correlation-id': correlationId,
            },
        }).then(this.checkStatus(correlationId));
        // Don't parse response, it's a 204
    }

    public getChatUrl(
        isProvider: boolean,
        visitId: string,
        sessionId: string,
    ): string {
        // TODO: align public urls: DC-4445
        return isProvider
            ? `/providerChat?sessionId=${sessionId}&visitId=${visitId}`
            : `${this.getSvcCallBaseUri()}/api/6/visit/${visitId}/chat/${sessionId}`;
    }

    public async cancelVisit(visitId: string): Promise<void> {
        const visitCancelUrl = `${this.getSvcCallBaseUri()}/api/9/visits/virtual/${visitId}/cancel`;
        const correlationId = createCorrelationId();

        await fetch(visitCancelUrl, {
            method: 'POST',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
        }).then(this.checkStatus(correlationId));
        // Don't parse response, it's a 204
    }

    public async cancelPhoneWithReason(
        visitId: string,
        reason: string,
        email: string,
    ): Promise<void> {
        const url = `${this.getSvcCallBaseUri()}/v1/visits/${visitId}/patient-cancel-phone`;
        const correlationId = createCorrelationId();

        const callOptions = {
            method: 'POST',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
            body: JSON.stringify({
                cancelReason: reason,
                patientEmail: email,
            }),
        };

        const logger = BlisseyLogger.child({
            module: 'VisitServiceClient',
            action: 'cancelPhoneWithReason',
            callOptions,
        });
        logger.info('calling cancel phone visit with reason');

        await fetch(url, callOptions);
        this.checkStatus(correlationId);
    }

    public async cancelVideoWithReason(
        visitId: string,
        reason: string,
    ): Promise<void> {
        const url = `${this.getSvcCallBaseUri()}/v1/visits/${visitId}/patient-cancel-video`;
        const correlationId = createCorrelationId();

        const callOptions = {
            method: 'POST',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
                ...authHeaders(this.sharedSessionStoreEnabled),
            }),
            body: JSON.stringify({
                cancelReason: reason,
            }),
        };

        const logger = BlisseyLogger.child({
            module: 'VisitServiceClient',
            action: 'cancelVideoWithReason',
            callOptions,
        });
        logger.info('calling cancel video visit with reason');

        await fetch(url, callOptions);
        this.checkStatus(correlationId);
    }

    public async getVisitStatus(visitId: string): Promise<string> {
        const correlationId = createCorrelationId();
        const url = `${this.getSvcCallBaseUri()}/v1/visits/${visitId}/visit-status`;
        const options = {
            method: 'GET',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
        };

        try {
            const response = await fetch(url, options);
            await this.checkStatus(correlationId)(response);
            const statusObject = (await response.json()) as { status: string };
            return statusObject.status;
        } catch (err) {
            return Promise.reject(
                err instanceof Error ? err : new Error(String(err)),
            );
        }
    }

    public async getVisitSummary(
        visitId: string,
        transform: boolean = true,
    ): Promise<VisitDetails | VisitResponseV9> {
        const correlationId = createCorrelationId();
        const url = `${this.getSvcCallBaseUri()}/api/9/visits/${visitId}/summary`;
        const options = {
            method: 'GET',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
        };

        const logger = BlisseyLogger.child({
            module: 'VisitServiceClient',
            action: 'getVisitSummary',
            url,
            options,
        });
        logger.info('Fetching visit summary');

        return fetch(url, options)
            .then(this.checkStatus(correlationId))
            .then(this.parseJSON)
            .then(async (responseJson: VisitResponseV9) => {
                const visitDetails = transform
                    ? this.transformVisitSummaryV9(responseJson)
                    : responseJson;
                logger.info({ visitDetails, transform }, 'got visit summary');
                return Promise.resolve(visitDetails);
            })
            .catch(async (error: Error) => {
                return Promise.reject(error);
            });
    }

    /**
     * Get transfer options
     * @param visitId
     * @returns TransferOptions
     */
    public async getTransferOptions(visitId: string): Promise<TransferOptions> {
        const correlationId = createCorrelationId();
        const url = `${this.getSvcCallBaseUri()}/v1/visits/${visitId}/transfer-options`;
        const options = {
            method: 'GET',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
        };
        const logger = BlisseyLogger.child({
            module: 'VisitServiceClient',
            action: 'getTransferOptions',
            url,
            options,
        });
        logger.info('Fetching transfer options');
        return fetch(url, options)
            .then(this.checkStatus(correlationId))
            .then(async (response) =>
                this.parseJSON<TransferOptions>(response),
            );
    }

    public async acceptConsentTerms(visitId: string): Promise<void> {
        const correlationId = createCorrelationId();
        const url = `${this.getSvcCallBaseUri()}/api/9/visits/${visitId}/acceptTerms`;

        return fetch(url, {
            method: 'PUT',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
        })
            .then(this.checkStatus(correlationId))
            .then(async () => {
                return Promise.resolve();
            })
            .catch(async (error: Error) => {
                return Promise.reject(error);
            });
    }

    public async patientEnterWaitOffline({
        visitId,
        practiceId,
        sessionId,
    }: PatientEnterWaitOffline): Promise<void> {
        const correlationId = createCorrelationId();
        const url = `${this.getSvcCallBaseUri()}/v1/visits/event`;

        const logger = BlisseyLogger.child({
            module: 'VisitServiceClient',
            action: VisitServiceV1Actions.PatientEnterWaitOffline,
            visitId,
            practiceId,
            sessionId,
        });
        logger.info('patient entering waitoffline');

        await fetch(url, {
            method: 'POST',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
            body: JSON.stringify({
                action: VisitServiceV1Actions.PatientEnterWaitOffline,
                data: {
                    visitId,
                    practiceId,
                    sessionId,
                },
            }),
        }).then(this.checkStatus(correlationId));
    }

    public async savePatientChatMessage(
        visitId: string,
        sessionId: string,
        message: VisitServiceV6SavePatientChatMessageBody,
    ): Promise<void | Response> {
        const correlationId = createCorrelationId();
        const chatUrl = this.getChatUrl(false, visitId, sessionId);
        return fetch(chatUrl, {
            method: 'POST',
            body: JSON.stringify(message),
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
                ...authHeaders(this.sharedSessionStoreEnabled),
            }),
        }).then(this.checkStatus(correlationId));
    }

    public async cacheInstantMessage(
        visitId: string,
        sessionId: string,
        instantMessage: object,
        isProvider?: boolean,
    ): Promise<void | Response> {
        const correlationId = createCorrelationId();
        const chatUrl = this.getChatUrl(!!isProvider, visitId, sessionId);

        return fetch(chatUrl, {
            method: 'POST',
            body: JSON.stringify({
                type: 'instantMessage',
                data: instantMessage,
            }),
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
        }).then(this.checkStatus(correlationId));
    }

    private checkStatus(correlationId: string) {
        return async (response: Response) => {
            if (response.status >= 200 && response.status < 400) {
                return response;
            } else {
                let errorMessage = response.statusText;
                let errorJson;
                try {
                    errorJson = (await response.json()) as object;
                } catch (error) {
                    BlisseyLogger.warn(
                        {
                            details: JSON.stringify(error),
                            correlationId,
                        },
                        'error parsing response',
                    );
                }

                errorMessage =
                    (errorJson as { [key: string]: string })?.error ||
                    errorMessage;
                BlisseyLogger.error(
                    {
                        correlationId,
                        details: {
                            message: errorMessage,
                            error: errorJson || 'unknown error',
                            status: response.status,
                        },
                    },
                    'fetch error',
                );
                throw new Error(errorMessage);
            }
        };
    }

    private parseJSON = async <T>(response: Response): Promise<T> => {
        return response.json() as Promise<T>;
    };

    private transformVisitSummaryV9(
        visitResponse: VisitResponseV9,
    ): VisitDetails {
        const {
            visitId,
            status,
            patientGuid,
            providerId,
            tokBoxVisit,
            integrations,
            acceptTerms,
            timestamps,
            practiceId,
            modality,
            origin,
            traveling,
            brand,
            deviceModel,
        } = visitResponse;

        return {
            waitingConferenceId: '', // not available in v9, not actually being used in this call except for logger so OK to use blank
            videoConferenceId: '', // not available in v9, not actually being used in this call except for logger, so OK to use blank
            visitId,
            isTokBox: true, // legacy flag not available in v9, always true for new visits; for legacy visits will let this check pass and move on to check sessionId within tokBoxVisit. TODO: will remove after fully migrated to v9
            tokBoxVisit,
            visitStatus: status as VisitStatus,
            integrations,
            patientGuid,
            providerId,
            acceptTerms,
            timestamps,
            practiceId,
            modality,
            origin,
            traveling,
            brand,
            deviceModel,
        };
    }

    /**
     * get latest post visit survey
     * @param surveyType
     * @returns the latest survey defintion
     */
    public async getLatestSurvey(surveyType: string): Promise<PostVisitSurvey> {
        const correlationId = createCorrelationId();
        const url = `/survey/${surveyType}`;
        const options = {
            method: 'GET',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
        };
        const logger = BlisseyLogger.child({
            module: 'VisitServiceClient',
            action: 'getLatestSurvey',
            url,
            options,
        });
        logger.info('Fetching latest survey');
        return fetch(url, options)
            .then(this.checkStatus(correlationId))
            .then(async (response) =>
                this.parseJSON<PostVisitSurvey>(response),
            );
    }

    public async submitSurveyResponse(
        visitId: string,
        userRole: string,
        surveyResponse: object,
        surveyId: string,
    ): Promise<void> {
        const correlationId = createCorrelationId();
        const url = '/survey-response';

        const options = {
            method: 'POST',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: false,
            }),
            body: JSON.stringify({
                surveyId,
                userRole,
                visitId,
                surveyResponse,
            }),
        };
        const logger = BlisseyLogger.child({
            module: 'VisitServiceClient',
            action: 'submitSurveyResponse',
            url,
            options,
        });
        logger.info('Submitting survey response');
        return fetch(url, options)
            .then(this.checkStatus(correlationId))
            .then(async () => {
                return Promise.resolve();
            })
            .catch(async (error: Error) => {
                return Promise.reject(error);
            });
    }

    public async getReasons(): Promise<ReasonData> {
        const correlationId = createCorrelationId();
        const url = `${this.getSvcCallBaseUri()}/v1/reference/reasons`;
        const options = {
            method: 'GET',
            headers: getStandardHeaders({
                correlationId,
                sharedSessionStoreEnabled: this.sharedSessionStoreEnabled,
            }),
        };

        const logger = BlisseyLogger.child({
            module: 'VisitServiceClient',
            action: 'getReasons',
            url,
            options,
        });
        logger.info('Fetching reasons');

        return fetch(url, options)
            .then(this.checkStatus(correlationId))
            .then(this.parseJSON)
            .then(async (responseJson: ReasonData) =>
                Promise.resolve(responseJson),
            )
            .catch(async (error: Error) => {
                return Promise.reject(error);
            });
    }

    public async getParticipantTypes(): Promise<VisitParticipantType[]> {
        const correlationId = createCorrelationId();
        const url = `${this.getSvcCallBaseUri()}/v1/internal/participant-types`;
        const options = {
            method: 'GET',
            headers: getStandardHeaders({
                correlationId,
                ...authHeaders(this.sharedSessionStoreEnabled),
            }),
        };

        const logger = BlisseyLogger.child({
            module: 'VisitServiceClient',
            action: 'getParticipantTypes',
            url,
            options,
        });
        logger.debug('Fetching participant types');

        return fetch(url, options)
            .then(this.checkStatus(correlationId))
            .then(this.parseJSON)
            .then(async (responseJson: VisitParticipantType[]) =>
                Promise.resolve(responseJson),
            )
            .catch(async (error: Error) => {
                return Promise.reject(error);
            });
    }
}

export let visitServiceClient = new VisitServiceClient();

export const initVisitServiceClient = ({
    sharedSessionStoreEnabled,
}: {
    sharedSessionStoreEnabled: boolean;
}) => {
    visitServiceClient = new VisitServiceClient(sharedSessionStoreEnabled);
};

/**
 * Mockable getter so that this client can be properly mocked in tests
 */
export const getVisitServiceClient = () => visitServiceClient;
