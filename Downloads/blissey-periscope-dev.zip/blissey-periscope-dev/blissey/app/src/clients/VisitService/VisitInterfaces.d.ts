import { JsonObject as SurveyJsonObject } from 'survey-core';

/** enumeration of visit status needed by Blissey */
export type VisitStatus =
    | 'done'
    | 'staffdeclined'
    | 'cancelled'
    | 'requested'
    | 'waitingroom'
    | 'caregiverassigned'
    | 'waitoffline'
    | 'invisit';

export type VisitTimestamps = {
    created: string | undefined;
    requested: string | undefined;
    waitingroom: string | undefined;
    invisit: string | undefined;
    done: string | undefined;
    staffdeclined: string | undefined;
    cancelled: string | undefined;
    waitoffline: string | undefined;
    caregiverassigned: string | undefined;
};

export interface VisitIntegrations {
    tytoCare: {
        enabled: boolean;
        account?: {
            accountId: string;
        };
    };
}

export interface VisitDetails {
    waitingConferenceId?: string;
    videoConferenceId?: string;
    visitId: string;
    visitStatus: VisitStatus;
    patientGuid: string;
    providerId?: string | null;
    practiceId: string | null;
    isTokBox?: boolean;
    tokBoxVisit?: {
        apiKey: string;
        waitingRoomSession: TokboxSession;
        videoConferenceSession: TokboxSession;
    };
    integrations: VisitIntegrations;
    acceptTerms?: boolean;
    timestamps: VisitTimestamps;
    modality: string;
    origin?: string;
    traveling?: boolean;
    brand?: string;
    deviceModel?: string;
}

interface TokboxSession {
    sessionId: string;
}

export interface VisitResponseV9 {
    visitId: string;
    userId?: string | null;
    patientGuid: string;
    status: string;
    type: string;
    modality: string;
    assignmentQualifiers: string[];
    isHighPriority: boolean;
    stateLicensure: string;
    practiceId: string;
    providerId?: string | null;
    homeMarket: string;
    integrations: VisitIntegrations;
    tokBoxVisit: {
        videoConferenceSession: TokboxSession;
        waitingRoomSession: TokboxSession;
        apiKey: string;
    };
    acceptTerms?: boolean;
    timestamps: VisitTimestamps;
    origin?: string;
    traveling?: boolean;
    brand?: string;
    deviceModel?: string;
}

export interface Provider {
    id: string;
    displayInfo: {
        name: string;
        specialty?: string;
    };
    smsNumber?: string;
    oncallPractice?: string;
    visitId?: string | null;
    assignmentQualifiers: {
        id: string;
        name: string;
    }[];
    modalities: {
        id: string;
        name: string;
    }[];
    practiceRegions: PracticeRegion[];
    // optional
    credentials?: [];
    oncallAssignmentMethod?: {
        id: string;
        name: string;
        description?: string;
        isActive: boolean;
    };
}

export interface Market {
    id: string;
    name: string;
    description: string;
}

export interface PracticeRegion {
    id: string;
    regionCode: string;
    practiceId: string;
    market: Market;
}

// NOTE: source https://github.com/DexCare/visit-service/blob/5473197355b5a643d635ae824a77fbe2d902514b/app/src/dataTypes/TransferOptions.ts#L4
export interface TransferOptions {
    providers: Provider[];
    practiceRegions: PracticeRegion[];
}

export interface PatientEnterWaitOffline {
    visitId: string;
    practiceId: string;
    sessionId: string;
}

export interface PostVisitSurvey {
    id: string;
    surveyDefinition: SurveyJsonObject;
}
