import {
    initVisitServiceClient,
    visitServiceClient,
    VisitServiceV6SavePatientChatMessageBody,
} from '../VisitServiceClient';
import { getFeatureFlag } from '@utils/FeatureFlags';
import { jwtTokenHelper } from '@utils/jwt-helper';
import { createCorrelationId } from '@utils/requestUtils';
import { FeedbackQuestionType } from '@clients/Feedback/FeedbackQuestionType';
import { TransferOptions } from '../VisitInterfaces';
import { MockedFunction, vi } from 'vitest';
import { ReasonData, ReasonType } from '../../../data/VisitReasons';
import { InstantMessage } from '@dexcare/yak';

vi.mock('@dexcare/circus-jupiter');
vi.mock('@utils/jwt-helper');
vi.mock('@utils/requestUtils');
vi.mock('@utils/FeatureFlags');

const mockGetAuthenticationToken =
    jwtTokenHelper.getAuthenticationToken as MockedFunction<
        typeof jwtTokenHelper.getAuthenticationToken
    >;
const mockCreateCorrelationId = createCorrelationId as MockedFunction<
    typeof createCorrelationId
>;
const mockGetFeatureFlag = getFeatureFlag as MockedFunction<
    typeof getFeatureFlag
>;

const mockVisitId = 'mock-visit-id';

const mockResponse = (response: unknown, meta = { status: 200, ok: true }) => {
    fetchMock.mockResponseOnce(JSON.stringify(response), meta);
};

describe('VisitServiceClient', () => {
    beforeEach(() => {
        initVisitServiceClient({ sharedSessionStoreEnabled: false });
        fetchMock.resetMocks();
        mockGetAuthenticationToken.mockImplementation(() => 'mock-jwt-token');
        mockCreateCorrelationId.mockReturnValue(
            'b81b61c8-1987-4958-9d11-fd26e322136a',
        );
    });

    describe('startTytoCareVisit', () => {
        const mockTytoVisitResponse = { tytoCare: { visitUrl: mockVisitId } };
        const mockTytoVisitError = { error: 'not today!' };

        it('calls fetch', async () => {
            mockResponse(mockTytoVisitResponse);
            await visitServiceClient.startTytoCareVisit(mockVisitId);
            expect(fetchMock.mock.calls).toMatchInlineSnapshot(`
                [
                  [
                    "http://mock-visit-server/api/8/visits/mock-visit-id/integrations/tytoCare",
                    {
                      "headers": {
                        "Authorization": "Bearer mock-jwt-token",
                        "Content-Type": "application/json",
                        "correlation-id": "b81b61c8-1987-4958-9d11-fd26e322136a",
                      },
                      "method": "POST",
                    },
                  ],
                ]
            `);
        });
        it('returns successful response ', async () => {
            mockResponse(mockTytoVisitResponse);
            const res = await visitServiceClient.startTytoCareVisit(
                mockVisitId,
            );
            expect(res).toMatchInlineSnapshot(`
                {
                  "tytoCare": {
                    "visitUrl": "mock-visit-id",
                  },
                }
            `);
        });
        it('throws error from api', async () => {
            mockResponse(mockTytoVisitError, { ok: false, status: 400 });
            await expect(
                visitServiceClient.startTytoCareVisit(mockVisitId),
            ).rejects.toMatchInlineSnapshot(`[Error: not today!]`);
        });
        it('throws generic error message when response does not have specific error', async () => {
            mockResponse(undefined, { ok: false, status: 400 });
            await expect(
                visitServiceClient.startTytoCareVisit(mockVisitId),
            ).rejects.toMatchInlineSnapshot(`[Error: Bad Request]`);
        });
    });

    describe('getVisitSummary', () => {
        const visitSummaryUrlV9 = `http://mock-visit-server/api/9/visits/${mockVisitId}/summary`;
        const mockVisitSummaryResponseV9 = {
            visitId: mockVisitId,
            uid: 'mock-user-id',
            status: 'waitingroom',
            type: 'virtual',
            patientGuid: 'mock-patient-id',
            providerId: 'mock-provider-id',
            tokBoxVisit: {
                waitingRoomSession: {
                    sessionId: 'mock-waiting-room-session-id',
                },
                videoConferenceSession: {
                    sessionId: 'mock-video-conference-session-id',
                },
                apiKey: 'mock-api-key',
            },
            integrations: {
                tytoCare: {
                    enabled: true,
                },
            },
            brand: 'providence',
        };
        const expectedVisitDetails = {
            waitingConferenceId: '',
            videoConferenceId: '',
            visitId: mockVisitId,
            isTokBox: true,
            tokBoxVisit: {
                waitingRoomSession: {
                    sessionId: 'mock-waiting-room-session-id',
                },
                videoConferenceSession: {
                    sessionId: 'mock-video-conference-session-id',
                },
                apiKey: 'mock-api-key',
            },
            visitStatus: 'waitingroom',
            integrations: {
                tytoCare: {
                    enabled: true,
                },
            },
            patientGuid: 'mock-patient-id',
            providerId: 'mock-provider-id',
            brand: 'providence',
        };

        it('calls v9 visit summary endpoint to get visit details', async () => {
            mockGetFeatureFlag.mockReturnValue(true); // turn feature flag on to use v9 endpoint
            mockResponse(mockVisitSummaryResponseV9); // mock v9 visit summary response
            const res = await visitServiceClient.getVisitSummary(mockVisitId);
            expect(fetchMock.mock.calls[0][0]).toEqual(visitSummaryUrlV9); // expect v9 url to be called
            expect(res).toEqual(expectedVisitDetails);
        });
    });

    describe('getVisitStatus', () => {
        const visitStatusUrl = `http://mock-visit-server/v1/visits/${mockVisitId}/visit-status`;
        const mockVisitStatusResponse = 'waitingroom';
        it('calls v1 visit status endpoint to get visit status', async () => {
            mockResponse({
                status: mockVisitStatusResponse,
            });
            const res = await visitServiceClient.getVisitStatus(mockVisitId);
            expect(fetchMock.mock.calls[0][0]).toEqual(visitStatusUrl);
            expect(res).toMatchInlineSnapshot(`"waitingroom"`);
        });
    });

    describe('getTransferOptions', () => {
        const response: TransferOptions = {
            providers: [
                {
                    id: 'provider-1',
                    displayInfo: { name: 'Provider 1' },
                    assignmentQualifiers: [
                        {
                            id: 'qualifier-1',
                            name: '',
                        },
                    ],
                    modalities: [
                        {
                            id: 'modality-1',
                            name: '',
                        },
                    ],
                    practiceRegions: [],
                },
            ],
            practiceRegions: [
                {
                    id: 'practice-region-1',
                    regionCode: 'WA',
                    practiceId: 'practice-id',
                    market: {
                        id: 'market-id',
                        name: 'market A',
                        description: 'market a',
                    },
                },
            ],
        };

        it('should succeed', async () => {
            mockResponse(response);
            const res = await visitServiceClient.getTransferOptions(
                mockVisitId,
            );
            expect(res).toEqual(response);
            expect(fetchMock.mock.calls).toMatchSnapshot();
        });

        it('should fail', async () => {
            mockResponse(undefined, { ok: false, status: 400 });
            await expect(
                visitServiceClient.getTransferOptions(mockVisitId),
            ).rejects.toMatchSnapshot();
        });
    });

    describe('cancelVisit', () => {
        const visitCancelUrlV9 = `http://mock-visit-server/api/9/visits/virtual/${mockVisitId}/cancel`;

        it('calls v9 visit cancel endpoint to cancel visit', async () => {
            await visitServiceClient.cancelVisit(mockVisitId);
            expect(fetchMock.mock.calls[0][0]).toEqual(visitCancelUrlV9);
        });

        it('throws generic error message when response does not have specific error', async () => {
            mockResponse(undefined, { ok: false, status: 400 });
            await expect(
                visitServiceClient.cancelVisit(mockVisitId),
            ).rejects.toMatchInlineSnapshot(`[Error: Bad Request]`);
        });
    });

    describe('cancelPhoneWithReason', () => {
        it('calls v1 visit cancel phone endpoint to cancel visit with reason', async () => {
            await visitServiceClient.cancelPhoneWithReason(
                mockVisitId,
                'reason',
                'patient@mail.com',
            );
            expect(fetchMock.mock.calls[0]).toMatchInlineSnapshot(`
              [
                "http://mock-visit-server/v1/visits/mock-visit-id/patient-cancel-phone",
                {
                  "body": "{"cancelReason":"reason","patientEmail":"patient@mail.com"}",
                  "headers": {
                    "Authorization": "Bearer mock-jwt-token",
                    "Content-Type": "application/json",
                    "correlation-id": "b81b61c8-1987-4958-9d11-fd26e322136a",
                  },
                  "method": "POST",
                },
              ]
            `);
        });
    });

    describe('cancelVideoWithReason', () => {
        it('calls v1 visit cancel video endpoint to cancel visit with reason', async () => {
            await visitServiceClient.cancelVideoWithReason(
                mockVisitId,
                'reason',
            );
            expect(fetchMock.mock.calls[0]).toMatchInlineSnapshot(`
              [
                "http://mock-visit-server/v1/visits/mock-visit-id/patient-cancel-video",
                {
                  "body": "{"cancelReason":"reason"}",
                  "headers": {
                    "Authorization": "Bearer mock-jwt-token",
                    "Content-Type": "application/json",
                    "correlation-id": "b81b61c8-1987-4958-9d11-fd26e322136a",
                  },
                  "method": "POST",
                },
              ]
            `);
        });
    });

    describe('acceptTerms', () => {
        const termsAcceptUrlV9 = `http://mock-visit-server/api/9/visits/${mockVisitId}/acceptTerms`;

        it('calls v9 visit accept terms endpoint', async () => {
            mockGetFeatureFlag.mockReturnValue(true);
            await visitServiceClient.acceptConsentTerms(mockVisitId);
            expect(fetchMock.mock.calls[0][0]).toEqual(termsAcceptUrlV9);
        });
    });

    describe('saveFeedback', () => {
        const feedbackDetailMock = {
            feedbackId: 'feedbackId',
            appId: 'appId',
            userIdentifier: 'user',
            conferenceId: 'conference',
            conferenceSessionId: 'session',
            visitId: 'visit',
            userDisplayName: 'john',
            userRole: 'patient',
            startTime: '123456789',
            endTime: '234567890',
            feedbacks: [
                {
                    id: 'rating',
                    text: '',
                    type: FeedbackQuestionType.Number,
                    answers: [
                        {
                            id: 'ratingAnswer',
                            type: FeedbackQuestionType.Number,
                            value: 10,
                            text: '',
                        },
                    ],
                },
            ],
            rating: 10,
        };

        it('calls v6 endpoint to save feedback', async () => {
            await visitServiceClient.saveFeedback('visit', feedbackDetailMock);
            expect(fetchMock.mock.calls[0][0]).toEqual(
                '/feedback?visitId=visit',
            );
        });

        it('calls v6 endpoint to save feedback with multiple extra surveys', async () => {
            const feedbacksFullMock = [
                {
                    id: 'rating',
                    text: '',
                    type: FeedbackQuestionType.Number,
                    answers: [
                        {
                            id: 'ratingAnswer',
                            type: FeedbackQuestionType.Number,
                            value: 10,
                            text: '',
                        },
                    ],
                },
                {
                    id: 'feedback',
                    text: '',
                    type: FeedbackQuestionType.Text,
                    answers: [
                        {
                            id: 'feedbackAnswer',
                            type: FeedbackQuestionType.Text,
                            value: 0,
                            text: '',
                        },
                    ],
                },
                {
                    id: 'extraSurvey1',
                    text: '',
                    type: FeedbackQuestionType.Text,
                    answers: [
                        {
                            id: 'extraSurveyAnswer1',
                            type: FeedbackQuestionType.Text,
                            value: 0,
                            text: '',
                        },
                    ],
                },
                {
                    id: 'extraSurvey2',
                    text: '',
                    type: FeedbackQuestionType.Number,
                    answers: [
                        {
                            id: 'extraSurveyAnswer2',
                            type: FeedbackQuestionType.Number,
                            value: 5,
                            text: '',
                        },
                    ],
                },
                {
                    id: 'followUp',
                    text: 'contact text',
                    type: FeedbackQuestionType.Boolean,
                    answers: [
                        {
                            id: 'followUpAnswer',
                            type: FeedbackQuestionType.Boolean,
                            value: 0,
                            text: '',
                        },
                    ],
                },
            ];

            feedbackDetailMock.feedbacks = feedbacksFullMock;

            await visitServiceClient.saveFeedback('visit', feedbackDetailMock);
            expect(fetchMock.mock.calls[0][0]).toEqual(
                '/feedback?visitId=visit',
            );
        });
    });

    describe('getTestSession', () => {
        it('calls v6 connection test endpoint', async () => {
            const testSession = {
                apiKey: 'api-key',
                sessionId: 'session-id',
                token: 'token',
            };

            mockResponse(testSession);
            const result = await visitServiceClient.getTestSession();
            expect(fetchMock.mock.calls[0][0]).toEqual(
                'http://mock-visit-server/api/6/visits/virtual/connectiontest',
            );
            expect(result).toEqual(testSession);
        });
    });

    describe('savePatientChatMessage', () => {
        it('saves the patient chat message successfully', async () => {
            mockResponse(undefined, { ok: true, status: 204 });

            const message: VisitServiceV6SavePatientChatMessageBody = {
                type: 'botPromptMessage',
                data: {
                    fromParticipant: 'Patient',
                    senderId: '1234',
                    creationTime: '1731614571604',
                    uniqueId: '98f63e63-67a1-49ef-9b11-2a479f1ef56b',
                    prompt: 'abcd',
                    selectedOption: 'Yes',
                },
            };

            const result = (await visitServiceClient.savePatientChatMessage(
                'abcd',
                '1234',
                message,
            )) as unknown as Response;
            expect(fetchMock.mock.calls[0][0]).toEqual(
                'http://mock-visit-server/api/6/visit/abcd/chat/1234',
            );
            expect(fetchMock.mock.calls).toMatchSnapshot();
            expect(result.status).toBe(204);
        });
    });

    describe('cacheInstantMessage', () => {
        it('caches the patient chat message successfully', async () => {
            mockResponse(undefined, { ok: true, status: 204 });

            const message: InstantMessage = {
                fromParticipant: 'Test Patient',
                senderId: '1234',
                creationTime: '1731614571604',
                uniqueId: '98f63e63-67a1-49ef-9b11-2a479f1ef56b',
                message: 'hello from patient',
            };

            const result = (await visitServiceClient.cacheInstantMessage(
                'abcd',
                '1234',
                message,
            )) as unknown as Response;
            expect(fetchMock.mock.calls[0][0]).toEqual(
                'http://mock-visit-server/api/6/visit/abcd/chat/1234',
            );
            expect(fetchMock.mock.calls).toMatchSnapshot();
            expect(result.status).toBe(204);
        });

        it('caches the provider chat message successfully', async () => {
            mockResponse(undefined, { ok: true, status: 204 });

            const message = {
                message: 'Hello from provider',
                fromParticipant: 'Test Dr.',
                senderId: '5678',
                creationTime: '1731614571604',
                uniqueId: '98f63e63-67a1-49ef-9b11-2a479f1ef56b',
            };

            const result = (await visitServiceClient.cacheInstantMessage(
                'abcd',
                '1234',
                message,
                true,
            )) as unknown as Response;
            expect(fetchMock.mock.calls[0][0]).toEqual(
                '/providerChat?sessionId=1234&visitId=abcd',
            );
            expect(fetchMock.mock.calls).toMatchSnapshot();
            expect(result.status).toBe(204);
        });

        it('handles error responses from the server', async () => {
            mockResponse(
                { error: 'Failed to cache message' },
                { ok: false, status: 500 },
            );

            const message = {
                message: 'This will fail',
                fromParticipant: 'Test Patient',
                senderId: '1234',
                creationTime: '1731614571604',
                uniqueId: '98f63e63-67a1-49ef-9b11-2a479f1ef56b',
            };

            await expect(
                visitServiceClient.cacheInstantMessage('abcd', '1234', message),
            ).rejects.toEqual(
                expect.objectContaining({
                    message: 'Failed to cache message',
                }),
            );
        });

        it('includes correlation ID in request headers', async () => {
            mockResponse(undefined, { ok: true, status: 204 });
            mockCreateCorrelationId.mockReturnValue('test-correlation-id');

            const message = {
                message: 'Test correlation',
                fromParticipant: 'Test Patient',
                senderId: '1234',
                creationTime: '1731614571604',
                uniqueId: '123',
                isStaff: false,
            };

            await visitServiceClient.cacheInstantMessage(
                'abcd',
                '1234',
                message,
            );
            const body = fetchMock.mock.calls[0][1]?.headers as Record<
                string,
                string
            >;

            expect(body).toBeDefined();
            expect(body).toHaveProperty(
                'correlation-id',
                'test-correlation-id',
            );
        });

        it('handles different session store settings correctly', async () => {
            mockResponse(undefined, { ok: true, status: 204 });

            initVisitServiceClient({ sharedSessionStoreEnabled: true });

            const message = {
                message: 'Test shared session',
                fromParticipant: 'Test Patient',
                senderId: '1234',
                creationTime: '1731614571604',
                uniqueId: '123',
                isStaff: false,
            };

            await visitServiceClient.cacheInstantMessage(
                'abcd',
                '1234',
                message,
            );

            expect(fetchMock.mock.calls[0][0]).toMatch(/^\/proxy/);

            initVisitServiceClient({ sharedSessionStoreEnabled: false });
        });
    });

    describe('calling initVisitServiceClient', () => {
        // The API call, response, request, etc. are arbitrary for these tests
        //  so the response is not tested
        //  the service call URI is what's tested, as we can't test the private sharedSessionStoreEnabled directly
        const someVisitId = 'someVisitId';
        const someResponse = { tytoCare: { visitUrl: mockVisitId } };
        const someVisitServiceApiCall = async (
            client: typeof visitServiceClient = visitServiceClient,
        ) => client.startTytoCareVisit(someVisitId);

        it(
            'with sharedSessionStoreEnabled=false sets the sharedSessionStoreEnabled field to false' +
                ' sets the sharedSessionStoreEnabled field to false' +
                ' and adds an auth header to the call',
            async () => {
                initVisitServiceClient({ sharedSessionStoreEnabled: false });

                mockResponse(someResponse);
                await someVisitServiceApiCall();

                const [url, { headers = {} } = {}] =
                    fetchMock.mock.calls[0] ?? [];

                expect(url).not.toMatch(/^\/proxy/);
                expect(
                    (headers as Record<string, string>).Authorization,
                ).not.toBeUndefined();
            },
        );

        it(
            'with sharedSessionStoreEnabled=true' +
                ' sets the sharedSessionStoreEnabled field to true' +
                ' and does not add an auth header to the call',
            async () => {
                initVisitServiceClient({ sharedSessionStoreEnabled: true });
                const client = (await import('../VisitServiceClient'))
                    .visitServiceClient;
                mockResponse(someResponse);
                await someVisitServiceApiCall(client);

                const [url, { headers = {} } = {}] =
                    fetchMock.mock.calls[0] ?? [];
                expect(url).toMatch(/^\/proxy/);
                expect(
                    (headers as Record<string, string>).Authorization,
                ).toBeUndefined();
            },
        );
    });

    describe('patientEnterWaitOffline', () => {
        it('calls v1 endpoint and send patientEnterWaitOffline event', async () => {
            await visitServiceClient.patientEnterWaitOffline({
                visitId: 'visitId',
                practiceId: 'practiceId',
                sessionId: 'sessionId',
            });
            expect(fetchMock.mock.calls).toMatchInlineSnapshot(`
              [
                [
                  "http://mock-visit-server/v1/visits/event",
                  {
                    "body": "{"action":"patientEnterWaitOffline","data":{"visitId":"visitId","practiceId":"practiceId","sessionId":"sessionId"}}",
                    "headers": {
                      "Authorization": "Bearer mock-jwt-token",
                      "Content-Type": "application/json",
                      "correlation-id": "b81b61c8-1987-4958-9d11-fd26e322136a",
                    },
                    "method": "POST",
                  },
                ],
              ]
            `);
        });
    });

    describe('generateTytoCareQRCode', () => {
        const mockTytoVisitResponse = {
            tytoCare: { pairingDetails: 'pairingDetails' },
        };
        it('calls fetch', async () => {
            mockResponse(mockTytoVisitResponse);
            await visitServiceClient.generateTytoCareQRCode(
                mockVisitId,
                'domain',
            );
            expect(fetchMock.mock.calls).toMatchInlineSnapshot(`
                [
                  [
                    "http://mock-visit-server/api/8/visits/mock-visit-id/integrations/tytoCare/devices",
                    {
                      "headers": {
                        "Authorization": "Bearer mock-jwt-token",
                        "Content-Type": "application/json",
                        "correlation-id": "b81b61c8-1987-4958-9d11-fd26e322136a",
                        "domain": "domain",
                      },
                      "method": "POST",
                    },
                  ],
                ]
            `);
        });
    });

    describe('generateTokboxPatientToken', () => {
        const mockTytoVisitResponse = { token: 'token' };
        it('calls fetch', async () => {
            mockResponse(mockTytoVisitResponse);
            await visitServiceClient.generateTokboxPatientToken(
                'sessionId',
                mockVisitId,
            );
            expect(fetchMock.mock.calls).toMatchInlineSnapshot(`
                [
                  [
                    "http://mock-visit-server/api/6/visit/mock-visit-id/token/sessionId",
                    {
                      "headers": {
                        "Authorization": "Bearer mock-jwt-token",
                        "Content-Type": "application/json",
                        "correlation-id": "b81b61c8-1987-4958-9d11-fd26e322136a",
                      },
                      "method": "GET",
                    },
                  ],
                ]
            `);
        });
    });

    describe('getWaitTimeEstimateV9', () => {
        const mockTytoVisitResponse = null;
        it('calls fetch', async () => {
            mockResponse(mockTytoVisitResponse);
            await visitServiceClient.getWaitTimeEstimateV9(mockVisitId);
            expect(fetchMock.mock.calls).toMatchInlineSnapshot(`
                [
                  [
                    "http://mock-visit-server/api/9/visits/mock-visit-id/waittime",
                    {
                      "headers": {
                        "Authorization": "Bearer mock-jwt-token",
                        "Content-Type": "application/json",
                        "correlation-id": "b81b61c8-1987-4958-9d11-fd26e322136a",
                      },
                      "method": "GET",
                    },
                  ],
                ]
            `);
        });
    });

    describe('submitSurveyResponse', () => {
        const visitId = 'visitId';
        const userRole = 'userRole';
        const surveyResponse = { question: 'yes' };
        const surveyId = 'surveyId';

        it('submits survey response successfully', async () => {
            mockResponse({});
            await visitServiceClient.submitSurveyResponse(
                visitId,
                userRole,
                surveyResponse,
                surveyId,
            );

            expect(fetch).toHaveBeenCalledWith('/survey-response', {
                method: 'POST',
                headers: {
                    Authorization: 'Bearer mock-jwt-token',
                    'Content-Type': 'application/json',
                    'correlation-id': 'b81b61c8-1987-4958-9d11-fd26e322136a',
                },
                body: JSON.stringify({
                    surveyId,
                    userRole,
                    visitId,
                    surveyResponse,
                }),
            });
        });
    });

    describe('getLatestSurvey', () => {
        it('calls fetch', async () => {
            const mockSurvey = { survey: 'survey' };
            mockResponse(mockSurvey);
            await visitServiceClient.getLatestSurvey('provider');
            expect(fetchMock.mock.calls).toMatchInlineSnapshot(`
          [
            [
              "/survey/provider",
              {
                "headers": {
                  "Authorization": "Bearer mock-jwt-token",
                  "Content-Type": "application/json",
                  "correlation-id": "b81b61c8-1987-4958-9d11-fd26e322136a",
                },
                "method": "GET",
              },
            ],
          ]
        `);
        });
    });

    describe('getReasons', () => {
        const response: ReasonData = [
            {
                reasonType: ReasonType.WAIVE,
                reasons: [
                    {
                        key: 'out_of_service',
                        value: 'Out of service',
                    },
                ],
            },
        ];

        it('should succeed', async () => {
            mockResponse(response);
            const res = await visitServiceClient.getReasons();
            expect(res).toEqual(response);
            expect(fetchMock.mock.calls).toMatchSnapshot();
        });

        it('should fail', async () => {
            mockResponse(undefined, { ok: false, status: 400 });
            await expect(
                visitServiceClient.getReasons(),
            ).rejects.toMatchSnapshot();
        });
    });
});
