import 'whatwg-fetch';

import { BlisseyLogger } from '@utils/Logger';
import { createCorrelationId } from '@utils/requestUtils';

class OTPAuthClient {
    // these should maybe be more shared?
    private checkStatus = async (response: Response) => {
        if (response.status >= 200 && response.status < 300) {
            return response;
        } else {
            let errorMessage = response.statusText;
            let errorJson;
            try {
                errorJson = (await response.json()) as object;
            } catch (error) {
                BlisseyLogger.warn(
                    {
                        details: JSON.stringify(error),
                    },
                    'error parsing response',
                );
            }

            errorMessage =
                (errorJson as { [key: string]: string })?.error || errorMessage;
            BlisseyLogger.error(
                {
                    details: {
                        message: errorMessage,
                        error: errorJson || 'unknown error',
                        status: response.status,
                    },
                },
                'fetch error',
            );
            throw new Error(errorMessage);
        }
    };

    private async parseJSON<T>(response: Response): Promise<T> {
        return response.json() as Promise<T>;
    }

    /**
     * Request an otp passcode
     * @param otpMethod
     * @returns Promise<object>
     */
    public async requestPasscode(otpMethod: string): Promise<Response> {
        return fetch('/guest/otp/request', {
            method: 'POST',
            credentials: 'include',
            headers: {
                Accept: 'application/json, text/plain, */*',
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
            body: JSON.stringify({ otpMethod }),
        })
            .then(this.checkStatus)
            .then(async (response) => this.parseJSON<Response>(response))
            .catch((err: unknown) => {
                BlisseyLogger.error({
                    msg: 'OTPAuthClient: getPasscode failed',
                    err,
                });
                throw err;
            });
    }

    /**
     * Submit / verify an OTP passcode
     * @param otpCode
     * @param otpMethod
     * @returns Promise<object>
     */
    public async verifyPasscode(
        otpCode: string,
        otpMethod: string,
    ): Promise<unknown> {
        return fetch('/guest/otp/verify', {
            method: 'POST',
            credentials: 'include',
            headers: {
                Accept: 'application/json, text/plain, */*',
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
            body: JSON.stringify({ otpCode, otpMethod }),
        })
            .then(this.checkStatus)
            .then(async (response) => this.parseJSON<unknown>(response))
            .catch((err: unknown) => {
                BlisseyLogger.error({
                    msg: 'OTPAuthClient: getPasscode failed',
                    err,
                });
                throw err;
            });
    }
}

export const otpAuthClient = new OTPAuthClient();
