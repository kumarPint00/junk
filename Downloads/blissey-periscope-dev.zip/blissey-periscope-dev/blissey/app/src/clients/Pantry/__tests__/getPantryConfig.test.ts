import { getPantryConfig } from '@clients/Pantry/getPantryConfig';
import { createCorrelationId } from '@utils/requestUtils';
import { backendFacade } from '@clients/Backend/BackendFacade';
import { MockedFunction, vi } from 'vitest';

vi.mock('@utils/requestUtils', () => ({
    createCorrelationId: vi.fn(),
}));
vi.mock('@clients/Backend/BackendFacade', () => ({
    backendFacade: {
        getConfig: vi.fn(),
    },
}));
const mockCreateCID = createCorrelationId as MockedFunction<
    typeof createCorrelationId
>;
const mockGetAppConfig = vi.spyOn(backendFacade, 'getConfig');

describe('getPantryConfig', () => {
    beforeEach(() => {
        mockCreateCID.mockReturnValue('test-correlation-id');
        mockGetAppConfig.mockResolvedValue({
            externalIngress: 'test-external-ingress',
        } as never);
    });

    it('gets pantry config', async () => {
        fetchMock.mockResponse(JSON.stringify({ response: '' }), {
            status: 201,
        });
        await getPantryConfig();
        expect(fetchMock.mock.calls.length).toEqual(1);
        expect(fetchMock.mock.calls[0]).toMatchInlineSnapshot(`
          [
            "https://api.blissey_is_cool/v2/blisseyconfigs",
          ]
        `);
    });
});
