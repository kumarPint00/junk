import { BlisseyLogger } from '@utils/Logger';
import { backendFacade } from '@clients/Backend/BackendFacade';
import { getConfig } from '@utils/config';

export interface PantryConfig {
    minimumWaitTimeForWaitOffline: number;
}

export const getPantryConfig = async (): Promise<PantryConfig | undefined> => {
    try {
        const externalIngress =
            getConfig().externalIngress ??
            (await backendFacade.getConfig())?.externalIngress;
        if (!externalIngress) {
            BlisseyLogger.warn('externalIngress not found in appConfig');
        } else {
            const response = await fetch(
                `https://api.${externalIngress}/v2/blisseyconfigs`,
            );
            if (!response.ok) {
                throw new Error('failed to fetch blissey pantry configs');
            }
            return response.json() as Promise<PantryConfig | undefined>;
        }
    } catch (err: unknown) {
        BlisseyLogger.warn({ err }, 'error fetching blissey pantry configs');
    }
    return undefined;
};
