import 'whatwg-fetch';

import { Logger } from '../../utils';
import { UserDetails } from '../../types/UserDetails';

import { createCorrelationId } from '../../utils/requestUtils';
import { ClientAppConfig } from '../../../../server/config/configInterfaces';
import { getStandardHeaders } from '@utils/auth';
import {
    AddParticipantFormData,
    VisitParticipant,
    VisitParticipantType,
} from '@dexcare/visit-participants';
import { formatToHumanReadable } from '@utils/formatToHumanReadable';

export const SessionTokenHeaderName = 'x-blissey-session';

/*
    This represent the backend for our front end in the SPA. All calls
    to the backend must go throught this Facade.
*/
type IData<T> = T | PromiseLike<T>;
export class BackendFacade {
    // ENG-8525: for cookie-less guest visits, we keep a "local"
    // copy of the guest session jwt that is included in all requests
    // sent to the blissey backend from that session.
    private guestSessionJwt = '';

    private checkStatus = (response: Response) => {
        if (response.status >= 200 && response.status < 300) {
            return response;
        } else {
            Logger.error({
                msg: 'backendFacade: checkStatus failed',
                err: 'checkStatus failed',
                details: {
                    status: response.status,
                },
            });
            const error = new Error(response.statusText);
            throw error;
        }
    };

    private parseJSON = async <T>(response: Response): Promise<T> => {
        return response.json() as Promise<T>;
    };

    // use this for more detailed error handling
    private checkStatusKeepError = async (response: Response) => {
        if (response.status >= 200 && response.status < 300) {
            return response.json();
        } else {
            // visit-service returns errors with "error" string message and "code"
            let errorMessage = `HTTP error ${response.status}`;
            try {
                // eslint fun
                const errorBody: unknown = await response.json();
                if (
                    errorBody &&
                    typeof errorBody === 'object' &&
                    errorBody !== null &&
                    'error' in errorBody &&
                    typeof (errorBody as { error: unknown }).error === 'string'
                ) {
                    errorMessage = (errorBody as { error: string }).error;
                }
            } catch {
                errorMessage = response.statusText || errorMessage;
            }
            throw new Error(errorMessage);
        }
    };

    public async recoverGuestSession(
        accessCode: string,
    ): Promise<object | null> {
        const options = {
            method: 'POST',
            credentials: 'include' as const,
            redirect: 'follow' as const,
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
            body: JSON.stringify({
                accessCode: accessCode,
            }),
        };
        const url = '/guest/session/token';
        Logger.info({ url, options }, 'attempting to recover guest session');
        return await fetch(url, options)
            .then(async (resp) => {
                const sessionJwt = resp.headers.get(SessionTokenHeaderName);
                this.guestSessionJwt = sessionJwt ?? '';

                const r = (await resp.json()) as object;
                Logger.addCustomHeaders({
                    [SessionTokenHeaderName]: this.guestSessionJwt,
                });
                Logger.info(
                    { url, options, resp },
                    `Recovered guest session token successfully`,
                );

                return r;
            })
            .catch((err: unknown) => {
                Logger.warn(
                    { url, options, err },
                    `Failed to recover guest session token`,
                );
                return null;
            });
    }

    private getSessionHeaderforGuestSessionJWT(): {
        [SessionTokenHeaderName]?: string;
    } {
        if (this.guestSessionJwt) {
            return {
                [SessionTokenHeaderName]: this.guestSessionJwt,
            };
        } else {
            return {};
        }
    }

    // this service populates the ubiquitous "UserDetails" object which
    // determines which pages a user can see, important details etc
    // Do we need to make this endpoint work for our "passwordlessuser"?
    public async getUser(): Promise<UserDetails> {
        const promise: Promise<UserDetails> = new Promise((resolve, reject) => {
            fetch('/user', {
                credentials: 'include',
                headers: {
                    correlationId: createCorrelationId(),
                    ...this.getSessionHeaderforGuestSessionJWT(),
                },
            })
                .then(this.checkStatus)
                .then(this.parseJSON)
                .then((data: IData<UserDetails>) => {
                    resolve(data);
                })
                .catch((error: Error) => {
                    Logger.error({
                        msg: 'backendFacade: getUser failed',
                        err: error,
                    });
                    reject(error);
                });
        });
        return promise;
    }

    public async getConfig(): Promise<ClientAppConfig> {
        const promise: Promise<ClientAppConfig> = new Promise(
            (resolve, reject) => {
                fetch('/config', {
                    credentials: 'include',
                    headers: {
                        correlationId: createCorrelationId(),
                        ...this.getSessionHeaderforGuestSessionJWT(),
                    },
                })
                    .then(this.checkStatus)
                    .then(this.parseJSON)
                    .then((data: IData<ClientAppConfig>) => {
                        resolve(data);
                    })
                    .catch((error: Error) => {
                        Logger.error({
                            msg: 'backendFacade: getConfig failed',
                            err: error,
                        });
                        reject(error);
                    });
            },
        );
        return promise;
    }

    public async getBasicConfig(): Promise<ClientAppConfig> {
        const promise: Promise<ClientAppConfig> = new Promise(
            (resolve, reject) => {
                fetch('/basic-config', {
                    headers: {
                        correlationId: createCorrelationId(),
                        ...this.getSessionHeaderforGuestSessionJWT(),
                    },
                })
                    .then(this.checkStatus)
                    .then(this.parseJSON)
                    .then((data: IData<ClientAppConfig>) => {
                        resolve(data);
                    })
                    .catch((error: Error) => {
                        Logger.error({
                            msg: 'backendFacade: getBasicConfig failed',
                            err: error,
                        });
                        reject(error);
                    });
            },
        );
        return promise;
    }

    public async requestTokboxDogfoodVisit(): Promise<{
        sessionId: string;
        patientToken: string;
    }> {
        return fetch('/tokbox/createDogfoodSession', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
                ...this.getSessionHeaderforGuestSessionJWT(),
            },
        })
            .then(this.checkStatus)
            .then(async (response) =>
                this.parseJSON<{
                    sessionId: string;
                    patientToken: string;
                }>(response),
            );
    }

    public async generateTokboxProviderToken(
        sessionId: string,
        visitId: string,
        userId: string,
        isModerator: boolean = false,
    ): Promise<{ token: string }> {
        return fetch(
            `/tokbox/createProviderToken?sessionId=${sessionId}&visitId=${visitId}&userId=${userId}&moderator=${isModerator}`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    correlationId: createCorrelationId(),
                    ...this.getSessionHeaderforGuestSessionJWT(),
                },
            },
        )
            .then(this.checkStatus)
            .then(async (response) =>
                this.parseJSON<{ token: string }>(response),
            );
    }

    public async sendPatientRejoinSuccessMimirEvent({
        visitId = '',
        generatedBy = '',
    }: {
        visitId: string;
        generatedBy: string;
    }) {
        try {
            await fetch('/mimir/patient/rejoined', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    correlationId: createCorrelationId(),
                    ...this.getSessionHeaderforGuestSessionJWT(),
                },
                body: JSON.stringify({
                    visitId,
                    generatedBy,
                }),
            });
            // don't care about mimir results, just want to know if it fails to send
        } catch (err: unknown) {
            Logger.error({
                eventSource: 'BackendFacade',
                eventName: 'sendPatientRejoinSuccessMimirEvent',
                msg: 'backendFacade: sendPatientRejoinSuccessMimirEvent failed',
                err,
            });
        }
    }

    /**
     * Transfer a visit back to queue
     * @param visitId
     * @param currentProviderId
     * @returns 202
     */
    public async transferBackToQueue(
        visitId: string,
        currentProviderId: string,
    ): Promise<Response> {
        const url = '/visits/event';
        const options: RequestInit = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
            body: JSON.stringify({
                action: 'updateProvider',
                data: {
                    visitId,
                    assignmentMethod: 'unassign',
                    unassignProviderId: currentProviderId,
                    actorId: currentProviderId,
                },
            }),
        };
        Logger.info({
            url,
            options,
            module: 'BackendFacade',
            action: 'transferBackToQueue',
            msg: 'attempting to send request',
        });
        // NOTE: api returns 202 no body. nothing to json parse.
        return fetch(url, options).then(this.checkStatus);
    }

    /**
     * Transfer a visit to another provider
     * @param visitId
     * @param newProviderId
     * @param currentProviderId
     * @returns
     */
    public async transferToAnotherProvider(
        visitId: string,
        newProviderId: string,
        currentProviderId: string,
    ): Promise<Response> {
        const url = '/visits/event';
        const options: RequestInit = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
            body: JSON.stringify({
                action: 'updateProvider',
                data: {
                    visitId,
                    assignmentMethod: 'end_and_transfer',
                    providerId: newProviderId,
                    unassignProviderId: currentProviderId,
                    actorId: currentProviderId,
                },
            }),
        };
        Logger.info({
            url,
            options,
            module: 'BackendFacade',
            action: 'transferToAnotherProvider',
            msg: 'attempting to send request',
        });
        // NOTE: api returns 202 no body. nothing to json parse.
        return fetch(url, options).then(this.checkStatus);
    }

    /**
     * Convert modality of a visit
     * @param visitId
     * @param conversionReason
     * @param originalModality
     * @param targetModality
     * @param actorId
     * @returns
     */
    public async convertModality(
        visitId: string,
        conversionReason: string,
        originalModality: string,
        targetModality: string,
        actorId: string,
    ): Promise<Response> {
        const url = '/visits/event';
        const options: RequestInit = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
            body: JSON.stringify({
                action: 'modalityConversion',
                data: {
                    visitId,
                    conversionReason,
                    originalModality,
                    targetModality,
                    actorId,
                },
            }),
        };
        Logger.info({
            url,
            options,
            module: 'BackendFacade',
            action: 'convertModality',
            msg: 'attempting to send request',
        });

        return fetch(url, options).then(this.checkStatus);
    }

    public async sendSubmitSurveyResponseMimirEvent({
        surveyId,
        visitId,
        userRole,
        survey,
        userId,
    }: {
        surveyId: string;
        visitId: string;
        userRole: string;
        survey: object;
        userId?: string;
    }) {
        //build the body object without userId if not provided
        const body: Record<string, unknown> = {
            surveyId,
            visitId,
            userRole,
            survey,
        };
        if (userId) {
            body.userId = userId;
        }

        return fetch('/mimir/survey/submit', {
            method: 'POST',
            headers: getStandardHeaders({
                sharedSessionStoreEnabled: false,
            }),
            body: JSON.stringify(body),
        }).then(this.checkStatus);
    }

    /**
     * Get participant types list from bff so we can populate the dropdown
     * @returns
     */
    public async getParticipantTypes(): Promise<VisitParticipantType[]> {
        const url = '/visits/participant-types';
        const options: RequestInit = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
        };

        return fetch(url, options)
            .then(this.checkStatusKeepError)
            .then((data: VisitParticipantType[]) => {
                return data;
            })
            .catch((error: Error) => {
                Logger.error({
                    msg: 'backendFacade: getParticipantTypes failed',
                    err: error,
                });
                throw error;
            });
    }

    /**
     * Get participant list from bff so that we can redact personal info returned
     * @param visitId
     * @returns
     */
    public async getVisitParticipants(
        visitId: string,
    ): Promise<VisitParticipant[]> {
        const url = `/visits/${visitId}/participants`;
        const options: RequestInit = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
        };

        return fetch(url, options)
            .then(this.checkStatusKeepError)
            .then((data: VisitParticipant[]) => {
                return data.map((p) => {
                    return {
                        ...p,
                        createdAt: formatToHumanReadable(p.createdAt),
                    };
                });
            })
            .catch((error: Error) => {
                Logger.error({
                    msg: 'backendFacade: getVisitParticipants failed',
                    err: error,
                });
                throw error;
            });
    }

    public async addVisitParticipant(
        visitId: string,
        formData: AddParticipantFormData,
    ): Promise<VisitParticipant> {
        const url = `/visits/${visitId}/participants`;
        const options: RequestInit = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
            body: JSON.stringify(formData),
        };

        return fetch(url, options)
            .then(this.checkStatusKeepError)
            .then((data: VisitParticipant) => {
                return {
                    ...data,
                    createdAt: formatToHumanReadable(data.createdAt),
                };
            })
            .catch((error: Error) => {
                Logger.error({
                    msg: 'backendFacade: addVisitParticipant failed',
                    err: error,
                });
                throw error;
            });
    }

    public async deleteVisitParticipant(
        visitId: string,
        participantId: string,
    ): Promise<VisitParticipant> {
        const url = `/visits/${visitId}/participants/${participantId}`;
        const options: RequestInit = {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
        };

        return fetch(url, options)
            .then(this.checkStatusKeepError)
            .then((data: VisitParticipant) => {
                return {
                    ...data,
                    createdAt: formatToHumanReadable(data.createdAt),
                };
            })
            .catch((error: Error) => {
                Logger.error({
                    msg: 'backendFacade: deleteVisitParticipant failed',
                    err: error,
                });
                throw error;
            });
    }

    public async admitVisitParticipant(
        visitId: string,
        participantId: string,
    ): Promise<VisitParticipant> {
        const url = `/visits/${visitId}/participants/${participantId}`;
        const options: RequestInit = {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                correlationId: createCorrelationId(),
            },
            body: JSON.stringify({
                admitted: true,
            }),
        };

        return fetch(url, options)
            .then(this.checkStatusKeepError)
            .then((data: VisitParticipant) => {
                return {
                    ...data,
                    createdAt: formatToHumanReadable(data.createdAt),
                };
            })
            .catch((error: Error) => {
                Logger.error({
                    msg: 'backendFacade: admitVisitParticipant failed',
                    err: error,
                });
                throw error;
            });
    }
}

export const backendFacade = new BackendFacade();

export const getBackendFacade = () => backendFacade;
