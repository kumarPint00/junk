import React from 'react';
import { UserDetails, isPatient, isProvider } from '@dexcare/circus-saturn';
import { PatientDogfoodStageContainer } from '@stageManagement/PatientDogfood/PatientDogfoodStageContainer';
import { GuestUserDetails, requiresOTPAuth } from '@utils/User';
import {
    Navigate,
    RouteObject,
    NavigateOptions,
    createBrowserRouter as reactRouterDomCreateBrowserRouter,
} from 'react-router-dom';
import { AppConfig } from '../../server/config/configInterfaces';
import {
    ClosedVisitStageContainer,
    DogfoodStageContainer,
    HangupStageContainer,
    InVisitStageContainer,
    NotFoundContainer,
    OTPFlowContainer,
    PostConsultStageContainer,
} from './stageManagement';
import { PostVisitActionContainer } from './stageManagement/PostVisitAction/PostVisitActionContainer';
import { PostVisitSurveyContainer } from '@stageManagement/PostVisitSurveyContainer/PostVisitSurveyContainer';
import { PublicVisitSurveyContainer } from '@stageManagement/PublicVisitSurveyContainer/PublicVisitSurveyContainer';
import { PhoneCancelScreen } from '@stageManagement/PhoneCancel/PhoneCancelScreen';
import { ReasonTypesContext } from './context/ReasonTypes/state/ReasonTypeContext';
import { PhoneCancelNotAllowed } from '@stageManagement/PhoneCancel/PhoneCancelNotAllowedScreen';
import { FeatureFlags, getFeatureFlag } from './utils';
import { InvisitRoute } from './context/Invisit/InvisitRoute';

let browserRouter: ReturnType<typeof reactRouterDomCreateBrowserRouter>;

const createBrowserRouter = (routes: Array<RouteObject>) => {
    browserRouter = reactRouterDomCreateBrowserRouter(routes);
    return browserRouter;
};

export const navigate = async (
    to: string,
    options?: NavigateOptions & { forceRefresh?: boolean },
): Promise<void> => {
    if (options?.forceRefresh) {
        window.location.href = to;
        return;
    }
    return browserRouter?.navigate(to, options);
};

interface UserDetailsWithSMS extends UserDetails {
    sms: string;
}

interface UserDetailsHeader extends UserDetails {
    headerAuth?: boolean;
}

interface UserDetailsPublic extends UserDetails {
    public?: boolean;
}

interface RouteProps {
    userDetails: UserDetails;
    brand?: string;
}

function isAuthHeader(userDetails: UserDetailsHeader) {
    return !!userDetails.headerAuth;
}

function isPublic(userDetails: UserDetailsPublic) {
    return !!userDetails.public;
}

function getNotFoundRoute(props: RouteProps) {
    return createBrowserRouter([
        {
            path: '*',
            element: <NotFoundContainer {...props} />,
        },
    ]);
}

function getAuthHeaderRoutes(props: RouteProps) {
    if (!props.brand) {
        return getNotFoundRoute(props);
    }

    const requiredProps = props as Required<RouteProps>;

    return createBrowserRouter([
        {
            path: '/tokenvisit/:visitId/survey',
            element: <PublicVisitSurveyContainer {...requiredProps} />,
        },
        {
            path: '/end',
            element: (
                <HangupStageContainer
                    {...{ ...requiredProps, skipTimers: true }}
                />
            ),
        },
        {
            path: '*',
            element: <NotFoundContainer {...requiredProps} />,
        },
    ]);
}

function getPublicRoutes(props: RouteProps) {
    if (!props.brand) {
        return getNotFoundRoute(props);
    }

    const requiredProps = props as Required<RouteProps>;

    return createBrowserRouter([
        {
            path: '/publicvisit/:visitId/phonecancel',
            element: <PhoneCancelScreen {...requiredProps} />,
        },
        {
            path: '/publicvisit/closed/:closedReason',
            element: <ClosedVisitStageContainer {...requiredProps} />,
        },
        {
            path: '/publicvisit/cannotcancel/:visitId',
            element: <PhoneCancelNotAllowed {...requiredProps} />,
        },
        {
            path: '*',
            element: <NotFoundContainer {...requiredProps} />,
        },
    ]);
}

function getGuestRoutes(props: RouteProps) {
    if (!props.brand) {
        return getNotFoundRoute(props);
    }
    return createBrowserRouter([
        {
            path: '/guest',
            element: (
                <OTPFlowContainer
                    {...(props as {
                        brand: string;
                        userDetails: UserDetailsWithSMS;
                    })}
                />
            ),
        },
        {
            path: '*',
            element: <NotFoundContainer {...props} />,
        },
    ]);
}

function getPatientRoutes(props: RouteProps, patientDogfoodEnabled?: boolean) {
    if (!props.brand) {
        return getNotFoundRoute(props);
    }

    const requiredProps = props as Required<RouteProps>;
    const releaseSharedComponents = getFeatureFlag(FeatureFlags.releaseSharedVideoComponents);

    const routes = [
        {
            path: '/',
            element: <Navigate to="/end" replace />,
        },
        {
            path: '/visit/room/:visitId/survey',
            element: <PostVisitSurveyContainer {...requiredProps} />,
        },
        {
            path: '/visit/room/:visitId',
            element: (
                releaseSharedComponents
                ? <InvisitRoute />
                : <InVisitStageContainer {...requiredProps} />
            ),
        },
        {
            path: '/postconsult/:visitId',
            element: <PostConsultStageContainer {...requiredProps} />,
        },
        {
            path: '/end',
            element: <HangupStageContainer {...requiredProps} />,
        },
        {
            path: '/closed/:closedReason',
            element: <ClosedVisitStageContainer {...requiredProps} />,
        },
        {
            path: '*',
            element: <NotFoundContainer {...requiredProps} />,
        },
    ];

    if (patientDogfoodEnabled) {
        routes.push({
            path: '/patientdogfood',
            element: <PatientDogfoodStageContainer {...requiredProps} />,
        });
    }

    return createBrowserRouter(routes);
}

function getProviderRoutes(props: RouteProps) {
    if (!props.brand) {
        return createBrowserRouter([
            {
                path: '/',
                element: <Navigate to="/end" replace />,
            },
            {
                path: '/end',
                element: <HangupStageContainer {...props} />,
            },
            {
                path: '/dogfood',
                element: <DogfoodStageContainer {...props} />,
            },
            {
                path: '*',
                element: <NotFoundContainer {...props} />,
            },
        ]);
    }

    const requiredProps = props as Required<RouteProps>;
    const releaseSharedComponents = getFeatureFlag(FeatureFlags.releaseSharedVideoComponents);

    return createBrowserRouter([
        {
            path: '/',
            element: <Navigate to="/end" replace />,
        },
        {
            path: '/room/:visitId/survey',
            element: <PostVisitSurveyContainer {...requiredProps} />,
        },
        {
            path: '/room/:visitId',
            element: (
                releaseSharedComponents
                ? <InvisitRoute />
                : <ReasonTypesContext><InVisitStageContainer {...requiredProps} /></ReasonTypesContext>
            ),
        },
        {
            path: '/payment/:visitId',
            element: (
                <ReasonTypesContext>
                    <PostVisitActionContainer {...requiredProps} />
                </ReasonTypesContext>
            ),
        },
        {
            path: '/postconsult/:visitId',
            element: <PostConsultStageContainer {...requiredProps} />,
        },
        {
            path: '/end',
            element: <HangupStageContainer {...requiredProps} />,
        },
        {
            path: '/closed/:closedReason',
            element: <ClosedVisitStageContainer {...requiredProps} />,
        },
        {
            path: '/dogfood',
            element: <DogfoodStageContainer {...requiredProps} />,
        },
        {
            path: '*',
            element: <NotFoundContainer {...requiredProps} />,
        },
    ]);
}

export function getRoutes(
    userDetails: UserDetails,
    config?: AppConfig,
    brand?: string,
) {
    const props: RouteProps = {
        userDetails,
        brand,
    };

    // auth header routes
    if (isAuthHeader(userDetails)) {
        return getAuthHeaderRoutes(props);
    }

    if (isPublic(userDetails)) {
        return getPublicRoutes(props);
    }

    // guestflow routes
    if (requiresOTPAuth(userDetails as GuestUserDetails)) {
        return getGuestRoutes(props);
    }

    // patient routes
    if (isPatient(userDetails)) {
        return getPatientRoutes(props, config?.patientDogfoodEnabled);
    }

    // provider routes
    if (isProvider(userDetails)) {
        return getProviderRoutes(props);
    }

    // fallback route
    return getNotFoundRoute(props);
}
