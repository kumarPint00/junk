import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { BlisseyLogger } from '@utils/Logger';

export async function getTestSession() {
    try {
        return await visitServiceClient.getTestSession();
    } catch (error: unknown) {
        BlisseyLogger.error(
            {
                details: { error },
            },
            'error fetching test session',
        );
    }
    return undefined;
}
