import { sendGenericTechCheckEvent } from '@services/sendWaitingRoomEvent';
import { getVisitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { vi, Mock } from 'vitest';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { TechCheckLogic } from '@dexcare/video-conference';

const mockVisitServiceClient = {
    sendWaitingRoomEvent: vi.fn(),
};

vi.mock('@clients/VisitService/VisitServiceClient', () => {
    return {
        getVisitServiceClient: vi.fn(),
    };
});

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        interactionEvent: vi.fn(),
    },
}));

describe('sendWaitingRoomEvent', () => {
    beforeEach(() => {
        (getVisitServiceClient as Mock).mockReturnValue(mockVisitServiceClient);
    });
    afterEach(() => {
        vi.resetAllMocks();
    });

    it('should send successful tech check status via a waiting room event', () => {
        const logic = new TechCheckLogic({
            isConnected: true,
            audioInputDetected: true,
            videoInputDetected: true,
            accessAllowed: true
        });
        sendGenericTechCheckEvent('123', logic);
        expect(mockVisitServiceClient.sendWaitingRoomEvent).toHaveBeenCalledWith(
            '123',
            {
                techCheck: {
                    status: 'pass',
                    camStatus: 'pass',
                    micStatus: 'pass',
                    mediaPermissionStatus: 'pass',
                    networkStatus: 'pass',
                },
            },
        );
        expect(V2Analytics.interactionEvent).toHaveBeenCalledTimes(4);
    });

    it('should send failure tech check status via a waiting room event', () => {
        const logic = new TechCheckLogic({
            isConnected: true,
            audioInputDetected: false,
            videoInputDetected: true,
            accessAllowed: false,
        });
        sendGenericTechCheckEvent('123', logic);
        expect(mockVisitServiceClient.sendWaitingRoomEvent).toHaveBeenCalledWith(
            '123',
            {
                techCheck: {
                    status: 'fail',
                    camStatus: 'pass',
                    micStatus: 'fail',
                    mediaPermissionStatus: 'fail',
                    networkStatus: 'pass',
                },
            },
        );
        expect(V2Analytics.interactionEvent).toHaveBeenCalledTimes(3);
    });
});
