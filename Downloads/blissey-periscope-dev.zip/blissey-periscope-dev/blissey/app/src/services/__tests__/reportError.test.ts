import { reportError } from '@services/reportError';
import { BlisseyLogger } from '@utils/Logger';
import { Mock, vi } from 'vitest';

vi.mock('@utils/Logger', () => ({
    BlisseyLogger: {
        error: vi.fn(),
    },
}));

describe('reportError', () => {
    it('logs', () => {
        const errorReport = {
            visitId: 'testVisitId',
            sessionId: 'testSessionId',
            userId: 'testUserId',
            userRoles: ['telehealth_provider'],
            details: {
                test: 'detail',
            },
        };
        reportError(errorReport);
        expect(BlisseyLogger.error).toHaveBeenCalledTimes(1);
        expect((BlisseyLogger.error as Mock).mock.calls[0])
            .toMatchInlineSnapshot(`
            [
              {
                "details": {
                  "test": "detail",
                },
                "sessionId": "testSessionId",
                "userId": "testUserId",
                "userRoles": [
                  "telehealth_provider",
                ],
                "visitId": "testVisitId",
              },
              "user reported error",
            ]
        `);
    });
});
