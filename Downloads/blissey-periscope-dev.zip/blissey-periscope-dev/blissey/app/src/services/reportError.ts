import { BlisseyLogger } from '@utils/Logger';

export interface ErrorReport {
    visitId: string;
    sessionId: string;
    userId: string;
    userRoles: string[];
    details: object;
}

export function reportError(errorReport: ErrorReport) {
    BlisseyLogger.error(
        {
            ...errorReport,
        },
        'user reported error',
    );
}
