import { config } from '@dexcare/circus-jupiter';
import { AppConfig } from '../../../server/config/configInterfaces';

import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';
import { Configuration } from 'types/configuration';

export function submitDeviceChangeAnalytics(deviceName: 'video' | 'audio') {
    Analytics.sendEvent({
        eventAction: 'formEngagement',
        formEngagement: {
            formName: 'video/audio settings',
            fieldName: `${deviceName} settings`,
            fieldValue: 'complete',
        },
    });
    V2Analytics.interactionEvent({
        eventName: 'adjustment_made',
        adjustment_type: deviceName,
    });
}

export function submitGTMPageViewEvent(visitId: string | undefined) {
    const appConfig: AppConfig = (config as Configuration).getConfig();
    const { appTier, customer } = appConfig;

    const pageInfo = {
        path: `${window.location.pathname}${window.location.search}`,
        environment: appTier || 'dev',
        platform: 'video visit platform',
        customer,
        referrer: window.document.referrer,
    };

    const events = {
        visit_type: 'virtual',
        visit_id: visitId,
    };

    V2Analytics.pageViewEvent(pageInfo, events);
}

export const addBrowserActivityAnalyticsListeners = () => {
    window.addEventListener('beforeunload', () => {
        V2Analytics.interactionEvent({
            eventName: 'window_unload',
        });
    });

    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            V2Analytics.interactionEvent({
                eventName: 'leave_browser_page',
            });
        } else {
            V2Analytics.interactionEvent({
                eventName: 'return_to_browser_page',
            });
        }
    });
};
