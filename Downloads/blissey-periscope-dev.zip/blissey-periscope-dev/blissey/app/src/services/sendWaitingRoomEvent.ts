import {
    TechCheckResults,
    TechCheckStatus,
    visitServiceClient,
    getVisitServiceClient,
} from '@clients/VisitService/VisitServiceClient';
import { TestStatus } from '@common/video';
import { isProvider, UserDetails } from '@dexcare/circus-saturn';
import { BlisseyLogger } from '@utils/Logger';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { TechCheck } from '@dexcare/conference-client';
import { TechCheckLogic } from '@dexcare/video-conference';

function getTechCheckResults(status?: TestStatus) {
    switch (status) {
        case TestStatus.Passed:
            return 'pass';
        case TestStatus.Failed:
            return 'fail';
        default:
            return undefined;
    }
}

export function sendWaitingRoomEvent(
    userDetails: UserDetails,
    visitId: string,
    isTestVisit: boolean,
    {
        camStatus,
        micStatus,
        mediaPermissionStatus,
        networkStatus,
    }: {
        camStatus: TestStatus;
        micStatus: TestStatus;
        mediaPermissionStatus: TestStatus;
        networkStatus: TestStatus;
    },
) {
    if (isProvider(userDetails) || isTestVisit) {
        // only communicate patient's healthcheck results
        return;
    }

    let event: Partial<TechCheckResults> = {
        mediaPermissionStatus: getTechCheckResults(mediaPermissionStatus),
    };

    // only send other events if mediaPermissions passed.  They will
    // all fail on a mediaPermission failure
    if (event.mediaPermissionStatus === 'pass') {
        event = {
            ...event,
            camStatus: getTechCheckResults(camStatus),
            micStatus: getTechCheckResults(micStatus),
            networkStatus: getTechCheckResults(networkStatus),
        };
    }

    let status: TechCheckStatus = 'fail';
    if (Object.values(event).every((val) => val === 'pass')) {
        status = 'pass';

        V2Analytics.interactionEvent({
            eventName: 'media_permission_check',
            visit_id: visitId,
        });
        V2Analytics.interactionEvent({
            eventName: 'camera_check',
            visit_id: visitId,
        });
        V2Analytics.interactionEvent({
            eventName: 'mic_check',
            visit_id: visitId,
        });
        V2Analytics.interactionEvent({
            eventName: 'tech_check_complete',
            visit_id: visitId,
        });
    } else {
        V2Analytics.interactionEvent({
            eventName: 'tech_check_fail',
            visit_id: visitId,
        });
    }

    BlisseyLogger.debug({ details: { event } }, 'sending waitingroom events');
    void visitServiceClient.sendWaitingRoomEvent(visitId, {
        techCheck: { status, ...event },
    });
}

export const sendGenericTechCheckEvent = (
    visitId: string,
    techCheckLogic: TechCheckLogic
): void => {
    let overallPassed = false;
    const model: TechCheck = techCheckLogic.model as TechCheck;
    if (model.isConnected) {
        V2Analytics?.interactionEvent({
            eventName: 'tech_check_complete',
            visit_id: visitId,
        });
    }
    if (model.audioInputDetected) {
        V2Analytics?.interactionEvent({
            eventName: 'mic_check',
            visit_id: visitId,
        });
    }
    if (model.videoInputDetected) {
        V2Analytics?.interactionEvent({
            eventName: 'camera_check',
            visit_id: visitId,
        });
    }
    if (model.accessAllowed) {
        V2Analytics?.interactionEvent({
            eventName: 'media_permission_check',
            visit_id: visitId,
        });
    }
    if (!techCheckLogic.passed) {
        V2Analytics?.interactionEvent({
            eventName: 'tech_check_fail',
            visit_id: visitId,
        });
    } else {
        overallPassed = true;
    }

    // we have to translate the verbiage from the generic video conference client
    void getVisitServiceClient().sendWaitingRoomEvent(visitId, {
        techCheck: {
            status: overallPassed ? 'pass' : 'fail',
            camStatus: model.videoInputDetected ? 'pass' : 'fail',
            micStatus: model.audioInputDetected ? 'pass' : 'fail',
            mediaPermissionStatus: model.accessAllowed ? 'pass' : 'fail',
            networkStatus: model.isConnected ? 'pass' : 'fail',
        },
    });
};
