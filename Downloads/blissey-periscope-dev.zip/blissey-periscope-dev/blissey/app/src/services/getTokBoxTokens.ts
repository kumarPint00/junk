import { getBackendFacade } from "@clients/Backend/BackendFacade";
import { getVisitServiceClient } from "@clients/VisitService/VisitServiceClient";

export interface GetTokbokTokensRequest {
    visitId: string,
    userId: string,
    userIsProvider: boolean,
    visitSessionId: string,
    waitingRoomSessionId: string,
}

export interface UserTokens {
    visitToken: string,
    waitingRoomToken: string,
}

export const getTokboxTokens = async ({
    visitId,
    userId,
    userIsProvider,
    visitSessionId,
    waitingRoomSessionId,
}: GetTokbokTokensRequest): Promise<UserTokens> => {
    let visitToken: string = '';
    let waitingRoomToken: string = '';
    if (userIsProvider) {
        // if the user is a provider we just need a visit / video token
        // request moderator provileges (this service is only used in new context)
        visitToken = (await getBackendFacade().generateTokboxProviderToken(
            visitSessionId,
            visitId,
            userId,
            true,
        ) as { token: string }).token;
    } else {
        // patients need a visit and waiting room token
        visitToken = (await getVisitServiceClient().generateTokboxPatientToken(
            visitSessionId,
            visitId
        ) as { token: string }).token;
        waitingRoomToken = (await getVisitServiceClient().generateTokboxPatientToken(
            waitingRoomSessionId,
            visitId
        ) as { token: string }).token;
    }
    // return generated tokens
    return {
        visitToken,
        waitingRoomToken,
    }
}