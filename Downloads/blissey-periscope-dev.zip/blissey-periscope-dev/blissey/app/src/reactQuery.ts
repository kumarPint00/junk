import { QueryClient } from '@tanstack/react-query';

export const queryClientOptions = {
    defaultOptions: {
        queries: {
            refetchOnMount: false, // we need to control our refetching
            refetchOnWindowFocus: false, // please no lol!
            refetchOnReconnect: true, // sounds good
            cacheTime: 0, // we almost never want to cache data here,
            structuralSharing: false, // dont recycle cached data even if it's the same
            retry: 0, // we don't want to retry queries by default
            staleTime: 0,
        }
    }
}
export const queryClient = new QueryClient({ ...queryClientOptions });