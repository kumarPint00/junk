export type VisitReason = {
    key: string;
    value: string;
};

export enum ReasonType {
    WAIVE = 'waive',
    DECLINE = 'decline',
}
export type ReasonData = {
    reasonType: ReasonType;
    reasons: VisitReason[];
}[];
