export enum SurveyType {
    Provider = 'provider',
    Patient = 'patient',
}
