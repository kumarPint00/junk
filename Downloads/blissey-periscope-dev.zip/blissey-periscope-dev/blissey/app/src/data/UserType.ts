export enum UserType {
    Provider = 'telehealth_provider',
    Patient = 'telehealth_patient',
    PRR = 'telehealth_prr',
}
