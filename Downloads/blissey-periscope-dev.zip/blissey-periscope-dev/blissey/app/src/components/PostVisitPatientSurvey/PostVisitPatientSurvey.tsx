import * as React from 'react';
import { useEffect, useState } from 'react';
import { Survey } from 'survey-react-ui';
import { Model } from 'survey-core';
import surveyTheme from './SurveyTheme';
import {
    Card,
    CardContent,
    CircularProgress,
    Link,
    Typography,
} from '@mui/material';
import './PostVisitPatientSurvey.css';
import 'survey-core/survey-core.min.css';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { PostVisitSurvey } from '@clients/VisitService/VisitInterfaces';
import { BlisseyLogger } from '@utils/Logger';
import { SurveyType } from '../../data/SurveyType';
import { backendFacade } from '@clients/Backend/BackendFacade';

interface PostVisitPatientSurveyProps {
    submit: () => void;
    visitId: string;
}

const PostVisitPatientSurvey: React.FC<PostVisitPatientSurveyProps> = ({
    submit,
    visitId,
}) => {
    const [survey, setSurvey] = useState<PostVisitSurvey | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const [isComplete, setIsComplete] = useState(false);

    useEffect(() => {
        const fetchSurveyData = async () => {
            return await visitServiceClient.getLatestSurvey(SurveyType.Patient);
        };

        fetchSurveyData()
            .then((surveyDefinition) => setSurvey(surveyDefinition))
            .catch((error: Error) => {
                BlisseyLogger.info(
                    {
                        eventSource: 'PostVisitPatientSurvey',
                        eventType: 'render',
                    },
                    error.message,
                );
                return setErrorMessage('Failed to fetch survey definition');
            })
            .finally(() => setIsLoading(false));
    }, []);

    if (isLoading) {
        return (
            <div className="PostVisitProviderSurveyContainer">
                <div className="PostVisitProviderSurvey">
                    <div className="isLoading">
                        <CircularProgress size={20} />
                    </div>
                </div>
            </div>
        );
    }

    if (errorMessage || !survey) {
        return (
            <div className="PostVisitProviderSurveyContainer">
                <div className="PostVisitProviderSurvey">
                    <Card>
                        <CardContent>
                            <Typography align="center">
                                {errorMessage ?? 'Survey not available.'}
                            </Typography>
                        </CardContent>
                    </Card>
                </div>
            </div>
        );
    }

    const surveyDefinition = new Model(survey?.surveyDefinition);
    surveyDefinition.applyTheme(surveyTheme);
    surveyDefinition.showCompletedPage = false;
    surveyDefinition.showHeaderOnCompletePage = false;

    surveyDefinition.onComplete.add(async (sender) => {
        setIsComplete(true);

        try {
            await backendFacade.sendSubmitSurveyResponseMimirEvent({
                visitId,
                userRole: SurveyType.Patient,
                survey: sender.data as object,
                surveyId: survey?.id,
            });

            submit();
        } catch (error: unknown) {
            BlisseyLogger.info(
                {
                    eventSource: 'PostVisitPatientSurvey',
                    eventType: 'submit',
                },
                'Failed to submit survey response',
            );
            setErrorMessage('Failed to submit survey response');
        }
    });

    if (isComplete) {
        return null; // unmount survey entirely after completion
    }

    return (
        <Card>
            <div className="PostVisitPatientSurvey">
                <Survey
                    model={surveyDefinition}
                    css={{
                        root: 'post-visit-patient-survey',
                    }}
                />
                <Link
                    onClick={() => {
                        if (submit) {
                            submit();
                        }
                    }}
                    className="skip-link"
                >
                    SKIP
                </Link>
            </div>
        </Card>
    );
};

export default PostVisitPatientSurvey;
