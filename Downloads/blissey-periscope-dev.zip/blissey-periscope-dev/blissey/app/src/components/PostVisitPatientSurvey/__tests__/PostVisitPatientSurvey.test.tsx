import * as React from 'react';
import { render, waitFor } from '@testing-library/react';
import PostVisitPatientSurvey from '../PostVisitPatientSurvey';
import { Survey } from 'survey-react-ui';
import { Model } from 'survey-core';
import { vi } from 'vitest';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { SurveyType } from '../../../data/SurveyType';
import { backendFacade } from '@clients/Backend/BackendFacade';

const mockGetLatestSurvey = vi.fn(async () => {
    await new Promise((resolve) => setTimeout(resolve, 100));

    return {
        title: 'Mocked Survey',
        questions: [
            { name: 'question1', type: 'text', title: 'Question 1' },
            { name: 'question2', type: 'checkbox', title: 'Question 2' },
        ],
    };
}) as unknown as typeof visitServiceClient.getLatestSurvey;

visitServiceClient.getLatestSurvey = mockGetLatestSurvey;

vi.mock('@clients/VisitService/VisitServiceClient', () => ({
    visitServiceClient: {
        getLatestSurvey: vi.fn().mockResolvedValue({ surveyDefinition: {} }),
    },
}));

vi.mock('@clients/Backend/BackendFacade', () => ({
    backendFacade: {
        sendSubmitSurveyResponseMimirEvent: vi.fn(),
    },
}));

vi.mock('survey-react-ui', () => ({
    Survey: vi.fn(() => null),
}));

const mockApplyTheme = vi.fn();
const mockOnCompleteAdd = vi.fn();
const mockAddNavigationItem = vi.fn();

vi.mock('survey-core', () => ({
    Model: vi.fn(() => ({
        applyTheme: mockApplyTheme,
        onComplete: {
            add: mockOnCompleteAdd,
        },
        addNavigationItem: mockAddNavigationItem,
    })),
}));

vi.mock('@clients/Backend/BackendFacade', () => ({
    backendFacade: {
        sendSubmitSurveyResponseMimirEvent: vi.fn(),
    },
}));

describe('PostVisitPatientSurvey', () => {
    it('renders the survey', async () => {
        const submit = vi.fn();
        render(<PostVisitPatientSurvey submit={submit} visitId="1234" />);

        await waitFor(() => {
            expect(Survey).toHaveBeenCalled();
            expect(mockGetLatestSurvey).toHaveBeenCalledWith('patient');
            expect(Model).toHaveBeenCalled();
            expect(mockApplyTheme).toHaveBeenCalled();
            expect(mockOnCompleteAdd).toHaveBeenCalled();
        });
    });

    it('creates a survey model', async () => {
        const submit = vi.fn();
        render(<PostVisitPatientSurvey submit={submit} visitId="1234" />);

        await waitFor(() => {
            expect(Model).toHaveBeenCalled();
        });
    });

    it('applies the survey theme', async () => {
        const submit = vi.fn();
        render(<PostVisitPatientSurvey submit={submit} visitId="1234" />);

        await waitFor(() => {
            expect(mockApplyTheme).toHaveBeenCalled();
        });
    });

    it('adds a complete event listener', async () => {
        const submit = vi.fn();
        render(<PostVisitPatientSurvey submit={submit} visitId="1234" />);

        await waitFor(() => {
            expect(mockOnCompleteAdd).toHaveBeenCalled();
        });
    });

    it('submits the survey response', async () => {
        const submit = vi.fn();
        render(<PostVisitPatientSurvey submit={submit} visitId="1234" />);

        await waitFor(() => {
            expect(mockOnCompleteAdd).toHaveBeenCalled();

            if (mockOnCompleteAdd.mock.calls.length > 0) {
                const firstCall = mockOnCompleteAdd.mock.calls[0] as [
                    (data: object) => void,
                ];
                const onComplete = firstCall[0];
                onComplete({ data: {} });

                expect(
                    backendFacade.sendSubmitSurveyResponseMimirEvent,
                ).toHaveBeenCalledWith({
                    visitId: '1234',
                    userRole: SurveyType.Patient,
                    survey: {},
                    surveyId: undefined,
                });
            }
        });
    });
});
