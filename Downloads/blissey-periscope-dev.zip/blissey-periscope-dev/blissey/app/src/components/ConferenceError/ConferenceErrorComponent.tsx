import * as React from 'react';

import { LogManager } from '@dexcare/circus-jupiter';
import { MessageComponent } from '../Message/MessageComponent';
import {
    conferenceMessageMap,
    init,
} from '../../common/ConferenceErrorMessage';
import { ConferenceErrorProps } from './ConferenceErrorInterfaces';
import { ConferenceError } from '@modules/VideoCall/ConferenceError';
import { MessageType } from '@components/Message/MessageInterfaces';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
export class ConferenceErrorComponent extends React.PureComponent<ConferenceErrorProps> {
    public render() {
        init();
        let messageDetails = conferenceMessageMap.get(
            this.props.conferenceMessageKey,
        )!;
        if (!messageDetails) {
            messageDetails = conferenceMessageMap.get(
                ConferenceError[ConferenceError.Other],
            )!;
        }
        LogManager.getLogger().child(
            {
                eventSource: 'ConferenceErrorComponent',
                eventType: 'render',
                details: {
                    messageType: messageDetails.messageType,
                    msg: messageDetails.message as object,
                },
            },
            messageDetails.message as boolean,
        );

        if (messageDetails.messageType === MessageType.Error) {
            V2Analytics.errorEvent({
                text:
                    (
                        messageDetails.message as React.ReactElement<{
                            children: string[];
                        }>
                    )?.props?.children[1] || '',
                type: 'conference error',
            });
        }

        const messageProps = {
            message: messageDetails.message as string,
            messageType: messageDetails.messageType,
            icon: messageDetails.icon,
        };
        return (
            <div data-uitest={this.props.dataUiTest}>
                <MessageComponent {...messageProps} />
            </div>
        );
    }
}
