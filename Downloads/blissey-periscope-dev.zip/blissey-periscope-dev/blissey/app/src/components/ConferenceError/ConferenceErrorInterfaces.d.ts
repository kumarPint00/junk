export interface ConferenceErrorProps {
    conferenceMessageKey: string;
    className?: string;
    dataUiTest?: string;
}
