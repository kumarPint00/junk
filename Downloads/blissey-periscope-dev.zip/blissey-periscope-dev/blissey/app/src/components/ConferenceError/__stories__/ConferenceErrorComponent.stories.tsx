import * as React from 'react';

import { ConferenceErrorComponent } from '../ConferenceErrorComponent';
import { ConferenceErrorProps } from '../ConferenceErrorInterfaces';
import { StoryFn } from '@storybook/react';

const Template = (props: ConferenceErrorProps) => (
    <ConferenceErrorComponent {...props} />
);

export const Primary = Template.bind({}) as StoryFn<
    typeof ConferenceErrorComponent
>;
Primary.args = {
    conferenceMessageKey: 'DialingMessage',
};

export default {
    title: 'Components/ConferenceErrorComponent',
    component: ConferenceErrorComponent,
    argTypes: {
        conferenceMessageKey: {
            options: [
                'DialingMessage',
                'ConnectedMessage',
                'CameraWarningMessage',
                'MicrophoneWarningMessage',
                'ReconnectingMessage',
                'DisconnectedMessage',
                'ConferenceInactiveSubMessage',
                'ConferenceInactive',
                'NetworkIssues',
                null,
            ],
            control: { type: 'radio' },
        },
    },
    parameters: {
        layout: 'centered',
    },
};
