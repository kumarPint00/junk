import * as React from 'react';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import PhotoCamera from '@mui/icons-material/PhotoCamera';
import Mic from '@mui/icons-material/Mic';
import { withTranslation } from 'react-i18next';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

import { DeviceSelectionComponentProps } from './DeviceSelectionComponentInterfaces';

import * as styles from './DeviceSelectionComponentStyles.css';
class DeviceSelectionComponent extends React.Component<DeviceSelectionComponentProps> {
    constructor(props: DeviceSelectionComponentProps) {
        super(props);
    }

    public render() {
        const {
            onCameraChange,
            selectedCamera = '',
            videoDevices = [],
            audioDevices = [],
            onAudioChange,
            selectedAudio = '',
            disabled,
        } = this.props;

        // TODO: this logic should be consolidated into 1 generic device-selection component
        // then it can be pulled into CallSelfCheckComponent directly
        return (
            <div className={styles.container}>
                <div className={styles.dropdownPosition}>
                    {!disabled && (
                        <span className={styles.icon}>
                            <PhotoCamera />
                        </span>
                    )}
                    <FormControl
                        className={styles.formControl}
                        disabled={disabled}
                        variant="standard"
                    >
                        <InputLabel id="cam-select-label">
                            {this.props.t('waiting-room.videoSettings')}
                        </InputLabel>
                        <Select
                            data-uitest="cam-select"
                            labelId="cam-select-label"
                            id="cam-select"
                            fullWidth
                            onChange={onCameraChange}
                            value={selectedCamera}
                            label={this.props.t('waiting-room.videoSettings')}
                            onOpen={() =>
                                V2Analytics.interactionEvent({
                                    eventName: 'open_menu',
                                    menu_type: 'video settings',
                                })
                            }
                            variant="standard"
                        >
                            {videoDevices.map((device) => (
                                <MenuItem
                                    key={device.value}
                                    value={device.value}
                                >
                                    {device.label}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </div>
                <div className={styles.dropdownPosition}>
                    {!disabled && (
                        <span className={styles.icon}>
                            <Mic />
                        </span>
                    )}
                    <FormControl
                        className={styles.formControl}
                        disabled={disabled}
                        variant="standard"
                    >
                        <InputLabel id="mic-select-label">
                            {this.props.t('waiting-room.audioSettings')}
                        </InputLabel>
                        <Select
                            data-uitest="mic-select"
                            labelId="mic-select-label"
                            id="mic-select"
                            fullWidth
                            onChange={onAudioChange}
                            value={selectedAudio}
                            label={this.props.t('waiting-room.audioSettings')}
                            onOpen={() =>
                                V2Analytics.interactionEvent({
                                    eventName: 'open_menu',
                                    menu_type: 'audio settings',
                                })
                            }
                        >
                            {audioDevices.map((device) => (
                                <MenuItem
                                    key={device.value}
                                    value={device.value}
                                >
                                    {device.label}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </div>
            </div>
        );
    }
}

const _DeviceSelectionComponent = withTranslation()(DeviceSelectionComponent);
export { _DeviceSelectionComponent as DeviceSelectionComponent };
