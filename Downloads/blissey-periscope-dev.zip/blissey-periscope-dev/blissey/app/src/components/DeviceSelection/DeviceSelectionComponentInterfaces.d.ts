import { WithTranslation } from 'react-i18next';

import { MediaDevice } from '@common/video';
import { SelectChangeEvent } from '@mui/material';

export interface DeviceSelectionComponentProps extends WithTranslation {
    onCameraChange: (event: SelectChangeEvent<string>) => void;
    selectedCamera: string;
    videoDevices: MediaDevice[];
    onAudioChange: (event: SelectChangeEvent<string>) => void;
    selectedAudio: string;
    audioDevices: MediaDevice[];
    disabled: boolean;
}
