import { BlisseyLogger } from '@utils/Logger';
import * as React from 'react';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

interface Props {
    children?: React.ReactNode;
}

export class ErrorBoundary extends React.Component<
    Props,
    {
        hasError: boolean;
    }
> {
    constructor(props: Props) {
        super(props);
        this.state = { hasError: false };
    }

    static getDerivedStateFromError() {
        // Update state so the next render will show the fallback UI.
        V2Analytics.errorEvent({
            text: 'something went wrong',
            type: 'unknown',
        });
        return { hasError: true };
    }

    public componentDidCatch() {
        BlisseyLogger.error('ErrorBoundary hit');
    }

    render() {
        if (this.state.hasError) {
            return <h1>Something went wrong.</h1>;
        }
        return this.props.children;
    }
}
