import { CallLengthTimer } from '../CallLengthTimer';

export default {
    title: 'Components/CallLengthTimer',
    component: CallLengthTimer,
};

export const Default = {
    args: {
        callStartTime: new Date().getTime(),
    },
};
