import * as React from 'react';

import {
    CallLengthTimerProps,
    CallLengthTimerState,
} from './CallLengthTimerInterfaces';

import * as styles from './CallLengthTimer.css';

export class CallLengthTimer extends React.PureComponent<
    CallLengthTimerProps,
    CallLengthTimerState
> {
    public getTimeElapsed = (): number => {
        if (!this.props.callStartTime) {
            return 0;
        }

        return new Date().getTime() - this.props.callStartTime;
    };

    constructor(props: CallLengthTimerProps) {
        super(props);
        this.state = {
            timeElapsed: this.getTimeElapsed(),
            timerId: null,
        };
    }

    public componentDidMount() {
        const timerId = setInterval(() => {
            const timeElapsed = this.getTimeElapsed();
            this.setState({
                timeElapsed,
            });
        }, 5000);
        this.setState({ timerId });
    }

    public UNSAFE_componentWillMount() {
        clearInterval(this.state.timerId as number | undefined);
        this.setState({ timerId: null });
    }

    public getDisplayTime(time: number): string {
        let minutes = Math.round(time / 1000 / 60);
        minutes = Math.max(Math.min(999, minutes), 1);
        return `${minutes}`;
    }

    public render() {
        if (!this.props.callStartTime) {
            return null;
        }

        return (
            <div className={styles.timer}>
                {this.getDisplayTime(this.state.timeElapsed)}
            </div>
        );
    }
}
