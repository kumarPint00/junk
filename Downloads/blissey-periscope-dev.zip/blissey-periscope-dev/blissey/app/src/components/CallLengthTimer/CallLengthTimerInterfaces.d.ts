export interface CallLengthTimerProps {
    callStartTime: number | null;
}

export interface CallLengthTimerState {
    timerId: string | number | ReturnType<typeof setInterval> | null;
    timeElapsed: number;
}
