import * as React from 'react';

import * as styles from './ThanksComponent.css';

export function ThanksComponent() {
    return <div className={styles.thanks}>Thanks.</div>;
}
