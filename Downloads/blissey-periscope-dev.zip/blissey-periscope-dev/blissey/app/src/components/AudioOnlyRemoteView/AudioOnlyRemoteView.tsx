import * as React from 'react';

import * as styles from './AudioOnlyRemoteView.css';
import { UserDetails } from '@dexcare/circus-saturn';

export function AudioOnlyRemoteView(props: {
    user?: UserDetails;
    audioOnly: boolean;
}) {
    return (
        <div className={styles.main}>
            <div className={styles.outside}>
                <div className={styles.inner} />
            </div>
            <div className={styles.displayContainer}>
                {props?.user?.displayName || ''}
            </div>
            {props.audioOnly ? (
                <div className={styles.audioText}>AUDIO ONLY</div>
            ) : null}
        </div>
    );
}
