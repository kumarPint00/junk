import * as React from 'react';

import MUISnackbar, {
    SnackbarProps as MUISnackbarProps,
} from '@mui/material/Snackbar';
import ErrorIcon from '@mui/icons-material/Error';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

import { SnackbarAction } from './SnackbarAction';

type Props = MUISnackbarProps & {
    onDismiss: () => void;
    type?: string;
};

export const ErrorSnackbar = (props: Props) => {
    const muiSnackbarProps: MUISnackbarProps = {
        anchorOrigin: {
            vertical: 'bottom',
            horizontal: 'center',
        },
        autoHideDuration: 10000,
        action: (
            <SnackbarAction onClick={props.onDismiss}>Dismiss</SnackbarAction>
        ),
        ...props,
        message: (
            <>
                <ErrorIcon />
                {props.message}
            </>
        ),
    };
    if (muiSnackbarProps.open && muiSnackbarProps.message) {
        V2Analytics.errorEvent({ text: props.message, type: props.type });
    }

    return <MUISnackbar {...muiSnackbarProps} />;
};
