import * as React from 'react';
import { Button } from '@components/Button';

const styles = {
    root: {
        fontWeight: 600,
    },
};

export const SnackbarAction: React.FunctionComponent<
    React.PropsWithChildren<{
        onClick?: (
            event: React.MouseEvent<HTMLButtonElement, MouseEvent>,
        ) => void;
    }>
> = ({ onClick, children }) => {
    return (
        <Button
            variant="text"
            size="small"
            color="grey"
            fullWidth={false}
            onClick={onClick}
            sx={styles.root}
        >
            {children}
        </Button>
    );
};
