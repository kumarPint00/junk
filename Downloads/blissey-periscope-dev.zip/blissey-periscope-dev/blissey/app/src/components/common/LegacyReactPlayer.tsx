import * as React from 'react';
import ReactPlayer from 'react-player';

// Lightweight wrapper to preserve legacy `url` prop usage after upstream typing changes.
// Accepts any props and forwards to ReactPlayer; keeps code modifications minimal during migration.
export interface LegacyReactPlayerProps extends Omit<any, 'ref'> {
  url: any;
}

export const LegacyReactPlayer: React.FC<LegacyReactPlayerProps> = (props) => {
  const { url, ...rest } = props as any;
  return <ReactPlayer {...rest} url={url} />;
};

export default LegacyReactPlayer;