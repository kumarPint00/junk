import { VerifyOTPComponent } from '../VerifyOTPComponent';

const defaultProps = {
    localizedText: {
        verifyInstructionHeaderText: 'instruction header text',
        verifyInstructionLineValid: 'instruction line valid',
        verifyModifiedInstructionPhone: 'instruction phone',
        verifyModifiedInstructionEmail: 'instruction email',
        verifyButtonText: 'button text',
        verifyLinkText: 'link text',
        verifyPasscodeLabelText: 'passcode label',
        errorMessageText: undefined,
    },
    onVerifyPasscodeButtonClick: (): void => undefined,
    onVerifyDidNotReceiveCode: (): void => undefined,
    otpMethod: 'email',
    otpCode: '',
    setOTPCode: (): void => undefined,
    isLoading: false,
};

export default {
    title: 'Components/VerityOTPWindow',
    component: VerifyOTPComponent,
};

export const Email = {
    args: { ...defaultProps },
};

export const Phone = {
    args: {
        ...defaultProps,
        otpMethod: 'phone',
    },
};

export const Loading = {
    args: {
        ...defaultProps,
        otpCode: 'code',
        isLoading: true,
    },
};

export const ErrorMessage = {
    args: {
        ...defaultProps,
        otpCode: 'code',
        localizedText: {
            ...defaultProps.localizedText,
            errorMessageText: 'Oops its broked.',
        },
    },
};
