import * as React from 'react';
import { TextField, Link } from '@mui/material';
import { PillButton } from '@components/Button';

import * as styles from './VerifyOTPComponent.css';

export interface VerifyOTPComponentProps {
    localizedText: {
        verifyInstructionHeaderText: string;
        verifyInstructionLineValid: string;
        verifyModifiedInstructionPhone: string;
        verifyModifiedInstructionEmail: string;
        verifyButtonText: string;
        verifyLinkText: string;
        verifyPasscodeLabelText: string;
        errorMessageText: string | undefined;
    };
    onVerifyPasscodeButtonClick: () => void;
    onVerifyDidNotReceiveCode: () => void;
    otpMethod: string;
    otpCode: string;
    setOTPCode: React.Dispatch<React.SetStateAction<string>>;
    isLoading: boolean;
}

export const VerifyOTPComponent = ({
    localizedText,
    onVerifyPasscodeButtonClick,
    onVerifyDidNotReceiveCode,
    otpMethod,
    otpCode,
    setOTPCode,
    isLoading,
}: VerifyOTPComponentProps) => {
    const {
        verifyInstructionHeaderText,
        verifyInstructionLineValid,
        verifyModifiedInstructionPhone,
        verifyModifiedInstructionEmail,
        verifyButtonText,
        verifyLinkText,
        errorMessageText,
        verifyPasscodeLabelText,
    } = localizedText;

    const handleButtonClick = () => {
        onVerifyPasscodeButtonClick();
    };

    const handleLinkClick = () => {
        onVerifyDidNotReceiveCode();
    };

    const onTextChange = (evt: React.ChangeEvent<HTMLInputElement>) => {
        const {
            target: { value },
        } = evt;
        setOTPCode(value);
    };

    return (
        <div data-uitest="verify-otp-window" className={styles.otpWindow}>
            <div className={styles.instructions}>
                <div>
                    <b>{verifyInstructionHeaderText}</b>
                </div>
                <div>
                    {otpMethod === 'email'
                        ? verifyModifiedInstructionEmail
                        : verifyModifiedInstructionPhone}
                </div>
                <div>{verifyInstructionLineValid}</div>
            </div>
            <div className={styles.passwordBox}>
                <TextField
                    data-uitest="verify-otp-input"
                    data-1p-ignore
                    label={verifyPasscodeLabelText}
                    variant="standard"
                    value={otpCode}
                    onChange={onTextChange}
                    disabled={isLoading}
                    error={Boolean(errorMessageText)}
                />
                {errorMessageText && (
                    <div className={styles.inlineErrorMessage}>
                        {errorMessageText}
                    </div>
                )}
            </div>
            <div>
                <PillButton
                    data-uitest="verify-otp-button"
                    variant="contained"
                    color="grey"
                    onClick={handleButtonClick}
                    disabled={isLoading || !otpCode}
                >
                    {verifyButtonText}
                </PillButton>
            </div>
            <div className={styles.link}>
                <Link
                    data-uitest="verify-otp-link"
                    component="button"
                    onClick={handleLinkClick}
                    disabled={isLoading}
                >
                    {verifyLinkText}
                </Link>
            </div>
        </div>
    );
};
