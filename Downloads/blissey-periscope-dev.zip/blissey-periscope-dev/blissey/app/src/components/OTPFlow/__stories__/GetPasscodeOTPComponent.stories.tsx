import { GetPasscodeOTPComponent } from '../GetPasscodeOTPComponent';

const defaultProps = {
    patientInfo: {
        sms: '1234567890',
        email: 'example@example.com',
    },
    localizedText: {
        getOTPInstructionHeaderText: 'instruction header text',
        getOTPInstructionBodyText: 'instruction body text',
        getOTPDisclaimerText: 'disclaimer text',
        getOTPButtonText: 'button text',
        errorMessageText: undefined,
        dismissErrorModalText: 'Dismiss',
    },
    otpMethod: 'email',
    isLoading: false,
    onGetPasscodeButtonClick: (): void => undefined,
    setOTPMethod: (): void => undefined,
    handleSetErrorMessage: (): void => undefined,
};

export default {
    title: 'Components/GetPasscodeOTPComponent',
    component: GetPasscodeOTPComponent,
};

export const Default = {
    args: { ...defaultProps },
};

export const Loading = {
    args: {
        ...defaultProps,
        isLoading: true,
    },
};

export const ErrorMessage = {
    args: {
        ...defaultProps,
        localizedText: {
            ...defaultProps.localizedText,
            errorMessageText: 'Oops its broked.',
        },
    },
};
