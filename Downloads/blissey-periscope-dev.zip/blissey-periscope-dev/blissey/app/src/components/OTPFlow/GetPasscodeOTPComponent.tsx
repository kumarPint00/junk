import * as React from 'react';
import { Radio, RadioGroup, FormControlLabel } from '@mui/material';
import { MessageModal } from '@components/MessageModal/MessageModal';
import { PillButton } from '@components/Button';

import * as styles from './GetPasscodeOTPComponent.css';

export interface GetPasscodeOTPComponentProps {
    patientInfo: {
        sms: string;
        email: string;
    };
    localizedText: {
        getOTPInstructionHeaderText: string;
        getOTPInstructionBodyText: string;
        getOTPDisclaimerText: string;
        getOTPButtonText: string;
        errorMessageText: string | undefined;
        dismissErrorModalText: string;
    };
    otpMethod: string;
    isLoading: boolean;
    onGetPasscodeButtonClick: () => void;
    setOTPMethod: React.Dispatch<React.SetStateAction<string>>;
    handleSetErrorMessage: (message: string | undefined) => void;
}

export const GetPasscodeOTPComponent = ({
    patientInfo,
    localizedText,
    otpMethod,
    isLoading,
    onGetPasscodeButtonClick,
    setOTPMethod,
    handleSetErrorMessage,
}: GetPasscodeOTPComponentProps) => {
    const { email, sms } = patientInfo;
    const {
        getOTPInstructionHeaderText,
        getOTPInstructionBodyText,
        getOTPDisclaimerText,
        getOTPButtonText,
        errorMessageText,
        dismissErrorModalText,
    } = localizedText;

    const handleButtonClick = () => {
        onGetPasscodeButtonClick();
    };

    const onRadioChange = (
        event: React.ChangeEvent<HTMLInputElement>,
        value: string,
    ): void => {
        setOTPMethod(value || event.currentTarget.value);
    };

    const handleModalClose = () => {
        handleSetErrorMessage(undefined);
    };

    return (
        <div data-uitest="get-otp-password-window" className={styles.otpWindow}>
            <div className={styles.instructions}>
                <div>
                    <b>{getOTPInstructionHeaderText}</b>
                </div>
                <div>{getOTPInstructionBodyText}</div>
            </div>
            <RadioGroup value={otpMethod} onChange={onRadioChange}>
                <FormControlLabel
                    value="email"
                    control={
                        <Radio
                            color="primary"
                            inputProps={
                                {
                                    'data-uitest': 'email-radio',
                                } as React.InputHTMLAttributes<HTMLInputElement>
                            }
                        />
                    }
                    label={email}
                    disabled={isLoading}
                />
                <FormControlLabel
                    value="sms"
                    control={
                        <Radio
                            color="primary"
                            inputProps={
                                {
                                    'data-uitest': 'sms-radio',
                                } as React.InputHTMLAttributes<HTMLInputElement>
                            }
                        />
                    }
                    label={sms}
                    disabled={isLoading}
                />
            </RadioGroup>
            <div className={styles.disclaimer}>{getOTPDisclaimerText}</div>
            <PillButton
                data-uitest="get-otp-password-button"
                color="grey"
                variant="contained"
                onClick={handleButtonClick}
                disabled={isLoading}
            >
                {getOTPButtonText}
            </PillButton>
            <MessageModal
                isOpen={Boolean(errorMessageText)}
                messageText={errorMessageText}
                dismissButtonText={dismissErrorModalText}
                onModalClosed={handleModalClose}
            />
        </div>
    );
};
