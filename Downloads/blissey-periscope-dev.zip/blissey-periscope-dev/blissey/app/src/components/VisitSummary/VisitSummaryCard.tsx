import * as React from 'react';
import Card from '@mui/material/Card';
import { config } from '@dexcare/circus-jupiter';

import { VisitSummaryProps } from './VisitSummaryInterfaces';
import { AdCard } from '@components/AdvertisementCard/AdvertisementCard';

import * as styles from './VisitSummaryCard.css';
import { Configuration } from 'types/configuration';

export function VisitSummaryCard(props: VisitSummaryProps) {
    const {
        thanksText,
        concludeText,
        treatmentPlanText,
        treatmentPlanAltText,
        treatmentPlanAltURL,
        treatmentPlanAltTimeText,
        prescriptionText,
        followupText,
    } = props;

    const disablePrescriptionText =
        (config as Configuration).getConfig()?.visitSummaryText
            ?.disablePrescriptionText || false;

    const treatmentPlanAlternate =
        treatmentPlanAltText && treatmentPlanAltURL ? (
            <>
                <p className={styles.smallText}>
                    {treatmentPlanText}
                    <a href={treatmentPlanAltURL}>{treatmentPlanAltText}.</a>
                </p>
                {treatmentPlanAltTimeText && (
                    <p
                        dangerouslySetInnerHTML={{
                            __html: treatmentPlanAltTimeText,
                        }}
                    />
                )}
            </>
        ) : null;

    const advertisementComp = (
        <div className={styles.advertisementContainer}>
            <AdCard
                visitId={props.visitId}
                source={'thank_you'}
                t={props.t}
            />
        </div>
    );

    return (
        <div>
            <Card className={styles.card} data-uitest="visitsummary-card">
                <div className={styles.text}>
                    <p className={styles.mediumText}>
                        {thanksText}
                        <br />
                        {concludeText}
                    </p>
                    <p className={styles.smallText}>
                        {treatmentPlanAlternate || treatmentPlanText}
                    </p>
                    {followupText && (
                        <>
                            <br />
                            {followupText}
                        </>
                    )}
                    {!disablePrescriptionText && (
                        <p
                            dangerouslySetInnerHTML={{
                                __html: prescriptionText,
                            }}
                        />
                    )}
                </div>
            </Card>
            {advertisementComp}
        </div>
    );
}
