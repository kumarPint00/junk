export interface VisitSummaryProps {
    thanksText: string;
    concludeText: string;
    treatmentPlanText: string;
    treatmentPlanAltText: string;
    treatmentPlanAltURL: string;
    treatmentPlanAltTimeText: string;
    prescriptionText: string;
    followupText: string;
    visitId: string;
    t: (key: string, options?: Record<string, unknown>) => string;
}
