import { VisitSummaryCard } from '../VisitSummaryCard';

export const Default = {
    args: {
        thanksText: 'Thank you for choosing Express Care Virtual.',
        concludeText: 'This concludes your visit.',
        treatmentPlanText:
            'A treatment plan summary will be sent to you via secure email withing 24 hours.',
        prescriptionText: 'If you received a prescription please allow ',
    },
};

export default {
    title: 'Components/VisitSummary',
    component: VisitSummaryCard,
    parameters: {
        layout: 'centered',
    },
};
