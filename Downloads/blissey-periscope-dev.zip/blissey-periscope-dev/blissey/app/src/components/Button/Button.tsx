import * as React from 'react';
import MUIButton, { ButtonProps as MUIButtonProps } from '@mui/material/Button';

interface ButtonProps {
    uiTestTag?: string;
}

export type Props = ButtonProps & MUIButtonProps;

export const Button: React.FunctionComponent<Props> = (props: Props) => {
    const { children, uiTestTag, ...rest } = props;

    const muiButtonProps: MUIButtonProps = {
        color: 'primary',
        variant: 'contained',
        fullWidth: true,
        ...rest,
    };
    return (
        <MUIButton {...{ ...muiButtonProps }} data-uitest={uiTestTag}>
            {children}
        </MUIButton>
    );
};

export const PillButton: React.FunctionComponent<MUIButtonProps> = (props) => {
    return (
        <MUIButton
            {...props}
            sx={{
                borderRadius: '20px',
                backgroundColor: '#3172A8',
                color: 'white',
                cursor: 'pointer',
            }}
        />
    );
};
