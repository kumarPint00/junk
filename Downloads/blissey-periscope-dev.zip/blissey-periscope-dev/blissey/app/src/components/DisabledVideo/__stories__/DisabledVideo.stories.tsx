import { DisabledVideo } from '../DisabledVideo';

export default {
    title: 'Components/DisabledVideo',
    component: DisabledVideo,
    parameters: {
        layout: 'centered',
    },
};

export const Default = {
    args: {
        muterDisplayName: 'Jane Doe',
    },
};
