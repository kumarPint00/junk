import * as React from 'react';

import * as styles from './DisabledVideo.css';

export interface DisabledVideoProps {
    muterDisplayName: string;
}
export function DisabledVideo(props: DisabledVideoProps) {
    switch (props.muterDisplayName) {
        case '':
            return (
                <div className={styles.instructions}>
                    <p data-uitest="videodisabled-message">
                        The video feed has been momentarily disabled
                    </p>
                </div>
            );
        default:
            return (
                <div className={styles.instructions}>
                    <p
                        className={styles.text}
                        data-uitest="videodisabled-message"
                    >
                        {props.muterDisplayName} has momentarily disabled the
                        video feed
                    </p>
                </div>
            );
    }
}
