import { DisabledSelfView } from '../DisabledSelfView';

export default {
    title: 'Components/DisabledSelfView',
    component: DisabledSelfView,
    parameters: {
        layout: 'centered',
    },
};

export const Default = {
    args: {},
};
