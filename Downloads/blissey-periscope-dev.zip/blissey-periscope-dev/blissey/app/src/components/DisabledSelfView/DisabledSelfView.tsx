import * as React from 'react';

import * as styles from './DisabledSelfView.css';

export function DisabledSelfView() {
    return (
        <div className={styles.instructionsContainer}>
            <div className={styles.instructions}>
                <p data-uitest="selfview-disabled" className={styles.text}>
                    Your video feed is disabled
                </p>
            </div>
        </div>
    );
}
