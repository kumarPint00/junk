import * as React from 'react';
import { mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { Stream } from '@dexcare/yak';
import { Subscribers, SubscribersProps } from '../Subscriber';
import { vi } from 'vitest';

const wrappedComponent = (props: SubscribersProps) => {
    return mount(<Subscribers {...props} />);
};

describe('<Subscriber />', () => {
    let props: SubscribersProps;
    beforeEach(() => {
        props = {
            otStreams: [{ streamId: 'stream1' } as Stream],
            subscribe: vi.fn(),
        };
    });

    test('mounts streams', () => {
        expect(toJson(wrappedComponent(props))).toMatchSnapshot();
        expect(props.subscribe).toHaveBeenCalledTimes(1);
    });

    test('empty stream is handled', () => {
        const subscribe = vi.fn();
        expect(
            toJson(wrappedComponent({ otStreams: [], subscribe })),
        ).toMatchSnapshot();
        expect(props.subscribe).not.toHaveBeenCalled();
    });
});
