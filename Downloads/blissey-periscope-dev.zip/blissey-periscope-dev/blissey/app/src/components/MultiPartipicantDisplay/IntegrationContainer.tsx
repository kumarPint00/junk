import * as React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Action } from 'redux';
import { createSelector } from 'reselect';
import cn from 'classnames';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

import { ErrorSnackbar } from '@components/ErrorSnackbar';
import { Store } from '@redux/modules';
import { isTytoCareVisit } from '@redux/selectors/isTytoCareVisit';
import { isUserProvider } from '@redux/selectors/isUserProvider';
import {
    clearTytoCareError,
    hideTytoCareWidet,
    loadTytoCareWidget,
} from '@redux/modules/tytoCare';
import { TytoCareWidget } from '../TytoCare/TytoCareWidget';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import {
    VideoStatistics,
    VideoStats,
} from '@components/VideoStatistics/VideoStatistics';
import { IntegrationButtonList } from '@components/IntegrationButton';

import * as styles from './IntegrationContainer.css';
import { ThunkDispatch } from 'types/redux';

type Context = 'tytocare' | 'videostats';

const tytoCareButtonVisible = createSelector(
    isTytoCareVisit,
    isUserProvider,
    (isTytoCareVisit: boolean, isUserProvider: boolean) => {
        return isTytoCareVisit && isUserProvider;
    },
);

const videoIssueReportVisible = createSelector(
    isUserProvider,
    (isUserProvider) =>
        isUserProvider &&
        getFeatureFlag(FeatureFlags.providerStatsAndReportIssue),
);

export const IntegrationContainer = ({
    getStats,
}: {
    getStats: () => Promise<VideoStats>;
}) => {
    const [context, setContext] = React.useState<Context | null>(null);
    const [snack, setSnack] = React.useState<string | null>(null);

    const dispatch =
        useDispatch<ThunkDispatch<Store['All'], unknown, Action>>();
    const isProvider = useSelector(isUserProvider);
    const hasTytoCareButton = useSelector(tytoCareButtonVisible);
    const hasVideoReportButton = useSelector(
        videoIssueReportVisible,
    ) as boolean;

    const videoSessionId = useSelector(
        (state: Store['All']) => state.postconsult.tokBoxVideoSessionId,
    );
    const userDetails = useSelector(
        (state: Store['All']) => state.user.userDetails,
    );
    const visitId = useSelector(
        (state: Store['All']) => state.postconsult.visitId,
    );

    const tytoCareProviderUrl = useSelector(
        (state: Store['All']) => state.tytoCare.providerVisitUrl,
    );
    const tytoCareError = useSelector(
        (state: Store['All']) => state.tytoCare.error,
    );
    const loadingTytoCare = useSelector(
        (state: Store['All']) => state.tytoCare.loading,
    );

    const onMaximizeTyto = React.useCallback(() => {
        dispatch(loadTytoCareWidget() as (...args: unknown[]) => void);
        setContext('tytocare');
    }, [dispatch]);
    const onMinimize = React.useCallback(() => {
        switch (context) {
            case 'tytocare':
                dispatch(hideTytoCareWidet());
        }
        V2Analytics.interactionEvent({ eventName: 'close_video_statistics' });

        setContext(null);
    }, [context, dispatch]);
    const dismissSnack = React.useCallback(() => {
        // TODO: possibly consolidate to 1 snack message
        if (snack) {
            setSnack(null);
        }
        if (tytoCareError) {
            clearTytoCareError();
        }
    }, [snack, tytoCareError]);
    const onMaximizeVideoStats = React.useCallback(() => {
        V2Analytics.interactionEvent({ eventName: 'open_video_statistics' });
        setContext('videostats');
    }, []);
    const onErrorSubmitted = React.useCallback(() => {
        setSnack('Error Report Submitted');
        setContext(null);
    }, []);

    const sidePaneVisible =
        isProvider && (hasTytoCareButton || hasVideoReportButton);

    const snackMessage = tytoCareError || snack;
    let minimized = true;
    switch (context) {
        case 'tytocare':
            minimized = !tytoCareProviderUrl && !loadingTytoCare;
            break;
        case 'videostats':
            minimized = false;
    }
    return (
        <>
            {sidePaneVisible && (
                <>
                    {minimized && (
                        <IntegrationButtonList
                            open={false}
                            tytoCare={{
                                enabled: hasTytoCareButton,
                                onClick: onMaximizeTyto,
                            }}
                            videoStats={{
                                enabled: hasVideoReportButton,
                                onClick: onMaximizeVideoStats,
                            }}
                        />
                    )}
                    <div
                        className={cn(
                            styles.container,
                            minimized
                                ? styles.containerHidden
                                : styles.containerShown,
                        )}
                    >
                        {
                            <IntegrationButtonList
                                open={true}
                                tytoCare={{
                                    enabled: hasTytoCareButton,
                                    onClick: onMinimize,
                                }}
                                videoStats={{
                                    enabled: hasVideoReportButton,
                                    onClick: onMinimize,
                                }}
                            />
                        }
                        {context === 'tytocare' && (
                            <TytoCareWidget sourceUrl={tytoCareProviderUrl} />
                        )}
                        {context === 'videostats' && videoSessionId && (
                            <VideoStatistics
                                sessionId={videoSessionId}
                                userId={userDetails?.id}
                                userRoles={userDetails?.roles || []}
                                visitId={visitId}
                                getStats={getStats}
                                onClose={onMinimize}
                                onSubmitted={onErrorSubmitted}
                            />
                        )}
                    </div>
                    <ErrorSnackbar
                        open={!!snackMessage}
                        message={snackMessage}
                        onDismiss={dismissSnack}
                        onClose={dismissSnack}
                    />
                </>
            )}
        </>
    );
};
