import * as React from 'react';
import { OTStream } from '@components/CameraDisplay/OTStream';
import { streamTargetElement } from '@utils/otUtils';
import { DisabledVideo } from '@components/DisabledVideo/DisabledVideo';
import { Logger } from '../../utils';
import { SubscribeHandlers, Stream } from '@dexcare/yak';

import * as styles from './Subscriber.css';

export type SubscribeToStream = (
    streamId: string,
    handlers: SubscribeHandlers,
) => OT.Subscriber | undefined;
export interface SubscribersProps {
    otStreams: Stream[];
    subscribe: SubscribeToStream;
}

export function Subscribers({ otStreams, subscribe }: SubscribersProps) {
    return (
        <>
            {otStreams.map((stream: OT.Stream) => {
                if (stream) {
                    return (
                        <Subscriber
                            streamId={stream.streamId}
                            subscribe={subscribe}
                            key={stream.streamId}
                        />
                    );
                }
                Logger.info(
                    { eventType: 'tokbox', eventSource: 'Subscribers' },
                    'Subscribers component - null stream',
                );
                return <></>;
            })}
        </>
    );
}
interface SubscriberProps {
    streamId: string;
    subscribe: SubscribeToStream;
}
class Subscriber extends React.Component<
    SubscriberProps,
    { videoEnabled: boolean }
> {
    private otSubscriber?: OT.Subscriber;

    constructor(props: SubscriberProps) {
        super(props);
        // TODO how to get mic state
        this.state = {
            videoEnabled: true,
        };
    }
    private setVideoEnabled = (val: boolean) => () => {
        Logger.info(
            {
                enabled: val,
                eventType: 'tokbox',
                eventSource: 'SubscriberComponent',
            },
            'subscriber video enabled updated',
        );
        this.setState({ videoEnabled: val });
    };

    public componentWillUnmount() {
        if (this.otSubscriber) {
            this.otSubscriber.off();
        }
    }

    public componentDidMount() {
        // possible events to listen to: connected, destroyed
        this.otSubscriber = this.props.subscribe(this.props.streamId, {
            onVideoEnabled: this.setVideoEnabled(true),
            onVideoDisabled: this.setVideoEnabled(false),
        });
    }

    public render() {
        const { streamId } = this.props;
        const divId = streamTargetElement(streamId);
        return (
            <>
                {!this.state.videoEnabled && ( // TODO get remote visit displayname
                    <div className={styles.disabledVideoContainer}>
                        <DisabledVideo muterDisplayName={''} />
                    </div>
                )}
                <OTStream key={`${divId}-container`} id={divId} />
            </>
        );
    }
}
