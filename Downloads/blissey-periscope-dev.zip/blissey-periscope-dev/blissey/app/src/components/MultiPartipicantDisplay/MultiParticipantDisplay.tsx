import * as React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Action } from 'redux';
import { Stream } from '@dexcare/yak';
import { Subscribers, SubscribeToStream } from './Subscriber';
import { OTConnectionView } from '@components/CameraDisplay/OTConnection';
import Publisher from './Publisher';
import { IntegrationContainer } from './IntegrationContainer';
import {
    OTConnection,
    OTPublishingStatus,
    OTSubscribingStatus,
} from '@utils/otUtils';
import { setIsChatVisible } from '@redux/modules/videoMenu';
import { isUserProvider } from '@redux/selectors/isUserProvider';
import { VideoStats } from '@components/VideoStatistics/VideoStatistics';
import * as styles from './MultiParticipantDisplay.css';
import { ThunkDispatch } from 'types/redux';
import { Store } from '@redux/modules';

export interface MultiParticipantDisplayProps {
    publisherId: string;
    isProvider: boolean;
    otConnectionStatus?: OTConnection;
    otSubscribingStatus?: OTSubscribingStatus;
    otPublishingStatus?: OTPublishingStatus;
    otStreams: Stream[];
    getStats: () => Promise<VideoStats>;
    onReconnect: () => void;
    publish: () => Promise<void>;
    subscribe: SubscribeToStream;
    toggleMicEnabled: () => void;
    toggleCamEnabled: () => void;
    cleanupSelfView: () => void;
    toggleBlurEnabled: () => void;
    onDeviceChange: (cameraDeviceId: string, audioDeviceId: string) => void;
}

const MultiParticipantDisplay = React.memo(
    ({
        otConnectionStatus,
        otSubscribingStatus,
        otPublishingStatus,
        otStreams,
        publisherId,
        getStats,
        onReconnect,
        subscribe,
        publish,
        toggleMicEnabled,
        toggleCamEnabled,
        cleanupSelfView,
        toggleBlurEnabled,
        onDeviceChange,
    }: MultiParticipantDisplayProps) => {
        const dispatch =
            useDispatch<ThunkDispatch<Store['All'], unknown, Action>>();
        const isProvider = useSelector(isUserProvider);

        React.useEffect(() => {
            dispatch(setIsChatVisible(false));
        }, [dispatch]);

        return (
            <div className={styles.streamsContainer}>
                {isProvider && <IntegrationContainer getStats={getStats} />}
                <div className={styles.subscriberContainer}>
                    <Subscribers otStreams={otStreams} subscribe={subscribe} />
                    <OTConnectionView
                        onReconnect={onReconnect}
                        otConnectionStatus={otConnectionStatus}
                        otSubscribingStatus={otSubscribingStatus}
                        otPublishingStatus={otPublishingStatus}
                        otStreams={otStreams}
                    />
                    <div className={styles.publisherContainer}>
                        <Publisher
                            id={publisherId}
                            publish={publish}
                            toggleMicEnabled={toggleMicEnabled}
                            toggleCamEnabled={toggleCamEnabled}
                            cleanupSelfView={cleanupSelfView}
                            toggleBlurEnabled={toggleBlurEnabled}
                            onDeviceChange={onDeviceChange}
                        />
                    </div>
                </div>
            </div>
        );
    },
);

MultiParticipantDisplay.displayName = 'MultiParticipantDisplay';

export { MultiParticipantDisplay };
