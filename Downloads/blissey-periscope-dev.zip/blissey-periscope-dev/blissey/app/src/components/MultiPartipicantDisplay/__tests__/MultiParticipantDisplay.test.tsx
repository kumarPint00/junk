import * as React from 'react';
import { mount, ReactWrapper } from 'enzyme';
import thunk from 'redux-thunk';
const thunkMw: any = thunk;
import configureMockStore, { MockStoreEnhanced } from 'redux-mock-store';
import { Provider } from 'react-redux';
import { initialState, Store } from '@redux/modules';
import {
    MultiParticipantDisplay,
    MultiParticipantDisplayProps,
} from '../MultiParticipantDisplay';
import { OTConnectionView } from '@components/CameraDisplay/OTConnection';
import { vi } from 'vitest';
import { render } from '@testing-library/react';

type Wrapper = ReactWrapper<MultiParticipantDisplayProps>;

const mockStore = configureMockStore([thunkMw]);
const getMockState = (roles = ['telehealth_provider']): Store['All'] => ({
    ...initialState,
    user: {
        userDetails: {
            ...initialState.user.userDetails,
            roles,
        },
    },
});

const getWrapper = (
    props: MultiParticipantDisplayProps,
    store: MockStoreEnhanced<unknown>,
): Wrapper => {
    return mount(
        <Provider store={store}>
            <MultiParticipantDisplay {...props} />
        </Provider>,
    ) as Wrapper;
};

describe('<MultiParticipantDisplay />', () => {
    let wrapper: Wrapper;
    let defaultProps: MultiParticipantDisplayProps;
    let mockStoreWithState: MockStoreEnhanced<unknown>;
    beforeEach(() => {
        mockStoreWithState = mockStore(getMockState());
        defaultProps = {
            isProvider: true,
            otStreams: [],
            publisherId: 'publisherId',
            publish: vi.fn(),
            subscribe: vi.fn(),
            onReconnect: vi.fn(),
            toggleCamEnabled: vi.fn(),
            toggleMicEnabled: vi.fn(),
            cleanupSelfView: vi.fn(),
            getStats: vi.fn(),
            toggleBlurEnabled: vi.fn(),
            onDeviceChange: vi.fn(),
        };
    });

    it('mounts', () => {
        const { container } = render(
            <Provider store={mockStoreWithState}>
                <MultiParticipantDisplay {...defaultProps} />
            </Provider>,
        );
        expect(container).toMatchSnapshot();
    });

    it('sets chat to not visible', () => {
        wrapper = getWrapper(defaultProps, mockStoreWithState);
        expect(mockStoreWithState.getActions()).toMatchInlineSnapshot(`
            [
              {
                "payload": false,
                "type": "videoMenu/SET_IS_CHAT_VISIBLE",
              },
            ]
        `);
    });

    it('calls reconnect', () => {
        wrapper = getWrapper(defaultProps, mockStoreWithState);
        wrapper.find(OTConnectionView).first().props().onReconnect();

        expect(defaultProps.onReconnect).toHaveBeenCalledTimes(1);
    });
});
