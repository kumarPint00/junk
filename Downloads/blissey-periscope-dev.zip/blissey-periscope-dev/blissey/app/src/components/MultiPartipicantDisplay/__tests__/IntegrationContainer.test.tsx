import thunk from '@redux/middleware/thunkShim';
import configureMockStore from 'redux-mock-store';
import * as React from 'react';
import { Provider } from 'react-redux';
import { render } from '@testing-library/react';
import { initialState, Store } from '@redux/modules';
import { IntegrationContainer } from '../IntegrationContainer';
import { Mocked, vi } from 'vitest';
import { MuiRippleDisabledWrapper } from '../../../../__mocks__/theme-provider';
// snackbar throws an error with vi: https://stackoverflow.com/questions/57660098/react-material-getting-typeerror-cannot-set-property-transition-of-undefine
vi.mock('@mui/material/Snackbar', () => ({
    default: () => '<Snackbar/>',
}));
vi.mock('@redux/modules/tytoCare');
vi.mock('@utils/FeatureFlags');
vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        errorEvent: vi.fn(),
    },
}));

type MockedFeatureFlags = Mocked<typeof import('@utils/FeatureFlags')>;
let mockFeatureFlags: MockedFeatureFlags;

const middlewares: any[] = [thunk];
const mockStore = configureMockStore(middlewares);

const getMockState = (
    tytoCare = {},
    roles = ['telehealth_provider'],
): Store['All'] => ({
    ...initialState,
    user: {
        userDetails: {
            ...initialState.user.userDetails,
            roles,
        },
    },
    tytoCare: {
        ...initialState.tytoCare,
        ...tytoCare,
    },
});

describe('<IntegrationContainer />', () => {
    beforeEach(async () => {
        mockFeatureFlags = (await import(
            '@utils/FeatureFlags'
        )) as MockedFeatureFlags;
        mockFeatureFlags.getFeatureFlag.mockReturnValue(true);
    });
    afterEach(() => {
        vi.clearAllMocks();
    });
    it('renders nothing for the patient', () => {
        const mockStoreWithState = mockStore(
            getMockState({}, ['telehealth_patient']),
        );
        const { container } = render(
            <MuiRippleDisabledWrapper>
                <Provider store={mockStoreWithState}>
                    <IntegrationContainer getStats={vi.fn()} />
                </Provider>
            </MuiRippleDisabledWrapper>,
        );
        expect(container).toMatchSnapshot();
    });
    it('renders nothing for the provider when not a tytocare visit and not a video stats visit', () => {
        mockFeatureFlags.getFeatureFlag.mockReturnValue(false);
        const mockStoreWithState = mockStore(getMockState({}));
        const { container } = render(
            <MuiRippleDisabledWrapper>
                <Provider store={mockStoreWithState}>
                    <IntegrationContainer getStats={vi.fn()} />
                </Provider>
            </MuiRippleDisabledWrapper>,
        );
        expect(container).toMatchSnapshot();
    });
    it('shows provider button when tytocare visit is true', () => {
        const mockStoreWithState = mockStore(
            getMockState({
                isTytoCareVisit: true,
            }),
        );
        const { container } = render(
            <MuiRippleDisabledWrapper>
                <Provider store={mockStoreWithState}>
                    <IntegrationContainer getStats={vi.fn()} />
                </Provider>
            </MuiRippleDisabledWrapper>,
        );
        expect(container).toMatchSnapshot();
    });
    it('shows panel when loading', () => {
        const mockStoreWithState = mockStore(
            getMockState({
                isTytoCareVisit: true,
                loading: true,
            }),
        );
        const { container } = render(
            <MuiRippleDisabledWrapper>
                <Provider store={mockStoreWithState}>
                    <IntegrationContainer getStats={vi.fn()} />
                </Provider>
            </MuiRippleDisabledWrapper>,
        );
        expect(container).toMatchSnapshot();
    });
    it('shows panel when providerUrl is not empty', () => {
        const mockStoreWithState = mockStore(
            getMockState({
                isTytoCareVisit: true,
                providerVisitUrl: 'https://mock-tyto-provider-url',
            }),
        );
        const { container } = render(
            <MuiRippleDisabledWrapper>
                <Provider store={mockStoreWithState}>
                    <IntegrationContainer getStats={vi.fn()} />
                </Provider>
            </MuiRippleDisabledWrapper>,
        );
        expect(container).toMatchSnapshot();
    });
    it('shows error', () => {
        const mockStoreWithState = mockStore(
            getMockState({
                isTytoCareVisit: true,
                error: 'tytocare error',
            }),
        );
        const { container } = render(
            <MuiRippleDisabledWrapper>
                <Provider store={mockStoreWithState}>
                    <IntegrationContainer getStats={vi.fn()} />
                </Provider>
            </MuiRippleDisabledWrapper>,
        );
        expect(container).toMatchSnapshot();
    });
    it('shows error', () => {
        const mockStoreWithState = mockStore(
            getMockState({
                isTytoCareVisit: true,
                error: 'tytocare error',
            }),
        );
        const { container } = render(
            <MuiRippleDisabledWrapper>
                <Provider store={mockStoreWithState}>
                    <IntegrationContainer getStats={vi.fn()} />
                </Provider>
            </MuiRippleDisabledWrapper>,
        );
        expect(container).toMatchSnapshot();
    });
});
