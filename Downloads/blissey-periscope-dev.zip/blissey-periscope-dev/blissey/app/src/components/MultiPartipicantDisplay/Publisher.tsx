import * as React from 'react';
import * as Redux from 'react-redux';
import { Dimensions } from '@dexcare/yak';

import { Store } from '../../redux/modules';
import { OTStream } from '@components/CameraDisplay/OTStream';
import { VideoMenu } from '../VideoMenu/VideoMenu';
import { SelfViewContainer } from '@components/SelfViewContainer/SelfViewContainer';
import { ToastMessageDisplayComponent } from '@components/CameraDisplay/ToastMessageDisplayComponent';
import { Logger } from '../../utils';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './Publisher.css';
import {
    AudioVideoSwitcherDialog,
    AudioVideoSwitcherDialogProps,
} from '@modules/AudioVideoSwitcherDialog/AudioVideoSwitcherDialog';
import { MediaDevice } from '@common/video/getDevices/MediaDevice';

interface StateProps {
    isCamEnabled: boolean;
    isMicEnabled: boolean;
    isChatVisible: boolean;
    videoDeviceId: string;
    audioDeviceId: string;
    videoDimensions: Dimensions;
    visitId: string;
    isBlurEnabled: boolean;
    videoDevices: MediaDevice[];
    audioDevices: MediaDevice[];
}
interface PublisherProps {
    id: string;
    publish: () => Promise<void>;
    toggleMicEnabled: () => void;
    toggleCamEnabled: () => void;
    toggleBlurEnabled: () => void;
    onDeviceChange: (cameraDeviceId: string, audioDeviceId: string) => void;
    cleanupSelfView: () => void;
}
export type Props = StateProps & PublisherProps;
const mapStateToProps = (state: Store['All']) => {
    return {
        isMicEnabled: state.video.isMicEnabled,
        isCamEnabled: state.video.isCamEnabled,
        isChatVisible: state.video.isChatVisible,
        isBlurEnabled: state.video.isBlurEnabled,
        visitId: state.postconsult.visitId,
        ...state.usersettings,
        ...state.selfView,
    };
};
export interface PublisherComponentState {
    dismissedMediaWarning: boolean;
    showAudioVideoSwitcherDialog: boolean;
}

export class PublisherComponent extends React.Component<
    Props,
    PublisherComponentState
> {
    constructor(props: Props) {
        super(props);

        this.state = {
            dismissedMediaWarning: false,
            showAudioVideoSwitcherDialog: false,
        };
    }

    private logTokBoxEvent = (message: string, ...params: unknown[]) => {
        Logger.info(
            {
                eventSource: 'PublisherComponent',
                eventType: 'tokbox',
                ...params,
            },
            message,
        );
    };

    public async componentDidMount() {
        const { publish } = this.props;

        this.logTokBoxEvent('publisher mount - starting publish');
        await publish();
    }

    public componentWillUnmount() {
        this.props.cleanupSelfView();
    }

    private toggleCam = () => {
        const eventName = this.props.isCamEnabled ? 'camera_off' : 'camera_on';
        V2Analytics.interactionEvent({
            eventName,
            visit_id: this.props.visitId,
        });

        this.props.toggleCamEnabled();
    };

    private toggleMic = () => {
        if (this.props.isMicEnabled) {
            V2Analytics.interactionEvent({
                eventName: 'mute',
                visit_id: this.props.visitId,
            });
        }

        this.props.toggleMicEnabled();
    };

    private toggleBlur = () => {
        const eventName = this.props.isBlurEnabled ? 'blur_off' : 'blur_on';
        V2Analytics.interactionEvent({
            eventName,
            visit_id: this.props.visitId,
        });

        this.props.toggleBlurEnabled();
    };

    private toggleAudioVideoSwitcherDialog = () => {
        this.setState({
            showAudioVideoSwitcherDialog:
                !this.state.showAudioVideoSwitcherDialog,
        });
    };

    private handleSwitcherConfirm: AudioVideoSwitcherDialogProps['onConfirm'] =
        (deviceIds) => {
            Logger.debug(
                {
                    videoDeviceId: deviceIds.videoDeviceId,
                    audioDeviceId: deviceIds.audioDeviceId,
                },
                'device change confirmed',
            );
            this.props.onDeviceChange(
                deviceIds.videoDeviceId,
                deviceIds.audioDeviceId,
            );
            this.setState({
                showAudioVideoSwitcherDialog: false,
            });
        };

    private handleSwitcherCancel = () => {
        this.setState({
            showAudioVideoSwitcherDialog: false,
        });
    };

    public render() {
        const { isChatVisible, videoDimensions } = this.props;

        // TODO clean this styles logic up
        const videoMenuStyles = isChatVisible
            ? [styles.videoMenu, styles.chatOpen].join(' ')
            : styles.videoMenu;

        const selfViewStyles = isChatVisible
            ? [styles.selfViewContainer, styles.chatOpen].join(' ')
            : styles.selfViewContainer;

        return (
            <>
                <div className={selfViewStyles}>
                    <SelfViewContainer
                        videoWidth={videoDimensions.width}
                        videoHeight={videoDimensions.height}
                    >
                        <OTStream id={this.props.id} />
                    </SelfViewContainer>
                </div>
                <ToastMessageDisplayComponent
                    micExists={this.props.isMicEnabled}
                    camExists={this.props.isCamEnabled}
                />
                <div className={videoMenuStyles}>
                    <VideoMenu
                        onMicClick={this.toggleMic}
                        onCamClick={this.toggleCam}
                        onBlurBackgroundClick={this.toggleBlur}
                        visitId={this.props.visitId}
                        onSwitchCameraClick={
                            this.toggleAudioVideoSwitcherDialog
                        }
                    />
                </div>
                <AudioVideoSwitcherDialog
                    open={this.state.showAudioVideoSwitcherDialog}
                    onClose={this.handleSwitcherCancel}
                    onConfirm={this.handleSwitcherConfirm}
                    onCancel={this.handleSwitcherCancel}
                    audioDevices={this.props.audioDevices}
                    videoDevices={this.props.videoDevices}
                    defaultValue={{
                        audioDeviceId: this.props.audioDeviceId,
                        videoDeviceId: this.props.videoDeviceId,
                    }}
                />
            </>
        );
    }
}

export default Redux.connect<StateProps, Record<string, never>, PublisherProps>(
    mapStateToProps,
)(PublisherComponent);
