import * as React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import { PublisherComponent, Props } from '../Publisher';
import { VideoMenu } from '@components/VideoMenu/VideoMenu';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { interactionEvent: vi.fn() },
}));

const shallowComponent = (props: Props) => {
    return shallow(<PublisherComponent {...props} />);
};
describe('<Publisher />', () => {
    const id = 'testid';
    let defaultProps: Props;
    beforeEach(() => {
        defaultProps = {
            isMicEnabled: true,
            isCamEnabled: true,
            isBlurEnabled: true,
            isChatVisible: true,
            videoDeviceId: 'videoId',
            audioDeviceId: 'audioId',
            visitId: 'visitId',
            id,
            publish: vi.fn(),
            toggleMicEnabled: vi.fn(),
            toggleCamEnabled: vi.fn(),
            toggleBlurEnabled: vi.fn(),
            cleanupSelfView: vi.fn(),
            videoDimensions: {
                width: 0,
                height: 0,
            },
            onDeviceChange: vi.fn(),
            videoDevices: [],
            audioDevices: [],
        };
    });

    test('mounts and publishes', () => {
        expect(toJson(shallowComponent(defaultProps))).toMatchSnapshot();

        expect(defaultProps.publish).toHaveBeenCalledTimes(1);
    });

    test('videoDimensions passed to children', () => {
        const wrapper = shallowComponent({
            ...defaultProps,
            videoDimensions: { width: 300, height: 400 },
        });

        expect(toJson(wrapper)).toMatchSnapshot();
    });

    test('toggles mic', () => {
        const wrapper = shallowComponent(defaultProps);

        wrapper.find(VideoMenu).first().props().onMicClick();
        expect(defaultProps.toggleMicEnabled).toHaveBeenCalled();
    });

    test('fires analytics event when toggles mic off', () => {
        defaultProps.isMicEnabled = true;
        const wrapper = shallowComponent(defaultProps);

        wrapper.find(VideoMenu).first().props().onMicClick();
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'mute',
            visit_id: 'visitId',
        });
    });

    test('toggles cam', () => {
        const wrapper = shallowComponent(defaultProps);

        wrapper.find(VideoMenu).first().props().onCamClick();
        expect(defaultProps.toggleCamEnabled).toHaveBeenCalled();
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'camera_off',
            visit_id: 'visitId',
        });
    });

    test('fires analytics event when toggles cam on', () => {
        defaultProps.isCamEnabled = false;
        const wrapper = shallowComponent(defaultProps);

        wrapper.find(VideoMenu).first().props().onCamClick();
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'camera_on',
            visit_id: 'visitId',
        });
    });

    test('cleanup on unmount', () => {
        const wrapper = shallowComponent(defaultProps);

        wrapper.unmount();
        expect(defaultProps.cleanupSelfView).toHaveBeenCalledTimes(1);
    });

    test('toggles blur', () => {
        const wrapper = shallowComponent(defaultProps);

        wrapper.find(VideoMenu).first().props().onBlurBackgroundClick();
        expect(defaultProps.toggleBlurEnabled).toHaveBeenCalled();
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'blur_off',
            visit_id: 'visitId',
        });
    });

    test('fires analytics event when toggles blur on', () => {
        defaultProps.isBlurEnabled = false;
        const wrapper = shallowComponent(defaultProps);

        wrapper.find(VideoMenu).first().props().onBlurBackgroundClick();
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'blur_on',
            visit_id: 'visitId',
        });
    });
});
