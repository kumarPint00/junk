import * as React from 'react';

import { FlipCardProps } from './FlipCardInterfaces';

import * as styles from './FlipCard.css';

// This is used by EstimatedWaitTime to wrap some complexity of a flipping effect
// If you want to reuse some of this logic please do, but will require a bit of code shuffle
// to make this more reusable.
export class FlipCard extends React.Component<FlipCardProps> {
    public containerRef: React.RefObject<HTMLDivElement>;
    constructor(props: FlipCardProps) {
        super(props);
        this.containerRef = React.createRef();
    }

    public shouldComponentUpdate(nextProps: FlipCardProps) {
        const noPropChange =
            nextProps.front === this.props.front &&
            nextProps.back === this.props.back;
        return !noPropChange;
    }

    public componentDidUpdate() {
        if (this.containerRef.current) {
            this.containerRef.current.classList.remove(styles.flip);
        }
        setTimeout(() => {
            if (this?.containerRef?.current) {
                this.containerRef.current.classList.add(styles.flip);
            }
        }, 10);
    }

    public render() {
        const { front, back } = this.props;
        return (
            <div className={styles.container} ref={this.containerRef}>
                <div className={styles.front}>{front}</div>
                <div className={styles.back}>{back}</div>
            </div>
        );
    }
}
