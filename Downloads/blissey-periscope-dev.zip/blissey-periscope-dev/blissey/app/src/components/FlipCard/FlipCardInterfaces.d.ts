export interface FlipCardProps {
    front: string;
    back: string;
}
