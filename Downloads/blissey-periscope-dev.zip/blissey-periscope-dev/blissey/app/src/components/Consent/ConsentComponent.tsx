import * as React from 'react';
import { Checkbox, Link } from '@mui/material';
import { MessageModal } from '@components/MessageModal/MessageModal';
import { PillButton } from '@components/Button';

import * as styles from './ConsentComponent.css';

interface ConsentComponentProps {
    localizedText: {
        consentHeaderText: string;
        consentInstructionText: string;
        consentCheckboxLabelText: string;
        consentButtonText: string;
        consentCancelLinkText: string;
        errorMessageText: string | undefined;
        dismissErrorModalText: string;
    };
    onConsentButtonClick: () => void;
    onConsentCancelLinkClick: () => void;
    setTermsAccepted: (value: boolean) => void;
    handleSetErrorMessage: (message: string | null) => void;
    termsAccepted: boolean;
    isLoading: boolean;
}

export const ConsentComponent = ({
    localizedText,
    onConsentButtonClick,
    onConsentCancelLinkClick,
    setTermsAccepted,
    handleSetErrorMessage,
    termsAccepted,
    isLoading,
}: ConsentComponentProps) => {
    const {
        consentHeaderText,
        consentInstructionText,
        consentCheckboxLabelText,
        consentButtonText,
        consentCancelLinkText,
        errorMessageText,
        dismissErrorModalText,
    } = localizedText;

    const handleButtonClick = () => {
        onConsentButtonClick();
    };

    const handleLinkClick = () => {
        onConsentCancelLinkClick();
    };

    const onCheckboxChange = (evt: React.ChangeEvent<HTMLInputElement>) => {
        const {
            target: { checked },
        } = evt;
        setTermsAccepted(checked);
    };

    const handleModalClose = () => {
        handleSetErrorMessage(null);
    };

    return (
        <div data-uitest="verify-otp-window" className={styles.window}>
            <div className={styles.instructions}>
                <div>
                    <b>{consentHeaderText}</b>
                </div>
                <div>{consentInstructionText}</div>
            </div>
            <div className={styles.inputBox}>
                <div>
                    <Checkbox
                        disabled={isLoading}
                        checked={termsAccepted}
                        onChange={onCheckboxChange}
                        inputProps={
                            {
                                'data-uitest': 'consent-checkbox',
                            } as React.InputHTMLAttributes<HTMLInputElement>
                        }
                    />
                    <span
                        dangerouslySetInnerHTML={{
                            __html: consentCheckboxLabelText,
                        }}
                    />
                </div>
            </div>
            <div>
                <PillButton
                    data-uitest="accept-terms-button"
                    variant="contained"
                    color="grey"
                    onClick={handleButtonClick}
                    disabled={isLoading || !termsAccepted}
                >
                    {consentButtonText}
                </PillButton>
            </div>
            <div className={styles.link}>
                <Link
                    data-uitest="cancel-terms-link"
                    component="button"
                    onClick={handleLinkClick}
                    disabled={isLoading}
                >
                    {consentCancelLinkText}
                </Link>
            </div>
            <MessageModal
                isOpen={Boolean(errorMessageText)}
                messageText={errorMessageText}
                dismissButtonText={dismissErrorModalText}
                onModalClosed={handleModalClose}
            />
        </div>
    );
};
