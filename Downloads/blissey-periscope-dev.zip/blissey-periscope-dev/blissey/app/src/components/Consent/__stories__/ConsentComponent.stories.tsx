import { ConsentComponent } from '../ConsentComponent';

const defaultProps = {
    localizedText: {
        consentHeaderText: 'consent header text',
        consentInstructionText: 'instruction body text',
        consentCheckboxLabelText:
            'consent checkbox text with <a href="https://twitter.com">link</a>',
        consentButtonText: 'button text',
        consentCancelLinkText: 'link text',
        errorMessageText: undefined,
        dismissErrorModalText: 'dismiss',
    },
    onConsentButtonClick: (): void => undefined,
    onConsentCancelLinkClick: (): void => undefined,
    setTermsAccepted: (): void => undefined,
    handleSetErrorMessage: (): void => undefined,
    termsAccepted: false,
    isLoading: false,
};

export default {
    title: 'Components/ConsentComponent',
    component: ConsentComponent,
};

export const Default = {
    args: { ...defaultProps },
};

export const Loading = {
    args: {
        ...defaultProps,
        isLoading: true,
    },
};

export const TermsAccepted = {
    args: {
        ...defaultProps,
        termsAccepted: true,
    },
};

export const ErrorMessage = {
    args: {
        ...defaultProps,
        termsAccepted: true,
        localizedText: {
            ...defaultProps.localizedText,
            errorMessageText: 'Oops its broked.',
        },
    },
};
