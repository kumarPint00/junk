import * as React from 'react';
import { withTranslation } from 'react-i18next';
import { FooterProps } from './FooterInterfaces';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './Footer.css';

function buildLegalLinks(
    legal: Array<{
        url: string;
        linkText: string;
    }>,
) {
    return legal.map(({ linkText, url }) => (
        <a
            href={url}
            key={linkText}
            rel="noopener noreferrer"
            target="_blank"
            className={styles.link}
        >
            {linkText}
        </a>
    ));
}

function Footer(props: FooterProps) {
    const { t } = props;

    let legal = [
        {
            url: t('branding:footer.urlTerms', { defaultValue: null }),
            linkText:
                t('footer.termsAndPrivacyPolicy') ||
                t('branding:footer.linkTerms'),
        },
        {
            url: t('branding:footer.urlDisclaimer', { defaultValue: null }),
            linkText:
                t('footer.disclaimer') || t('branding:footer.linkDisclaimer'),
        },
        {
            url: t('branding:footer.urlPrivacy', { defaultValue: null }),
            linkText:
                t('footer.privacyNotice') || t('branding:footer.linkPrivacy'),
        },
        {
            url: t('branding:footer.urlNonDiscrimination', {
                defaultValue: null,
            }),
            linkText:
                t('footer.nonDiscrimination') ||
                t('branding:footer.linkNonDiscrimination'),
        },
    ];
    legal = legal.filter((l) => !!l.url);

    const emergencyNumber =
        t('footer.contactEmergency') ||
        t('branding:footer.emergencyNumber', {
            defaultValue: 'IN CASE OF EMERGENCY - DIAL 911',
        });
    const helpText =
        t('footer.contactSupport') ||
        t('branding:footer.needHelp', { defaultValue: 'Need Help? Call' });
    const telephoneNumber = t('branding:footer.helpPhone', {
        defaultValue: null,
    });
    const phoneClickAnalytics = (telephone: string) =>
        V2Analytics.interactionEvent({
            eventName: 'click_to_call',
            click_text: telephone,
        });

    //dynamic year for footer
    const currentYear = new Date().getFullYear();
    const copyrightTextWithYear = t('branding:footer.copyright', {
        year: currentYear,
    });

    return (
        <div data-uitest="lego-footer" className={styles.footer}>
            <div className={styles.topRow}>
                <div>
                    <img
                        className={styles.logo}
                        src={t('branding:greyLogo')}
                        alt="Logo"
                    />
                </div>
                <div>{emergencyNumber}</div>
                {telephoneNumber && (
                    <div className={styles.helpText}>
                        {helpText}{' '}
                        <a
                            className={[
                                styles.link,
                                styles.linkWithBrackets,
                            ].join(' ')}
                            href={`tel:${telephoneNumber}`}
                            // tslint:disable-next-line
                            onClick={() => phoneClickAnalytics(telephoneNumber)}
                        >
                            {telephoneNumber}
                        </a>
                    </div>
                )}
            </div>
            <div className={styles.legal}>{buildLegalLinks(legal)}</div>
            <div className={styles.copyright}>{copyrightTextWithYear}</div>
        </div>
    );
}

const _Footer = withTranslation()(Footer);
export { _Footer as Footer };
