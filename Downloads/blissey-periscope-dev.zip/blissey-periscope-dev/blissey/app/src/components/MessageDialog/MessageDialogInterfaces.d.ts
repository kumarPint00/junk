export interface MessageDialogProps {
    active: boolean;
    messageText: string | null;
    closeButtonText?: string;
    onClose(): void;
}
