import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Button from '@mui/material/Button';

import { MessageDialogProps } from './MessageDialogInterfaces';

const styles = {
    dialogRoot: {
        justifyContent: 'center',
        flexWrap: 'wrap',
        flexBasis: '100px',
    },
    dialogTitle: {
        fontSize: '1.8rem',
        fontWeight: 700,
        textAlign: 'center',
        color: 'black',
        marginBottom: '20px',
    },
    buttonRootStay: {
        border: 'solid 2px',
        borderRadius: '24px',
        boxSizing: 'border-box',
        width: '250px',
        minWidth: '200px',
        height: '50px',
        fontSize: '1.25rem',
        fontWeight: 600,
        '&:hover': {
            backgroundColor: 'primary.main',
            color: 'white',
        },
        margin: '5px 25px',
    },
};

// eslint-disable-next-line react/display-name
export const MessageDialog = React.memo(
    ({
        active = false,
        messageText = null,
        closeButtonText = 'CLOSE',
        onClose,
    }: MessageDialogProps) => {
        // accessibility, autofocus on the heading when modal pops up
        const dialogRef = React.useRef<HTMLDivElement>();
        React.useEffect(() => {
            if (active) {
                setTimeout(() => {
                    if (dialogRef.current) {
                        dialogRef.current.focus();
                    }
                }, 1);
            }
        }, [active]);

        return (
            <Dialog
                open={active}
                onClose={onClose}
                PaperProps={{ style: { borderRadius: '24px' } }}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                maxWidth="md"
                fullWidth={true}
            >
                <DialogContent tabIndex={0} ref={dialogRef}>
                    <DialogTitle
                        sx={styles.dialogTitle}
                        id="alert-dialog-title"
                        variant="h4"
                    >
                        {messageText}
                    </DialogTitle>
                </DialogContent>
                <DialogActions disableSpacing={true} sx={styles.dialogRoot}>
                    <div style={{ margin: '25px 25px' }}>
                        <Button
                            color="primary"
                            variant="outlined"
                            onClick={onClose}
                            data-uitest="waitingroom-dialog-close"
                            sx={styles.buttonRootStay}
                        >
                            {closeButtonText.toLocaleUpperCase()}
                        </Button>
                    </div>
                </DialogActions>
            </Dialog>
        );
    },
);
