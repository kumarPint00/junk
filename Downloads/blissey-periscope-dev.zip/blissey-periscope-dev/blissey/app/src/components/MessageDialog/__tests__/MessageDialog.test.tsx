import * as React from 'react';
import { render } from '@testing-library/react';

import { MessageDialog } from '../MessageDialog';
import { vi } from 'vitest';

describe('<MessageDialog />', () => {
    it('renders as active and with a message', () => {
        const { baseElement } = render(
            <MessageDialog
                active={true}
                messageText={'Some Message'}
                onClose={vi.fn()}
            />,
        );
        expect(baseElement).toMatchSnapshot();
    });
});
