import * as React from 'react';
import CircularProgress from '@mui/material/CircularProgress';

const TytoCareWidget = React.memo(({ sourceUrl }: { sourceUrl?: string }) => (
    <>
        {sourceUrl ? (
            <iframe
                sandbox="allow-same-origin allow-popups allow-forms allow-scripts allow-top-navigation"
                allow="autoplay; fullscreen; animations"
                frameBorder="0"
                width="100%"
                height="600"
                src={sourceUrl}
            />
        ) : (
            <div>
                <CircularProgress size={50} />
            </div>
        )}
    </>
));

TytoCareWidget.displayName = 'TytoCareWidget';

export { TytoCareWidget };
