import * as React from 'react';
import { render } from '@testing-library/react';
import { TytoCareWidget } from '../TytoCareWidget';

describe('<TytoCareWidget />', () => {
    it('renders', () => {
        const { container } = render(
            <TytoCareWidget sourceUrl={'http://mock-source-url'} />,
        );
        expect(container).toMatchSnapshot();
    });
});
