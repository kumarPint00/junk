import * as React from 'react';
import { TytoCareWidget } from '../TytoCareWidget';
import { Meta } from '@storybook/react/*';

const meta: Meta<typeof TytoCareWidget> = {
    title: 'Components/TytoCareContainer',
    component: TytoCareWidget,
    decorators: [
        (story) => {
            return <div style={{ height: '300px' }}>{story()}</div>;
        },
    ],
};
export default meta;

export const Default = {
    args: {
        sourceUrl:
            'https://www-stage1.tytocare.com/index.htm#/startOnlineVisit/KmOdaJzM/iZrl1RWPNYQISwkOfYRz4ayWw1U6L0EB5Uu7MoaeqgU*/true',
    },
};

export const Loading = {
    args: {
        sourceUrl: undefined,
    },
};
