import * as React from 'react';
import { ToastMessageDisplayComponent } from '../ToastMessageDisplayComponent';
import { StoryFn } from '@storybook/react';

export default {
    title: 'Components/Camera Display/ToastMessageDisplayComponent',
    component: ToastMessageDisplayComponent,
    parameters: {
        layout: 'centered',
    },
};

interface ToastMessageDisplayProps {
    micExists: boolean;
    camExists: boolean;
}

const Template: React.FC<ToastMessageDisplayProps> = (props) => {
    return (
        <ToastMessageDisplayComponent
            {...{
                dismissMediaWarning: () => {
                    console.log('dismissMediaWarning');
                },
                ...props,
            }}
        />
    );
};

export const Primary = Template.bind({}) as StoryFn<
    typeof ToastMessageDisplayComponent
>;
Primary.args = {
    micExists: true,
    camExists: true,
};
