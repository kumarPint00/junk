import * as React from 'react';
import Button from '@mui/material/Button';
import CircularProgress from '@mui/material/CircularProgress';

import { ConnectionProps } from './ConnectionInterfaces';
import { SelfViewContainer } from '../SelfViewContainer/SelfViewContainer';
import { AudioOnlyRemoteView } from '../AudioOnlyRemoteView/AudioOnlyRemoteView';
import { ConferenceErrorComponent } from '../ConferenceError/ConferenceErrorComponent';
import { RTCConnectionState } from '@utils/RTCConnectionState';
import { BlisseyLogger } from '@utils/Logger';

import { Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './Connection.css';

const sxStyles = {
    buttonRoot: {
        width: '142px',
        height: '46px',
        fontSize: '16px',
        fontWeight: 600,
        borderRadius: '3px',
        margin: '0 auto',
        fontStyle: 'normal',
        lineHeight: '46px',
        textTransform: 'none',
        marginTop: '18px',
        border: 'solid 1px #9b9b9b',
        color: '#181818',
        backgroundColor: '#FFFFFF',
        boxShadow: 'inset 0 -3px 0 0 #e6e6e6',
    },
};

// TODO split connection into a self-view connection and a subscriber connection
export const Connection = (props: ConnectionProps) => {
    React.useEffect(() => {
        if (props.rtcConnectionState === RTCConnectionState.Reconnecting) {
            Analytics.sendEvent({
                eventAction: 'RTC connection lost - attempt reconnection',
                eventName: 'error',
                type: 'error',
            });
        }
        BlisseyLogger.info(
            {
                eventSource: 'Connection',
                eventType: 'render',
                visitId: props.visitId,
                isTestVisit: props.isTestVisit,
            },
            'ConnectionComponent',
        );
    }, [props.isTestVisit, props.rtcConnectionState, props.visitId]);

    let messageKey = 'DialingMessage';
    let showSpinner = true;
    let showSelfView = false;
    let showReconnectButton = false;
    let showAvatar = false;
    if (props.rtcConnectionState === RTCConnectionState.Closed) {
        messageKey = 'DisconnectedMessage';
        showSpinner = false;
        showSelfView = true;
        showReconnectButton = true;
        showAvatar = false;
    } else if (props.rtcConnectionState === RTCConnectionState.Reconnecting) {
        messageKey = 'ReconnectingMessage';
        showSpinner = true;
        showSelfView = true;
        showReconnectButton = false;
        showAvatar = true;
    }

    const selfView =
        !props.disableSelfView && showSelfView ? (
            <div className={styles.selfViewContainer}>
                <SelfViewContainer />
            </div>
        ) : null;

    const avatar =
        !props.disableAvatar && showAvatar ? (
            <div className={styles.avatarCard}>
                <AudioOnlyRemoteView user={props.user} audioOnly={false} />
            </div>
        ) : null;
    return (
        <div>
            {showSpinner ? <CircularProgress size={20} /> : null}
            {selfView}
            <div className={styles.main}>
                {avatar}
                <ConferenceErrorComponent conferenceMessageKey={messageKey} />
                {showReconnectButton && (
                    <Button
                        onClick={props.onReconnect}
                        variant="contained"
                        color="grey"
                        sx={sxStyles.buttonRoot}
                    >
                        Reconnect
                    </Button>
                )}
            </div>
        </div>
    );
};
