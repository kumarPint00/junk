import { UserDetails } from '@dexcare/circus-saturn';
import { RTCConnectionState } from '@utils/RTCConnectionState';

export interface ConnectionProps {
    onReconnect: () => void;
    user?: UserDetails;
    rtcConnectionState: RTCConnectionState;
    visitId: string;
    isTestVisit?: boolean;
    disableSelfView: boolean;
    disableAvatar: boolean;
}
