import * as React from 'react';
import { useSelector } from 'react-redux';
import { Store } from '../../redux/modules';
import { Connection } from './Connection';
import { ConferenceErrorComponent } from '@components/ConferenceError/ConferenceErrorComponent';
import {
    OTConnection,
    OTSubscribingStatus,
    OTPublishingStatus,
} from '@utils/otUtils';
import { Stream } from '@dexcare/yak';
import { RTCConnectionState } from '@utils/RTCConnectionState';

import * as styles from './OTConnection.css';

// this is a component for messages that need to be displayed to the user
// regarding video connection / remote participant connection
// for now, wrap the connection component.
export function OTConnectionView(props: {
    onReconnect: () => void;
    otConnectionStatus?: OTConnection;
    otSubscribingStatus?: OTSubscribingStatus;
    otPublishingStatus?: OTPublishingStatus;
    otStreams: Stream[];
}) {
    const {
        onReconnect,
        otConnectionStatus,
        otSubscribingStatus,
        otPublishingStatus,
        otStreams,
    } = props;
    const { visitId, isTestVisit } = useSelector(
        (state: Store['All']) => state.postconsult,
    );
    const baseProps = {
        disableSelfView: true,
        disableAvatar: true,
        visitId,
        isTestVisit,
        onReconnect,
        user: undefined,
    };
    // firstly, show connection states
    switch (otConnectionStatus) {
        case 'sessionReconnecting':
            return (
                <Connection
                    {...baseProps}
                    rtcConnectionState={RTCConnectionState.Reconnecting}
                />
            );
        case 'error':
        case 'sessionDisconnected':
            return (
                <Connection
                    {...baseProps}
                    rtcConnectionState={RTCConnectionState.Closed}
                />
            );
        case 'sessionConnected':
        case 'sessionReconnected':
        default:
            // connection is healthy and alive - now look at publish / subscribe states
            switch (otPublishingStatus) {
                case 'publishSuccess':
                    if (otStreams.length > 0) {
                        switch (otSubscribingStatus) {
                            case 'subscribeStarted':
                                return (
                                    <Connection
                                        {...baseProps}
                                        rtcConnectionState={
                                            RTCConnectionState.Connecting
                                        }
                                    />
                                );
                            case 'subscribeFailure':
                                return (
                                    <Connection
                                        {...baseProps}
                                        rtcConnectionState={
                                            RTCConnectionState.Closed
                                        }
                                    />
                                );
                            case 'subscribeSuccess':
                            default:
                                return <></>;
                        }
                    }
                    // Single participant:
                    return (
                        <div className={styles.information}>
                            <ConferenceErrorComponent
                                dataUiTest="infocard-messagecard"
                                conferenceMessageKey={'ConnectedMessage'}
                            />
                        </div>
                    );
                case 'publishStarted':
                    return (
                        <Connection
                            {...baseProps}
                            rtcConnectionState={RTCConnectionState.Connecting}
                        />
                    );
                case 'publishFailure':
                default:
                    return (
                        <Connection
                            {...baseProps}
                            rtcConnectionState={RTCConnectionState.Closed}
                        />
                    );
            }
    }
}
