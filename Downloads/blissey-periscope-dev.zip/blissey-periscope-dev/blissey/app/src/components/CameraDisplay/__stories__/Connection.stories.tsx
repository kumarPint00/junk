import * as React from 'react';
import { RTCConnectionState } from '@utils/RTCConnectionState';
import { Connection } from '../Connection';
import { ConnectionProps } from '../ConnectionInterfaces';
import { StoryFn } from '@storybook/react';
import { UserDetails } from '@dexcare/circus-saturn';

const Template = (args: ConnectionProps) => (
    <Connection
        {...{
            rtcConnectionState: args.rtcConnectionState,
            onReconnect: () => {
                console.log('onReconnect');
            },
            user: {
                id: 'remoteUserID',
                displayName: 'Remote User',
                givenName: 'Remote',
                familyName: 'User',
            } as UserDetails,
            localVideoStream: undefined,
            visitId: 'madeUpVisitId',
            disableSelfView: false,
            disableAvatar: false,
        }}
    />
);

export const Default = Template.bind({}) as StoryFn<typeof Connection>;
Default.args = {
    rtcConnectionState: RTCConnectionState.Connecting,
};

export default {
    title: 'Components/Connection',
    component: Connection,
    parameters: {
        layout: 'centered',
    },
    argTypes: {
        rtcConnectionState: {
            options: [
                ...Object.values(RTCConnectionState).filter(
                    (m) => typeof m === 'string',
                ),
            ],
            control: 'select',
        },
    },
};
