import * as React from 'react';
import { withTranslation, WithTranslation } from 'react-i18next';

import { conferenceMessageMap, init } from '@common/ConferenceErrorMessage';
import Alert from '@mui/material/Alert';
import Snackbar from '@mui/material/Snackbar';

export interface ToastMessageProps extends WithTranslation {
    micExists: boolean;
    camExists: boolean;
}

export interface ToastMessageState {
    micOffToast: boolean;
    micOnToast: boolean;
    camOffToast: boolean;
    camOnToast: boolean;
}

class ToastMessageDisplayComponent extends React.Component<
    ToastMessageProps,
    ToastMessageState
> {
    constructor(props: ToastMessageProps) {
        super(props);

        this.state = {
            micOffToast: false,
            micOnToast: false,
            camOffToast: false,
            camOnToast: false,
        };
    }

    public render() {
        return this.buildToastMessageDisplay();
    }

    private micOffCloseToast = () => {
        this.setState({ micOffToast: false });
    };

    private micOnCloseToast = () => {
        this.setState({ micOnToast: false });
    };

    private camOffCloseToast = () => {
        this.setState({ camOffToast: false });
    };

    private camOnCloseToast = () => {
        this.setState({ camOnToast: false });
    };

    public componentDidUpdate(
        prevProps: ToastMessageProps,
        prevState: ToastMessageState,
    ) {
        if (
            prevProps.micExists === false &&
            this.props.micExists === true &&
            prevState.micOnToast === false
        ) {
            this.setState({ micOnToast: true });
        } else if (
            prevProps.micExists === true &&
            this.props.micExists === false &&
            prevState.micOffToast === false
        ) {
            this.setState({ micOffToast: true });
        } else if (
            prevProps.camExists === false &&
            this.props.camExists === true &&
            prevState.camOnToast === false
        ) {
            this.setState({ camOnToast: true });
        } else if (
            prevProps.camExists === true &&
            this.props.camExists === false &&
            prevState.camOffToast === false
        ) {
            this.setState({ camOffToast: true });
        }
    }

    private buildToastMessageDisplay(): JSX.Element {
        init();
        const micOffMessage = conferenceMessageMap.get(
            'MicrophoneWarningMessage',
        )!.message;
        const micOnMessage = this.props.t(
            'video-conference.error-messages.micUnmuted',
        );
        const camOffMessage = conferenceMessageMap.get(
            'CameraWarningMessage',
        )!.message;
        const camOnMessage = this.props.t(
            'video-conference.error-messages.camUnmuted',
        );

        return (
            <div>
                {/* materialUI only allows a single snackbar at a time, autocloses others */}
                <Snackbar
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                    open={this.state.micOffToast}
                    autoHideDuration={7000}
                    onClose={this.micOffCloseToast}
                >
                    <Alert
                        onClose={this.micOffCloseToast}
                        severity="warning"
                        variant="filled"
                        color="info"
                    >
                        {micOffMessage}
                    </Alert>
                </Snackbar>
                <Snackbar
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                    open={this.state.micOnToast}
                    autoHideDuration={5000}
                    onClose={this.micOnCloseToast}
                >
                    <Alert
                        onClose={this.micOnCloseToast}
                        severity="warning"
                        variant="filled"
                        color="info"
                    >
                        {micOnMessage}
                    </Alert>
                </Snackbar>
                <Snackbar
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                    open={this.state.camOffToast}
                    autoHideDuration={7000}
                    onClose={this.camOffCloseToast}
                >
                    <Alert
                        onClose={this.camOffCloseToast}
                        severity="warning"
                        variant="filled"
                        color="info"
                    >
                        {camOffMessage}
                    </Alert>
                </Snackbar>
                <Snackbar
                    anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
                    open={this.state.camOnToast}
                    autoHideDuration={5000}
                    onClose={this.camOnCloseToast}
                >
                    <Alert
                        onClose={this.camOnCloseToast}
                        severity="warning"
                        variant="filled"
                        color="info"
                    >
                        {camOnMessage}
                    </Alert>
                </Snackbar>
            </div>
        );
    }
}

const _ToastMessageDisplayComponent = withTranslation()<
    typeof ToastMessageDisplayComponent
>(ToastMessageDisplayComponent);
export { _ToastMessageDisplayComponent as ToastMessageDisplayComponent };
