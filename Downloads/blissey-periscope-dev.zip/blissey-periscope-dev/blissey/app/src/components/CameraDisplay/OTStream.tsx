import * as React from 'react';

import * as styles from './OTStream.css';

const OTStream = React.memo(({ id }: { id: string }) => {
    return <div id={id} className={styles.streamContainer} />;
});

OTStream.displayName = 'OTStream';

export { OTStream };
