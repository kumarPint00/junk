import * as React from 'react';
import Button from '@mui/material/Button';

import * as styles from './Toast.css';

export class ToastProps {
    public message: string;
    public buttonLabel: React.ReactNode;
    public backgroundOpacity?: boolean;
    public callback: () => void;
}

export function Toast(props: ToastProps) {
    let opacityStyle = styles.opaque;

    if (props.backgroundOpacity) {
        opacityStyle = styles.transparent;
    }

    return (
        <div className={opacityStyle}>
            <div className={styles.message}>
                <div className={styles.main}>
                    <div>{props.message}</div>
                    <Button
                        variant="outlined"
                        className={styles.button}
                        onClick={props.callback}
                    >
                        {props.buttonLabel}
                    </Button>
                </div>
            </div>
        </div>
    );
}
