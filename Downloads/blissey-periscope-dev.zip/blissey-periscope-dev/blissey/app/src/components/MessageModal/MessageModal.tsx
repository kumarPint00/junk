import * as React from 'react';
import { useState, useEffect } from 'react';
import { Modal } from '@mui/material';
import { PillButton } from '@components/Button';

import * as styles from './MessageModal.css';

interface MessageModalProps {
    isOpen: boolean;
    messageText: string | undefined;
    dismissButtonText: string;
    onModalClosed: () => void;
}

export const MessageModal = ({
    isOpen,
    messageText,
    dismissButtonText,
    onModalClosed,
}: MessageModalProps) => {
    const [modalOpen, setModalOpen] = useState(false);

    useEffect(() => {
        setModalOpen(isOpen);
    }, [isOpen]);

    const handleModalClose = () => {
        setModalOpen(false);
        onModalClosed();
    };

    return (
        <Modal open={modalOpen} onClose={handleModalClose}>
            <div className={styles.modal}>
                <div className={styles.modalMessage}>{messageText}</div>
                <PillButton
                    className={styles.modalDismissButton}
                    data-uitest="dismiss-modal-button"
                    variant="contained"
                    color="grey"
                    onClick={handleModalClose}
                >
                    {dismissButtonText}
                </PillButton>
            </div>
        </Modal>
    );
};
