import * as React from 'react';
import * as redux from 'react-redux';
import { OTStream } from '@components/CameraDisplay/OTStream';
import thunk from '@redux/middleware/thunkShim';
import configureMockStore from 'redux-mock-store';

import { SelfViewContainer } from '../SelfViewContainer';
import { createOTPublisher } from '@utils/otUtils';

const WrapperComponent: React.FunctionComponent<
    React.PropsWithChildren<{ streamId: string }>
> = ({ streamId, children }) => {
    const [width, setWidth] = React.useState(0);
    const [height, setHeight] = React.useState(0);

    React.useEffect(() => {
        const publisher = createOTPublisher(
            streamId,
            (error) => {
                if (error) {
                    console.log('error');
                }
            },
            {},
        );
        publisher.on('videoDimensionsChanged', (event) => {
            if (event.newValue.height) {
                setHeight(event.newValue.height);
            }
            if (event.newValue.width) {
                setWidth(event.newValue.width);
            }
        });
        return () => {
            publisher.destroy();
        };
    }, [streamId]);

    return (
        <SelfViewContainer videoWidth={width} videoHeight={height}>
            {children}
        </SelfViewContainer>
    );
};

export default {
    title: 'Components/Self View Container/SelfViewContainer',
    parameters: {
        docs: { disable: true },
    },
};

export const Default = () => {
    return (
        <div style={{ position: 'fixed', bottom: '60px' }}>
            <SelfViewContainer />
        </div>
    );
};

export const WithLocalVideo = () => {
    const streamId = 'stream-id';
    const middlewares: any[] = [thunk];
    const testState = {};
    const mockStore = configureMockStore(middlewares);
    const mockStoreWithState = mockStore(testState);
    return (
        <redux.Provider store={mockStoreWithState}>
            <div style={{ position: 'fixed', bottom: '60px' }}>
                <WrapperComponent streamId={streamId}>
                    <OTStream id={streamId} />
                </WrapperComponent>
            </div>
        </redux.Provider>
    );
};
