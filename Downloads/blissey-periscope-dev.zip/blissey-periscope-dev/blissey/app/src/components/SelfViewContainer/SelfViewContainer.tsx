import * as React from 'react';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import styled from '@mui/material/styles/styled';
import { withTranslation, WithTranslation } from 'react-i18next';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

import { LogManager, Counted } from '@dexcare/circus-jupiter';

import * as styles from './SelfViewContainer.css';

export interface SelfViewContainerProps
    extends WithTranslation,
        React.PropsWithChildren<object> {
    videoWidth?: number;
    videoHeight?: number;
}

const StyledIconButton = styled(IconButton)({
    border: 'none',
    borderRadius: '4px',
    padding: '10px',
});

// TODO change this to a react.memo functional component to make sure it doesn't
// rerender too often which may cause flickers
// the Publisher will not update state if height & width don't change, but we want to be careful
class SelfViewContainer extends React.Component<
    SelfViewContainerProps,
    { isSelfViewClicked: boolean }
> {
    private LOGGER = LogManager.getLogger();
    private camSelfViewToggleText = this.props.t(
        'video-conference.controls.camSelfViewToggle',
    );

    constructor(props: SelfViewContainerProps) {
        super(props);
        this.state = {
            isSelfViewClicked: true,
        };
    }

    public render() {
        const { videoWidth, videoHeight } = this.props;
        let selfViewStyles: string = '';
        let videoStreamStyles: React.CSSProperties | undefined;

        if (this.state.isSelfViewClicked) {
            // set width and height ratios as a percentage otSelfViewInCall, which is a square box
            // with media queries to resize based on the window size.
            selfViewStyles = styles.otSelfViewInCall;
            if (videoWidth && videoHeight) {
                if (videoWidth > videoHeight) {
                    const heightToWidthPercentage = Math.trunc(
                        100 * (videoHeight / videoWidth),
                    );
                    videoStreamStyles = {
                        height: `${heightToWidthPercentage}%`,
                        width: `100%`,
                    };
                } else {
                    // if height is greater than width it is probably a mobile self view
                    // set height to 100% in this case and width as a percentage of height
                    const widthToHeightPercentage = Math.trunc(
                        100 * (videoWidth / videoHeight),
                    );
                    videoStreamStyles = {
                        height: `100%`,
                        width: `${widthToHeightPercentage}%`,
                    };
                }
            }
        } else {
            selfViewStyles = styles.selfViewNoShow;
        }
        this.LOGGER.info(
            {
                eventSource: 'SelfViewContainer',
                eventType: 'render',
            },
            `Participant viewing self-view video screen`,
        );

        const selfViewUpButton: JSX.Element = (
            <StyledIconButton
                style={{
                    backgroundColor: '#535151',
                    color: '#FFF',
                    width: '45px',
                    height: '45px',
                }}
                onClick={() => this.onClick()}
            >
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    style={{ width: '24px', height: '24px' }}
                    strokeWidth={3}
                    stroke="currentColor"
                >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="m19.5 19.5-15-15m0 0v11.25m0-11.25h11.25"
                    />
                </svg>
            </StyledIconButton>
        );

        const selfViewDownButton: JSX.Element = (
            <StyledIconButton
                style={{
                    backgroundColor: '#535151',
                    color: '#FFF',
                    width: '45px',
                    height: '45px',
                    opacity: 0.8,
                }}
                onClick={() => this.onClick()}
            >
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    style={{ width: '24px', height: '24px' }}
                    strokeWidth={3}
                    stroke="currentColor"
                >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="m4.5 4.5 15 15m0 0V8.25m0 11.25H8.25"
                    />
                </svg>
            </StyledIconButton>
        );

        return (
            <div className={styles.otSelfViewContainer}>
                <div className={styles.selfViewMinimizeControl}>
                    <Tooltip
                        title={this.camSelfViewToggleText}
                        placement="left"
                        data-uitest="control-selfViewButton"
                        disableInteractive
                    >
                        {this.state.isSelfViewClicked
                            ? selfViewDownButton
                            : selfViewUpButton}
                    </Tooltip>
                </div>
                <div className={selfViewStyles}>
                    <div
                        style={videoStreamStyles}
                        className={styles.otSelfViewInCallInner}
                        id="selfViewDiv"
                        data-uitest="selfviewcontainer-minmax"
                    >
                        {this.props.children}
                    </div>
                </div>
            </div>
        );
    }

    @Counted
    private onClick(): void {
        if (this.state.isSelfViewClicked) {
            V2Analytics.interactionEvent({
                eventName: 'new_pip_setting',
                value: 'non-PIP',
            });
            this.setState({ isSelfViewClicked: false });
        } else {
            V2Analytics.interactionEvent({
                eventName: 'new_pip_setting',
                value: 'PIP',
            });
            this.setState({ isSelfViewClicked: true });
        }
    }
}

const _SelfViewContainer = withTranslation()(SelfViewContainer);
export { _SelfViewContainer as SelfViewContainer };
