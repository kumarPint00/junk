import { MessageType } from '../MessageInterfaces';
import { MessageComponent } from '../MessageComponent';

export const Default = {
    args: {
        enumMessageType: MessageType.Error,
        message: 'Uh oh! You did not replace the coffee!',
        subMessage: 'Please contact the team to make an apology',
        icon: undefined,
    },
};

export default {
    title: 'Components/Message',
    component: MessageComponent,
    argTypes: {
        icon: {
            options: ['cloud_off', null],
            control: { type: 'radio' },
        },
        enumMessageType: {
            options: [
                ...Object.values(MessageType).filter(
                    (m) => typeof m === 'string',
                ),
            ],
            control: { type: 'radio' },
        },
    },
    parameters: {
        layout: 'centered',
    },
};
