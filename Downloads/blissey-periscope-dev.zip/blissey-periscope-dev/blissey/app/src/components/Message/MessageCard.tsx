import * as React from 'react';

import { MessageCardProps, MessageType } from './MessageInterfaces';

import * as styles from './MessageCard.css';

export function MessageCard(props: MessageCardProps) {
    let backgroundStyle;
    switch (props.type) {
        case MessageType.Action:
            backgroundStyle = styles.action;
            break;
        case MessageType.Error:
            backgroundStyle = styles.error;
            break;
        default:
            backgroundStyle = styles.info;
    }

    return (
        <div
            data-uitest="messagecard-message"
            className={[styles.messageCard, backgroundStyle].join(' ')}
        >
            {props.message}
        </div>
    );
}
