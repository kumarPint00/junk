import * as React from 'react';

import CloudOffIcon from '@mui/icons-material/CloudOff';
import WarningIcon from '@mui/icons-material/Warning';

import { MessageProps, MessageType } from './MessageInterfaces';
import { MessageCard } from './MessageCard';

import * as styles from './Message.css';

export const MessageComponent = (props: MessageProps) => {
    let icon = <></>;
    if (props.icon === 'cloud_off') {
        icon = <CloudOffIcon className={styles.icon} />;
    } else if (props.messageType === MessageType.Error) {
        icon = <WarningIcon className={styles.icon} />;
    }
    return (
        <div className={styles.messageContainer}>
            {icon}
            <MessageCard message={props.message} type={props.messageType} />
            {
                <div className={styles.subMessageCard}>
                    {props.subMessage || ''}
                </div>
            }
        </div>
    );
};
