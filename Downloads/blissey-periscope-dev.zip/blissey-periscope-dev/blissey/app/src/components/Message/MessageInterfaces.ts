/* There are conclusively 3 types of messages:
  1. Error (or warning): An end state where there is an issue, shown with a red background
  2. Info: Displaying information to the user where the user does not need to take action, shown with a blue background
  3. Action: A message that the user is in a state where they need to take action, shown with a gray background
  */
export enum MessageType {
    Info = 0,
    Action = 1,
    Error = 2,
}

export class MessageCardProps {
    public message: React.ReactNode;
    public type?: MessageType;
}

export interface MessageProps {
    message: string;
    messageType: MessageType;
    icon?: string;
    subMessage?: string;
}
