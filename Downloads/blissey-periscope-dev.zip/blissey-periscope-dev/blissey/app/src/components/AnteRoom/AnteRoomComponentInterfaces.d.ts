import { HealthInfo } from '@common/ConnectionTest/HealthInfo';
import { Publisher } from '@common/video';
import { UserDetails } from '@dexcare/circus-saturn';
import { TState as HealthState } from '@redux/modules/health';

export interface AnteRoomComponentProps {
    visitId: string;
    selfCheckCompleted: boolean;
    userDetails: UserDetails;
    health: HealthState;
    healthInfo: HealthInfo;
    isTestVisit?: boolean;
    blurEnabled: boolean;
    lostConnection: boolean;
    onConnect: () => Promis<void>;
    changeCam: (deviceId: string) => void;
    changeMic: (deviceId: string) => void;
    runTests: (publisher: Publisher) => void;
    toggleBlur: () => void;
}
