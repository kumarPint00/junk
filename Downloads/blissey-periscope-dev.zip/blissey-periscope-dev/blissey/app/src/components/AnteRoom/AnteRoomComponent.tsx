import * as React from 'react';
import Link from '@mui/material/Link';
import { Logger, LogManager } from '@dexcare/circus-jupiter';

import { ConnectionTestComponent } from '@components/ConnectionTest/ConnectionTestComponent';
import { AnteRoomComponentProps } from './AnteRoomComponentInterfaces';
import CallSelfCheckComponent from '@components/CallSelfCheck/CallSelfCheckComponent';
import { FooterPage } from '@layout/PageLayout/FooterPage';
import { Button } from '@components/Button';
import { isHealthCheckRunning } from '@redux/modules/health';
import { Publisher } from '@common/video';
import { submitDeviceChangeAnalytics } from '@services/analytics';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './AnteRoomComponentStyles.css';
export class AnteRoomComponent extends React.Component<AnteRoomComponentProps> {
    private logger: Logger;
    private PUBLISHER_ID = 'anteRoomSelfView';
    private selfViewPublisher: Publisher;

    private static techCheckText = 'RUNNING TECH CHECK';
    private static connectButtonText = 'CONNECT WITH PATIENT';
    private static waitingForPatientButtonText = 'WAITING FOR PATIENT...';
    private static cancelButtonText = 'CANCEL';

    constructor(props: AnteRoomComponentProps) {
        super(props);

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'AnteRoomComponent',
                visitId: this.props.visitId,
                userId: this.props.userDetails.id,
                isTestVisit: this.props.isTestVisit,
            },
            true,
        );
        this.selfViewPublisher = new Publisher({
            id: this.PUBLISHER_ID,
            callbacks: {
                onCamDeviceChange: this.props.changeCam,
                onMicDeviceChange: this.props.changeMic,
                onBlurEnabledChange: this.props.toggleBlur,
            },
        });
    }

    public componentDidMount() {
        this.logger.info({ eventType: 'render' });
    }

    public componentWillUnmount() {
        this.selfViewPublisher?.cleanup();
    }

    private onConnectClick = () => {
        this.logger.info(
            {
                eventType: 'userAction',
                eventName: 'connectClick',
            },
            'Connect to patient clicked',
        );

        this.props.onConnect();
    };

    private getButtonLabel = () => {
        if (isHealthCheckRunning(this.props.health.healthCheckProgress)) {
            return AnteRoomComponent.techCheckText;
        } else if (this.props.selfCheckCompleted) {
            return AnteRoomComponent.waitingForPatientButtonText;
        }

        return AnteRoomComponent.connectButtonText;
    };

    public onCameraChange = (
        event: React.ChangeEvent<HTMLSelectElement>,
    ): void => {
        const value = event.target.value;
        try {
            this.logger.info(`onCameraChange ${value}`);
            submitDeviceChangeAnalytics('video');
            void this.selfViewPublisher.setVideoDeviceId(value);
        } catch (error: unknown) {
            this.logger.error(
                { details: { error, deviceId: value } },
                'error setting video source',
            );
        }
    };

    public onAudioChange = (
        event: React.ChangeEvent<HTMLSelectElement>,
    ): void => {
        const value = event.target.value;
        try {
            this.logger.info(`onMicChange ${value}`);
            submitDeviceChangeAnalytics('audio');
            void this.selfViewPublisher.setAudioDeviceId(value);
        } catch (error: unknown) {
            this.logger.error(
                { details: { error, deviceId: value } },
                'error setting audio source',
            );
        }
    };

    private toggleBlur = () => {
        V2Analytics.interactionEvent({
            eventName:
                !this.props.blurEnabled === true ? 'blur_on' : 'blur_off',
            visit_id: this.props.visitId,
        });
        void this.selfViewPublisher.publishBlur(!this.props.blurEnabled);
    };

    private runTests = () => this.props.runTests(this.selfViewPublisher);

    private onCancelClick = () => {
        this.logger.info({
            eventType: 'userAction',
            eventName: 'cancelClick',
        });

        V2Analytics.interactionEvent({
            eventName: 'visit_cancel',
            visitId: this.props.visitId,
        });

        window.close();
    };

    public render() {
        return (
            <div className={styles.footerContainer}>
                <FooterPage>
                    <div className={styles.body}>
                        <ConnectionTestComponent
                            userDetails={this.props.userDetails}
                            health={this.props.health}
                            healthInfo={this.props.healthInfo}
                            runTests={this.runTests}
                            isProvider={true}
                            lostConnection={this.props.lostConnection}
                        />
                        <h1 className={styles.header}>
                            Please prepare to see the patient
                        </h1>
                        <div className={styles.videoWrapper}>
                            <CallSelfCheckComponent
                                runTechCheck={this.runTests}
                                disabled={this.props.selfCheckCompleted}
                                selfViewId={this.PUBLISHER_ID}
                                onAudioChange={this.onAudioChange}
                                onCameraChange={this.onCameraChange}
                                toggleBlur={this.toggleBlur}
                                lostConnection={this.props.lostConnection}
                            />
                        </div>
                        <div>
                            <Button
                                uiTestTag={'anteroom-connectbutton'}
                                onClick={this.onConnectClick}
                                disabled={
                                    this.props.selfCheckCompleted ||
                                    isHealthCheckRunning(
                                        this.props.health.healthCheckProgress,
                                    )
                                }
                            >
                                {this.getButtonLabel()}
                            </Button>
                            <div className={styles.cancelContainer}>
                                <Link
                                    component="button"
                                    role="link"
                                    className={styles.cancelLink}
                                    onClick={this.onCancelClick}
                                >
                                    {AnteRoomComponent.cancelButtonText}
                                </Link>
                            </div>
                        </div>
                    </div>
                </FooterPage>
            </div>
        );
    }
}
