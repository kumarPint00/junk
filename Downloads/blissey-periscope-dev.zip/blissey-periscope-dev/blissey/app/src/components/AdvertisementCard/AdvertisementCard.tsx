import {
    AdvertisementsCard,
    AdvertisementsCardProps,
} from '@dexcare/circus-saturn';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { submitGTMPageViewEvent } from '@services/analytics';
import * as React from 'react';

interface AdCardProps {
    visitId: string;
    source: string;
    t: (key: string, options?: Record<string, unknown>) => string;
}

export const AdCard = (props: AdCardProps) => {
    const virtualNudge = props.t('virtualNudge', { returnObjects: true });
    const showAdvertisements =
        typeof virtualNudge !== 'string' || virtualNudge !== 'virtualNudge';

    if (!showAdvertisements) {
        return null;
    }

    submitGTMPageViewEvent(props.visitId);

    const advertisements = virtualNudge as unknown as AdvertisementsCardProps;

    const onAdClickHandler = (
        event:
            | React.MouseEvent<HTMLAnchorElement>
            | React.KeyboardEvent<HTMLAnchorElement>,
        type: string,
        url: string,
    ) => {
        V2Analytics.interactionEvent({
            eventName: 'patient_clicked_ad',
            click_text: type,
            click_url: url,
            visit_id: props.visitId,
            source: props.source,
            source_url: event?.view?.document?.location?.href,
        });
        window.open(
            url,
            '_blank',
            'noopener,noreferrer,width=1200,height=800,resizable=1',
        );
    };

    const sxAds = {
        card: {
            display: 'flex',
            alignItems: 'flex-start',
            textAlign: 'left',
            flexDirection: 'column',
            position: 'relative',
            m: { xs: 2, sm: 4 },
            p: { xs: 2, sm: 4 },
            pt: { xs: 4, sm: 2 },
            pb: { xs: 10, sm: 0 },
            width: { xs: '85vw', sm: 600 },
            maxWidth: { xs: '85vw', sm: 600 },
        },
        content: {
            padding: '8px',
        },
        header: {
            marginBottom: '15px',
        },
        ad: {
            marginBottom: '14px',
        },
        title: {
            fontWeight: 'bold',
            fontSize: '1.25rem',
            color: '#0070a9',
        },
        link: {
            textDecoration: 'underline',
            marginBottom: '8px',
        },
    };

    return (
        <AdvertisementsCard
            advertisements={advertisements.advertisements}
            header={advertisements.header}
            onLinkClick={onAdClickHandler}
            sx={sxAds}
        />
    );
};
