import * as React from 'react';

import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import styled from '@mui/material/styles/styled';

import * as styles from './PlayerControls.css';
const blurBackgroundText = 'Toggle Blur Background On/Off';

const StyledIconButton = styled(IconButton)({
    border: 'none',
    borderRadius: '4px',
    padding: '10px',
});

interface DeviceControls {
    enabled: boolean;
    exists: boolean;
    onClick: () => void;
}

export interface PlayerFilterProps {
    videoBackgroundControls: DeviceControls;
}

/**
 * React component for video player controls
 */
export const PlayerFilterControls = ({
    videoBackgroundControls: {
        enabled: isBlurEnabled,
        exists: blurBackgroundExists,
        onClick: onBlurBackgroundClick,
    },
}: PlayerFilterProps) => {
    let backgroundControlButton: JSX.Element;

    if (!blurBackgroundExists) {
        // hide button
        backgroundControlButton = <></>;
    } else if (isBlurEnabled) {
        // enabled
        backgroundControlButton = (
            <Tooltip
                title={
                    blurBackgroundExists
                        ? blurBackgroundText
                        : 'Blur Background not supported'
                }
                placement="left"
                data-uitest="control-blurBackgroundButton"
            >
                <StyledIconButton
                    style={{ backgroundColor: '#2B5C8C' }}
                    onClick={onBlurBackgroundClick}
                >
                    <img
                        src={'/assets/playercontrols/blurOnIcon.svg'}
                        height={25}
                        width={25}
                    />
                </StyledIconButton>
            </Tooltip>
        );
    } else {
        // disabled
        backgroundControlButton = (
            <Tooltip
                title={
                    blurBackgroundExists
                        ? blurBackgroundText
                        : 'Blur Background not supported'
                }
                placement="left"
                data-uitest="control-blurBackgroundButton"
                disableInteractive
            >
                <StyledIconButton
                    style={{ backgroundColor: '#535151' }}
                    onClick={onBlurBackgroundClick}
                >
                    <img
                        src={'/assets/playercontrols/blurOffIcon.svg'}
                        height={25}
                        width={25}
                    />
                </StyledIconButton>
            </Tooltip>
        );
    }

    return (
        <div className={styles.controls}>
            <div className={styles.control}>{backgroundControlButton}</div>
        </div>
    );
};
