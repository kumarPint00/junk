import * as React from 'react';
import * as Redux from 'redux';
import { Provider } from 'react-redux';
import thunkShim from '@redux/middleware/thunkShim';
const thunkMw: any = thunkShim;
import { rootReducer, initialState, Store } from '@redux/modules';

import { VideoMenu } from '../VideoMenu';

const component = (state: Store['All']) => {
    const store: Redux.Store<Store['All']> = Redux.createStore(
        rootReducer as any,
        state as any,
        Redux.applyMiddleware(thunkMw as any),
    );

    const micClick = () => {
        console.log('mic click');
    };
    const camClick = () => {
        console.log('cam click');
    };
    const switchCameraClick = () => {
        console.log('switch camera click');
    };
    const blurBackgroundClick = () => {
        console.log('blur background click');
    };

    return (
        <Provider store={store}>
            <VideoMenu
                onMicClick={micClick}
                onCamClick={camClick}
                visitId={'visitId'}
                onBlurBackgroundClick={blurBackgroundClick}
                onSwitchCameraClick={switchCameraClick}
            />
        </Provider>
    );
};

export default {
    title: 'Components/Video Menu',
};

export const DefaultProvider = () => component(initialState);
