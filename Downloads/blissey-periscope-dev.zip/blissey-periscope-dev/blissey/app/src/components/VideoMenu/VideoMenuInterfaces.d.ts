export interface VideoMenuProps {
    onCamClick: () => void;
    onMicClick: () => void;
    onBlurBackgroundClick: () => void;
    onSwitchCameraClick: () => void;
    visitId: string;
}
