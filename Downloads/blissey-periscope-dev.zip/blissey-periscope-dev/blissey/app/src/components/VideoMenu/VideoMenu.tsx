import * as React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Action } from 'redux';
import { isProvider } from '@dexcare/circus-saturn';
import { Store } from '@redux/modules';
import { VideoMenuProps } from './VideoMenuInterfaces';
import { PlayerControls } from './PlayerControls';
import {
    setIsChatVisible,
    setEndCallConfirmation,
    toggleFullScreen,
} from '@redux/modules/videoMenu';
import {
    getArrayFeatureFlag,
    FeatureFlags,
    getFeatureFlag,
} from '@utils/FeatureFlags';
import { isSupportedBrowser } from '@utils/BrowserCheck';
import { getTransferOptions } from '@redux/modules/transferOptions';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

import { ThunkDispatch } from 'types/redux';

/**
 * React component for video player controls
 */
export function VideoMenu(props: VideoMenuProps) {
    const {
        localMicExists,
        localCamExists,
        isFullScreen,
        isCamEnabled,
        isMicEnabled,
        isChatVisible,
        isBlurEnabled,
    } = useSelector((state: Store['All']) => state.video);
    const callStartTime = useSelector(
        (state: Store['All']) => state.postconsult.callStartTime,
    );
    const userDetails = useSelector(
        (state: Store['All']) => state.user.userDetails,
    );

    const dispatch =
        useDispatch<ThunkDispatch<Store['All'], unknown, Action>>();

    let displayedCallStartTime = null;
    if (userDetails && isProvider(userDetails)) {
        displayedCallStartTime = callStartTime;
    }

    const showBlurFeatureFlag = getArrayFeatureFlag(
        FeatureFlags.showBlurOption,
    );

    // default to not showing
    let showBlurBackgroundButton = false;

    if (showBlurFeatureFlag) {
        // based on browser, browser version, provider, patient hide or show the blur option
        const { supportedBrowser, providerAvailable, patientAvailable } =
            isSupportedBrowser(showBlurFeatureFlag);

        if (supportedBrowser) {
            if (userDetails) {
                if (isProvider(userDetails) && providerAvailable) {
                    showBlurBackgroundButton = true;
                    console.log(
                        'Setting blurbackgroundEnabled to true - supported browser and providerAvailable',
                        showBlurFeatureFlag,
                    );
                }
                if (!isProvider(userDetails) && patientAvailable) {
                    showBlurBackgroundButton = true;
                    console.log(
                        'Setting blurbackgroundEnabled to true - supported browser and patientAvailable',
                        showBlurFeatureFlag,
                    );
                }
            }
        }
    }

    // always hide blur background if not provider or not featureflagged on
    if ((userDetails && !isProvider(userDetails)) || !showBlurFeatureFlag) {
        showBlurBackgroundButton = false;
        console.log(
            'Setting blurbackgroundEnabled to false - ShowBlurOptions:',
            showBlurFeatureFlag,
        );
    }
    const toggle = () => dispatch(toggleFullScreen);
    const handleChatClick = () => {
        V2Analytics.interactionEvent({
            eventName: 'chat_engage',
            location: 'virtual visit',
            visit_id: props.visitId,
        });
        dispatch(setIsChatVisible(!isChatVisible));
    };

    const endCallHandler = async () => {
        dispatch(setEndCallConfirmation(true));
        const endAndTransferVisit = getFeatureFlag(
            FeatureFlags.endAndTransferVisit,
        );
        const shouldGetTransferOptions =
            isProvider(userDetails) && endAndTransferVisit;
        if (shouldGetTransferOptions) {
            await dispatch(getTransferOptions(props.visitId));
        }
    };

    return (
        <PlayerControls
            micControls={{
                exists: localMicExists,
                enabled: isMicEnabled,
                onClick: props.onMicClick,
            }}
            camControls={{
                exists: localCamExists,
                enabled: isCamEnabled,
                onClick: props.onCamClick,
            }}
            videoBackgroundControls={{
                exists: showBlurBackgroundButton,
                enabled: isBlurEnabled,
                onClick: props.onBlurBackgroundClick,
            }}
            onEndCallClick={endCallHandler}
            onSwitchCameraClick={props.onSwitchCameraClick}
            isFullScreen={isFullScreen}
            toggleFullScreen={toggle}
            onChatClick={handleChatClick}
            callStartTime={displayedCallStartTime}
        />
    );
}
