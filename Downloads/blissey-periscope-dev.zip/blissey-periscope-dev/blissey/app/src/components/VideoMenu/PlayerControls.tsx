import * as React from 'react';
import { withTranslation, WithTranslation } from 'react-i18next';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import styled from '@mui/material/styles/styled';

import { CallLengthTimer } from '../CallLengthTimer/CallLengthTimer';

import * as styles from './PlayerControls.css';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';

const StyledIconButton = styled(IconButton)({
    border: 'none',
    borderRadius: '4px',
    padding: '10px',
});

interface DeviceControls {
    enabled: boolean;
    exists: boolean;
    onClick: () => void;
}

export interface PlayerControlProps extends WithTranslation {
    camControls: DeviceControls;
    micControls: DeviceControls;
    videoBackgroundControls: DeviceControls;
    isFullScreen: boolean; // TODO: remove, not used
    callStartTime: number | null;
    toggleFullScreen: () => void;
    onEndCallClick: () => Promise<void>;
    onChatClick: () => void;
    onSwitchCameraClick: () => void;
}

const PlayerControls = ({
    t,
    camControls: {
        enabled: isCamEnabled,
        exists: camExists,
        onClick: onCamClick,
    },
    micControls: {
        enabled: isMicEnabled,
        exists: micExists,
        onClick: onMicClick,
    },
    videoBackgroundControls: {
        enabled: isBlurEnabled,
        exists: blurBackgroundExists,
        onClick: onBlurBackgroundClick,
    },
    callStartTime,
    toggleFullScreen,
    onEndCallClick,
    onChatClick,
    onSwitchCameraClick,
}: PlayerControlProps) => {
    const enableCameraSwitcher = getFeatureFlag(
        FeatureFlags.releaseCameraSwitcher,
    );
    const fullscreenToggleText = t(
        'video-conference.controls.fullscreenToggle',
    );
    const micToggleText = t('video-conference.controls.micToggle');
    const micDisabledText = t('video-conference.controls.micDisabled');
    const camToggleText = t('video-conference.controls.camToggle');
    const camSwitchText = t('video-conference.controls.camSwitch');
    const camDisabledText = t('video-conference.controls.camDisabled');
    const blurToggleText = t('video-conference.controls.blurToggle');
    const blurToggleUnsupportedText = t(
        'video-conference.controls.blurToggle_notSupported',
    );
    const chatToggleText = t('video-conference.controls.chatToggle');
    const endCallText = t('video-conference.controls.endCall');

    const endCallButton: JSX.Element = (
        <StyledIconButton
            style={{ backgroundColor: '#F04823', marginBottom: '50px' }}
            onClick={() => {
                void onEndCallClick();
            }}
        >
            <img
                src={'/assets/playercontrols/phoneIcon.svg'}
                height={25}
                width={25}
            />
        </StyledIconButton>
    );

    const fullScreenButton: JSX.Element = (
        <StyledIconButton
            style={{ backgroundColor: '#2B5C8C' }}
            onClick={toggleFullScreen}
        >
            <img
                src={'/assets/playercontrols/fullScreenIcon.svg'}
                height={25}
                width={25}
            />
        </StyledIconButton>
    );

    let micControlButton: JSX.Element;
    if (isMicEnabled) {
        micControlButton = (
            <StyledIconButton
                style={{ backgroundColor: '#2B5C8C' }}
                onClick={onMicClick}
            >
                <img
                    src={'/assets/playercontrols/micOnIcon.svg'}
                    height={25}
                    width={25}
                />
            </StyledIconButton>
        );
    } else {
        micControlButton = (
            <StyledIconButton
                style={{ backgroundColor: '#535151' }}
                onClick={onMicClick}
            >
                <img
                    src={'/assets/playercontrols/micOffIcon.svg'}
                    height={25}
                    width={25}
                />
            </StyledIconButton>
        );
    }

    let camControlButton: JSX.Element;
    if (isCamEnabled) {
        camControlButton = (
            <StyledIconButton
                style={{ backgroundColor: '#2B5C8C' }}
                onClick={onCamClick}
            >
                <img
                    src={'/assets/playercontrols/camOnIcon.svg'}
                    height={25}
                    width={25}
                />
            </StyledIconButton>
        );
    } else {
        camControlButton = (
            <StyledIconButton
                style={{ backgroundColor: '#535151' }}
                onClick={onCamClick}
            >
                <img
                    src={'/assets/playercontrols/camOffIcon.svg'}
                    height={25}
                    width={25}
                />
            </StyledIconButton>
        );
    }

    const selfieCameraControlButton = (
        <StyledIconButton
            style={{ backgroundColor: '#2B5C8C', color: '#FFF' }}
            onClick={onSwitchCameraClick}
        >
            <img
                src={'/assets/playercontrols/cameraRotate.svg'}
                height={25}
                width={25}
            />
        </StyledIconButton>
    );

    const chatButton: JSX.Element = (
        <StyledIconButton
            style={{ backgroundColor: '#2B5C8C' }}
            onClick={onChatClick}
        >
            <img
                src={'/assets/playercontrols/chatIcon.svg'}
                height={25}
                width={25}
            />
        </StyledIconButton>
    );

    let backgroundControlButton: JSX.Element;

    if (!blurBackgroundExists) {
        // hide button
        backgroundControlButton = <></>;
    } else if (isBlurEnabled) {
        // enabled
        backgroundControlButton = (
            <Tooltip
                title={
                    blurBackgroundExists
                        ? blurToggleText
                        : blurToggleUnsupportedText
                }
                placement="left"
                data-uitest="control-blurBackgroundButton"
                disableInteractive
            >
                <StyledIconButton
                    style={{ backgroundColor: '#2B5C8C' }}
                    onClick={onBlurBackgroundClick}
                >
                    <img
                        src={'/assets/playercontrols/blurOnIcon.svg'}
                        height={25}
                        width={25}
                    />
                </StyledIconButton>
            </Tooltip>
        );
    } else {
        // disabled
        backgroundControlButton = (
            <Tooltip
                title={
                    blurBackgroundExists
                        ? blurToggleText
                        : blurToggleUnsupportedText
                }
                placement="left"
                data-uitest="control-blurBackgroundButton"
            >
                <StyledIconButton
                    style={{ backgroundColor: '#535151' }}
                    onClick={onBlurBackgroundClick}
                >
                    <img
                        src={'/assets/playercontrols/blurOffIcon.svg'}
                        height={25}
                        width={25}
                    />
                </StyledIconButton>
            </Tooltip>
        );
    }

    return (
        <ul className={styles.controlsListContainer}>
            <li className={styles.spacing}>
                <div className={`${styles.control}`}>
                    <Tooltip
                        title={endCallText}
                        placement="left"
                        data-uitest="control-endCallButton"
                    >
                        {endCallButton}
                    </Tooltip>
                </div>
            </li>
            <li>
                <div className={styles.control}>
                    <Tooltip
                        title={fullscreenToggleText}
                        placement="left"
                        data-uitest="fullscreencontrol-button"
                    >
                        {fullScreenButton}
                    </Tooltip>
                </div>
            </li>
            <li>
                <div className={styles.control}>
                    <Tooltip
                        title={micExists ? micToggleText : micDisabledText}
                        placement="left"
                        data-uitest="control-micButton"
                    >
                        {micControlButton}
                    </Tooltip>
                </div>
            </li>
            <li>
                <div className={styles.control}>
                    <Tooltip
                        title={camExists ? camToggleText : camDisabledText}
                        placement="left"
                        data-uitest="control-camButton"
                    >
                        {camControlButton}
                    </Tooltip>
                </div>
            </li>
            {enableCameraSwitcher && (
                <li>
                    <div className={styles.control}>
                        <Tooltip
                            title={camExists ? camSwitchText : camDisabledText}
                            placement="left"
                            data-uitest="control-camSwitcher"
                        >
                            {selfieCameraControlButton}
                        </Tooltip>
                    </div>
                </li>
            )}
            <li>
                <div className={styles.control}>
                    <Tooltip
                        title={chatToggleText}
                        placement="left"
                        data-uitest="control-chatButton"
                    >
                        {chatButton}
                    </Tooltip>
                </div>
            </li>
            {callStartTime && (
                <li>
                    <div
                        className={styles.control}
                        data-uitest="control-callLengthTimer"
                    >
                        <CallLengthTimer callStartTime={callStartTime} />
                    </div>
                </li>
            )}
            {blurBackgroundExists && (
                <li>
                    <div className={styles.control}>
                        {backgroundControlButton}
                    </div>
                </li>
            )}
        </ul>
    );
};

const _PlayerControls = withTranslation()(PlayerControls);
export { _PlayerControls as PlayerControls };
