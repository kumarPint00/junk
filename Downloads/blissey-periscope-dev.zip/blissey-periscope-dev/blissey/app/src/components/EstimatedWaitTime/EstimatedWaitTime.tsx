import * as React from 'react';
import { withTranslation } from 'react-i18next';
import {
    EstimatedWaitTimeProps,
    EstimatedWaitTimeState,
} from './EstimatedWaitTimeInterfaces';
import CircularProgress from '@mui/material/CircularProgress';
import { FlipCard } from '@components/FlipCard/FlipCard';
import { sleep } from '@utils/miscUtils';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './EstimatedWaitTime.css';

class EstimatedWaitTime extends React.Component<
    EstimatedWaitTimeProps,
    EstimatedWaitTimeState
> {
    private initSleepTime: number = 1000 * 5;

    constructor(props: EstimatedWaitTimeProps) {
        super(props);
    }

    public async componentDidMount() {
        if (this.props.isTestVisit) {
            this.setState({
                estimatedWaitTimeMessage: this.props.t(
                    'waiting-room.waitEstimation_test',
                ),
                loading: false,
            });
        } else {
            for (let i = 0; i < 2; i++) {
                await sleep(this.props.initialWait || this.initSleepTime);
                if (this.props.waitTimeInfo?.estimatedWaitTimeSeconds) {
                    this.submitWaitingRoomEvent(
                        this.state?.estimatedWaitTimeSeconds,
                    );
                    return;
                }
            }
        }

        this.submitWaitingRoomEvent(
            this.props.waitTimeInfo?.estimatedWaitTimeSeconds,
        );
    }

    public submitWaitingRoomEvent(estimatedSeconds?: number) {
        const waitTime = estimatedSeconds
            ? this.formatWaitTimeAnalytics(
                  this.props.waitTimeInfo?.estimatedWaitTimeSeconds,
              )
            : 'unknown';

        V2Analytics.interactionEvent({
            eventName: 'enter_waiting_room',
            appt_date: this.formatDate(),
            visit_id: this.props.visitId,
            wait_time: waitTime,
        });
    }

    public formatDate(): string {
        const today = new Date();
        return `${today.getFullYear()}-${
            today.getMonth() + 1
        }-${today.getDate()}`;
    }

    public formatWaitTimeAnalytics(estimatedSeconds: number): string {
        let minutes = Math.round(estimatedSeconds / 60);
        minutes = Math.max(Math.min(999, minutes), 1);
        return `${minutes} min`;
    }

    public formatEstimateAsOf(timestamp: string | Date = '') {
        const formattedTimestamp =
            typeof timestamp === 'string' ? new Date(timestamp) : timestamp;
        const userLang = this.props.i18n.language || 'en-US';

        return this.props.t('waiting-room.waitEstimation_asOf', {
            time: formattedTimestamp
                .toLocaleTimeString(userLang, {
                    hour: 'numeric',
                    minute: '2-digit',
                })
                .toLowerCase(),
        });
    }

    public render() {
        const loading = this.props.waitTimeInfo?.loading;
        const estimatedWaitTimeMessage =
            this.props.waitTimeInfo?.estimatedWaitTimeMessage ??
            this.props.t('waiting-room.providerSoon');
        const estimateAsOf = this.formatEstimateAsOf(
            this.props.waitTimeInfo?.estimateGeneratedAt,
        );
        const previousEstimateAsOf = this.formatEstimateAsOf(
            this.props.waitTimeInfo?.estimateGeneratedAt,
        );

        let spinner = null;
        if (loading) {
            spinner = (
                <CircularProgress
                    size={15}
                    thickness={8}
                    classes={{ colorPrimary: styles.loadingColor }}
                />
            );
        }
        return (
            <div className={styles.main}>
                <p className={styles.estimatedWaitTime}>
                    {estimatedWaitTimeMessage}
                </p>
                <FlipCard front={previousEstimateAsOf} back={estimateAsOf} />
                <div className={styles.spinnerContainer}>{spinner}</div>
            </div>
        );
    }
}

const _EstimatedWaitTime =
    withTranslation()<typeof EstimatedWaitTime>(EstimatedWaitTime);
export { _EstimatedWaitTime as EstimatedWaitTime };
