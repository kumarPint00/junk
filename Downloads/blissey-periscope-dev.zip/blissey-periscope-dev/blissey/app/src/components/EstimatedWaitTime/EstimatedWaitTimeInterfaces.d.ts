import { WithTranslation } from 'react-i18next';
import { UserDetails } from '@dexcare/circus-saturn';
import { WaitTimeInfo } from '@components/WaitingRoom/WaitingRoomInterfaces';

export interface EstimatedWaitTimeProps extends WithTranslation {
    visitId: string;
    userDetails: UserDetails;
    brand: string;
    initialWait?: number;
    isTestVisit?: boolean;
    waitTimeInfo: WaitTimeInfo;
}

export interface EstimatedWaitTimeState {
    estimatedWaitTimeMessage: string;
    estimateAsOf: string;
    estimatedWaitTimeSeconds: number;
    previousEstimateAsOf: string;
    loading: boolean;
}
