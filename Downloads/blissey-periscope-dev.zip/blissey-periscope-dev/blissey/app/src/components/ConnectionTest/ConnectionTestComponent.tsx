import * as React from 'react';
import { withTranslation } from 'react-i18next';

import { ConnectionTestProgressComponent } from './ConnectionTestProgressComponent';
import { ConnectionTestCompleteComponent } from './ConnectionTestCompleteComponent';
import { getConnectionTestMessageMap } from '../../common/ConnectionTest/ConnectionTestMessages';
import { ConnectionTestComponentProps } from './ConnectionTestInterfaces';
import { HealthCheckStatus } from '../../common/ConnectionTest/HealthCheckStatus';

class ConnectionTestComponent extends React.Component<ConnectionTestComponentProps> {
    public render() {
        if (
            this.props.health.healthCheckProgress === 0 ||
            this.props.lostConnection
        ) {
            const passed =
                this.props.healthInfo.healthCheckStatus ===
                    HealthCheckStatus.Healthy && !this.props.lostConnection;

            return (
                <div>
                    <ConnectionTestCompleteComponent
                        passed={passed}
                        lostConnection={this.props.lostConnection}
                        health={this.props.health}
                        isProvider={this.props.isProvider}
                        onClick={this.retest}
                    />
                </div>
            );
        }

        const testProgress = this.props.health.healthCheckProgress;
        const testStatus = getConnectionTestMessageMap(this.props.i18n).get(
            testProgress,
        );
        return (
            <div>
                <ConnectionTestProgressComponent
                    testProgress={testProgress}
                    testStatus={testStatus}
                />
            </div>
        );
    }

    componentDidMount() {
        this.props.runTests();
    }

    private retest = (): void => {
        setTimeout(this.props.runTests, 200);
    };
}

const _ConnectionTestComponent = withTranslation()(ConnectionTestComponent);
export { _ConnectionTestComponent as ConnectionTestComponent };
