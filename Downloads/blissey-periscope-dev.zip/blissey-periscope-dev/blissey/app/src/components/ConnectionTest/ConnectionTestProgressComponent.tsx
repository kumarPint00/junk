import * as React from 'react';
import LinearProgress from '@mui/material/LinearProgress';

import * as styles from './ConnectionTestProgressComponent.css';

export function ConnectionTestProgressComponent(props: {
    testProgress?: number;
    testStatus?: React.ReactNode;
}) {
    return (
        <div className={styles.main} data-uitest="testconnectionprogress">
            <LinearProgress
                variant="determinate"
                value={props.testProgress}
                className={styles.progressBar}
            />
            <div className={styles.assistText}>{props.testStatus}</div>
        </div>
    );
}
