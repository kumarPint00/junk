import { TState as HealthState } from '@redux/modules/health';
import { WithTranslation } from 'react-i18next';

import { UserDetails } from '@dexcare/circus-saturn';
import { HealthInfo } from '../../common/ConnectionTest/HealthInfo';

export interface ConnectionTestComponentProps extends WithTranslation {
    userDetails: UserDetails;
    health: HealthState;
    healthInfo: HealthInfo;
    runTests(): void;
    isProvider: boolean;
    lostConnection: boolean;
}

export interface ConnectionTestCompleteComponentProps extends WithTranslation {
    passed: boolean;
    isProvider: boolean;
    onClick: () => void;
    health: HealthState;
    lostConnection: boolean;
}
