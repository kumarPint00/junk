import * as React from 'react';
import CheckCircleOutline from '@mui/icons-material/CheckCircleOutline';
import Warning from '@mui/icons-material/Warning';
import { withTranslation } from 'react-i18next';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

import { ConnectionTestCompleteComponentProps } from './ConnectionTestInterfaces';
import { getErrorMessage } from '@common/techCheckErrorMessages';
import * as styles from './ConnectionTestCompleteComponent.css';

function ConnectionTestCompleteComponent(
    props: ConnectionTestCompleteComponentProps,
) {
    let icon = (
        <CheckCircleOutline
            data-uitest="testconnectionpassed"
            className={styles.successIcon}
        />
    );
    let successClass = styles.success;
    let header = props.t('waiting-room.tech-check.status.success');
    let message = props.t('waiting-room.tech-check.status.connectionGood');

    if (!props.passed) {
        icon = <Warning className={styles.errorIcon} />;
        successClass = styles.error;
        const text = getErrorMessage(props.health, props.lostConnection);
        header = text.techCheckHeader!;
        message = text.techCheckDescription!;

        V2Analytics.errorEvent({ text: message, type: header });
    }

    const containerClasses = `${styles.container} ${successClass}`;
    return (
        <div
            data-uitest="testconnectionbutton"
            className={containerClasses}
            onClick={props.onClick}
        >
            {icon}
            <div className={styles.header}>{header}</div>
            <div className={'message'}>{message}</div>
        </div>
    );
}

const _ConnectionTestCompleteComponent = withTranslation()(
    ConnectionTestCompleteComponent,
);
export { _ConnectionTestCompleteComponent as ConnectionTestCompleteComponent };
