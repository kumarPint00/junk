import * as React from 'react';
import { render } from '@testing-library/react';
import {
    IntegrationButton,
    IntegrationButtonProps,
} from '../IntegrationButton';
import { vi } from 'vitest';

const defaultProps = {
    keyName: 'viButton',
    displayName: 'Open Sesame',
    onClick: vi.fn(),
    clickTo: 'open' as const,
};

const matchesSnapshot = (props: IntegrationButtonProps) => {
    const { container } = render(<IntegrationButton {...props} />);
    expect(container).toMatchSnapshot();
};

describe('<IntegrationButton />', () => {
    it('renders with no children', () => {
        matchesSnapshot(defaultProps);
    });

    it('renders with children', () => {
        const { container } = render(
            <IntegrationButton {...defaultProps}>
                <img src="http://test-image" />
            </IntegrationButton>,
        );
        expect(container).toMatchSnapshot();
    });

    it('renders clickToClose', () => {
        matchesSnapshot({
            ...defaultProps,
            clickTo: 'close',
        });
    });
});
