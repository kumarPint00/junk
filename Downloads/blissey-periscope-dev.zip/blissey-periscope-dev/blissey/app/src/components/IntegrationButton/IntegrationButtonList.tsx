import * as React from 'react';
import InfoIcon from '@mui/icons-material/InfoOutlined';
import cn from 'classnames';
import { IntegrationButton } from '.';
import { TytoCareLogo } from '@components/TytoCare/TytoCareLogo';

import * as styles from './IntegrationButtonList.css';

export interface IntegrationButtonListProps {
    open: boolean;
    tytoCare: {
        enabled: boolean;
        onClick: () => void;
    };
    videoStats: {
        enabled: boolean;
        onClick: () => void;
    };
}

const sxStyles = {
    iconRoot: {
        color: '#212121',
    },
};

const intButtonConfigs: {
    [key: string]: { keyName: string; displayName: string };
} = {
    tytoCare: {
        keyName: 'tytoCare',
        displayName: 'TytoCare',
    },
    videoStats: {
        keyName: 'videoReporting',
        displayName: 'Video Reporting',
    },
};

export const IntegrationButtonList = ({
    open,
    tytoCare,
    videoStats,
}: IntegrationButtonListProps) => {
    const containerStyles = cn(
        open ? styles.closeButtonContainer : styles.openButtonContainer,
        styles.buttonList,
    );
    const clickTo = open ? 'close' : 'open';

    return (
        <div className={containerStyles}>
            {tytoCare.enabled && (
                <IntegrationButton
                    displayName={
                        open
                            ? `Close ${intButtonConfigs.tytoCare.displayName}`
                            : `Open ${intButtonConfigs.tytoCare.displayName}`
                    }
                    keyName={intButtonConfigs.tytoCare.keyName}
                    onClick={tytoCare.onClick}
                    clickTo={clickTo}
                >
                    <TytoCareLogo />
                </IntegrationButton>
            )}
            {videoStats.enabled && (
                <IntegrationButton
                    keyName={intButtonConfigs.videoStats.keyName}
                    displayName={'Video Reporting'}
                    onClick={videoStats.onClick}
                    clickTo={clickTo}
                >
                    <InfoIcon sx={sxStyles.iconRoot} />
                </IntegrationButton>
            )}
        </div>
    );
};
