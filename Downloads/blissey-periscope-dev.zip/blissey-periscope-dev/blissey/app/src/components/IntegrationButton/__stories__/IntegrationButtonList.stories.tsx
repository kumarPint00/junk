import { IntegrationButtonList } from '../';

export const Default = {
    args: {
        open: true,
        tytoCare: {
            enabled: true,
            onClick: () => console.log('tytoCare click!'),
        },
        videoStats: {
            enabled: true,
            onClick: () => console.log('videoStats click!'),
        },
    },
};

export default {
    title: 'Components/Integration Button List',
    component: IntegrationButtonList,
    parameters: {
        layout: 'padded',
    },
};
