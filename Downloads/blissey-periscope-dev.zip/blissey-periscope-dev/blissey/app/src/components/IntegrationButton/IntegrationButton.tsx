import * as React from 'react';
import Button from '@mui/material/Button';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';
import ArrowLeftIcon from '@mui/icons-material/ArrowLeft';

import * as styles from './IntegrationButton.css';

export type IntegrationButtonProps = React.PropsWithChildren<{
    onClick: () => void;
    keyName: string;
    clickTo: 'open' | 'close';
    displayName: string;
}>;

const sxStyles = {
    root: {
        background: '#FFFFFF',
        textTransform: 'none',
        width: '145px',
        height: '51px',
        '&:hover': {
            background: '#FFFFFF',
        },
        fontSize: '1rem',
        lineHeight: '1.2rem',
    },
};

export const IntegrationButton: React.FunctionComponent<
    IntegrationButtonProps
> = ({ onClick, keyName, clickTo, displayName, children }) => {
    return (
        <Button
            color="primary"
            onClick={onClick}
            data-uitest={`${keyName}-button`}
            sx={sxStyles.root}
        >
            {clickTo === 'close' && (
                <>
                    <ArrowLeftIcon />
                    <span className={styles.logoContainerSpaceRight}>
                        {children}
                    </span>
                </>
            )}
            {displayName}
            {clickTo === 'open' && (
                <>
                    <span className={styles.logoContainerSpaceLeft}>
                        {children}
                    </span>
                    <ArrowRightIcon />
                </>
            )}
        </Button>
    );
};
