import * as React from 'react';
import { withTranslation } from 'react-i18next';
import Card from '@mui/material/Card';
import { config } from '@dexcare/circus-jupiter';
import { NotFoundComponentProps } from './NotFoundComponentInterfaces';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './NotFoundComponent.css';
import { Configuration } from 'types/configuration';
import { BlisseyLogger } from '@utils/Logger';
import { Box, CardContent, ListItem, Typography } from '@mui/material';
import LightbulbOutlinedIcon from '@mui/icons-material/LightbulbOutlined';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';

const errorType = 'not found';

function NotFoundComponent(props: NotFoundComponentProps) {
    const {
        isProvider,
        invalidVisitReason,
        isTokBoxTokenError = false,
        tokboxTokenErrorMessage,
    } = props;

    const enableThingsYouCanTry = getFeatureFlag(
        FeatureFlags.enableThingsYouCanTry,
    );

    const helpNumber = (config as Configuration).getConfig()
        .technicalSupportHelpNumber;
    const displayNumber = (config as Configuration).getConfig()
        .displaySupportNumberOnError;

    let schedulingLink = props.t('branding:logoutReturnTo');
    if (schedulingLink.endsWith('=')) {
        schedulingLink = `${schedulingLink}error`; // append status used by KP analytics
    }

    const thingsYouCanTryTitle: string =
        props.t('thingsYouCanTry.title') ?? 'Things you can try:';

    const rawParticipantSuggestions = props.t(
        'thingsYouCanTry.participantSuggestions',
    );
    const customParticipantSuggestions: string[] | null = Array.isArray(
        rawParticipantSuggestions,
    )
        ? rawParticipantSuggestions
        : null;

    const rawProviderSuggestions = props.t(
        'thingsYouCanTry.providerSuggestions',
    );
    const customProviderSuggestions: string[] | null = Array.isArray(
        rawProviderSuggestions,
    )
        ? rawProviderSuggestions
        : null;

    const logAndReturn = (text: string, element: React.ReactNode) => {
        V2Analytics.errorEvent({ text, type: errorType });
        return element;
    };

    const providerErrorMessage = (
        <>
            <p className={styles.goBack}>
                The system failed to fetch the visit.
            </p>
        </>
    );

    const visitConvertedErrorMessage = (
        <p className={styles.goBack}>
            The virtual visit you are trying to access has been converted to a
            phone visit.
        </p>
    );

    const patientUnauthorizedErrorMessage =
        isTokBoxTokenError && tokboxTokenErrorMessage === 'Forbidden' ? (
            <p className={styles.goBack}>
                You do not have permission to join this video visit.
            </p>
        ) : null;

    const invalidVisitErrorMessage = (
        <p className={styles.goBack}>The system failed to fetch your visit.</p>
    );

    const helpSuggestion = displayNumber
        ? `Go back, or if you need help scheduling an appointment,
        <br class="${styles.br}" />
        call <a class="${styles.helpTelephone}" href="tel:${helpNumber}">${helpNumber}</a>`
        : `Try requesting a visit on the &nbsp;<a class="${styles.schedulingLink}" href="${schedulingLink}">scheduling page</a>`;

    const basePatientErrorMessage = (
        <>
            {patientUnauthorizedErrorMessage ?? invalidVisitErrorMessage}
            {!enableThingsYouCanTry && (
                <p
                    className={styles.helpSuggestion}
                    dangerouslySetInnerHTML={{ __html: helpSuggestion }}
                />
            )}
        </>
    );

    const baseSuggestions = React.useMemo(() => {
        const defaultParticipantSuggestions = [
            'Make sure you are accessing the correct visit link.',
            'Confirm the visit has not been canceled by your provider.',
            ...[helpSuggestion],
        ];

        const defaultProviderSuggestions = ['Try navigating back one page.'];

        const participantSuggestions = [
            ...(customParticipantSuggestions ?? defaultParticipantSuggestions),
        ];

        const providerSuggestions = [
            ...(customProviderSuggestions ?? defaultProviderSuggestions),
        ];

        return isProvider ? providerSuggestions : participantSuggestions;
    }, [customParticipantSuggestions, displayNumber, helpNumber]);

    const renderSuggestionList = (suggestions: string[]) => (
        <Box component="ul" sx={{ pl: 4, m: 0 }}>
            {suggestions.map((text, index) => (
                <ListItem
                    key={index}
                    component="li"
                    sx={{ display: 'list-item', p: 0 }}
                >
                    <Typography
                        variant="body1"
                        component="span"
                        dangerouslySetInnerHTML={{ __html: text }}
                    />
                </ListItem>
            ))}
        </Box>
    );

    const buildErrorMessage = () => {
        BlisseyLogger.info({
            eventSource: 'NotFoundComponent',
            eventType: 'buildErrorMessage',
            isProvider,
            displayNumber,
            isTokBoxTokenError,
            tokboxTokenErrorMessage,
        });

        if (isProvider && invalidVisitReason === 'VISIT_CONVERTED') {
            return logAndReturn(
                'visit has been converted to phone visit',
                visitConvertedErrorMessage,
            );
        }

        if (isProvider) {
            return logAndReturn('try going back', providerErrorMessage);
        }

        const eventText = displayNumber
            ? 'go back or call to schedule'
            : 'try the scheduling page';

        return logAndReturn(eventText, basePatientErrorMessage);
    };

    return (
        <div className={styles.notFoundModuleContainer}>
            <div data-uitest="notFoundPage" className={styles.notFound}>
                <h1 className={styles.sorry}>Sorry.</h1>
                <h3 className={styles.weWerentExpecting}>
                    We weren&apos;t expecting you here.
                </h3>
                <div className={styles.notFoundCard}>
                    <Card className={styles.notFoundMessage}>
                        {buildErrorMessage()}
                    </Card>
                </div>

                {enableThingsYouCanTry && (
                    <div className={styles.thingsYouCanTryCard}>
                        <Card className={styles.thingsYouCanTryMessage}>
                            <CardContent>
                                <Box display="flex" alignItems="center" mb={2}>
                                    <LightbulbOutlinedIcon
                                        fontSize="medium"
                                        sx={{ mr: 1 }}
                                    />
                                    <Typography variant="h6">
                                        {thingsYouCanTryTitle}
                                    </Typography>
                                </Box>
                                {renderSuggestionList(baseSuggestions)}
                            </CardContent>
                        </Card>
                    </div>
                )}
            </div>
        </div>
    );
}

const _NotFoundComponent = withTranslation()(NotFoundComponent);
export { _NotFoundComponent as NotFoundComponent };
export { NotFoundComponent as UnwrappedNotFoundComponent };
