import { WithTranslation } from 'react-i18next';

export interface NotFoundComponentProps extends WithTranslation {
    isProvider: boolean;
    invalidVisitReason: string | null;
    isTokBoxTokenError: boolean;
    tokboxTokenErrorMessage: string | null;
}
