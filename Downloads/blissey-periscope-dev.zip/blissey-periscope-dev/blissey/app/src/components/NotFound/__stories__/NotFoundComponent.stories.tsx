/* eslint-disable */
/* tslint:disable */
import type { Meta, StoryObj } from '@storybook/react';
import type { TFunction } from 'i18next';
import { UnwrappedNotFoundComponent } from '../NotFoundComponent';
import { config } from '@dexcare/circus-jupiter';
import { FeatureFlags } from '@utils/FeatureFlags';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import { NotFoundComponentProps } from '../NotFoundComponentInterfaces';
import { Configuration } from 'types/configuration';
import configureMockStore from 'redux-mock-store';
import thunk from '@redux/middleware/thunkShim';

// Mock translation function
const t: TFunction = ((key: string) => {
    const translations: Record<string, string | string[] | null> = {
        'thingsYouCanTry.providerSuggestions': [
            'Verify you are accessing the correct visit.',
        ],
        'thingsYouCanTry.title': 'Additional Details:',
        'thingsYouCanTry.participantSuggestions': [
            'To join a video visit, select <a href="https://example.com/start-visit">Start a video or phone visit</a>. After you answer a few questions, you’ll be placed back in line for an on-demand visit.',
            'You can also try changing the region or time zone selection.',
            'Be sure to confirm the visit has not been canceled by your provider.',
        ],
    };
    return translations[key] || key;
}) as TFunction;

interface ComponentProps extends NotFoundComponentProps {
    flagValue?: boolean; // Optional prop for feature flag
    displaySupportNumberOnError?: boolean;
}

const Component = (props: ComponentProps) => {
    const defaultAppConfig = (config as Configuration).getConfig();
    (config as Configuration).setConfig({
        ...defaultAppConfig,
        technicalSupportHelpNumber: '1-800-555-1234',
        displaySupportNumberOnError: props.displaySupportNumberOnError ?? true,
        chatbot: {},
        brands: [],
        cookieDurationSeconds: 3600,
        customer: {},
        features: {
            [FeatureFlags.enableThingsYouCanTry]:
                (props as any).flagValue ?? false,
        },
    });

    const mockStore = configureMockStore([thunk]);
    const mockStoreWithState = mockStore({});
    return (
        <BrowserRouter>
            <Provider store={mockStoreWithState}>
                <UnwrappedNotFoundComponent {...props} />
            </Provider>
        </BrowserRouter>
    );
};

const meta: Meta<typeof Component> = {
    title: 'Components/NotFoundComponent',
    component: Component,
    tags: ['autodocs'],
    parameters: {
        layout: 'centered',
    },
};

export default meta;

type Story = StoryObj<typeof Component>;

export const ProviderView: Story = {
    args: {
        isProvider: true,
        t,
    },
};

export const ProviderViewWithVisitConverted: Story = {
    args: {
        isProvider: true,
        invalidVisitReason: 'VISIT_CONVERTED',
        t,
    },
};

export const ProviderViewAndSuggestions: Story = {
    args: {
        isProvider: true,
        t: ((key: string) => {
            if (key === 'branding:logoutReturnTo')
                return 'https://example.com/schedule';
            if (key === 'thingsYouCanTry.title') return 'Things you can try:';
            return t(key);
        }) as TFunction,
        flagValue: true,
    },
};

export const PatientViewWithPhoneSupport: Story = {
    args: {
        isProvider: false,
        t,
    },
};

export const PatientViewWithLinkSupport: Story = {
    args: {
        isProvider: false,
        t,
        displaySupportNumberOnError: false,
    },
};

export const PatientViewWithPhoneSupportAndSuggestions: Story = {
    args: {
        isProvider: false,
        t: ((key: string) => {
            if (key === 'thingsYouCanTry.participantSuggestions')
                return undefined;
            if (key === 'thingsYouCanTry.title') return undefined;
            return t(key);
        }) as TFunction,
        flagValue: true,
    },
};

export const PatientViewWithLinkSupportAndSuggestions: Story = {
    args: {
        isProvider: false,
        t: ((key: string) => {
            if (key === 'thingsYouCanTry.participantSuggestions')
                return undefined;
            if (key === 'thingsYouCanTry.title') return undefined;
            return t(key);
        }) as TFunction,
        flagValue: true,
        displaySupportNumberOnError: false,
    },
};

export const TokBoxForbiddenError: Story = {
    args: {
        isProvider: false,
        isTokBoxTokenError: true,
        tokboxTokenErrorMessage: 'Forbidden',
        t,
    },
};

export const TokBoxForbiddenErrorAndSuggestions: Story = {
    args: {
        isProvider: false,
        isTokBoxTokenError: true,
        tokboxTokenErrorMessage: 'Forbidden',
        t: ((key: string) => {
            if (key === 'thingsYouCanTry.participantSuggestions')
                return undefined;
            if (key === 'thingsYouCanTry.title') return undefined;
            return t(key);
        }) as TFunction,
        flagValue: true,
    },
};

export const CustomerSuggestionsPatientErrorMessage: Story = {
    args: {
        isProvider: false,
        t,
        flagValue: true,
    },
};

export const CustomerSuggestionsTokBoxErrorMessage: Story = {
    args: {
        isProvider: false,
        isTokBoxTokenError: true,
        tokboxTokenErrorMessage: 'Forbidden',
        t,
        flagValue: true,
    },
};
