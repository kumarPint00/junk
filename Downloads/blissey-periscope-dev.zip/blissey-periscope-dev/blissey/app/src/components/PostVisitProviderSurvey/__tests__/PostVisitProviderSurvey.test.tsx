import * as React from 'react';
import { render, waitFor } from '@testing-library/react';
import PostVisitProviderSurvey from '../PostVisitProviderSurvey';
import { Survey } from 'survey-react-ui';
import { Model } from 'survey-core';
import { vi } from 'vitest';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';

const mockUserDetails = { id: 'test-user-id' };
const mockStore = configureStore([]);
const store = mockStore({ user: { userDetails: mockUserDetails } });

const mockGetLatestSurvey = vi.fn(async () => {
    await new Promise((resolve) => setTimeout(resolve, 100));

    return {
        title: 'Mocked Survey',
        questions: [
            { name: 'question1', type: 'text', title: 'Question 1' },
            { name: 'question2', type: 'checkbox', title: 'Question 2' },
        ],
    };
}) as unknown as typeof visitServiceClient.getLatestSurvey;

visitServiceClient.getLatestSurvey = mockGetLatestSurvey;

vi.mock('survey-react-ui', () => ({
    Survey: vi.fn(() => null),
}));

const mockApplyTheme = vi.fn();
const mockOnCompleteAdd = vi.fn();
const mockAddNavigationItem = vi.fn();

vi.mock('survey-core', () => ({
    Model: vi.fn(() => ({
        applyTheme: mockApplyTheme,
        onComplete: {
            add: mockOnCompleteAdd,
        },
        addNavigationItem: mockAddNavigationItem,
    })),
}));

describe('PostVisitProviderSurvey', () => {
    it('renders the survey', async () => {
        const submit = vi.fn();
        const skip = vi.fn();
        render(
            <Provider store={store}>
                <PostVisitProviderSurvey
                    submit={submit}
                    skip={skip}
                    visitId={'visitId'}
                />
            </Provider>,
        );

        await waitFor(() => {
            expect(Survey).toHaveBeenCalled();
            expect(mockGetLatestSurvey).toHaveBeenCalledWith('provider');
            expect(Model).toHaveBeenCalled();
            expect(mockApplyTheme).toHaveBeenCalled();
            expect(mockOnCompleteAdd).toHaveBeenCalled();
        });
    });

    it('creates a survey model', async () => {
        const submit = vi.fn();
        const skip = vi.fn();
        render(
            <Provider store={store}>
                <PostVisitProviderSurvey
                    submit={submit}
                    skip={skip}
                    visitId={'visitId'}
                />
            </Provider>,
        );

        await waitFor(() => {
            expect(Model).toHaveBeenCalled();
        });
    });

    it('applies the survey theme', async () => {
        const submit = vi.fn();
        const skip = vi.fn();
        render(
            <Provider store={store}>
                <PostVisitProviderSurvey
                    submit={submit}
                    skip={skip}
                    visitId={'visitId'}
                />
            </Provider>,
        );

        await waitFor(() => {
            expect(mockApplyTheme).toHaveBeenCalled();
        });
    });

    it('adds a complete event listener', async () => {
        const submit = vi.fn();
        const skip = vi.fn();
        render(
            <Provider store={store}>
                <PostVisitProviderSurvey
                    submit={submit}
                    skip={skip}
                    visitId={'visitId'}
                />
            </Provider>,
        );

        await waitFor(() => {
            expect(mockOnCompleteAdd).toHaveBeenCalled();
        });
    });

    it('submits the survey response', async () => {
        const submit = vi.fn();
        const skip = vi.fn();
        render(
            <Provider store={store}>
                <PostVisitProviderSurvey
                    submit={submit}
                    skip={skip}
                    visitId={'visitId'}
                />
            </Provider>,
        );

        await waitFor(() => {
            expect(mockOnCompleteAdd).toHaveBeenCalled();
        });
    });

    it('handles survey submission error', async () => {
        const submit = vi.fn();
        const skip = vi.fn();

        render(
            <Provider store={store}>
                <PostVisitProviderSurvey
                    submit={submit}
                    skip={skip}
                    visitId={'visitId'}
                />
            </Provider>,
        );

        await waitFor(() => {
            expect(mockOnCompleteAdd).toHaveBeenCalled();
            expect(submit).not.toHaveBeenCalled();
        });
    });

    it('handles survey loading error', async () => {
        const submit = vi.fn();
        const skip = vi.fn();

        render(
            <Provider store={store}>
                <PostVisitProviderSurvey
                    submit={submit}
                    skip={skip}
                    visitId={'visitId'}
                />
            </Provider>,
        );

        await waitFor(() => {
            expect(mockGetLatestSurvey).toHaveBeenCalledWith('provider');
            expect(submit).not.toHaveBeenCalled();
        });
    });

    it('handles survey skipping', async () => {
        const submit = vi.fn();
        const skip = vi.fn();
        render(
            <Provider store={store}>
                <PostVisitProviderSurvey
                    submit={submit}
                    skip={skip}
                    visitId={'visitId'}
                />
            </Provider>,
        );

        await waitFor(() => {
            expect(mockGetLatestSurvey).toHaveBeenCalledWith('provider');
            expect(submit).not.toHaveBeenCalled();
        });
    });
});
