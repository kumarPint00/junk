import * as React from 'react';
import { Survey } from 'survey-react-ui';
import { Model } from 'survey-core';
import 'survey-core/survey-core.min.css';
import surveyTheme from './SurveyTheme';
import './PostVisitProviderSurvey.css';
import { useEffect, useState } from 'react';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { PostVisitSurvey } from '@clients/VisitService/VisitInterfaces';
import { SurveyType } from '../../data/SurveyType';
import { BlisseyLogger } from '@utils/Logger';
import { Card, CardContent, CircularProgress, Typography } from '@mui/material';
import { backendFacade } from '@clients/Backend/BackendFacade';
import { useSelector } from 'react-redux';
import { Store } from '@redux/modules';

interface PostVisitProviderSurveyProps {
    submit: () => void;
    skip: () => void;
    visitId: string;
}

const PostVisitProviderSurvey: React.FC<PostVisitProviderSurveyProps> = ({
    submit,
    skip,
    visitId,
}) => {
    const [survey, setSurvey] = useState<PostVisitSurvey | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const [isComplete, setIsComplete] = useState(false);

    const userDetails = useSelector(
        (state: Store['All']) => state.user.userDetails,
    );

    useEffect(() => {
        const fetchSurveyData = async () => {
            return await visitServiceClient.getLatestSurvey(
                SurveyType.Provider,
            );
        };

        fetchSurveyData()
            .then((surveyDefinition) => setSurvey(surveyDefinition))
            .catch((error: Error) => {
                BlisseyLogger.info(
                    {
                        eventSource: 'PostVisitProviderSurvey',
                        eventType: 'render',
                    },
                    error.message,
                );
                return setErrorMessage('Failed to fetch survey definition');
            })
            .finally(() => setIsLoading(false));
    }, []);

    if (isLoading) {
        return (
            <div className="PostVisitProviderSurveyContainer">
                <div className="PostVisitProviderSurvey">
                    <div className="isLoading">
                        <CircularProgress size={20} />
                    </div>
                </div>
            </div>
        );
    }

    if (errorMessage || !survey) {
        return (
            <div className="PostVisitProviderSurveyContainer">
                <div className="PostVisitProviderSurvey">
                    <Card>
                        <CardContent>
                            <Typography align="center">
                                {errorMessage ?? 'Survey not available.'}
                            </Typography>
                        </CardContent>
                    </Card>
                </div>
            </div>
        );
    }

    const surveyDefinition = new Model(survey?.surveyDefinition);
    surveyDefinition.applyTheme(surveyTheme);
    surveyDefinition.showCompletedPage = false;
    surveyDefinition.showHeaderOnCompletePage = false;

    /**
     * Submit the survey response
     */
    surveyDefinition.onComplete.add(async (sender) => {
        setIsComplete(true);

        try {
            await backendFacade.sendSubmitSurveyResponseMimirEvent({
                visitId,
                userRole: SurveyType.Provider,
                survey: sender.data as object,
                surveyId: survey?.id,
                userId: userDetails?.id ?? '',
            });

            submit();
        } catch (error: unknown) {
            BlisseyLogger.info(
                {
                    eventSource: 'PostVisitProviderSurvey',
                    eventType: 'submit',
                },
                'Failed to submit survey response',
            );

            setErrorMessage('Failed to submit survey response');
        }
    });

    surveyDefinition.addNavigationItem({
        id: 'survey_skip',
        title: 'SKIP',
        visibleIndex: 49,
        action: () => {
            if (skip) {
                skip();
            }
        },
    });

    if (isComplete) {
        return null; // unmount survey entirely after completion
    }

    return (
        <div className="PostVisitProviderSurveyContainer">
            <div className="PostVisitProviderSurvey">
                <Survey model={surveyDefinition} />
            </div>
        </div>
    );
};

export default PostVisitProviderSurvey;
