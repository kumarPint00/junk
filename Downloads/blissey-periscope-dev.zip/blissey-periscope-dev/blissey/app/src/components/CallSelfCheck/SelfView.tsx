import * as React from 'react';
import classnames from 'classnames';
import Link from '@mui/material/Link';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import { withTranslation, WithTranslation } from 'react-i18next';

import { OTStream } from '@components/CameraDisplay/OTStream';
import { ErrorMessageConfig } from '@common/techCheckErrorMessages';
import {
    PlayerFilterControls,
    PlayerFilterProps,
} from '@components/VideoMenu/PlayerFilterControls';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './SelfView.css';

interface SelfViewProps extends WithTranslation {
    streamId: string;
    errorMessageConfig: ErrorMessageConfig | undefined;
    runTechCheck: () => void;
    playerFilterProps: PlayerFilterProps | undefined;
}

const SelfView = ({
    streamId,
    errorMessageConfig: { selfViewErrorDescription } = {},
    runTechCheck,
    playerFilterProps,
    t,
}: SelfViewProps) => {
    const ClickToReloadText = t('video-conference.selfview.clickToReload');
    const ClickToRerunText = t('video-conference.selfview.clickToRerun');

    const {
        message: errorMessage,
        action,
        type,
    } = selfViewErrorDescription || {};
    const reload = React.useCallback(() => {
        window.location.reload();
    }, []);

    let link;
    if (action === 'rerun') {
        link = (
            <span>
                <Link
                    className={classnames(styles.alertText, styles.link)}
                    component="button"
                    onClick={runTechCheck}
                >
                    {ClickToRerunText}
                </Link>
            </span>
        );
    } else if (action === 'reload') {
        link = (
            <span>
                <Link
                    className={classnames(styles.alertText, styles.link)}
                    component="button"
                    onClick={reload}
                >
                    {ClickToReloadText}
                </Link>
            </span>
        );
    }

    if (errorMessage) V2Analytics.errorEvent({ text: errorMessage, type });

    if (!playerFilterProps) {
        playerFilterProps = {
            videoBackgroundControls: {
                exists: false,
                enabled: false,
                onClick: () => {
                    console.log('Empty blur click');
                },
            },
        };
    }
    return (
        <div
            data-uitest="callselfcheck-videostream"
            className={styles.otVideoContainer}
        >
            {errorMessage && (
                <div>
                    <Card>
                        <CardContent>
                            <div>
                                <ErrorOutlineIcon />
                            </div>
                            <div>
                                <p className={styles.alertText}>
                                    {errorMessage} {link}
                                </p>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            )}
            <div className={styles.waitingRoomParent}>
                <OTStream id={streamId} />
                <div className={styles.playerControls}>
                    <PlayerFilterControls
                        videoBackgroundControls={
                            playerFilterProps.videoBackgroundControls
                        }
                    />
                </div>
            </div>
        </div>
    );
};

const _SelfView = withTranslation()(SelfView);
export { _SelfView as SelfView };
