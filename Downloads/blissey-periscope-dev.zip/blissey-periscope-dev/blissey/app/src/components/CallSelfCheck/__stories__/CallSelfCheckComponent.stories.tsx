import * as React from 'react';
import { initialState } from '@redux/modules';
import { CallSelfCheckComponent } from '../CallSelfCheckComponent';
import { getDevices, MediaDevice } from '@common/video';
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';

const { useEffect, useState } = React;

export default {
    title: 'Components/CallSelfCheck',
    component: CallSelfCheckComponent,
};

export const Default = () => {
    const [audioId, setAudioId] = useState('abcabc');
    const [videoId, setVideoId] = useState('');
    const [audioDevices, setAudioDevices] = useState([] as MediaDevice[]);
    const [videoDevices, setVideoDevices] = useState([] as MediaDevice[]);

    const updateAudioId = (event: React.ChangeEvent<HTMLSelectElement>) => {
        console.log('in set audio id', event);
        setAudioId(event.target.value);
    };
    const updateVideoId = (event: React.ChangeEvent<HTMLSelectElement>) => {
        console.log('in set video id', event);
        setVideoId(event.target.value);
    };
    const runTechCheck = () => {
        console.log('in run tech check');
    };
    const toggleBlurEnabled = () => {
        console.log('in toggle blur enabled');
    };

    useEffect(() => {
        const init = async () => {
            const { videoDevices, audioDevices } = await getDevices();
            setAudioDevices(audioDevices);
            setVideoDevices(videoDevices);
        };
        void init();
    }, []);

    return (
        <CallSelfCheckComponent
            disabled={false}
            visitId={'visitId'}
            userDetails={initialState.user.userDetails}
            isTestVisit={false}
            audioDeviceId={audioId}
            videoDeviceId={videoId}
            videoDevices={videoDevices}
            audioDevices={audioDevices}
            selfViewId={'test'}
            onAudioChange={updateAudioId}
            onCameraChange={updateVideoId}
            health={initialState.health}
            runTechCheck={runTechCheck}
            healthInfo={{
                healthCheckStatus: HealthCheckStatus.Unknown,
            }}
            lostConnection={false}
            toggleBlur={toggleBlurEnabled}
            isBlurEnabled={false}
        />
    );
};
