export interface CallSelfCheckComponentProps {
    disabled: boolean;
    selfViewId: string;
    lostConnection: boolean;
    runTechCheck: () => void;
    onAudioChange: (event: SelectChangeEvent<string>) => void;
    onCameraChange: (event: SelectChangeEvent<string>) => void;
    toggleBlur: () => void;
}
