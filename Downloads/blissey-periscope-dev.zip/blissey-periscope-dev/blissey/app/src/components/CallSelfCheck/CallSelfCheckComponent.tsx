import * as React from 'react';
import * as Redux from 'react-redux';

import { CallSelfCheckComponentProps } from './CallSelfCheckComponentInterfaces';
import { DeviceSelectionComponent } from '@components/DeviceSelection/DeviceSelectionComponent';
import { UserDetails } from '@dexcare/circus-saturn';
import { Store } from '@redux/modules';
import { MediaDevice } from '@common/video';
import {
    isHealthCheckRunning,
    TState as HealthState,
} from '@redux/modules/health';
import { SelfView } from './SelfView';
import { getHealthInfo } from '@redux/selectors/getHealthInfo';
import { HealthInfo } from '@common/ConnectionTest/HealthInfo';
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';
import { getErrorMessage } from '@common/techCheckErrorMessages';
import { PlayerFilterProps } from '@components/VideoMenu/PlayerFilterControls';
import { getArrayFeatureFlag, FeatureFlags } from '@utils/FeatureFlags';
import { isSupportedBrowser } from '@utils/BrowserCheck';
import { isProvider } from '@dexcare/circus-saturn';

import * as styles from './CallSelfCheckComponentStyles.css';

interface StateProps {
    visitId: string;
    userDetails: UserDetails;
    isTestVisit?: boolean;
    audioDeviceId: string;
    videoDeviceId: string;
    health: HealthState;
    healthInfo: HealthInfo;
    videoDevices: MediaDevice[];
    audioDevices: MediaDevice[];
    isBlurEnabled: boolean;
}

export type Props = StateProps & CallSelfCheckComponentProps;
const mapStateToProps = (state: Store['All']): StateProps => {
    const {
        user: { userDetails },
        postconsult: { visitId, isTestVisit },
        health,
    } = state;

    return {
        userDetails,
        visitId,
        isTestVisit,
        healthInfo: getHealthInfo(health),
        health,
        isBlurEnabled: state.video.isBlurEnabled,
        ...state.usersettings,
    };
};

export class CallSelfCheckComponent extends React.PureComponent<Props> {
    constructor(props: Props) {
        super(props);
    }

    public render() {
        const {
            videoDeviceId,
            audioDeviceId,
            videoDevices = [],
            audioDevices = [],
            healthInfo: { healthCheckStatus = HealthCheckStatus.Unknown } = {},
            health: { mediaPermissionStatus, healthCheckProgress },
            health,
            disabled,
            selfViewId,
            lostConnection,
            runTechCheck,
            onCameraChange,
            onAudioChange,
            isBlurEnabled,
            userDetails,
        } = this.props;

        const deviceSelectionDisabled =
            disabled ||
            mediaPermissionStatus === 'denied' ||
            isHealthCheckRunning(healthCheckProgress);
        let errorMessageConfig;
        if (
            !isHealthCheckRunning(healthCheckProgress) &&
            healthCheckStatus === HealthCheckStatus.Unhealthy
        ) {
            errorMessageConfig = getErrorMessage(health, lostConnection);
        }

        const showBlurFeatureFlag = getArrayFeatureFlag(
            FeatureFlags.showBlurOption,
        );

        // default to not showing
        let showBlurBackgroundButton = false;

        if (showBlurFeatureFlag) {
            // based on browser, browser version, provider, patient hide or show the blur option
            const { supportedBrowser, providerAvailable, patientAvailable } =
                isSupportedBrowser(showBlurFeatureFlag);

            if (supportedBrowser) {
                if (userDetails) {
                    if (isProvider(userDetails) && providerAvailable) {
                        showBlurBackgroundButton = true;
                    }
                    if (!isProvider(userDetails) && patientAvailable) {
                        showBlurBackgroundButton = true;
                    }
                }
            }
        }

        const playerFilterProps: PlayerFilterProps = {
            videoBackgroundControls: {
                exists: showBlurBackgroundButton,
                enabled: isBlurEnabled,
                onClick: this.props.toggleBlur,
            },
        };

        return (
            <div className={styles.videoWrapper}>
                <SelfView
                    runTechCheck={runTechCheck}
                    streamId={selfViewId}
                    errorMessageConfig={errorMessageConfig}
                    playerFilterProps={playerFilterProps}
                />
                <div className={styles.deviceSelectionContainer}>
                    <DeviceSelectionComponent
                        onCameraChange={onCameraChange}
                        selectedCamera={videoDeviceId}
                        selectedAudio={audioDeviceId}
                        videoDevices={videoDevices}
                        onAudioChange={onAudioChange}
                        audioDevices={audioDevices}
                        disabled={deviceSelectionDisabled}
                    />
                </div>
            </div>
        );
    }
}

export default Redux.connect<
    StateProps,
    Record<string, never>,
    CallSelfCheckComponentProps
>(mapStateToProps)(CallSelfCheckComponent);
