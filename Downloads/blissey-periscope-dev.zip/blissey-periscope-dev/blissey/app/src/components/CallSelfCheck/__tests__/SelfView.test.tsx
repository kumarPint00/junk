import * as React from 'react';
import { render } from '@testing-library/react';
import { ErrorMessageConfig } from '@common/techCheckErrorMessages';

import { SelfView } from '../SelfView';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';

const mockStreamId = 'streamId';
const playerFilterProps = {
    videoBackgroundControls: {
        exists: false,
        enabled: false,
        onClick: () => {
            /* empty */
        },
    },
};
const mockMediaAccessDeniedConfig: ErrorMessageConfig = {
    techCheckDescription:
        'waiting-room.tech-check.errors.mediaPermissionIssueMessage',
    techCheckHeader:
        'waiting-room.tech-check.errors.mediaPermissionIssueHeader',
    selfViewErrorDescription: {
        message:
            'waiting-room.tech-check.errors.mediaPermissionIssueDescription',
        action: 'reload',
        type: 'media access',
    },
};
const mockNetworkErrorConfig: ErrorMessageConfig = {
    techCheckDescription: 'waiting-room.tech-check.errors.networkIssueMessage',
    techCheckHeader: 'waiting-room.tech-check.errors.connectionIssueHeader',
    selfViewErrorDescription: {
        message: 'waiting-room.tech-check.errors.networkIssueDescription',
        action: 'rerun',
        type: 'network',
    },
};

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { errorEvent: vi.fn() },
}));

describe('<SelfView />', () => {
    it('renders', () => {
        const { container } = render(
            <SelfView
                runTechCheck={vi.fn()}
                streamId={mockStreamId}
                errorMessageConfig={{}}
                playerFilterProps={playerFilterProps}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).not.toHaveBeenCalled();
    });

    it('renders when mediaPermission has been denied', () => {
        const { container } = render(
            <SelfView
                runTechCheck={vi.fn()}
                streamId={mockStreamId}
                errorMessageConfig={mockMediaAccessDeniedConfig}
                playerFilterProps={playerFilterProps}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: mockMediaAccessDeniedConfig.selfViewErrorDescription?.message,
            type: mockMediaAccessDeniedConfig.selfViewErrorDescription?.type,
        });
    });

    it('renders with an error that prompts a tech check rerun', () => {
        const { container } = render(
            <SelfView
                runTechCheck={vi.fn()}
                streamId={mockStreamId}
                errorMessageConfig={mockNetworkErrorConfig}
                playerFilterProps={playerFilterProps}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: mockNetworkErrorConfig.selfViewErrorDescription?.message,
            type: mockNetworkErrorConfig.selfViewErrorDescription?.type,
        });
    });
});
