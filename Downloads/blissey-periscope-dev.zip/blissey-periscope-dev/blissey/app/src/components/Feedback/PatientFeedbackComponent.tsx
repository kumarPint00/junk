import * as React from 'react';
import Link from '@mui/material/Link';
import Card from '@mui/material/Card';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import { withTranslation, WithTranslation } from 'react-i18next';

import { FeedbackQuestion } from '../../clients/Feedback/FeedbackQuestion';
import { FeedbackQuestionType } from '../../clients/Feedback/FeedbackQuestionType';
import { config } from '@dexcare/circus-jupiter';
import { getDuration } from '@utils/callDuration';

import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './PatientFeedbackComponent.css';
import { Configuration } from 'types/configuration';

export interface PatientFeedbackComponentProps extends WithTranslation {
    submit(feedback: FeedbackQuestion[], skip?: boolean): void;
    visitId: string;
    providerId?: string | null;
    userId: string;
    callStartTime: number | null;
    callEndTime: number | null;
}

export interface PatientFeedbackComponentState {
    feedbackRecommend: string | number;
    feedbackText: string;
    followUp: string;
    extraSurvey1Answer?: string;
    extraSurvey2Answer?: number | string;
}

class PatientFeedbackComponent extends React.Component<
    PatientFeedbackComponentProps,
    PatientFeedbackComponentState
> {
    public maxTextLength = 250;

    public titleText = this.props.t('feedback.patient.title');
    public instructionText = this.props.t('feedback.patient.instructions');
    public feedbackText = this.props.t('feedback.patient.feedbackPrompt');
    public contactText = this.props.t('feedback.patient.contactPrompt');
    public contactYesText = this.props.t('feedback.patient.contact_yes');
    public contactNoText = this.props.t('feedback.patient.contact_no');
    public surveyScaleMinimumText = this.props.t(
        'feedback.patient.surveyScaleMinimum',
    );
    public surveyScaleMaximumText = this.props.t(
        'feedback.patient.surveyScaleMaximum',
    );
    public subText = (config as Configuration).getConfig().feedbackText
        ?.subText;
    public feedbackSubmitText = this.props.t('feedback.patient.submit');
    public feedbackSkipText = this.props.t('feedback.patient.skip');
    public feedbackPlaceholder = this.props.t(
        'feedback.patient.recommendPrompt',
    );

    public extraPatientSurvey1 = getFeatureFlag(
        FeatureFlags.extraPatientSurvey1,
    );
    public extraPatientSurvey2 = getFeatureFlag(
        FeatureFlags.extraPatientSurvey2,
    );
    public extraSurveyQuestion1 = this.props.t(
        'feedback.patient.extraSurvey1.question',
    );
    public extraSurveyAnswers1: Record<number, string> = this.props.t(
        'feedback.patient.extraSurvey1.answers',
        { returnObjects: true },
    ) as unknown as Record<number, string>;
    public extraSurveyQuestion2 = this.props.t(
        'feedback.patient.extraSurvey2.question',
    );
    public extraSurveyAnswers2: Record<number, string> = this.props.t(
        'feedback.patient.extraSurvey2.answers',
        { returnObjects: true },
    ) as unknown as Record<number, string>;
    public extraSurveyPlaceholder1 = this.props.t(
        'feedback.patient.extraSurvey1.placeholder',
    );
    public extraSurveyPlaceholder2 = this.props.t(
        'feedback.patient.extraSurvey2.placeholder',
    );
    public suppressPatientSurvey = getFeatureFlag(
        FeatureFlags.suppressPatientSurvey,
    );

    constructor(props: PatientFeedbackComponentProps) {
        super(props);

        this.state = {
            feedbackRecommend: '',
            feedbackText: '',
            followUp: '',
            extraSurvey1Answer: '',
            extraSurvey2Answer: '',
        };
    }

    public submit = (skip?: boolean) => {
        this.props.submit(
            [
                {
                    id: 'rating',
                    text: this.instructionText,
                    type: FeedbackQuestionType.Number,
                    answers: [
                        {
                            id: 'ratingAnswer',
                            type: FeedbackQuestionType.Number,
                            value: this.state.feedbackRecommend,
                            text: '',
                        },
                    ],
                },
                {
                    id: 'feedback',
                    text: this.feedbackText,
                    type: FeedbackQuestionType.Text,
                    answers: [
                        {
                            id: 'feedbackAnswer',
                            type: FeedbackQuestionType.Text,
                            value: this.state.feedbackText,
                            text: '',
                        },
                    ],
                },
                {
                    id: 'extraSurvey1',
                    text: this.extraSurveyQuestion1,
                    type: FeedbackQuestionType.Text,
                    answers: [
                        {
                            id: 'extraSurveyAnswer1',
                            type: FeedbackQuestionType.Text,
                            value: this.state.extraSurvey1Answer,
                            text: '',
                        },
                    ],
                },
                {
                    id: 'extraSurvey2',
                    text: this.extraSurveyQuestion2,
                    type: FeedbackQuestionType.Number,
                    answers: [
                        {
                            id: 'extraSurveyAnswer2',
                            type: FeedbackQuestionType.Number,
                            value: this.state.extraSurvey2Answer,
                            text: '',
                        },
                    ],
                },
                ...((this.contactText && [
                    {
                        id: 'followUp',
                        text: this.contactText,
                        type: FeedbackQuestionType.Boolean,
                        answers: [
                            {
                                id: 'followUpAnswer',
                                type: FeedbackQuestionType.Boolean,
                                value: this.state.followUp === 'yes',
                                text: '',
                            },
                        ],
                    },
                ]) ||
                    []),
            ],
            skip === true,
        );
    };

    public submitButtonClick = () => {
        const { visitId } = this.props;
        V2Analytics.interactionEvent({
            eventName: 'nps_submit',
            rating: this.state.feedbackRecommend,
            contact_us: this.state.followUp,
            visit_id: visitId,
            provider_id: this.props.providerId,
            feedbackText: this.state.feedbackText,
            extraSurvey1Answer: this.state.extraSurvey1Answer,
            extraSurvey2Answer: this.state.extraSurvey2Answer,
        });

        this.submit();
    };

    public skipButtonClick = () => {
        const { callStartTime, callEndTime, visitId } = this.props;
        V2Analytics.interactionEvent({
            eventName: 'nps_skip',
            visit_id: visitId,
            duration: getDuration(callStartTime, callEndTime),
        });

        this.submit(true);
    };

    public openMenuClick = (menu: string) => {
        V2Analytics.interactionEvent({
            eventName: 'open_menu',
            menu_type: menu,
        });
    };

    public feedbackRecommendChange = (
        evt: React.ChangeEvent<HTMLInputElement>,
    ) => {
        V2Analytics.interactionEvent({
            eventName: 'click_option',
            menu_type: 'nps_rating',
            menu_item: evt.target.value,
        });
        this.setState({
            feedbackRecommend: evt.target.value,
        });
    };

    public feedbackTextChange = (evt: React.ChangeEvent<HTMLInputElement>) => {
        this.setState({
            feedbackText: evt.target.value,
        });
    };

    public followUpChange = (evt: React.ChangeEvent<HTMLInputElement>) => {
        this.setState({
            followUp: evt.target.value,
        });
    };

    public extraSurvey1AnswerChange = (
        evt: React.ChangeEvent<HTMLInputElement>,
    ) => {
        V2Analytics.interactionEvent({
            eventName: 'click_option',
            menu_type: 'nps_survey_1',
            menu_item: evt.target.value,
        });
        this.setState({
            extraSurvey1Answer: evt.target.value,
        });
    };

    public extraSurvey2AnswerChange = (
        evt: React.ChangeEvent<HTMLInputElement>,
    ) => {
        V2Analytics.interactionEvent({
            eventName: 'click_option',
            menu_type: 'nps_survey_2',
            menu_item: evt.target.value,
        });
        this.setState({
            extraSurvey2Answer: evt.target.value,
        });
    };

    public render() {
        if (this.suppressPatientSurvey) {
            this.skipButtonClick();
        }

        const charsRemaining = `${this.state.feedbackText.length}/${this.maxTextLength}`;
        const feedbackRecommendMenuItems = [];
        const extraSurvey1MenuItems = [];
        const extraSurvey2MenuItems = [];
        for (let i = 9; i >= 1; i--) {
            feedbackRecommendMenuItems.push(
                <MenuItem value={i} key={`feedbackRecommend-${i}`}>
                    {i}
                </MenuItem>,
            );
        }
        feedbackRecommendMenuItems.push(
            <MenuItem value={0} key={'feedbackRecommend-0'}>
                0 - {this.surveyScaleMinimumText}
            </MenuItem>,
        );
        feedbackRecommendMenuItems.unshift(
            <MenuItem value={10} key={'feedbackRecommend-10'}>
                10 - {this.surveyScaleMaximumText}
            </MenuItem>,
        );
        if (this.extraPatientSurvey1) {
            for (let i = 1; i <= 5; i++) {
                extraSurvey1MenuItems.push(
                    <MenuItem
                        value={this.extraSurveyAnswers1[i]}
                        key={`extra-survey-1-${i}`}
                    >
                        {this.extraSurveyAnswers1[i]}
                    </MenuItem>,
                );
            }
        }
        if (this.extraPatientSurvey2) {
            for (let i = 5; i >= 1; i--) {
                extraSurvey2MenuItems.push(
                    <MenuItem value={i} key={`extra-survey-2-${i}`}>
                        {this.extraSurveyAnswers2[i]}
                    </MenuItem>,
                );
            }
        }

        return (
            <Card className={styles.container}>
                <div className={styles.feedback}>
                    <span className={styles.spanHeader}>{this.titleText}</span>
                    {this.subText && (
                        <p className={styles.optionalFieldsLabel}>
                            {this.subText}
                        </p>
                    )}
                    <p className={styles.instructionText}>
                        {this.instructionText}
                    </p>
                    <FormControl variant="standard">
                        <InputLabel id="feedback-select-label">
                            {this.feedbackPlaceholder}
                        </InputLabel>
                        <Select
                            labelId="feedback-select-label"
                            id="feedback-select"
                            classes={{ icon: styles.selectIcon }}
                            value={this.state.feedbackRecommend}
                            onChange={this.feedbackRecommendChange}
                            fullWidth={true}
                            label={this.feedbackPlaceholder}
                            placeholder={this.feedbackPlaceholder}
                            MenuProps={{
                                anchorOrigin: {
                                    vertical: 'bottom',
                                    horizontal: 'left',
                                },
                                transformOrigin: {
                                    vertical: 'top',
                                    horizontal: 'left',
                                },
                            }}
                            data-ui-test="recommend-select"
                            onOpen={() => this.openMenuClick('nps rating')}
                            inputProps={{
                                'data-uitest': 'recommend-select-option',
                            }}
                            variant="standard"
                        >
                            <MenuItem value="">
                                <em>None</em>
                            </MenuItem>
                            {feedbackRecommendMenuItems}
                        </Select>
                    </FormControl>
                    <p className={styles.instructionText}>
                        {this.feedbackText}
                    </p>
                    <TextField
                        value={this.state.feedbackText}
                        onChange={this.feedbackTextChange}
                        fullWidth
                        multiline
                        margin="none"
                        rows={3}
                        label={''}
                        placeholder={''}
                        FormHelperTextProps={{
                            classes: { root: styles.helper },
                        }}
                        helperText={charsRemaining}
                        inputProps={{
                            maxLength: `${this.maxTextLength}`,
                            'data-uitest': 'feedback-text',
                        }}
                        variant="standard"
                    />
                    {this.extraPatientSurvey1 && (
                        <>
                            <p className={styles.instructionText}>
                                {this.extraSurveyQuestion1}
                            </p>
                            <FormControl variant="standard">
                                <InputLabel id="extra-survey1-label">
                                    {this.extraSurveyPlaceholder1}
                                </InputLabel>
                                <Select
                                    labelId="extra-survey1-select-label"
                                    id="extra-survey1-select"
                                    classes={{ icon: styles.selectIcon }}
                                    value={this.state.extraSurvey1Answer}
                                    onChange={this.extraSurvey1AnswerChange}
                                    fullWidth={true}
                                    label={this.extraSurveyPlaceholder1}
                                    placeholder={this.extraSurveyPlaceholder1}
                                    MenuProps={{
                                        anchorOrigin: {
                                            vertical: 'bottom',
                                            horizontal: 'left',
                                        },
                                        transformOrigin: {
                                            vertical: 'top',
                                            horizontal: 'left',
                                        },
                                    }}
                                    data-ui-test="extra-survey1-select"
                                    onOpen={() =>
                                        this.openMenuClick('nps survey 1')
                                    }
                                    inputProps={{
                                        'data-uitest':
                                            'extra-survey1-select-option',
                                    }}
                                    variant="standard"
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    {extraSurvey1MenuItems}
                                </Select>
                            </FormControl>
                        </>
                    )}
                    {this.extraPatientSurvey2 && (
                        <>
                            <p className={styles.instructionText}>
                                {this.extraSurveyQuestion2}
                            </p>
                            <FormControl variant="standard">
                                <InputLabel id="extra-survey2-label">
                                    {this.extraSurveyPlaceholder2}
                                </InputLabel>
                                <Select
                                    labelId="extra-survey2-select-label"
                                    id="extra-survey2-select"
                                    classes={{ icon: styles.selectIcon }}
                                    value={this.state.extraSurvey2Answer}
                                    onChange={this.extraSurvey2AnswerChange}
                                    fullWidth={true}
                                    label={this.extraSurveyPlaceholder2}
                                    placeholder={this.extraSurveyPlaceholder2}
                                    MenuProps={{
                                        anchorOrigin: {
                                            vertical: 'bottom',
                                            horizontal: 'left',
                                        },
                                        transformOrigin: {
                                            vertical: 'top',
                                            horizontal: 'left',
                                        },
                                    }}
                                    data-ui-test="extra-survey2-select"
                                    onOpen={() =>
                                        this.openMenuClick('nps survey 2')
                                    }
                                    inputProps={{
                                        'data-uitest':
                                            'extra-survey2-select-option',
                                    }}
                                    variant="standard"
                                >
                                    <MenuItem value={0}>
                                        <em>None</em>
                                    </MenuItem>
                                    {extraSurvey2MenuItems}
                                </Select>
                            </FormControl>
                        </>
                    )}
                    {this.contactText && (
                        <>
                            <p className={styles.instructionText}>
                                {this.contactText}
                            </p>
                            <RadioGroup
                                value={this.state.followUp}
                                onChange={this.followUpChange}
                            >
                                <FormControlLabel
                                    value="yes"
                                    control={
                                        <Radio
                                            inputProps={
                                                {
                                                    'data-uitest': 'yes-radio',
                                                } as React.InputHTMLAttributes<HTMLInputElement>
                                            }
                                        />
                                    }
                                    label={this.contactYesText}
                                />
                                <FormControlLabel
                                    value="no"
                                    control={
                                        <Radio
                                            inputProps={
                                                {
                                                    'data-uitest': 'no-radio',
                                                } as React.InputHTMLAttributes<HTMLInputElement>
                                            }
                                        />
                                    }
                                    label={this.contactNoText}
                                />
                            </RadioGroup>
                        </>
                    )}
                    <div className={styles.divCentered}>
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={this.submitButtonClick}
                            data-uitest="submit-button"
                            className={styles.button}
                            classes={{ root: styles.button }}
                        >
                            {this.feedbackSubmitText}
                        </Button>
                    </div>
                    <Link
                        component="button"
                        role="link"
                        underline="always"
                        data-uitest="skip-button"
                        onClick={this.skipButtonClick}
                        className={styles.skipLink}
                    >
                        {this.feedbackSkipText.toLocaleUpperCase()}
                    </Link>
                </div>
            </Card>
        );
    }
}

const _PatientFeedbackComponent = withTranslation()(PatientFeedbackComponent);
export { _PatientFeedbackComponent as PatientFeedbackComponent };
