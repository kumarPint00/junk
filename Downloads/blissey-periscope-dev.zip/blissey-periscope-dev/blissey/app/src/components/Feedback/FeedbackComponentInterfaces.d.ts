import { FeedbackQuestion } from '@clients/Feedback/FeedbackQuestion';

export class FeedbackComponentProps {
    feedbackQuestions: FeedbackQuestion[];
    onAnswerChange: (...rest) => unknown;
}
