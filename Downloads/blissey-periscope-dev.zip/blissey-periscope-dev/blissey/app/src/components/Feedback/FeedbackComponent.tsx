import * as React from 'react';
import Card from '@mui/material/Card';
import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';

import { FeedbackQuestionType } from '@clients/Feedback/FeedbackQuestionType';
import { FeedbackComponentProps } from './FeedbackComponentInterfaces';
import { StarRating } from './StarRating';

import * as styles from './FeedbackComponent.css';

export function FeedbackComponent(props: FeedbackComponentProps): JSX.Element {
    const components = [];
    let count = 0;
    for (const feedbackQuestion of props.feedbackQuestions) {
        let nextComponent: React.ReactNode;
        const engagement = (e: Event) => {
            const fieldValue =
                e?.target && !(e.target as HTMLInputElement).value
                    ? 'skip'
                    : 'complete';
            const formName = 'Visit Questionnaire';

            Analytics.sendEvent({
                eventAction: 'formEngagement',
                formEngagement: {
                    formName,
                    fieldName: feedbackQuestion.id,
                    fieldValue,
                },
            });

            V2Analytics.interactionEvent({
                eventName: 'form_field_engage',
                form_field: feedbackQuestion.id,
                form_name: formName.toLowerCase(),
            });
        };
        const engagementWithClick = (e: Event, ...args: unknown[]) => {
            engagement(e);
            props.onAnswerChange(e, ...args);
        };
        switch (feedbackQuestion.type) {
            case FeedbackQuestionType.Number:
                nextComponent = (
                    <div>
                        <p className={styles.questionText}>
                            {feedbackQuestion.text}
                        </p>
                        <StarRating
                            onClick={engagementWithClick}
                            questionId={feedbackQuestion.id}
                            answerId={feedbackQuestion.answers[0].id}
                        />
                    </div>
                );
                break;
            default:
                nextComponent = null;
        }
        components.push(
            <div
                className={styles.questionContainer}
                key={'FeedbackComponent-' + count++}
            >
                {nextComponent}
            </div>,
        );
    }

    return (
        <Card className={styles.feedbackCard}>
            <div className={styles.feedback}>{components}</div>
        </Card>
    );
}
