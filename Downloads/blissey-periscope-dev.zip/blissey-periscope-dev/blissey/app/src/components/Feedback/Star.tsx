import * as React from 'react';
import StarIcon from '@mui/icons-material/Star';
import StarBorder from '@mui/icons-material/StarBorder';

import * as styles from './Star.css';

export interface Props {
    rating: number;
    value: number;
    dataUiTest: string;
    questionId: string;
    answerId: string;
    onRate: (value: number) => void;
    onClick: (...args: unknown[]) => void;
    onHover: (newRating: number) => void;
    endHover: () => void;
}

export class Star extends React.Component<Props> {
    public render() {
        const { rating, value, dataUiTest } = this.props;
        const filledInStar = (
            <StarIcon
                data-uitest={dataUiTest}
                className={styles.star}
                onClick={this.handleClick}
                onMouseEnter={this.onMouseEnter}
                onMouseLeave={this.onMouseLeave}
            />
        );
        const emptyStar = (
            <StarBorder
                data-uitest={dataUiTest}
                className={styles.star}
                onClick={this.handleClick}
                onMouseEnter={this.onMouseEnter}
                onMouseLeave={this.onMouseLeave}
            />
        );
        if (rating >= value) {
            return filledInStar;
        } else {
            return emptyStar;
        }
    }

    private handleClick = (): void => {
        this.props.onRate(this.props.value);
        this.props.onClick(
            this.props.value,
            this.props.questionId,
            this.props.answerId,
        );
    };

    private onMouseEnter = (): void => {
        this.props.onHover(this.props.value);
    };

    private onMouseLeave = (): void => {
        this.props.endHover();
    };
}
