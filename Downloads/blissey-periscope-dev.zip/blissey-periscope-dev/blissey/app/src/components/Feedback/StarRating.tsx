import * as React from 'react';

import { Star } from './Star';

import * as styles from './StarRating.css';

interface Props {
    questionId: string;
    answerId: string;
    onClick: (e: Event, ...args: unknown[]) => void;
}

interface State {
    hovering: boolean;
    hoverRating: number;
    rating: number;
}

export class StarRating extends React.Component<Props, State> {
    constructor(props: Props) {
        super(props);

        this.state = {
            rating: 0,
            hovering: false,
            hoverRating: 0,
        };
    }

    public render() {
        let rating: number;
        if (this.state.hovering) {
            rating = this.state.hoverRating;
        } else {
            rating = this.state.rating;
        }

        const starPrefix: string =
            this.props.questionId + '-' + this.props.answerId + '-starrating-';
        return (
            <div>
                <div className={styles.starWrapper}>
                    {this.renderStar(rating, 1, starPrefix + '1')}
                    {this.renderStar(rating, 2, starPrefix + '2')}
                    {this.renderStar(rating, 3, starPrefix + '3')}
                    {this.renderStar(rating, 4, starPrefix + '4')}
                    {this.renderStar(rating, 5, starPrefix + '5')}
                </div>
            </div>
        );
    }

    private renderStar(
        rating: number,
        value: number,
        dataUiTest: string,
    ): JSX.Element {
        return (
            <Star
                dataUiTest={dataUiTest}
                rating={rating}
                value={value}
                onRate={this.onRate}
                onClick={this.props.onClick}
                questionId={this.props.questionId}
                answerId={this.props.answerId}
                onHover={this.onHover}
                endHover={this.endHover}
            />
        );
    }

    private onRate = (newRating: number): void => {
        this.setState(
            Object.assign({}, this.state, {
                hovering: false,
                rating: newRating,
            }),
        );
    };

    private onHover = (newRating: number): void => {
        this.setState(
            Object.assign({}, this.state, {
                hovering: true,
                hoverRating: newRating,
            }),
        );
    };

    private endHover = (): void => {
        this.setState(
            Object.assign({}, this.state, {
                hovering: false,
                hoverRating: 0,
            }),
        );
    };
}
