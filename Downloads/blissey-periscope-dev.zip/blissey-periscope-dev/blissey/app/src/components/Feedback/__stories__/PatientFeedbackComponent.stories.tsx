import { PatientFeedbackComponent } from '../PatientFeedbackComponent';
import { FeedbackQuestion } from '@clients/Feedback/FeedbackQuestion';

export default {
    title: 'Components/Feedback/PatientFeedbackComponent',
    component: PatientFeedbackComponent,
};

export const DefaultPatient = {
    args: {
        visitId: 'visitId',
        userId: 'userId',
        callStartTime: 3211,
        callEndTime: 4578,
        handleSubmit: (feedback: FeedbackQuestion[], skip?: boolean) => {
            console.log('submit clicked!');
            console.log('feedback: ', feedback);
            console.log('skip: ', skip);
        },
    },
};
