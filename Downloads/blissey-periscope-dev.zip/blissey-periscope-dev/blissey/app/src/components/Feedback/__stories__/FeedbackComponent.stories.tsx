import { FeedbackQuestionType } from '@clients/Feedback/FeedbackQuestionType';
import { FeedbackComponent } from '../FeedbackComponent';

const sampleProviderQuestions = [
    'rating',
    {
        id: 'rating',
        text: 'Rate Your Overall Experience',
        type: FeedbackQuestionType.Number,
        answers: [
            {
                id: 'ratingAnswer',
                value: 0,
                type: FeedbackQuestionType.Number,
            },
        ],
    },
];

export default {
    title: 'Components/Feedback/FeedbackComponent',
    component: FeedbackComponent,
};

export const DefaultProvider = {
    name: 'Default - provider',
    args: {
        feedbackQuestions: sampleProviderQuestions,
        onAnswerChange: () => {
            console.log('Changed!');
        },
    },
};
