import * as React from 'react';

import * as styles from './Hangup.css';

export interface HangupProps {
    caregiverPortalLink: string;
}

export function Hangup(props: HangupProps) {
    return (
        <div>
            <div className={styles.contentBox}>
                <div className={styles.instructions}>
                    <div data-uitest="hangup-commonmessage">
                        Thank you. This video visit has concluded.
                    </div>
                    <div>
                        <div data-uitest="hangup-providermessage">
                            Please close the window and return to the
                        </div>
                        <a
                            data-uitest="hangup-portallink"
                            href={props.caregiverPortalLink}
                            className={styles.link}
                        >
                            Caregiver Portal
                        </a>
                        .
                    </div>
                </div>
            </div>
        </div>
    );
}
