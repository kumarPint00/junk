import * as React from 'react';
import { Button } from '@components/Button';

type ChatButtonProps = React.PropsWithChildren<{
    onClick: React.MouseEventHandler<HTMLButtonElement>;
}>;

const styles = {
    root: {
        width: {
            xs: '220px',
            sm: '300px',
        },
        height: {
            xs: '50px',
        },
        whiteSpace: {
            xs: 'break-spaces',
        },
        lineHeight: {
            xs: '20px',
        },
        boxShadow: 'none',
    },
};

export const ChatButton: React.FunctionComponent<ChatButtonProps> = ({
    onClick,
    children,
}) => {
    return (
        <Button onClick={onClick} uiTestTag="waitingroom-chat" sx={styles.root}>
            {children}
        </Button>
    );
};
