import * as React from 'react';
import { Logger, LogManager, config } from '@dexcare/circus-jupiter';
import { Link, SelectChangeEvent } from '@mui/material';
import * as browserCheck from '@utils/BrowserCheck';
import { withTranslation } from 'react-i18next';

import { YouTubePlayer } from 'youtube-player/dist/types';
import { EstimatedWaitTime } from '@components/EstimatedWaitTime/EstimatedWaitTime';
import { InstructionVideoComponent } from './InstructionVideoComponent';
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';
import { FooterPage } from '@layout/PageLayout/FooterPage';
import { CancelVisitDialog } from './CancelVisitDialog';
import { WaitOfflineDialog } from './WaitOfflineDialog';
import {
    WaitingRoomProps,
    WaitingRoomState,
    VideoStatus,
} from './WaitingRoomInterfaces';
import { AdCard } from '@components/AdvertisementCard/AdvertisementCard';
import { getFeatureFlag, FeatureFlags } from '@utils/FeatureFlags';
import { ChatButton } from './ChatButton';
import { Publisher } from '@common/video';
import { submitDeviceChangeAnalytics } from '@services/analytics';
import { ConnectionTestComponent } from '@components/ConnectionTest/ConnectionTestComponent';
import CallSelfCheckComponent from '@components/CallSelfCheck/CallSelfCheckComponent';
import { getWaitTime } from '@utils/getWaitTime';
import { backendFacade } from '@clients/Backend/BackendFacade';
import { enableWaitOfflineButton, sleep } from '@utils/miscUtils';
import { getPantryConfig } from '@clients/Pantry/getPantryConfig';
import isEqual from 'lodash/isEqual';

import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './WaitingRoomComponent.css';
import { Configuration } from 'types/configuration';

interface TroubleshootingLinks {
    [key: string]: string;
}

class WaitingRoomComponent extends React.Component<
    WaitingRoomProps,
    WaitingRoomState
> {
    private DEFAULT_WAITING_ROOM_VIDEO_DELAY = 10000;
    private PUBLISHER_ID = 'waitingRoomSelfView';
    private selfViewPublisher: Publisher;

    private troubleshootingLinks: TroubleshootingLinks;
    private logger: Logger;
    private videoPlayer: YouTubePlayer;
    private cancelVisitButtonText: string;
    private chatButtonText: string;
    private headerText: string;
    private troubleshootingButtonText: string;
    private troubleshootingText: { __html: string };
    private waitOfflineButtonText: string;
    private waitOfflineClickText: string;
    private chatButtonCaptionText: string;
    private waitTimeIntervalId:
        | string
        | number
        | ReturnType<typeof setInterval>
        | null = null;

    constructor(props: WaitingRoomProps) {
        super(props);
        this.state = {
            cancelVisitDialogActive: false,
            videoStatus: VideoStatus.NONE,
            vimeoPlaying: true,
            patientRejoinGeneratedBy: '',
            patientRejoinMimirSent: false,
            waitOfflineDialogActive: false,
            estimatedWaitTimeSeconds: 0,
            minimumWaitTimeForWaitOffline: 600,
            waitTimeInfo: {
                estimatedWaitTimeSeconds: 0,
                estimatedWaitTimeMessage: this.props.t(
                    'waiting-room.providerSoon',
                ),
                estimateGeneratedAt: '',
                waitTimeLocalizationInfo: {
                    waitTimeMapKey: '',
                    timeMinSeconds: 0,
                    timeMaxSeconds: 0,
                    modality: '',
                },
                loading: true,
            },
            displayWaitOfflineButton: false,
            enableManuallyEnteringWaitoffline: false,
        };

        const defaultTroubleshootingMarkup = () => {
            return {
                __html: this.props.t('visit.techReconnection'),
            };
        };

        this.cancelVisitButtonText = this.props.t('visit.cancelVisit');

        this.chatButtonText = this.props.t('visit.supportCall');
        this.headerText = this.props.t('waiting-room.techGuidance');
        this.troubleshootingButtonText = this.props.t(
            'visit.techTroubleshooting',
        );

        this.chatButtonCaptionText =
            this.props.t('visit.chatButtonCaption') ?? 'Questions?';

        this.waitOfflineButtonText =
            this.props.t('wait-offline.buttonText') ?? 'Come Back Later';
        this.waitOfflineClickText =
            this.props.t('wait-offline.buttonCaption') ?? "Don't Want To Wait?";

        this.troubleshootingLinks =
            (config as Configuration).getConfig().troubleshootingLinks || {};
        this.troubleshootingText = defaultTroubleshootingMarkup();

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'WaitingRoomComponent',
                userId: this.props.userDetails.id,
                visitId: this.props.visitId,
                isTestVisit: this.props.isTestVisit,
            },
            true,
        );

        this.selfViewPublisher = new Publisher({
            id: this.PUBLISHER_ID,
            callbacks: {
                onCamDeviceChange: this.props.changeCam,
                onMicDeviceChange: this.props.changeMic,
            },
        });
    }

    public setQueued = () => {
        this.setState({ videoStatus: VideoStatus.QUEUED });
    };

    public async componentDidMount() {
        const { waitingRoomVideoDelayInMs } = this.props;
        Analytics.sendPageView({
            destinationURL: '/visit/room/anteRoom',
        });
        Analytics.sendEvent({
            eventAction: 'waitingRoomEnter',
            eventName: 'enter waiting room',
            type: 'success',
            visitId: this.props.visitId,
        });
        this.logger.info({ eventType: 'render' });
        const videoDelayTime =
            waitingRoomVideoDelayInMs || this.DEFAULT_WAITING_ROOM_VIDEO_DELAY;

        if (getFeatureFlag(FeatureFlags.waitingRoomVideo)) {
            setTimeout(this.setQueued, videoDelayTime);
        }

        const pageUrl = window.location?.href;
        const urlParams = new URLSearchParams(pageUrl?.split('?')[1]);
        const generatedBy = urlParams.get('generated_by') ?? undefined;
        if (generatedBy) {
            this.setState({
                patientRejoinGeneratedBy: generatedBy,
            });
        }

        void this.refreshWaitTime();
        this.waitTimeIntervalId = setInterval(
            () => void this.refreshWaitTime(),
            1 * 60 * 1000,
        );

        const minimumWaitTimeForWaitOffline = (await getPantryConfig())
            ?.minimumWaitTimeForWaitOffline;
        if (minimumWaitTimeForWaitOffline) {
            this.setState({ minimumWaitTimeForWaitOffline });
        }

        const enableManuallyEnteringWaitoffline = getFeatureFlag(
            FeatureFlags.enableManuallyEnteringWaitoffline,
        ) as boolean;
        this.setState({ enableManuallyEnteringWaitoffline });

        this.updateDisplayWaitOfflineButton();
    }

    public componentWillUnmount() {
        this.selfViewPublisher?.cleanup();
        clearInterval(this.waitTimeIntervalId as number | undefined);
    }

    private sendVideoAnalytics = (
        eventName: string,
        eventAction = 'click',
    ): void => {
        Analytics.sendEvent({
            eventAction,
            eventName,
            type: 'video',
        });
    };

    public componentDidUpdate(
        prevProps: WaitingRoomProps,
        prevState: WaitingRoomState,
    ) {
        if (getFeatureFlag(FeatureFlags.waitingRoomVideo)) {
            const { healthInfo, chatIsVisible } = this.props;
            const { videoStatus } = this.state;

            const healthInfoOrVideoStatusChanged =
                healthInfo !== prevProps.healthInfo ||
                videoStatus !== prevState.videoStatus;
            const isStateToStartVideo =
                videoStatus === VideoStatus.QUEUED &&
                healthInfo.healthCheckStatus === HealthCheckStatus.Healthy;

            const shouldAutoPlayVideo =
                healthInfoOrVideoStatusChanged &&
                this.props.enableInstructionVideo &&
                isStateToStartVideo;
            if (shouldAutoPlayVideo) {
                this.logger.info(
                    {
                        eventType: 'waitingRoomVideo',
                        eventName: 'auto play video',
                        details: {
                            previousVideoStatus: prevState.videoStatus,
                            currentVideoStatus: videoStatus,
                            updatedVideoStatus: 'AUTO_PLAY',
                            previousHealthCheckStatus:
                                prevProps.healthInfo.healthCheckStatus,
                            currentHealthCheckStatus:
                                healthInfo.healthCheckStatus,
                        },
                    },
                    'triggering video because health check passed and 10 seconds is up',
                );
                this.sendVideoAnalytics(
                    'virtual-waitingroom-videoroll-autoplay',
                    'appservice',
                );
                this.setState({ videoStatus: VideoStatus.PLAYING });
            }

            if (
                chatIsVisible !== prevProps.chatIsVisible &&
                chatIsVisible &&
                !this.videoIsStopped() &&
                this.videoPlayer
            ) {
                this.logger.info(
                    {
                        eventType: 'waitingRoomVideo',
                        eventName: 'new chat received',
                        eventAction: 'pauseVideo()',
                    },
                    'video auto pause due to incoming chat msg',
                );
                void this.videoPlayer.pauseVideo();
                this.setState({ videoStatus: VideoStatus.AUTO_PAUSED });
                this.setState({ vimeoPlaying: false });
            }
        }

        if (
            !this.state.patientRejoinMimirSent &&
            !!this.state.patientRejoinGeneratedBy &&
            this.props.healthInfo.healthCheckStatus ===
                HealthCheckStatus.Healthy
        ) {
            this.setState({
                patientRejoinMimirSent: true,
            });

            void backendFacade.sendPatientRejoinSuccessMimirEvent({
                visitId: this.props.visitId,
                generatedBy: this.state.patientRejoinGeneratedBy,
            });
        }

        if (
            prevProps.isTestVisit !== this.props.isTestVisit ||
            prevProps.status !== this.props.status ||
            !isEqual(prevProps.timestamps, this.props.timestamps) ||
            prevState.minimumWaitTimeForWaitOffline !==
                this.state.minimumWaitTimeForWaitOffline ||
            !isEqual(prevState.waitTimeInfo, this.state.waitTimeInfo) ||
            prevState.enableManuallyEnteringWaitoffline !==
                this.state.enableManuallyEnteringWaitoffline
        ) {
            this.updateDisplayWaitOfflineButton();
        }
    }

    public refreshWaitTime = async () => {
        this.setState((prevState) => ({
            waitTimeInfo: {
                ...prevState.waitTimeInfo,
                loading: true,
            },
        }));

        const {
            visitId,
            i18n: { language },
        } = this.props;

        const oneSecondWait = sleep(1000);
        const [waitTimeInfo] = await Promise.all([
            getWaitTime(visitId, language),
            oneSecondWait,
        ]);
        if (waitTimeInfo) {
            this.setState({
                waitTimeInfo: {
                    ...waitTimeInfo,
                    loading: false,
                },
            });
        } else {
            this.logger.error(
                { visitId, language, state: this.state, props: this.props },
                'failed to refresh wait time',
            );
        }
    };

    public openWaitOfflineDialog = (): void => {
        V2Analytics.interactionEvent({
            eventName: 'cta_click',
            text: 'come back later',
        });
        this.setState({
            waitOfflineDialogActive: true,
        });
    };

    public closeWaitOfflineDialog = (): void => {
        V2Analytics.interactionEvent({
            eventName: 'wait_offline_option',
            selection: 'wait here',
        });
        this.setState({
            waitOfflineDialogActive: false,
        });
    };

    public openCancelVisitDialog = (): void => {
        V2Analytics.interactionEvent({
            eventName: 'cta_click',
            text: 'cancel visit',
        });
        this.setState({
            cancelVisitDialogActive: true,
        });
    };

    public closeCancelVisitDialog = (): void => {
        V2Analytics.interactionEvent({
            eventName: 'cancel_vist_option',
            selection: 'keep my visit',
        });
        this.setState({
            cancelVisitDialogActive: false,
        });
        this.logger.info(
            {
                eventType: 'userAction',
                eventName: 'keepMyVisitClick',
            },
            'Keep my visit clicked',
        );
    };

    public cancelVisitHandle = (): void => {
        this.logger.info(
            {
                eventType: 'userAction',
                eventName: 'cancelVisit',
            },
            'Cancel this visit - clicked',
        );

        V2Analytics.interactionEvent({
            eventName: 'visit_cancel',
            visit_id: this.props.visitId,
        });

        this.props.cancelVisit();
    };

    private chatClickHandle = (): void => {
        Analytics.sendEvent({
            eventAction: 'click',
            eventName: 'Have questions? Chat with our clinic staff',
            type: 'button',
        });
        V2Analytics.interactionEvent({
            eventName: 'chat_engage',
            location: 'waiting room',
            visit_id: this.props.visitId,
        });

        this.props.onChatClick();
    };

    // TODO: clean up when we fully transition away from youtube
    private onVideoReady = (event: { target: YouTubePlayer }): void => {
        this.logger.info(
            {
                eventType: 'waitingRoomVideo',
                eventName: 'onVideoReady',
                eventAction: 'playVideo()',
            },
            'Video load successful, calling playVideo() on videoPlayer',
        );
        this.videoPlayer = event.target;
        void this.videoPlayer.playVideo();
    };

    private onVideoReadyVimeo = (): void => {
        this.logger.info(
            {
                eventType: 'waitingRoomVideo',
                eventName: 'onVideoReady',
                eventAction: 'playVideo()',
            },
            'Video load successful, calling playVideo() on videoPlayer, vimeo',
        );
        this.setState({ vimeoPlaying: true });
    };

    private onPlayVideo = (): void => {
        const { videoStatus } = this.state;
        if (
            videoStatus === VideoStatus.AUTO_PAUSED ||
            videoStatus === VideoStatus.USER_PAUSED
        ) {
            this.sendVideoAnalytics('virtual-waitingroom-videoroll-resume');
        } else if (
            videoStatus === VideoStatus.MINIMIZED ||
            videoStatus === VideoStatus.ENDED
        ) {
            this.sendVideoAnalytics('virtual-waitingroom-videoroll-replay');
        }
        this.logger.info(
            {
                eventType: 'waitingRoomVideo',
                eventName: 'onPlayVideo',
                details: { videoStatus: 'PLAYING' },
            },
            'Video state set to playing',
        );
        this.setState({ videoStatus: VideoStatus.PLAYING });
    };

    private onPlayVideoVimeo = (): void => {
        const { videoStatus } = this.state;
        if (
            videoStatus === VideoStatus.AUTO_PAUSED ||
            videoStatus === VideoStatus.USER_PAUSED
        ) {
            this.sendVideoAnalytics('virtual-waitingroom-videoroll-resume');
        } else if (
            videoStatus === VideoStatus.MINIMIZED ||
            videoStatus === VideoStatus.ENDED
        ) {
            this.sendVideoAnalytics('virtual-waitingroom-videoroll-replay');
        }
        this.logger.info(
            {
                eventType: 'waitingRoomVideo',
                eventName: 'onPlayVideo',
                details: { videoStatus: 'PLAYING' },
            },
            'Video state set to playing',
        );
        this.setState({ videoStatus: VideoStatus.PLAYING });
        this.setState({ vimeoPlaying: true });
    };

    private onVideoError = (event: { data: number }): void => {
        this.logger.info(
            {
                eventType: 'waitingRoomVideo',
                eventName: 'onVideoError',
                details: { errorCode: event.data, videoStatus: 'ERROR' },
            },
            'Video load error.  Video will not be shown',
        );
        this.setState({ videoStatus: VideoStatus.ERROR });
    };

    private onVideoErrorVimeo = (error: Error): void => {
        this.logger.error(
            {
                eventType: 'waitingRoomVideo',
                eventName: 'onVideoError',
                details: {
                    msg: 'vimeo video unable to be played',
                    error: error?.message,
                    videoStatus: 'ERROR',
                },
            },
            'Video load error.  Video will not be shown',
        );
        // Safari restricts autoplay for unmuted videos, causing a NotAllowedError.
        // To keep the video player so the user can still watch it by manually clicking the play button, we avoid setting an error state.
        if (error?.name !== 'NotAllowedError') {
            this.setState({ videoStatus: VideoStatus.ERROR });
        }
        this.setState({ vimeoPlaying: false });
    };

    private onEndVideo = (): void => {
        if (this.videoPlayer) {
            this.logger.info(
                {
                    eventType: 'waitingRoomVideo',
                    eventName: 'onEndVideo',
                    eventAction: 'stopVideo()',
                    details: { videoStatus: 'ENDED_OR_MINIMIZED' },
                },
                'Video is no longer playing',
            );
            if (this.state.videoStatus !== VideoStatus.MINIMIZED) {
                this.sendVideoAnalytics(
                    'virtual-waitingroom-videoroll-complete',
                    'appservice',
                );
            }
            void this.videoPlayer.stopVideo();
            this.setState({ videoStatus: VideoStatus.ENDED });
            this.setState({ vimeoPlaying: false });
        }
    };

    private onEndVideoVimeo = (): void => {
        this.logger.info(
            {
                eventType: 'waitingRoomVideo',
                eventName: 'onEndVideo',
                eventAction: 'stopVideo()',
                details: { videoStatus: 'ENDED_OR_MINIMIZED' },
            },
            'Video is no longer playing',
        );
        if (this.state.videoStatus !== VideoStatus.MINIMIZED) {
            this.sendVideoAnalytics(
                'virtual-waitingroom-videoroll-complete',
                'appservice',
            );
        }
        this.setState({ videoStatus: VideoStatus.ENDED });
        this.setState({ vimeoPlaying: false });
    };

    private onPauseVideo = (): void => {
        if (this.state.videoStatus !== VideoStatus.AUTO_PAUSED) {
            this.sendVideoAnalytics('virtual-waitingroom-videoroll-pause');
            this.setState({ videoStatus: VideoStatus.USER_PAUSED });
        }
    };

    private onPauseVideoVimeo = (): void => {
        if (this.state.videoStatus === VideoStatus.MINIMIZED) {
            return;
        }
        if (this.state.videoStatus !== VideoStatus.AUTO_PAUSED) {
            this.setState({ videoStatus: VideoStatus.USER_PAUSED });
        }
        this.sendVideoAnalytics('virtual-waitingroom-videoroll-pause');
        this.setState({ vimeoPlaying: false });
    };

    private onExitVideo = (): void => {
        this.sendVideoAnalytics('virtual-waitingroom-videoroll-close');
        void this.videoPlayer.stopVideo();
        this.setState({ videoStatus: VideoStatus.MINIMIZED });
    };

    private onExitVideoVimeo = (): void => {
        this.sendVideoAnalytics('virtual-waitingroom-videoroll-close');
        this.setState({ videoStatus: VideoStatus.MINIMIZED });
        this.setState({ vimeoPlaying: false });
    };

    private getVimeoProps = () => {
        return {
            onVideoReadyVimeo: this.onVideoReadyVimeo,
            onVideoErrorVimeo: this.onVideoErrorVimeo,
            onPlayVideoVimeo: this.onPlayVideoVimeo,
            onPauseVideoVimeo: this.onPauseVideoVimeo,
            onEndVideoVimeo: this.onEndVideoVimeo,
            onExitVideoVimeo: this.onExitVideoVimeo,
            vimeoPlaying: this.state?.vimeoPlaying,
        };
    };

    private videoIsPlayingOrPaused = () => {
        const { videoStatus } = this.state;
        return (
            videoStatus === VideoStatus.PLAYING ||
            videoStatus === VideoStatus.AUTO_PAUSED ||
            videoStatus === VideoStatus.USER_PAUSED
        );
    };

    private videoIsStopped = () => {
        const { videoStatus } = this.state;
        return (
            videoStatus === VideoStatus.ENDED ||
            videoStatus === VideoStatus.MINIMIZED
        );
    };

    public clickTroubleshootingLink = (link: string): void => {
        const clickText = 'Troubleshoot Your Audio/Video Settings';
        Analytics.sendEvent({
            eventAction: 'click',
            eventName: clickText,
            type: 'button',
        });

        V2Analytics.interactionEvent({
            eventName: 'cta_click',
            click_text: clickText,
            click_url: link,
        });
    };

    public onCameraChange = (event: SelectChangeEvent<string>) => {
        const value = event.target.value;
        try {
            this.logger.info(`onCameraChange ${value}`);
            submitDeviceChangeAnalytics('video');
            void this.selfViewPublisher.setVideoDeviceId(value);
        } catch (error: unknown) {
            this.logger.error(
                { details: { error, deviceId: value } },
                'error setting video source',
            );
        }
    };

    public onAudioChange = (event: SelectChangeEvent<string>) => {
        const value = event.target.value;
        try {
            this.logger.info(`onMicChange ${value}`);
            submitDeviceChangeAnalytics('audio');
            void this.selfViewPublisher.setAudioDeviceId(value);
        } catch (error: unknown) {
            this.logger.error(
                { details: { error, deviceId: value } },
                'error setting audio source',
            );
        }
    };

    public toggleBlurEnabled = () => {
        console.log('Patient blur not enabled');
    };

    private runTests = () => this.props.runTests(this.selfViewPublisher);

    public updateDisplayWaitOfflineButton = () => {
        const enable = enableWaitOfflineButton({
            isTestVisit: this.props.isTestVisit,
            status: this.props.status,
            enableManuallyEnteringWaitoffline:
                this.state.enableManuallyEnteringWaitoffline,
            timestamps: this.props.timestamps,
            minimumWaitTimeForWaitOffline:
                this.state.minimumWaitTimeForWaitOffline,
            estimatedWaitTimeSeconds:
                this.state.waitTimeInfo?.estimatedWaitTimeSeconds,
        });
        this.setState({ displayWaitOfflineButton: enable });
    };

    public render() {
        const headerText = this.headerText;
        const { healthInfo, enableCancelButton } = this.props;
        let cancelVisitElement = null;
        let instructionVideoElement = null;
        let advertisementComp = null;
        const portalChatButton: React.ReactNode = (
            <div className={styles.chatButton}>
                <ChatButton onClick={this.chatClickHandle}>
                    {this.chatButtonText}
                </ChatButton>
            </div>
        );

        const waitOfflineButton = (
            <div className={styles.waitOfflineButton}>
                <ChatButton onClick={this.openWaitOfflineDialog}>
                    {this.waitOfflineButtonText}
                </ChatButton>
            </div>
        );

        const buttonDisplay = (
            <div className={styles.buttonContainer}>
                <div className={styles.buttonAndText}>
                    {this.chatButtonCaptionText}
                    {portalChatButton}
                </div>
                {this.state.displayWaitOfflineButton && (
                    <div className={styles.buttonAndText}>
                        {this.waitOfflineClickText}
                        {waitOfflineButton}
                    </div>
                )}
            </div>
        );

        let troubleshootingLink = '';
        const browser = browserCheck.getBrowser();
        if (browser && browser in this.troubleshootingLinks) {
            troubleshootingLink = this.troubleshootingLinks[browser];
        }

        const troubleshootingElement = (
            <>
                <span
                    className={styles.troubleshootingText}
                    dangerouslySetInnerHTML={this.troubleshootingText}
                />
                {troubleshootingLink && (
                    <Link
                        className={styles.troubleshootingLink}
                        sx={{
                            fontWeight: 600,
                            fontSize: '16px',
                        }}
                        href={troubleshootingLink}
                        // tslint:disable-next-line
                        onClick={() =>
                            this.clickTroubleshootingLink(troubleshootingLink)
                        }
                        target="_blank"
                        rel="noreferrer"
                        underline="always"
                        data-uitest="troubleshootingLink"
                    >{` ${this.troubleshootingButtonText}`}</Link>
                )}
            </>
        );

        // consider refactoring to create a single place for cancel button logic
        // all conditions must be true to show the cancel button
        const notSeenByProvider = !this.props.timestamps?.invisit;
        const showCancelButton =
            getFeatureFlag(FeatureFlags.cancellation) &&
            enableCancelButton &&
            notSeenByProvider;
        this.logger.info(
            {
                featureFlag: getFeatureFlag(FeatureFlags.cancellation),
                enableCancelButton,
                notSeenByProvider,
                timestamps: this.props.timestamps,
            },
            'show cancel button context',
        );
        if (showCancelButton) {
            cancelVisitElement = (
                <div className={styles.cancelVisitContainer}>
                    <Link
                        className={styles.cancelVisitLink}
                        onClick={this.openCancelVisitDialog}
                        underline="none"
                        rel="noreferrer"
                        data-uitest="cancelVisitLink"
                        tabIndex={0}
                        component="button"
                        role="link"
                    >
                        {this.cancelVisitButtonText}
                    </Link>
                </div>
            );
        }

        let selfCheckStyles = styles.selfViewNoShow;
        if (
            !getFeatureFlag(FeatureFlags.waitingRoomVideo) ||
            !this.videoIsPlayingOrPaused()
        ) {
            selfCheckStyles = '';
        }

        const shouldShowInstructionVideo =
            this.props.enableInstructionVideo &&
            getFeatureFlag(FeatureFlags.waitingRoomVideo) &&
            (this.videoIsPlayingOrPaused() || this.videoIsStopped());

        if (shouldShowInstructionVideo) {
            instructionVideoElement = (
                <InstructionVideoComponent
                    onPlayVideo={this.onPlayVideo}
                    videoIsActive={this.videoIsPlayingOrPaused()}
                    onEndVideo={this.onEndVideo}
                    onVideoError={this.onVideoError}
                    onVideoReady={this.onVideoReady}
                    onPauseVideo={this.onPauseVideo}
                    onExitVideo={this.onExitVideo}
                    vimeoProps={this.getVimeoProps()}
                />
            );
        }

        advertisementComp = (
            <div className={styles.advertisementContainer}>
                <AdCard
                    visitId={this.props.visitId}
                    source={'waiting_room'}
                    t={this.props.t}
                />
            </div>
        );

        return (
            <div className={styles.footerContainer}>
                <FooterPage>
                    <div className={styles.container}>
                        <ConnectionTestComponent
                            userDetails={this.props.userDetails}
                            health={this.props.health}
                            healthInfo={healthInfo}
                            runTests={this.runTests}
                            isProvider={false}
                            lostConnection={this.props.lostConnection}
                        />
                        <div className={styles.headerBlock}>
                            <h1
                                data-uitest="waitingroom-header"
                                className={styles.header}
                            >
                                {headerText}
                            </h1>
                        </div>
                        <EstimatedWaitTime
                            visitId={this.props.visitId}
                            userDetails={this.props.userDetails}
                            brand={this.props.brand}
                            isTestVisit={this.props.isTestVisit}
                            waitTimeInfo={this.state.waitTimeInfo}
                        />
                        <div className={selfCheckStyles}>
                            <CallSelfCheckComponent
                                runTechCheck={this.runTests}
                                disabled={false}
                                selfViewId={this.PUBLISHER_ID}
                                onAudioChange={this.onAudioChange}
                                onCameraChange={this.onCameraChange}
                                lostConnection={this.props.lostConnection}
                                toggleBlur={this.toggleBlurEnabled}
                            />
                        </div>
                        {instructionVideoElement}
                        {troubleshootingElement}
                        {buttonDisplay}
                        {cancelVisitElement}
                        {advertisementComp}
                    </div>
                    <CancelVisitDialog
                        active={this.state.cancelVisitDialogActive}
                        closeCancelVisitDialog={this.closeCancelVisitDialog}
                        endCall={this.cancelVisitHandle}
                        visitId={this.props.visitId}
                    />
                    <WaitOfflineDialog
                        active={this.state.waitOfflineDialogActive as boolean}
                        closeWaitOfflineDialog={this.closeWaitOfflineDialog}
                        handleSendPatientEnterWaitOffline={
                            this.props.handleSendPatientEnterWaitOffline
                        }
                        visitId={this.props.visitId}
                        patientEnterWaitOfflineStatus={
                            this.props.patientEnterWaitOfflineStatus
                        }
                        patientEnterWaitOfflineErrorType={
                            this.props.patientEnterWaitOfflineErrorType
                        }
                        handlePatientRedirectAfterWaitOffline={
                            this.props.handlePatientRedirectAfterWaitOffline
                        }
                        status={this.props.status}
                    />
                </FooterPage>
            </div>
        );
    }
}

const _WaitingRoomComponent =
    withTranslation()<typeof WaitingRoomComponent>(WaitingRoomComponent);
export { _WaitingRoomComponent as WaitingRoomComponent };
