import * as React from 'react';
import { useSelector, Provider, ProviderProps } from 'react-redux';
import { Action, applyMiddleware, createStore } from 'redux';
import { Store } from '@redux/modules';
import { rootReducer } from '@redux/modules/index';
// use local thunk shim to avoid strict generic mismatch noise in story context
import thunkShim from '@redux/middleware/thunkShim';
const thunkMw: any = thunkShim;

import { TestStatus } from '@common/video';
import { WaitingRoomComponent } from '../WaitingRoomComponent';
import { runTests } from '../../../redux/modules/health';
import { setVideoDeviceId } from '../../../redux/modules/userSettings';
import { setAudioDeviceId } from '../../../redux/modules/userSettings';
import { getHealthInfo } from '../../../redux/selectors/getHealthInfo';
import { WaitingRoomProps } from '../WaitingRoomInterfaces';
import { ThunkDispatch } from 'types/redux';
import { BrowserRouter } from 'react-router-dom';

const userDetails = {
    id: 'testUserId',
    displayName: 'testDisplayName',
    givenName: 'testGivenName',
    familyName: 'testFamilyName',
    email: 'textEmail@example.com',
    token: 'testToken',
    expiration: 0,
};

// Cast as Partial to avoid needing full root state shape (stories only exercise a slice)
// Broad any cast to bypass deep structural typing for storybook mock state
const testState: any = {
    postconsult: {
        visitId: 'testVisitId',
        isTestVisit: false,
        isTokBox: false,
        waitingConferenceId: 'waitingconferenceid',
        videoConferenceId: 'videoconferenceid',
        consult: {},
    },
    health: {
        healthCheckProgress: 0,
        networkStatus: TestStatus.NotRun,
        signalingStatus: TestStatus.NotRun,
        camStatus: TestStatus.NotRun,
        micStatus: TestStatus.NotRun,
        iceCandidateStatus: TestStatus.NotRun,
        localConnectStatus: TestStatus.NotRun,
        remoteConnectStatus: TestStatus.NotRun,
    },
    usersettings: {
        audioDeviceId: undefined,
        videoDeviceId: undefined,
        audioDevices: [],
        videoDevices: [],
    },
    video: {
        localCamExists: true,
        localMicExists: true,
        isFullScreen: false,
        endCallConfirmation: false,
        isChatVisible: false,
    },
    instantMessage: {
        waitingInstantMessages: [],
        videoInstantMessages: [],
        waitingRoomHasUnread: false,
        videoHasUnread: false,
    },
    user: {
        userDetails: {
            id: '',
            displayName: '',
            givenName: '',
            familyName: '',
            email: '',
            token: '',
            expiration: -1,
        },
    },
    otConnection: {
        otConnectionStatus: 'sessionConnected',
    },
    runTests: () => undefined,
};
type MockStoreType = Omit<ProviderProps['store'], 'dispatch'> & {
    dispatch: ThunkDispatch<Store['All'], unknown, Action>;
};

const mockStore: MockStoreType = createStore(
    rootReducer as any,
    testState as any,
    applyMiddleware(thunkMw as any),
) as any;

const Template = () => {
    const WrapperComponent = () => {
    const health = useSelector((state: Store['All']) => (state as any).health);
        const props = {
            visitId: 'visitId1234',
            userDetails: { userDetails },
            onChatClick: () => {
                console.log('chat click!');
            },
            health,
            lostConnection: false,
            healthInfo: useSelector((state: Store['All']) =>
                getHealthInfo((state as any).health),
            ),
            runTests: async () => {
                await (mockStore.dispatch as any)(runTests(null));
            },
            setVideoDeviceId: (deviceId: string) => {
                (mockStore.dispatch as any)(setVideoDeviceId(deviceId));
            },
            setAudioDeviceId: (deviceId: string) => {
                (mockStore.dispatch as any)(setAudioDeviceId(deviceId));
            },
        } as unknown as WaitingRoomProps;
        return <WaitingRoomComponent {...props} />;
    };

    return (
        <div style={{ textAlign: 'center' }}>
            <BrowserRouter>
                <Provider store={mockStore}>
                    <WrapperComponent />
                </Provider>
            </BrowserRouter>
        </div>
    );
};
export const Default = Template.bind({}) as typeof Template;

export default {
    title: 'Components/WaitingRoom',
    component: WaitingRoomComponent,
};
