import { config } from '@dexcare/circus-jupiter';
import IconButton from '@mui/material/IconButton';
import Clear from '@mui/icons-material/Clear';
import * as React from 'react';
import { withTranslation } from 'react-i18next';
import Youtube from 'react-youtube';
import LegacyReactPlayer from '@components/common/LegacyReactPlayer';
import { InstructionVideoComponentProps } from './InstructionVideoInterfaces';
import { languageDictionary } from '@utils/languageISODictionary';

import * as styles from './InstructionVideoComponent.css';
import { Configuration } from 'types/configuration';
const DEFAULT_VIDEO_ID = 'KzmBrWswLUM'; // Bethany video

type YouTubeVideoOptions = {
    cc_lang_pref?: string;
    rel?: 0 | 1;
    modestbranding?: 0 | 1;
    fs?: 0 | 1;
    cc_load_policy?: 1; // per YouTube docs only 1 is valid when provided
    controls?: 0 | 1;
};

function InstructionVideoComponent(props: InstructionVideoComponentProps) {
    const {
        videoIsActive,
        onPlayVideo,
        onEndVideo,
        onVideoReady,
        onVideoError,
        onPauseVideo,
        onExitVideo,
        i18n,
        vimeoProps,
    } = props;

    const instructionVideoId =
        (config as Configuration).getConfig().instructionVideoId ||
        DEFAULT_VIDEO_ID;
    const videoHostingSource =
        (config as Configuration).getConfig().instructionVideoHostingSource ||
        'youtube';
    const videoDirectUrl =
        (config as Configuration).getConfig().instructionalVideoDirectUrl ||
        'https://www.youtube.com/watch?v=Ai1Gb6ygeXI';
    const trimmedISOCode = i18n?.language?.split('-')[0]?.toLowerCase();
    const language = languageDictionary[trimmedISOCode];

    const containerStyles = videoIsActive
        ? styles.instructionVideoContainerPlaying
        : styles.instructionVideoContainer;
    const containerStylesVimeo = styles.instructionVideoContainerPlayingVimeo;
    const xButton = videoIsActive && (
        <IconButton onClick={onExitVideo} data-uitest={'minimizeVideo'}>
            <Clear />
        </IconButton>
    );
    const xButtonVimeo = videoIsActive && (
        <IconButton
            onClick={vimeoProps?.onExitVideoVimeo}
            data-uitest={'minimizeVideo'}
        >
            <Clear
                style={{
                    color: 'white',
                    backgroundColor: 'red',
                }}
            />
        </IconButton>
    );

    const youtubeVideoOptions: YouTubeVideoOptions = {
        controls: 1,
        rel: 0,
        modestbranding: 1,
        fs: 0,
        cc_load_policy: 1,
        cc_lang_pref: (language as string) || 'en',
    };

    // TODO: should we refactor this youtube player into using react-player?
    const youtubePlayer = (
        <div className={containerStyles}>
            <div className={styles.xButtonContainer}>{xButton}</div>
            <div className={styles.instructionVideo}>
                <Youtube
                    id={'youtube-player'}
                    videoId={instructionVideoId}
                    opts={{ playerVars: youtubeVideoOptions as any }}
                    onEnd={onEndVideo}
                    onReady={onVideoReady}
                    onPlay={onPlayVideo}
                    onError={onVideoError}
                    onPause={onPauseVideo}
                />
            </div>
        </div>
    );

    const reactPlayerConfig: any = {
        vimeo: {
            playerOptions: {
                texttrack: language,
            },
        },
    };

    const vimeoPlayer = (
        <>
            <div>{xButtonVimeo}</div>
            <div className={containerStylesVimeo}>
                    <LegacyReactPlayer
                    id={'vimeo-player'}
                        // cast component props to any to satisfy updated type defs differences
                        url={videoDirectUrl as any}
                    controls={true}
                    playing={vimeoProps?.vimeoPlaying}
                    onReady={vimeoProps?.onVideoReadyVimeo}
                    // cast due to react-player typing expecting ReactEventHandler, underlying callback receives Error
                    onError={vimeoProps?.onVideoErrorVimeo as any}
                    onPlay={vimeoProps?.onPlayVideoVimeo}
                    onPause={vimeoProps?.onPauseVideoVimeo}
                    onEnded={vimeoProps?.onEndVideoVimeo}
                    config={reactPlayerConfig}
                    playsinline
                />
            </div>
        </>
    );

    return (
        <>
            {videoHostingSource === 'youtube' && youtubePlayer}
            {videoHostingSource === 'vimeo' && vimeoPlayer}
        </>
    );
}

const _InstructionVideoComponent = withTranslation()(InstructionVideoComponent);
export { _InstructionVideoComponent as InstructionVideoComponent };
