import * as React from 'react';
import { Meta } from '@storybook/react';
import { CancelVisitDialog } from '../CancelVisitDialog';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
// Temporary cast for redux-thunk v3 typing mismatch in story environment
const thunkMw: any = thunk;
import configureMockStore from 'redux-mock-store';
import { CancelVisitDialogProps } from '../CancelVisitDialogInterfaces';
import { config } from '@dexcare/circus-jupiter';
import { FeatureFlags } from '@utils/FeatureFlags';
import { Configuration } from 'types/configuration';
import { BrowserRouter } from 'react-router-dom';

const defaultProps = {
    active: false,
    closeCancelVisitDialog: console.log('closeCancelVisitDialog hit'),
    endCall: console.log('endCall hit'),
    visitId: '1234',
    replace: console.log('replace hit'),
};

const Component = (props: CancelVisitDialogProps) => {
    const defaultAppConfig = (config as Configuration).getConfig();
    (config as Configuration).setConfig({
        ...defaultAppConfig,
        features: {
            [FeatureFlags.enablePatientCancelFlowWithReason]: {
                video: true,
                phone: false,
            },
        },
    });

    const mockStore = configureMockStore([thunkMw]);
    const mockStoreWithState = mockStore({});
    return (
        <BrowserRouter>
            <Provider store={mockStoreWithState}>
                <CancelVisitDialog {...props} />
            </Provider>
        </BrowserRouter>
    );
};

const meta: Meta = {
    title: 'Modules/CancelVisitDialog',
    component: Component,
    parameters: {
        fetchMock: {},
    },
};

export default meta;

export const Default = {
    args: {
        ...defaultProps,
    },
};
