import { WithTranslation } from 'react-i18next';

// TODO: clean up when we fully transition away from youtube
export interface InstructionVideoComponentProps extends WithTranslation {
    videoIsActive: boolean;
    onPlayVideo: () => void;
    onEndVideo: () => void;
    onPauseVideo: () => void;
    onVideoReady: (event: { target: YouTubePlayer }) => void;
    onVideoError: (event: { target: YouTubePlayer; data: number }) => void;
    onExitVideo: () => void;
    vimeoProps: {
        onVideoReadyVimeo: () => void;
        onVideoErrorVimeo: (error: Error) => void;
        onPlayVideoVimeo: () => void;
        onPauseVideoVimeo: () => void;
        onEndVideoVimeo: () => void;
        onExitVideoVimeo: () => void;
        vimeoPlaying?: boolean;
    };
}
