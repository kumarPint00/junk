import { WithTranslation } from 'react-i18next';

export interface WaitOfflineDialogProps extends WithTranslation {
    active: boolean;
    closeWaitOfflineDialog: () => void;
    handleSendPatientEnterWaitOffline(): void;
    handlePatientRedirectAfterWaitOffline: () => void;
    visitId: string;
    patientEnterWaitOfflineStatus?: string | null;
    patientEnterWaitOfflineErrorType?: string | null;
    status?: string | null;
}
