import * as React from 'react';
import { Meta } from '@storybook/react';
import { CancelVisitDialog } from '../CancelVisitDialog';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
const thunkMw: any = thunk;
import configureMockStore from 'redux-mock-store';
import { CancelVisitDialogProps } from '../CancelVisitDialogInterfaces';
import { BrowserRouter } from 'react-router-dom';

const defaultProps = {
    active: false,
    closeCancelVisitDialog: console.log('closeCancelVisitDialog hit'),
    endCall: console.log('endCall hit'),
    visitId: '1234',
    replace: console.log('replace hit'),
};

const Component = (props: CancelVisitDialogProps) => {
    const mockStore = configureMockStore([thunkMw]);
    const mockStoreWithState = mockStore({});
    return (
        <BrowserRouter>
            <Provider store={mockStoreWithState}>
                <CancelVisitDialog {...props} />
            </Provider>
        </BrowserRouter>
    );
};

const meta: Meta = {
    title: 'Modules/CancelVisitDialogLegacy',
    component: Component,
    parameters: {
        fetchMock: {},
    },
};

export default meta;

export const Default = {
    args: {
        ...defaultProps,
    },
};
