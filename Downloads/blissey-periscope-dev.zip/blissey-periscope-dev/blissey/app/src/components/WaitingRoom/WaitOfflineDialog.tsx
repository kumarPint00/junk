import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import Button from '@mui/material/Button';
import { withTranslation } from 'react-i18next';
import { styles } from './makeStyles/Dialog';
import { WaitOfflineDialogProps } from './WaitOfflineDialogInterfaces';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

const WaitOfflineDialog = React.memo((props: WaitOfflineDialogProps) => {
    const [disableWaitOfflineButton, setDisableWaitOfflineButton] =
        React.useState(false);

    const handleSendPatientEnterWaitOffline = () => {
        /// facepalm
        if (!disableWaitOfflineButton) {
            setDisableWaitOfflineButton(true);
            setTimeout(() => {
                setDisableWaitOfflineButton(false);
            }, 1000);
        }

        props.handleSendPatientEnterWaitOffline();

        V2Analytics?.interactionEvent({
            eventName: 'patient_enter_wait_offline',
            visitId: props.visitId,
        });
    };

    // accessibility, autofocus on the heading when modal pops up
    const dialogRef = React.useRef<HTMLDivElement>();
    React.useEffect(() => {
        if (props.active === true) {
            setTimeout(() => {
                if (dialogRef.current) {
                    dialogRef.current.focus();
                }
            }, 1);
        }
    }, [props.active]);

    const visitAssignedToProvider =
        props.patientEnterWaitOfflineErrorType ===
            'VisitNotAllowedToGoToWaitOffline' &&
        props.status === 'caregiverassigned';

    const dialogTitleText =
        props.t('wait-offline.modal.header') ||
        'Your place in line is reserved.';
    const dialogContentText =
        props.t('wait-offline.modal.body') ||
        'We can contact you when the provider is ready.';
    const buttonAcceptText =
        props.t('wait-offline.modal.accept') || 'Come Back Later';
    const buttonDeclineText =
        props.t('wait-offline.modal.decline') || 'Wait Here';
    const enterWaitOfflineSuccessfulText =
        props.t('wait-offline.modal.success') ||
        'Great. We will notify you through email or text message when the provider is ready.';
    const enterWaitOfflineFailureText = visitAssignedToProvider
        ? props.t('wait-offline.modal.failure-visit-not-allowed')
        : props.t('wait-offline.modal.failure') ||
          'Something went wrong. Please try again.';
    const closeText = props.t('wait-offline.modal.close') || 'Close';

    const waitOfflineDiglogSuccess =
        props.patientEnterWaitOfflineStatus === 'success';
    const waitofflineDialogFailure =
        props.patientEnterWaitOfflineStatus === 'failure';

    const waitOfflineModalInitial: React.ReactElement = (
        <Dialog
            data-testid="waitoffline-dialog"
            open={props.active}
            onClose={props.closeWaitOfflineDialog}
            PaperProps={{ style: { borderRadius: '24px' } }}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth="md"
            fullWidth={true}
        >
            <DialogContent tabIndex={0} ref={dialogRef}>
                <DialogTitle
                    sx={styles.dialogTitle}
                    id="alert-dialog-title"
                    variant="h4"
                >
                    {dialogTitleText}
                </DialogTitle>
                <DialogContentText
                    sx={styles.dialogText}
                    id="alert-dialog-description"
                >
                    {dialogContentText}
                </DialogContentText>
            </DialogContent>
            <DialogActions disableSpacing={true} sx={styles.dialogRoot}>
                <div style={{ margin: '25px 25px' }}>
                    <Button
                        color="primary"
                        variant="outlined"
                        onClick={props.closeWaitOfflineDialog}
                        data-testid="waitingroom-dialog-close"
                        sx={{
                            ...styles.outlinedPrimary,
                            ...styles.buttonRootStay,
                        }}
                    >
                        {buttonDeclineText.toLocaleUpperCase()}
                    </Button>
                    <Button
                        color="primary"
                        variant="outlined"
                        onClick={handleSendPatientEnterWaitOffline}
                        data-testid="waitingroom-dialog-waitoffline"
                        sx={{
                            ...styles.outlinedPrimary,
                            ...styles.buttonRootLeave,
                        }}
                        disabled={disableWaitOfflineButton}
                    >
                        {buttonAcceptText.toLocaleUpperCase()}
                    </Button>
                </div>
            </DialogActions>
            {waitofflineDialogFailure && (
                <div
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                >
                    <span
                        style={{
                            color: 'red',
                            textAlign: 'center',
                            marginBottom: '20px',
                            fontSize: 'large',
                        }}
                        data-testid="waitingroom-dialog-waitoffline-failure-message"
                    >
                        {enterWaitOfflineFailureText}
                    </span>
                </div>
            )}
        </Dialog>
    );

    const waitOfflineModalSuccess: React.ReactElement = (
        <Dialog
            open={props.active}
            onClose={props.handlePatientRedirectAfterWaitOffline}
            PaperProps={{ style: { borderRadius: '24px' } }}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth="md"
            fullWidth={true}
            data-testid="waitoffline-dialog-success"
        >
            <DialogContent tabIndex={0} ref={dialogRef}>
                <DialogTitle
                    sx={styles.dialogTitle}
                    id="alert-dialog-title"
                    variant="h4"
                >
                    {enterWaitOfflineSuccessfulText}
                </DialogTitle>
                <DialogActions disableSpacing={true} sx={styles.dialogRoot}>
                    <div style={{ margin: '25px 25px' }}>
                        <Button
                            color="primary"
                            variant="outlined"
                            onClick={
                                props.handlePatientRedirectAfterWaitOffline
                            }
                            data-testid="waitingroom-dialog-close"
                            sx={{
                                ...styles.outlinedPrimary,
                                ...styles.buttonRootStay,
                            }}
                        >
                            {closeText.toLocaleUpperCase()}
                        </Button>
                    </div>
                </DialogActions>
            </DialogContent>
        </Dialog>
    );

    return waitOfflineDiglogSuccess
        ? waitOfflineModalSuccess
        : waitOfflineModalInitial;
});

WaitOfflineDialog.displayName = 'WaitOfflineDialog';

const _WaitOfflineDialog = withTranslation()(WaitOfflineDialog);
export { _WaitOfflineDialog as WaitOfflineDialog };
