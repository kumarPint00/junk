import { WithTranslation } from 'react-i18next';

export interface CancelVisitDialogProps extends WithTranslation {
    active: boolean;
    closeCancelVisitDialog: () => void;
    endCall: () => void;
    visitId: string;
}
