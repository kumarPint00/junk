import * as React from 'react';
import {
    Grid,
    Dialog,
    Button,
    Select,
    MenuItem,
    InputLabel,
    Typography,
    FormControl,
    DialogTitle,
    useMediaQuery,
    DialogActions,
    DialogContent,
    TypographyProps,
    SelectChangeEvent,
    DialogContentText,
} from '@mui/material';
import { withTranslation } from 'react-i18next';
import { styles } from './makeStyles/Dialog';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { useDispatch } from 'react-redux';
import { ThunkDispatch } from 'types/redux';
import { AnyAction } from 'redux';
import { cancelVideoWithReason } from '@redux/modules/postConsult';
import { getClosedVisitRoute } from '@utils/getRoutes';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import { CancelVisitDialogProps } from './CancelVisitDialogInterfaces';
import { defaultReasonsForCancel } from '@utils/otUtils';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { useNavigate } from 'react-router-dom';

const DialogTypography = (props: TypographyProps) => (
    <Typography
        {...props}
        sx={{
            ...(props.sx ?? {}),
            fontFamily: 'Open Sans',
        }}
    >
        {props.children}
    </Typography>
);

const CancelVisitDialog = React.memo((props: CancelVisitDialogProps) => {
    const dialogTitleText = props.t(
        'modal.cancelAppointment.cancelApptTitle',
        '',
    );
    const dialogContentText = props.t(
        'modal.cancelAppointment.cancelApptBody',
        '',
    );
    const buttonStayText = props.t(
        'modal.cancelAppointment.cancelApptStayButton',
        '',
    );
    const buttonLeaveText = props.t(
        'modal.cancelAppointment.cancelApptLeaveButton',
        '',
    );
    let reasonsForCancel = props.t('cancelWithReason.reasons', {
        returnObjects: true,
    }) as unknown as { label: string; value: string }[];
    if (!Array.isArray(reasonsForCancel)) {
        reasonsForCancel = defaultReasonsForCancel;
    }
    let headerText = props.t('cancelWithReason.video.header');
    if (headerText === 'cancelWithReason.video.header')
        headerText = 'Your place in line is reserved.';
    let bodyText = props.t('cancelWithReason.video.body');
    if (bodyText === 'cancelWithReason.video.body')
        bodyText = 'Cancelling now will remove you from the queue.';
    let instructionText = props.t('cancelWithReason.video.instruction');
    if (instructionText === 'cancelWithReason.video.instruction')
        instructionText =
            'If you wish to keep the appointment, please close this window.';
    let reasonText = props.t('cancelWithReason.video.reason');
    if (reasonText === 'cancelWithReason.video.reason')
        reasonText =
            'If you still need to cancel, please select a reason below.';
    let label = props.t('cancelWithReason.video.label');
    if (label === 'cancelWithReason.video.label')
        label = 'Reason for cancelling';
    let buttonAccept = props.t('cancelWithReason.video.buttonAccept');
    if (buttonAccept === 'cancelWithReason.video.buttonAccept')
        buttonAccept = 'CANCEL VISIT';
    let buttonClose = props.t('cancelWithReason.video.buttonClose');
    if (buttonClose === 'cancelWithReason.video.buttonClose')
        buttonClose = 'CLOSE';

    const defaultReasonSelected = reasonsForCancel[0].value;
    const [reason, setReason] = React.useState<string | null>(
        defaultReasonSelected,
    );

    const navigate = useNavigate();
    const dispatch: ThunkDispatch<unknown, void, AnyAction> = useDispatch();

    const handleReasonChange = (event: SelectChangeEvent<string>) => {
        setReason(event.target.value);
    };

    const cancelVisitHandler = () => {
        V2Analytics.interactionEvent({
            eventName: 'visit_cancel',
            visit_id: props.visitId,
        });

        void dispatch(cancelVideoWithReason(props.visitId, reason));

        navigate(getClosedVisitRoute('cancelled'), { replace: true });
    };

    // accessibility, autofocus on the heading when modal pops up
    const dialogRef = React.useRef<HTMLDivElement>();
    React.useEffect(() => {
        if (props.active === true) {
            setTimeout(() => {
                if (dialogRef.current) {
                    dialogRef.current.focus();
                }
            }, 1);
        }
    }, [props.active]);

    let enableCancelModalWithReason = false;
    const enablePatientCancelFlowWithReasonFlags = getFeatureFlag(
        FeatureFlags.enablePatientCancelFlowWithReason,
    );
    if (typeof enablePatientCancelFlowWithReasonFlags === 'object') {
        enableCancelModalWithReason =
            enablePatientCancelFlowWithReasonFlags.video;
    }

    const isSmallScreen = useMediaQuery('(max-width:600px)');

    const newCancelModal = (
        <Dialog
            open={props.active}
            onClose={props.closeCancelVisitDialog}
            PaperProps={{ style: { borderRadius: '8px' } }}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth="md"
            fullWidth={true}
        >
            <DialogContent
                tabIndex={0}
                ref={dialogRef}
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                }}
            >
                <DialogTitle
                    variant={isSmallScreen ? 'h6' : 'h4'}
                    sx={{
                        p: 0,
                        pt: 2,
                        fontWeight: '600',
                        textAlign: 'center',
                        fontFamily: 'Open Sans',
                    }}
                    id="alert-dialog-title"
                >
                    {headerText}
                </DialogTitle>
                <DialogContentText
                    sx={styles.dialogTextSmall}
                    id="alert-dialog-description"
                >
                    <DialogTypography
                        variant={isSmallScreen ? 'body1' : 'h6'}
                        sx={{ fontWeight: '600' }}
                    >
                        {bodyText}
                    </DialogTypography>
                    <DialogTypography variant="body1" sx={{ mt: 1 }}>
                        {instructionText}
                    </DialogTypography>
                    <DialogTypography
                        variant="subtitle2"
                        sx={{
                            mt: 5,
                            mx: 'auto',
                            maxWidth: 400,
                            fontWeight: '500',
                            textAlign: 'center',
                        }}
                    >
                        {reasonText}
                    </DialogTypography>
                </DialogContentText>
                <FormControl
                    fullWidth
                    variant="outlined"
                    margin="normal"
                    sx={{ maxWidth: 400 }}
                >
                    <InputLabel id="cancel-reason-label">{label}</InputLabel>
                    <Select
                        labelId="cancel-reason-label"
                        id="cancel-reason"
                        value={reason}
                        onChange={handleReasonChange}
                        label="Reason for cancelling"
                        IconComponent={KeyboardArrowDownIcon}
                    >
                        {Array.isArray(reasonsForCancel) &&
                            reasonsForCancel.map(
                                (r: { value: string; label: string }) => (
                                    <MenuItem key={r.value} value={r.value}>
                                        {r.label}
                                    </MenuItem>
                                ),
                            )}
                    </Select>
                </FormControl>
                <DialogActions
                    disableSpacing={true}
                    sx={{
                        ...styles.dialogRoot,
                        width: '100%',
                        maxWidth: 400,
                        p: 0,
                    }}
                >
                    <Grid display="flex" width="100%" flexDirection="column">
                        <Button
                            color="silver"
                            variant="contained"
                            sx={{ width: '100%' }}
                            onClick={cancelVisitHandler}
                            data-uitest="waitingroom-dialog-cancel"
                        >
                            {buttonAccept}
                        </Button>
                        <Button
                            variant="text"
                            sx={{ width: '100%', mt: 1 }}
                            onClick={props.closeCancelVisitDialog}
                            data-uitest="waitingroom-dialog-close"
                        >
                            {buttonClose}
                        </Button>
                    </Grid>
                </DialogActions>
            </DialogContent>
        </Dialog>
    );

    const legacyCancelModal = (
        <Dialog
            open={props.active}
            onClose={props.closeCancelVisitDialog}
            PaperProps={{ style: { borderRadius: '24px' } }}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            maxWidth="md"
            fullWidth={true}
        >
            <DialogContent tabIndex={0} ref={dialogRef}>
                <DialogTitle
                    sx={styles.dialogTitle}
                    id="alert-dialog-title"
                    variant="h4"
                >
                    {dialogTitleText}
                </DialogTitle>
                <DialogContentText
                    sx={styles.dialogText}
                    id="alert-dialog-description"
                >
                    {dialogContentText}
                </DialogContentText>
            </DialogContent>
            <DialogActions disableSpacing={true} sx={styles.dialogRoot}>
                <div style={{ margin: '25px 25px' }}>
                    <Button
                        color="primary"
                        variant="outlined"
                        onClick={props.closeCancelVisitDialog}
                        data-uitest="waitingroom-dialog-close"
                        sx={{
                            ...styles.outlinedPrimary,
                            ...styles.buttonRootStay,
                        }}
                    >
                        {buttonStayText?.toLocaleUpperCase()}
                    </Button>
                    <Button
                        color="primary"
                        variant="outlined"
                        onClick={props.endCall}
                        data-uitest="waitingroom-dialog-cancel"
                        sx={{
                            ...styles.outlinedPrimary,
                            ...styles.buttonRootLeave,
                        }}
                    >
                        {buttonLeaveText?.toLocaleUpperCase()}
                    </Button>
                </div>
            </DialogActions>
        </Dialog>
    );

    return enableCancelModalWithReason ? newCancelModal : legacyCancelModal;
});

CancelVisitDialog.displayName = 'CancelVisitDialog';

const _CancelVisitDialog = withTranslation()(CancelVisitDialog);
export { _CancelVisitDialog as CancelVisitDialog };
