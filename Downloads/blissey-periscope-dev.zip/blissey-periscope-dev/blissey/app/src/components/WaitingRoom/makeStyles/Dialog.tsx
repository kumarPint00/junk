export const styles = {
    dialogRoot: {
        justifyContent: 'center',
        flexWrap: 'wrap',
        flexBasis: '100px',
    },
    dialogTitle: {
        fontSize: '1.8rem',
        fontWeight: 700,
        textAlign: 'center',
        color: 'black',
        marginBottom: '20px',
    },
    dialogText: {
        fontSize: '1.35rem',
        fontWeight: 600,
        textAlign: 'center',
        color: 'black',
    },
    dialogTitleSmall: {
        fontSize: '1.4rem',
        fontWeight: 700,
        textAlign: 'center',
        color: 'black',
        marginBottom: '20px',
    },
    dialogTextSmall: {
        fontSize: '1.1rem',
        fontWeight: 600,
        textAlign: 'center',
        color: 'black',
    },
    outlinedPrimary: {
        border: 'solid 2px',
        borderRadius: '24px',
        boxSizing: 'border-box',
    },
    outlinedSecondary: {
        border: 'none',
        borderRadius: '24px',
        boxSizing: 'border-box',
    },
    buttonRootLeave: {
        width: '250px',
        minWidth: '200px',
        height: '50px',
        fontSize: '1.25rem',
        fontWeight: 600,
        '&:hover': {
            backgroundColor: 'primary.main',
            color: 'white',
        },
        margin: '5px 25px',
    },
    buttonRootStay: {
        width: '250px',
        minWidth: '200px',
        height: '50px',
        fontSize: '1.25rem',
        fontWeight: 600,
        '&:hover': {
            backgroundColor: 'primary.main',
            color: 'white',
        },
        margin: '5px 25px',
    },
};
