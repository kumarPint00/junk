import { UserDetails } from '@dexcare/circus-saturn';
import { HealthInfo } from '@common/ConnectionTest/HealthInfo';
import { Publisher } from '@common/video';
import { WaitTime } from '@clients/VisitService/VisitServiceClient';
import { WithTranslation } from 'react-i18next';
import { TState as HealthState } from '@redux/modules/health';
export interface WaitTimeInfo extends WaitTime {
    loading: boolean;
}

export enum VideoStatus {
    NONE, // state for before the 10 second delay in the waiting room
    QUEUED, // state time delay is up, but before initial 'play'
    PLAYING, // state for anytime the video is in playing and center of the screen (playing or paused)
    AUTO_PAUSED, // state for when a chat comes in and video is automatically paused
    USER_PAUSED, // state for when user pauses the video - need to differentiate between auto_paused for analytics
    MINIMIZED, // state for when user clicks 'X'
    ENDED, // state for after video ends
    ERROR, // any errror that comes from the youtube iframe.  Video will not appear on the screen at all
}

export interface WaitingRoomProps extends WithTranslation {
    visitId: string;
    userDetails: UserDetails;
    brand: string;
    health: HealthState;
    healthInfo: HealthInfo;
    isTestVisit: boolean;
    chatIsVisible: boolean;
    waitingRoomVideoDelayInMs?: number; // for testing
    waitingRoomChatDelayInMs?: number; // for testing
    lostConnection: boolean;
    enableInstructionVideo: boolean;
    enableCancelButton: boolean;
    timestamps: {
        created: string | undefined;
        requested: string | undefined;
        waitingroom: string | undefined;
        invisit: string | undefined;
        done: string | undefined;
        staffdeclined: string | undefined;
        cancelled: string | undefined;
        waitoffline: string | undefined;
        caregiverassigned: string | undefined;
    };
    cancelVisit(): void;
    onChatClick: () => void;
    changeCam: (val: string) => void;
    changeMic: (val: string) => void;
    runTests: (publisher: Publisher) => void;
    handleSendPatientEnterWaitOffline: () => void;
    handlePatientRedirectAfterWaitOffline: () => void;
    patientEnterWaitOfflineStatus?: string | null;
    patientEnterWaitOfflineErrorType?: string | null;
    status?: string;
}

export interface WaitingRoomState {
    cancelVisitDialogActive: boolean;
    videoStatus: VideoStatus;
    vimeoPlaying?: boolean;
    patientRejoinGeneratedBy?: string;
    patientRejoinMimirSent?: boolean;
    waitOfflineDialogActive?: boolean;
    estimatedWaitTimeSeconds: number;
    minimumWaitTimeForWaitOffline: number;
    waitTimeInfo: WaitTimeInfo;
    displayWaitOfflineButton?: boolean;
    enableManuallyEnteringWaitoffline: boolean;
}
