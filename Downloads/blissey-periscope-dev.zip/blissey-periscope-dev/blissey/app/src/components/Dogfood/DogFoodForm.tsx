import * as React from 'react';
import { Select, SelectChangeEvent } from '@mui/material';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import FormControl from '@mui/material/FormControl';
import Grid from '@mui/material/Grid';
import { CopyButton } from './CopyButton';
import { DogFoodOtSession } from './DogFoodOTSession';
import { v4 } from 'uuid';

import * as styles from './DogFoodForm.css';

type DropdownProp = { label: string; value: string };
type ChangeEvent = (
    event: React.ChangeEvent<{ name?: string; value: unknown }>,
) => void;

const generateSignal = (
    label: string,
    name: string,
    method: string,
    args: [
        {
            visitId: string;
            targetModality?: string;
            actorId: string;
            timestamp: number;
            error?: {
                code: string;
                message: string;
            };
        },
    ],
) => ({
    label,
    name,
    method,
    args,
});

export interface DogfoodFormProps {
    providerLink?: string;
    patientLink?: string;
    onBrandChange: (
        event: SelectChangeEvent<string>,
        child: React.ReactNode,
    ) => void;
    brands: DropdownProp[];
    selectedBrand: string;
    onGenerateClick: () => void;
    patientWaitingRoomToken?: string;
    patientVideoToken?: string;
    videoSessionId?: string;
    waitingRoomSessionId?: string;
}

export class DogFoodForm extends React.Component<DogfoodFormProps> {
    constructor(props: DogfoodFormProps) {
        super(props);
    }

    public render() {
        const {
            onBrandChange,
            brands,
            selectedBrand,
            onGenerateClick,
            providerLink,
            patientLink,
            patientWaitingRoomToken,
            patientVideoToken,
            videoSessionId,
            waitingRoomSessionId,
        } = this.props;

        return (
            <Grid container spacing={5}>
                <Grid item xs={12}>
                    <FormControl variant="standard">
                        <InputLabel shrink={true}>Brand</InputLabel>
                        <Select
                            onChange={onBrandChange}
                            value={selectedBrand}
                            variant="standard"
                        >
                            {brands.map((brand) => (
                                <MenuItem key={brand.value} value={brand.value}>
                                    {brand.label}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={12}>
                    <Button
                        color="primary"
                        variant="contained"
                        data-uitest="dogfoodform-generatebutton"
                        onClick={onGenerateClick}
                        classes={{ root: styles.generateButton }}
                    >
                        Generate a test visit
                    </Button>
                </Grid>
                {patientWaitingRoomToken && waitingRoomSessionId && (
                    <Grid item xs={12}>
                        <DogFoodOtSession
                            label="Waiting Room Signal:"
                            otToken={patientWaitingRoomToken}
                            sessionId={waitingRoomSessionId}
                            signals={[
                                generateSignal(
                                    'Send Patient Enter WaitOffline Success',
                                    'sendPatientEnterWaitOfflineSuccess',
                                    'sendPatientEnterWaitOfflineSuccess',
                                    [
                                        {
                                            visitId: 'test-visit',
                                            actorId: 'actor-id',
                                            timestamp: Date.now(),
                                        },
                                    ],
                                ),
                                generateSignal(
                                    'Send Patient Enter WaitOffline Error',
                                    'sendPatientEnterWaitOfflineError',
                                    'sendPatientEnterWaitOfflineError',
                                    [
                                        {
                                            visitId: 'test-visit',
                                            actorId: 'actor-id',
                                            timestamp: Date.now(),
                                            error: {
                                                code: 'enter waitoffline error',
                                                message: "it didn't work",
                                            },
                                        },
                                    ],
                                ),
                                generateSignal(
                                    'Send Modality Conversion Success',
                                    'sendModalityConversionSignal',
                                    'sendModalityConversion',
                                    [
                                        {
                                            visitId: 'test-visit',
                                            targetModality: 'phone',
                                            actorId: 'actor-id',
                                            timestamp: Date.now(),
                                        },
                                    ],
                                ),
                                generateSignal(
                                    'Send Modality Conversion Error',
                                    'sendModalityConversionErrorSignal',
                                    'sendModalityConversionError',
                                    [
                                        {
                                            visitId: 'test-visit',
                                            actorId: 'actor-id',
                                            targetModality: 'phone',
                                            timestamp: Date.now(),
                                            error: {
                                                code: 'convert modality error',
                                                message:
                                                    "it didn't convert modality",
                                            },
                                        },
                                    ],
                                ),
                                {
                                    label: 'Send Bot Prompt Signal',
                                    name: 'botPromptMessageSignal',
                                    method: 'sendBotPromptMessage',
                                    args: [
                                        {
                                            creationTime: `${new Date().getTime()}`,
                                            fromParticipant:
                                                'CHANGE-ME-WITH-ENG-13255',
                                            isBot: true,
                                            options: ['yes', 'no'],
                                            prompt: 'Hi Avery, I am an AI pre-visit screener with University Health. Before you visit gets started, may I ask you some additional questions about your condition?',
                                            senderId:
                                                'CHANGE-ME-WITH-ENG-13255',
                                            uniqueId: v4(),
                                        },
                                    ],
                                },
                            ]}
                        />
                    </Grid>
                )}
                {patientVideoToken && videoSessionId && (
                    <Grid item xs={12}>
                        <DogFoodOtSession
                            label="Video Session Signal:"
                            otToken={patientVideoToken}
                            sessionId={videoSessionId}
                            signals={[
                                {
                                    label: 'Send End Call',
                                    name: 'sendEndCallSignal',
                                    method: 'sendEndCall',
                                    args: [
                                        () =>
                                            console.log('sendEndCall callback'),
                                    ],
                                },
                                {
                                    label: 'Send End And Transfer',
                                    name: 'sendEndCallAndTransferSignal',
                                    method: 'sendEndCallAndTransfer',
                                    args: [
                                        // NOTE: the yak signal handler won't execute if this is undefined
                                        {
                                            visitId: 'test-visit',
                                            actorId: 'actor-id',
                                            timestamp: Date.now(),
                                        },
                                        () =>
                                            console.log(
                                                'sendEndCallAndTransfer callback',
                                            ),
                                    ],
                                },
                                {
                                    label: 'Send End And Transfer Error',
                                    name: 'sendEndCallAndTransferErrorSignal',
                                    method: 'sendEndCallAndTransferError',
                                    args: [
                                        // NOTE: the yak signal handler won't execute if this is undefined
                                        {
                                            visitId: 'test-visit',
                                            actorId: 'actor-id',
                                            timestamp: Date.now(),
                                            error: {
                                                code: 'transfer error',
                                                message: "it didn't transfer",
                                            },
                                        },
                                        () =>
                                            console.log(
                                                'sendEndCallAndTransferError callback',
                                            ),
                                    ],
                                },
                                {
                                    label: 'Send Modality Conversion Success',
                                    name: 'sendModalityConversionSignal',
                                    method: 'sendModalityConversion',
                                    args: [
                                        {
                                            visitId: 'test-visit',
                                            targetModality: 'phone',
                                            actorId: 'actor-id',
                                            timestamp: Date.now(),
                                        },
                                    ],
                                },
                                {
                                    label: 'Send Modality Conversion Error',
                                    name: 'sendModalityConversionErrorSignal',
                                    method: 'sendModalityConversionError',
                                    args: [
                                        {
                                            visitId: 'test-visit',
                                            actorId: 'actor-id',
                                            targetModality: 'phone',
                                            timestamp: Date.now(),
                                            error: {
                                                code: 'convert modality error',
                                                message:
                                                    "it didn't convert modality",
                                            },
                                        },
                                    ],
                                },
                            ]}
                        />
                    </Grid>
                )}
                <Grid item xs={12}>
                    <CopyButton
                        label={'Provider'}
                        text={providerLink}
                        isLink={true}
                        dataUiTest="dogfoodform-providerlink"
                    />
                </Grid>
                <Grid item xs={12}>
                    <CopyButton
                        label={'Patient'}
                        text={patientLink}
                        isLink={true}
                        dataUiTest="dogfoodform-patientlink"
                    />
                </Grid>
                <Grid item xs={12}>
                    <CopyButton
                        label={'Patient Waiting Room Token'}
                        text={patientWaitingRoomToken}
                    />
                </Grid>
                <Grid item xs={12}>
                    <CopyButton
                        label={'Patient Video Token'}
                        text={patientVideoToken}
                    />
                </Grid>
            </Grid>
        );
    }
}
