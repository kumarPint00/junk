import { SessionHelper } from '@dexcare/yak';

const mocks = vi.hoisted(() => ({
    connect: vi.fn((_, onSuccess) => {
        onSuccess();
    }) as MockedFunction<typeof SessionHelper.prototype.connect>,
    helper: vi.fn(),
}));

vi.mock('@dexcare/yak', () => ({
    SessionHelper: vi.fn().mockImplementation(() => {
        return {
            connect: mocks.connect,
            someHelper: mocks.helper,
        };
    }),
}));

import * as React from 'react';
import { DogFoodOtSession, DogFoodOtSessionProps } from '../DogFoodOTSession';

import { MockedFunction, vi } from 'vitest';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MuiRippleDisabledWrapper } from '../../../../__mocks__/theme-provider';

const renderComponent = (props: DogFoodOtSessionProps) => {
    return render(
        <MuiRippleDisabledWrapper>
            <DogFoodOtSession {...props} />
        </MuiRippleDisabledWrapper>,
    );
};

describe('<DogFoodOTSession />', () => {
    let defaultProps: DogFoodOtSessionProps;
    beforeEach(() => {
        defaultProps = {
            label: 'Some Session',
            sessionId: 'some-session-id',
            otToken: 'some-ot-token',
            signals: [
                {
                    name: 'someNameThing',
                    label: 'Some Label',
                    method: 'someHelper',
                    args: [],
                },
            ],
        };
        mocks.connect.mockClear();
    });
    describe('valid session', () => {
        test('renders component', () => {
            const { container } = renderComponent(defaultProps);
            expect(container).toMatchSnapshot();
        });

        test('mounts component and connects session', () => {
            renderComponent(defaultProps);
            expect(mocks.connect).toHaveBeenCalledTimes(1);
        });

        test('calls session helper', async () => {
            renderComponent(defaultProps);
            const sendButton = screen.getByRole('button');
            expect(sendButton).toBeTruthy();
            await waitFor(() => {
                expect(sendButton).not.toHaveProperty('disabled', true);
            });

            fireEvent.click(sendButton);
            expect(mocks.helper).toHaveBeenCalledTimes(1);
        });
    });
});
