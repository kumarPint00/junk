import * as React from 'react';

import * as styles from './DogFoodHeader.css';

export function DogFoodHeader(props: {
    headerTextOverride?: string;
    explanationTextOverride?: string;
}) {
    const { headerTextOverride, explanationTextOverride } = props;
    const headerText = headerTextOverride || 'Generate a Visit';
    const explanationText =
        explanationTextOverride ||
        'Create a test visit ID that can be used to test the patient/provider flow.';
    return (
        <div className={styles.container}>
            <div
                data-uitest="dogfoodheader-werebrewing"
                className={styles.WereBrewing}
            >
                {headerText}
            </div>
            <br />
            <div data-uitest="dogfoodheader-useit" className={styles.Useit}>
                {explanationText}
            </div>
        </div>
    );
}
