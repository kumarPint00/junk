import * as React from 'react';
import { SessionHelper, OTError } from '@dexcare/yak';
import { config, LogManager } from '@dexcare/circus-jupiter';
import { Button, MenuItem, Select } from '@mui/material';

import * as styles from './DogFoodOTSession.css';
import { Configuration } from 'types/configuration';

export interface Signal {
    name: string;
    label: string;
    method: string;
    args: unknown[];
}

export interface DogFoodOtSessionProps {
    label: string;
    sessionId: string;
    otToken: string;
    signals: Signal[];
}

export interface DogFoodOtSessionState {
    connected: boolean;
    selectedSignal: string | undefined;
}

export class DogFoodOtSession extends React.Component<
    DogFoodOtSessionProps,
    DogFoodOtSessionState
> {
    private sessionHelper: SessionHelper;

    constructor(props: DogFoodOtSessionProps) {
        super(props);
        this.state = {
            connected: false,
            selectedSignal: props.signals[0].name,
        };
    }

    private handleOTConnected = (err: OTError) => {
        if (err) {
            this.setState({ connected: false });
        } else {
            this.setState({ connected: true });
        }
    };

    private onSignalSelect(value: string) {
        this.setState({ selectedSignal: value });
    }

    private sendSelectedSignal() {
        const { signals } = this.props;
        if (this.sessionHelper) {
            const signal = signals.find(
                (s) => s.name === this.state.selectedSignal,
            );
            const { method, args = [] } = signal || {};
            (
                this.sessionHelper[method as keyof SessionHelper] as (
                    ...params: unknown[]
                ) => unknown
            )(...args);
        }
    }

    public componentDidMount() {
        const { sessionId, otToken } = this.props;
        const tokBoxProjectKey = (config as Configuration).getConfig()
            .tokboxProjectKey;
        this.sessionHelper = new SessionHelper(
            {
                config: {
                    sessionId,
                    projectKey: tokBoxProjectKey,
                },
                sessionHandlers: {
                    onSessionConnected: () => console.log('onSessionConnected'),
                },
                signalingHandlers: {
                    onBotPromptMessage: () => console.log('onBotPromptMessage'),
                    onInstantMessage: () => console.log('onInstantMessage'),
                    onTypingStateChange: () =>
                        console.log('onTypingStateChange'),
                },
            },
            LogManager.getLogger().child(
                { eventSource: 'dogfood', sessionId, otToken },
                true,
            ),
        );
        this.sessionHelper.connect(otToken, this.handleOTConnected);
    }

    public render() {
        const { label, signals } = this.props;
        const { connected, selectedSignal } = this.state;

        return (
            <div className={styles.otSession}>
                <span className={styles.label}>{label}</span>
                <Select
                    onChange={(e) => this.onSignalSelect(e.target.value)}
                    value={selectedSignal}
                    variant="standard"
                >
                    {signals.map(({ name, label: signalLabel }) => (
                        <MenuItem key={name} value={name}>
                            {signalLabel}
                        </MenuItem>
                    ))}
                </Select>
                <Button
                    className={styles.sendButton}
                    onClick={() => this.sendSelectedSignal()}
                    disabled={!connected}
                    variant="text"
                    color="grey"
                >
                    Send
                </Button>
            </div>
        );
    }
}
