import * as React from 'react';
import Button from '@mui/material/Button';

import * as styles from './CopyButtonStyles.css';

const copyLink = (link?: string) => {
    if (!link) {
        return;
    }
    const el = document.createElement('textarea');
    el.value = link;
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
};

export const CopyButton = ({
    text,
    dataUiTest,
    isLink,
    label,
}: {
    text?: string;
    dataUiTest?: string;
    isLink?: boolean;
    label: string;
}) => {
    const onCopy = React.useCallback(() => copyLink(text), [text]);
    let targetText = <>{text}</>;
    if (isLink) {
        targetText = (
            <a
                data-uitest={dataUiTest}
                href={text}
                target="_blank"
                rel="noreferrer"
            >
                {targetText}
            </a>
        );
    }

    return (
        <>
            <span className={styles.linkType}>{label}</span>
            <Button onClick={onCopy} color="grey">
                Copy Link to Clipboard
            </Button>
            <div className={styles.linkDisplay}>
                <div className={styles.link}>{targetText}</div>
            </div>
        </>
    );
};
