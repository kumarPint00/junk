import * as React from 'react';
import { ConfirmationDialog } from '../ConfirmationDialog';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import { vi } from 'vitest';

describe('confirmation dialog component', () => {
    afterEach(() => {
        vi.resetAllMocks();
    });

    it.each([
        ['confirm', 'confirmation-dialog-confirm-button', 'confirm'],
        ['cancel', 'confirmation-dialog-cancel-button', 'cancel'],
    ])(
        'has a reasonable default text for the %s button',
        (_, testId, expected) => {
            render(
                <ConfirmationDialog
                    open
                    onCancel={vi.fn()}
                    onConfirm={vi.fn()}
                    onClose={vi.fn()}
                >
                    lorem ipsum
                </ConfirmationDialog>,
            );
            expect(screen.getByTestId(testId)).toHaveTextContent(expected);
        },
    );

    it.each([
        [
            'confirm',
            'confirmation-dialog-confirm-button',
            { confirmText: 'potato' },
            'potato',
        ],
        [
            'cancel',
            'confirmation-dialog-cancel-button',
            { cancelText: 'tomato' },
            'tomato',
        ],
    ])(
        'renders override text for the %s button',
        (_, testId, props, expected) => {
            render(
                <ConfirmationDialog
                    onCancel={vi.fn()}
                    onConfirm={vi.fn()}
                    onClose={vi.fn()}
                    open
                    {...props}
                >
                    lorem ipsum
                </ConfirmationDialog>,
            );
            expect(screen.getByTestId(testId)).toHaveTextContent(expected);
        },
    );

    it.each([
        ['confirm', 'confirmation-dialog-confirm-button', 'onConfirm'],
        ['cancel', 'confirmation-dialog-cancel-button', 'onCancel'],
    ])(
        'fires click handler for the %s button',
        async (_, testId, handler: string) => {
            const handlers = {
                [handler]: vi.fn(),
            };
            render(
                <ConfirmationDialog
                    onCancel={vi.fn()}
                    onConfirm={vi.fn()}
                    onClose={vi.fn()}
                    open
                    {...handlers}
                >
                    lorem ipsum
                </ConfirmationDialog>,
            );
            await userEvent.click(screen.getByTestId(testId));
            expect(handlers[handler]).toHaveBeenCalled();
        },
    );
});
