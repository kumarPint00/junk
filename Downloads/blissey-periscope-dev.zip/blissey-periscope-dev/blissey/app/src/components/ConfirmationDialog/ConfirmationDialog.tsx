import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import Button from '@mui/material/Button';

export interface ConfirmationDialogProps {
    onCancel: () => void;
    onConfirm: () => void;
    onClose: () => void;
    children: React.ReactChild;
    confirmText?: string;
    open?: boolean;
    loading?: boolean;
    cancelText?: string;
    ['data-testid']?: string;
}
export const ConfirmationDialog = ({
    children,
    onCancel,
    onConfirm,
    onClose,
    open = false,
    loading = false,
    confirmText = 'confirm',
    cancelText = 'cancel',
    ['data-testid']: dataTestId,
}: ConfirmationDialogProps) => {
    const dialogRef = React.useRef<HTMLDivElement>();
    return (
        <Dialog
            open={open}
            onClose={(_event, reason) => {
                if (reason !== 'backdropClick') {
                    onClose();
                }
            }}
            data-testid={dataTestId ?? 'confirmation-dialog'}
        >
            <DialogContent
                data-testid="confirmation-dialog-content"
                ref={dialogRef}
                tabIndex={0}
            >
                {children}
            </DialogContent>
            <DialogActions>
                <Button
                    data-testid="confirmation-dialog-cancel-button"
                    onClick={onCancel}
                    color="primary"
                    disabled={loading}
                >
                    {cancelText}
                </Button>
                <Button
                    data-testid="confirmation-dialog-confirm-button"
                    onClick={onConfirm}
                    color="primary"
                    disabled={loading}
                >
                    {confirmText}
                </Button>
            </DialogActions>
        </Dialog>
    );
};
