import { ConfirmationDialog } from '../ConfirmationDialog';
import { action } from '@storybook/addon-actions';

export default {
    title: 'Components/ConfirmationDialog',
    component: ConfirmationDialog,
    parameters: {
        fetchMock: {},
    },
};

export const Default = {
    args: {
        children:
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
        onCancel: action('onCancel'),
        onConfirm: action('onConfirm'),
        open: false,
    },
};
