import React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import {
    StatsHandlerProps,
    VideoStatistics,
    publisherStatsToReport,
    subscriberStatsToReport,
} from '../VideoStatistics';
import { shallow } from 'enzyme';
import { AudioVideoBreakdown } from '../AudioVideoBreakdown';
import { vi } from 'vitest';

const getProps = (
    overrides: Partial<StatsHandlerProps> = {},
): StatsHandlerProps => ({
    sessionId: 'testSessionId',
    userId: 'testUserId',
    userRoles: ['telehealth_provider'],
    visitId: 'testVisitId',
    getStats: vi.fn(),
    onClose: vi.fn(),
    onSubmitted: vi.fn(),
    ...overrides,
});

describe('<VideoStatistics />', () => {
    beforeEach(() => {
        vi.useFakeTimers();
    });

    afterEach(() => {
        vi.clearAllTimers();
        vi.useRealTimers();
    });
    it('renders', () => {
        const props = getProps();
        const { container } = render(<VideoStatistics {...props} />);
        expect(container).toMatchSnapshot();
    });

    it('renders error state', () => {
        //mock useState for rtcExpanded
        vi.spyOn(React, 'useState').mockReturnValue([false, vi.fn()]);

        //mock getStats so that it throws an error
        const getStatsMock = vi.fn().mockRejectedValue(new Error('Test error'));

        const props = getProps({ getStats: getStatsMock });
        const { container } = render(<VideoStatistics {...props} />);
        expect(container).toMatchSnapshot();
    });

    it('renders loading state', () => {
        //mock useState for loading state
        vi.spyOn(React, 'useState').mockReturnValue([true, vi.fn()]);

        const props = getProps();
        const { container } = render(<VideoStatistics {...props} />);
        expect(container).toMatchSnapshot();
    });

    it('toggles rtcExpanded state on button click', () => {
        const getStatsMock = vi.fn().mockResolvedValue({
            publisherStats: [],
            subscriberStats: [],
            rtcStats: [],
        });
        const { container, getByRole } = render(
            <VideoStatistics
                sessionId="testSessionId"
                userId="testUserId"
                userRoles={['telehealth_provider']}
                visitId="testVisitId"
                getStats={getStatsMock}
                onClose={() => {}}
                onSubmitted={() => {}}
            />,
        );
        const button = getByRole('button');
        fireEvent.click(button);
        expect(container).toMatchSnapshot();
    });

    it('sets subscriberStats to empty array when currStats.subscriberStats is falsy', async () => {
        const propsMock = {
            sessionId: 'testSessionId',
            userId: 'testUserId',
            userRoles: ['telehealth_provider'],
            visitId: 'testVisitId',
            getStats: vi.fn().mockResolvedValue({
                publisherStats: [], //empty array
                subscriberStats: undefined, //falsy value
                rtcStats: [],
            }),
            onClose: vi.fn(),
            onSubmitted: vi.fn(),
        };

        vi.spyOn(React, 'useState').mockReturnValueOnce([false, vi.fn()]);

        const wrapper = shallow(<VideoStatistics {...propsMock} />);
        await propsMock.getStats();
        wrapper.update();

        expect(wrapper).toMatchSnapshot();
    });

    it('filters and adds interested rtcStats to currRtcStats', () => {
        const interestedRtcTypes = ['remote-inbound-rtp', 'inbound-rtp'];
        const rtcStatsMock = [
            { type: 'remote-inbound-rtp', data: {} },
            { type: 'inbound-rtp', data: {} },
            { type: 'outbound-rtp', data: {} },
        ];

        const publisherRtcReport = {
            rtcStatsReport: rtcStatsMock,
        };

        const currRtcStats: unknown[] = [];

        publisherRtcReport.rtcStatsReport.forEach((rtc) => {
            if (rtc && interestedRtcTypes.includes(rtc.type)) {
                currRtcStats.push(rtc);
            }
        });

        expect(currRtcStats).toMatchSnapshot();
    });

    it('calls onSubmitted when onSubmitted is called', async () => {
        const onSubmittedMock = vi.fn();
        const props = getProps({
            onSubmitted: onSubmittedMock,
            getStats: vi.fn().mockResolvedValue({
                publisherStats: [],
                subscriberStats: [],
                rtcStats: [],
            }),
        });

        vi.useRealTimers();
        const { container } = render(<VideoStatistics {...props} />);

        await waitFor(() => {
            expect(screen.getByText('Submit Report')).toBeTruthy();
        });

        const submitButton = screen.getByText('Submit Report');
        fireEvent.click(submitButton);

        expect(container).toMatchSnapshot();
        expect(onSubmittedMock).toHaveBeenCalled();
    });
});

describe('subscriberStatsToReport', () => {
    const incomingTrackStatsMock = {
        bytesReceived: 1000,
        packetsLost: 5,
        packetsReceived: 150,
    };

    const subscriberStatsMock = {
        id: 'testId',
        connectionData: 'testConnectionData',
        stats: {
            audio: incomingTrackStatsMock,
            video: {
                ...incomingTrackStatsMock,
                frameRate: 30,
            },
            timestamp: 123456789,
        },
    };

    it('formats subscriberStats correctly', () => {
        const formattedStats = subscriberStatsToReport([subscriberStatsMock]);
        expect(formattedStats).toMatchSnapshot();
    });

    it('returns empty array when input is an empty array', () => {
        const result = subscriberStatsToReport([]);
        expect(result).toMatchSnapshot();
    });

    it('handles undefined subscriber', () => {
        const input = [undefined];
        const result = subscriberStatsToReport(input);
        expect(result).toMatchSnapshot();
    });

    it('handles subscriber with all data', () => {
        const input = [
            {
                id: 'subscriber1',
                stats: {
                    audio: {
                        bytesReceived: 1000,
                        packetsLost: 5,
                        packetsReceived: 150,
                    },
                    video: {
                        bytesReceived: 2000,
                        packetsLost: 10,
                        packetsReceived: 200,
                        frameRate: 30,
                    },
                    timestamp: 123456789,
                },
                connectionData: 'connection1',
            },
        ];
        const result = subscriberStatsToReport(input);
        expect(result).toMatchSnapshot();
    });

    it('handles subscriber with missing stats', () => {
        const input = [
            {
                id: 'subscriber1',
                connectionData: 'connection1',
            },
        ];
        const result = subscriberStatsToReport(input);
        expect(result).toMatchSnapshot();
    });

    it('handles subscriber with missing connectionData', () => {
        const input = [
            {
                id: 'subscriber1',
                stats: {
                    audio: {
                        bytesReceived: 1000,
                        packetsLost: 5,
                        packetsReceived: 150,
                    },
                    video: {
                        bytesReceived: 2000,
                        packetsLost: 10,
                        packetsReceived: 200,
                        frameRate: 30,
                    },
                    timestamp: 123456789,
                },
                connectionData: undefined,
            },
        ];
        const result = subscriberStatsToReport(input);
        expect(result).toMatchSnapshot();
    });

    it('handles subscriber with no data', () => {
        const input = [{}];
        const result = subscriberStatsToReport(input);
        expect(result).toMatchSnapshot();
    });
});

describe('publisherStatsToReport', () => {
    it('formats publisherStats correctly', () => {
        //mocked data
        const outgoingTrackStatsMock = {
            bytesSent: 1000,
            packetsLost: 5,
            packetsSent: 150,
        };

        //mocked publisherStats data
        const publisherStatsMock = [
            {
                connectionId: 'connection1',
                subscriberId: 'subscriber1',
                stats: {
                    audio: outgoingTrackStatsMock,
                    video: {
                        ...outgoingTrackStatsMock,
                        frameRate: 30,
                    },
                    timestamp: 123456789,
                },
            },
        ];

        //validate
        const formattedStats = publisherStatsToReport(publisherStatsMock);
        expect(formattedStats).toMatchSnapshot();
    });

    it('formats publisherStats with missing stats', () => {
        const publisherStatsMock = [
            {
                connectionId: 'connection1',
                subscriberId: 'subscriber1',
                stats: {
                    audio: {
                        bytesSent: 0,
                        packetsLost: 0,
                        packetsSent: 0,
                    },
                    video: {
                        bytesSent: 0,
                        packetsLost: 0,
                        packetsSent: 0,
                        frameRate: 0,
                    },
                    timestamp: 0,
                },
            },
        ];

        const formattedStats = publisherStatsToReport(publisherStatsMock);

        expect(formattedStats).toMatchSnapshot();
    });

    it('formats publisherStats with missing subscriberId', () => {
        const publisherStatsMock = [
            {
                connectionId: 'connection1',
                stats: {
                    audio: {
                        bytesSent: 1000,
                        packetsLost: 5,
                        packetsSent: 150,
                    },
                    video: {
                        bytesSent: 2000,
                        packetsLost: 10,
                        packetsSent: 200,
                        frameRate: 30,
                    },
                    timestamp: 123456789,
                },
            },
        ];

        const formattedStats = publisherStatsToReport(publisherStatsMock);

        expect(formattedStats).toMatchSnapshot();
    });

    it('formats publisherStats with missing connectionId', () => {
        const publisherStatsMock = [
            {
                subscriberId: 'subscriber1',
                stats: {
                    audio: {
                        bytesSent: 1000,
                        packetsLost: 5,
                        packetsSent: 150,
                    },
                    video: {
                        bytesSent: 2000,
                        packetsLost: 10,
                        packetsSent: 200,
                        frameRate: 30,
                    },
                    timestamp: 123456789,
                },
            },
        ];

        const formattedStats = publisherStatsToReport(publisherStatsMock);

        expect(formattedStats).toMatchSnapshot();
    });
});

describe('AudioVideoBreakdown', () => {
    const audioStatsMock = {
        bytesReceived: 1000,
        packetsLost: 5,
        packetsReceived: 150,
    };

    const videoStatsMock = {
        bytesReceived: 2000,
        packetsLost: 10,
        packetsReceived: 200,
        frameRate: 30,
    };

    const statsMock = {
        audio: audioStatsMock,
        video: videoStatsMock,
    };

    it('renders AudioVideoBreakdown component with both audioStats and videoStats', () => {
        const wrapper = shallow(
            <AudioVideoBreakdown
                audioStats={statsMock.audio}
                videoStats={statsMock.video}
                audioWarning=""
                videoWarning=""
            />,
        );

        expect(wrapper).toMatchSnapshot();
    });

    it('renders AudioVideoBreakdown component with only audioStats', () => {
        const statsMock = {
            audio: audioStatsMock,
            video: undefined,
        };

        const wrapper = shallow(
            <AudioVideoBreakdown
                audioStats={statsMock.audio}
                videoStats={statsMock.video}
                audioWarning=""
                videoWarning=""
            />,
        );

        expect(wrapper).toMatchSnapshot();
    });

    it('renders AudioVideoBreakdown component with only videoStats', () => {
        const statsMock = {
            audio: undefined,
            video: videoStatsMock,
        };

        const wrapper = shallow(
            <AudioVideoBreakdown
                audioStats={statsMock.audio}
                videoStats={statsMock.video}
                audioWarning=""
                videoWarning=""
            />,
        );

        expect(wrapper).toMatchSnapshot();
    });

    it('renders AudioVideoBreakdown component without both audioStats and videoStats', () => {
        const statsMock = {
            audio: undefined,
            video: undefined,
        };

        const wrapper = shallow(
            <AudioVideoBreakdown
                audioStats={statsMock.audio}
                videoStats={statsMock.video}
                audioWarning=""
                videoWarning=""
            />,
        );

        expect(wrapper).toMatchSnapshot();
    });

    it('renders AudioVideoBreakdown component without audioStats and videoStats', () => {
        const wrapper = shallow(
            <AudioVideoBreakdown
                audioStats={undefined}
                videoStats={undefined}
                audioWarning=""
                videoWarning=""
            />,
        );

        expect(wrapper).toMatchSnapshot();
    });

    it('renders AudioVideoBreakdown components for each subscriber', () => {
        const subscriberStatsMock = [
            {
                id: 'subscriber1',
                stats: {
                    audio: {
                        bytesReceived: 1000,
                        packetsLost: 5,
                        packetsReceived: 150,
                    },
                    video: {
                        bytesReceived: 2000,
                        packetsLost: 10,
                        packetsReceived: 200,
                        frameRate: 30,
                    },
                },
            },
        ];

        const wrapper = shallow(
            <div>
                {subscriberStatsMock.map(({ id, stats }) => (
                    <AudioVideoBreakdown
                        key={`subscriber-${id}`}
                        audioStats={stats?.audio}
                        videoStats={stats?.video}
                        audioWarning=""
                        videoWarning=""
                    />
                ))}
            </div>,
        );

        expect(wrapper).toMatchSnapshot();
    });

    it('renders AudioVideoBreakdown components for each rtcStats', () => {
        //mock rtcStats data
        const rtcStatsMock = [
            {
                subscriberId: 'subscriber1',
                connectionId: 'connection1',
                type: 'remote-inbound-rtp',
            },
        ];

        const wrapper = shallow(
            <div>
                {rtcStatsMock.map((rtc) => (
                    <AudioVideoBreakdown
                        key={`${rtc.subscriberId}-${rtc.connectionId}`}
                        audioStats={undefined}
                        videoStats={undefined}
                        audioWarning=""
                        videoWarning=""
                    />
                ))}
            </div>,
        );

        expect(wrapper).toMatchSnapshot();
    });
});
