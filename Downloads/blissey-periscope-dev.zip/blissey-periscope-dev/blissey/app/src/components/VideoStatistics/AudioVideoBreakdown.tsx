import * as React from 'react';
import { IncomingTrackStats, OutgoingTrackStats } from '@dexcare/yak';
import SnackbarContent from '@mui/material/SnackbarContent';

type Stats = OutgoingTrackStats | IncomingTrackStats | undefined;

const StatsList = ({
    stat,
    titleKey,
    warning,
}: {
    stat: Record<string, string | number | React.ReactNode>;
    titleKey: 'audio' | 'video';
    warning?: string;
}) => (
    <>
        <h6>{titleKey} stats</h6>
        {warning && <SnackbarContent message={warning} />}
        <ul>
            {Object.keys(stat).map((key) => (
                <li key={`${key}`}>
                    {key}:{' '}
                    {typeof stat[key] === 'number'
                        ? stat[key]
                        : 'unsupported type'}
                </li>
            ))}
        </ul>
    </>
);

export const AudioVideoBreakdown = ({
    audioStats,
    videoStats,
    audioWarning,
    videoWarning,
}: {
    audioStats: Stats;
    videoStats: Stats;
    audioWarning?: string;
    videoWarning?: string;
}) => {
    return (
        <>
            <StatsList
                titleKey={'audio'}
                stat={audioStats || {}}
                warning={audioWarning}
            />
            <StatsList
                titleKey={'video'}
                stat={videoStats || {}}
                warning={videoWarning}
            />
        </>
    );
};
