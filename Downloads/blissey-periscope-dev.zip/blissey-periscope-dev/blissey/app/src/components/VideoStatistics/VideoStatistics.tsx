import * as React from 'react';
import CancelIcon from '@mui/icons-material/Cancel';
import CircularProgress from '@mui/material/CircularProgress';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
    PublisherRtcStatsReportArr,
    PublisherStatsArr,
    SubscriberStats,
} from '@dexcare/yak';

import { ErrorBoundary } from '@components/ErrorBoundary/ErrorBoundary';
import { reportError as sendErrorReport } from '@services/reportError';
import { AudioVideoBreakdown } from './AudioVideoBreakdown';
import { Button } from '@components/Button';
import { getWarningMessage } from '@common/videoStatisticsErrorMessages';

import * as styles from './VideoStatistics.css';

const { useEffect, useState, useCallback } = React;

export interface BlisseySubscriberStats {
    stats?: SubscriberStats;
    id?: string;
    connectionData?: string;
}

export interface VideoStats {
    publisherStats: PublisherStatsArr;
    subscriberStats: (BlisseySubscriberStats | undefined)[];
    rtcStats: PublisherRtcStatsReportArr;
}

export interface StatsHandlerProps {
    sessionId: string;
    userId: string;
    userRoles: string[];
    visitId: string;
    getStats: () => Promise<VideoStats>;
    onClose: () => void;
    onSubmitted: () => void;
}

const interestedRtcTypes = [
    'remote-inbound-rtp',
    'outbound-rtp',
    'track',
    'media-source',
];

export function subscriberStatsToReport(
    subscriberStats: (BlisseySubscriberStats | undefined)[],
) {
    return subscriberStats.map((subscriber) => {
        const {
            id,
            stats: { audio = {}, video = {} } = {},
            connectionData,
        } = subscriber || {};
        return {
            subscriberId: id,
            connectionData,
            stats: {
                audio,
                video,
            },
        };
    });
}

export function publisherStatsToReport(publisherStats: PublisherStatsArr) {
    return publisherStats.map((publisher) => {
        const {
            connectionId,
            subscriberId,
            stats: { audio = {}, video = {} } = {},
        } = publisher || {};
        return {
            connectionId,
            subscriberId,
            stats: {
                audio,
                video,
            },
        };
    });
}

const muiStyles = {
    closeButtonRoot: {
        color: '#212121',
        width: '100px',
        justifyContent: 'space-around',
    },
    submitButtonRoot: {
        width: '165px',
        height: '36px',
    },
};

interface RtcStat {
    type?: string;
    subscriberId?: string;
    connectionId?: string;
}

export const VideoStatistics = ({
    sessionId,
    userId,
    userRoles,
    visitId,
    getStats,
    onClose,
    onSubmitted,
}: StatsHandlerProps) => {
    const [publisherStats, setPublisherStats] = useState<PublisherStatsArr>([]);
    const [subscriberStats, setSubscriberStats] = useState<
        (BlisseySubscriberStats | undefined)[]
    >([]);
    // rtc stats report does not have typings at this time
    const [rtcStats, setRtcStats] = useState<(RtcStat | string)[]>([]);
    const [rtcExpanded, setRTCExpanded] = useState(false);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    const handleRtcExpandedChange = () => {
        setRTCExpanded((prev) => !prev);
    };
    useEffect(() => {
        const getSetStats = async () => {
            setError('');
            try {
                const currStats = await getStats();
                if (!currStats) {
                    throw new Error('stats undefined');
                } else {
                    setPublisherStats(currStats.publisherStats || []);
                    setSubscriberStats(currStats.subscriberStats || []);

                    const currRtcStats: RtcStat[] = [];
                    const publisherRtcReport = (currStats.rtcStats || [])[0];
                    if (publisherRtcReport?.rtcStatsReport) {
                        publisherRtcReport.rtcStatsReport.forEach(
                            (rtc: RtcStat & { type: string }) => {
                                if (interestedRtcTypes.includes(rtc?.type)) {
                                    currRtcStats.push(rtc);
                                }
                            },
                        );
                    }
                    setRtcStats(currRtcStats || []);
                }
            } catch (err) {
                setError((err as Error)?.message || 'error');
            } finally {
                setLoading(false);
            }
        };

        void getSetStats();
        const interval = setInterval(() => void getSetStats(), 5000);
        return () => {
            clearInterval(interval);
        };
    }, [getStats]);

    const reportError = useCallback(() => {
        sendErrorReport({
            visitId,
            sessionId,
            userId,
            userRoles,
            details: {
                publisherStats: publisherStatsToReport(publisherStats),
                subscriberStats: subscriberStatsToReport(subscriberStats),
                rtcReport: rtcStats,
            },
        });
        onSubmitted();
    }, [
        visitId,
        sessionId,
        userId,
        userRoles,
        publisherStats,
        subscriberStats,
        rtcStats,
        onSubmitted,
    ]);

    const renderContent = () => {
        if (loading) {
            return (
                <div>
                    <CircularProgress size={50} />
                </div>
            );
        }

        if (error) {
            return <p>{error}</p>;
        }

        return (
            <>
                <div className={styles.content}>
                    <h5>publisher (your outgoing video and audio)</h5>
                    {publisherStats.map(
                        ({ stats: { audio, video, timestamp } }) => (
                            <AudioVideoBreakdown
                                key={`publisher-${timestamp}`}
                                audioStats={audio}
                                videoStats={video}
                                audioWarning={getWarningMessage({
                                    packetsLost: audio.packetsLost,
                                    packetsSucceeded: audio.packetsSent,
                                })}
                                videoWarning={getWarningMessage({
                                    packetsLost: video.packetsLost,
                                    packetsSucceeded: video.packetsSent,
                                })}
                            />
                        ),
                    )}
                    <br />
                    <h5>
                        subscriber (incoming video and audio qualities from your
                        perspective)
                    </h5>
                    {subscriberStats.map(({ id, stats } = {}) => (
                        <div key={`subscriber-${id as string}`}>
                            <AudioVideoBreakdown
                                audioStats={stats?.audio}
                                videoStats={stats?.video}
                                audioWarning={getWarningMessage({
                                    packetsLost: stats?.audio.packetsLost || 0,
                                    packetsSucceeded:
                                        stats?.audio.packetsReceived || 0,
                                })}
                                videoWarning={getWarningMessage({
                                    packetsLost: stats?.video.packetsLost || 0,
                                    packetsSucceeded:
                                        stats?.video.packetsReceived || 0,
                                })}
                            />
                        </div>
                    ))}
                    <br />
                    <Accordion
                        expanded={rtcExpanded}
                        onChange={handleRtcExpandedChange}
                    >
                        <AccordionSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls={'rtc-stats-content'}
                            id={'rtcStats-header'}
                        >
                            Advanced - RTC Stats
                        </AccordionSummary>
                        {(rtcStats as RtcStat[]).map((rtc) => (
                            <AccordionDetails
                                key={`${rtc.subscriberId}-${rtc.connectionId}`}
                            >
                                <h6>type: {rtc.type}</h6>
                                <ul>
                                    {Object.keys(rtc).map(
                                        (r: keyof RtcStat) => (
                                            <ErrorBoundary
                                                key={`${rtc.subscriberId}-${rtc.connectionId}`}
                                            >
                                                <li
                                                    className={styles.listItem}
                                                    key={r}
                                                >
                                                    <span
                                                        className={styles.key}
                                                    >
                                                        {r}:
                                                    </span>
                                                    {typeof rtc[r] === 'object'
                                                        ? JSON.stringify(rtc[r])
                                                        : rtc[r]}
                                                </li>
                                            </ErrorBoundary>
                                        ),
                                    )}
                                </ul>
                            </AccordionDetails>
                        ))}
                    </Accordion>
                </div>
                <div className={styles.footer}>
                    <Button
                        onClick={reportError}
                        sx={muiStyles.submitButtonRoot}
                    >
                        Submit Report
                    </Button>
                </div>
            </>
        );
    };

    return (
        <>
            <ErrorBoundary>
                <div className={styles.container}>
                    <div className={styles.header}>
                        <p className={styles.headerText}>Video Reporting</p>
                        <Button
                            onClick={onClose}
                            variant={'text'}
                            sx={muiStyles.closeButtonRoot}
                        >
                            Close <CancelIcon />
                        </Button>
                    </div>
                    {renderContent()}
                </div>
            </ErrorBoundary>
        </>
    );
};
