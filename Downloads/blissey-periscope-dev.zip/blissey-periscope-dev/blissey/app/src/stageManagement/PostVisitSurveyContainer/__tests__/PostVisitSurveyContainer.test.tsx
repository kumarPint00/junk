import { UserDetails } from '@dexcare/circus-saturn';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import React from 'react';
import { vi } from 'vitest';
import configureMockStore from 'redux-mock-store';
import thunk from '@redux/middleware/thunkShim';
import { Provider } from 'react-redux';
import {
    PostVisitSurveyContainer,
    PostVisitSurveyContainerComponent,
    Props,
} from '../PostVisitSurveyContainer';
import * as ReactRouter from 'react-router-dom';
import { withRouter } from '@common/withRouter';

const middlewares = [thunk];
const mockStore = configureMockStore(middlewares);

const store = mockStore({
    postconsult: {
        visitId: 'testvisitid',
        isTestVisit: false,
        videoConferenceId: 'testvideoconferenceid',
        conferenceSessionId: 'testconferenceSessionId',
        callStartTime: 1526447801,
        callEndTime: 1526448101,
    },
});

const testUserDetails: UserDetails = {
    id: 'testUserId',
    displayName: 'testDisplayName',
    givenName: 'testGivenName',
    familyName: 'testFamilyName',
    email: 'textEmail',
    token: 'testToken',
    expiration: 0,
};

const testState = {
    postconsult: {
        visitId: 'testvisitid',
        isTestVisit: false,
        videoConferenceId: 'testvideoconferenceid',
        conferenceSessionId: 'testconferenceSessionId',
        callStartTime: 1526447801,
        callEndTime: 1526448101,
    } as unknown as Omit<Props, 'router' | 'userDetails' | 'brand'>,
};

const params = { visitId: 'testVisitId' };

vi.mock('react-router-dom', async () => {
    const original = await vi.importActual('react-router-dom');
    return {
        ...(original as object),
        useLocation: vi.fn().mockReturnValue({}),
        useNavigate: vi.fn().mockReturnValue(vi.fn()),
    };
});

describe('PostVisitSurveyContainer', () => {
    let props: Props;

    beforeEach(() => {
        props = {
            userId: 'testUserId',
            visitId: 'testVisitId',
            userDetails: { id: 'testUserId', roles: [] },
            isTestVisit: false,
            brand: 'providence',
            fetchVisitDetailsByVisitId: vi.fn(),
            fetchTestVisitDetailsByVisitId: vi.fn(),
        } as unknown as Props;
    });

    test('Providence brand', () => {
        const component = shallow(
            <Provider store={store}>
                <PostVisitSurveyContainer
                    userDetails={testUserDetails}
                    brand={'providence'}
                    {...testState.postconsult}
                />
            </Provider>,
        );
        expect(toJson(component)).toMatchSnapshot();
    });

    test('Swedish brand', () => {
        const component = shallow(
            <Provider store={store}>
                <PostVisitSurveyContainer
                    userDetails={testUserDetails}
                    brand={'swedish'}
                    {...testState.postconsult}
                />
            </Provider>,
        );
        expect(toJson(component)).toMatchSnapshot();
    });

    test('render', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const component = shallow(<PostVisitSurveyContainer {...props} />);
        expect(toJson(component)).toMatchSnapshot();
    });

    test('render with userType telehealth_provider', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        props.userDetails.roles = ['telehealth_provider'];
        const WrappedComponent = withRouter(
            PostVisitSurveyContainer,
        ) as React.ComponentClass<Props, unknown>;
        const component = shallow(<WrappedComponent {...props} />);
        expect(toJson(component)).toMatchSnapshot();
        expect(component.find(PostVisitSurveyContainer)).toHaveLength(1);
    });

    test('render with userType telehealth_patient', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        props.userDetails.roles = ['telehealth_patient'];
        const WrappedComponent = withRouter(
            PostVisitSurveyContainer,
        ) as React.ComponentClass<Props, unknown>;
        const component = shallow(<WrappedComponent {...props} />);
        expect(toJson(component)).toMatchSnapshot();
        expect(component.find(PostVisitSurveyContainer)).toHaveLength(1);
    });

    test('componentDidMount', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            PostVisitSurveyContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const component = shallow(<WrappedComponent {...props} />).dive();
        component.instance().componentDidMount?.();
        expect(props.fetchVisitDetailsByVisitId).toHaveBeenCalledWith(
            'testVisitId',
            false,
        );
    });

    test('should set visitId from params.visitId', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            PostVisitSurveyContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const component = shallow(<WrappedComponent {...props} />).dive();

        expect(
            (
                component.instance() as React.Component<
                    object,
                    object,
                    object
                > & { visitId: string }
            ).visitId,
        ).toEqual('testVisitId');
    });

    test('should call fetchVisitDetailsByVisitId with visitId and userType provider', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            PostVisitSurveyContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const component = shallow(<WrappedComponent {...props} />).dive();
        component.instance().componentDidMount?.();
        expect(props.fetchVisitDetailsByVisitId).toHaveBeenCalledWith(
            'testVisitId',
            false,
        );
    });

    test('should call fetchVisitDetailsByVisitId with visitId and userType patient', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            PostVisitSurveyContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        props.userDetails.roles = ['telehealth_patient'];
        const component = shallow(<WrappedComponent {...props} />).dive();
        component.instance().componentDidMount?.();
        expect(props.fetchVisitDetailsByVisitId).toHaveBeenCalledWith(
            'testVisitId',
            false,
        );
    });

    test('should grab visitId from params.visitId', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            PostVisitSurveyContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const component = shallow(<WrappedComponent {...props} />).dive();
        expect(
            (
                component.instance() as React.Component<
                    object,
                    object,
                    object
                > & { visitId: string }
            ).visitId,
        ).toEqual('testVisitId');
    });

    test('should render CircularProgress if visitId is not defined', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            PostVisitSurveyContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        props.visitId = '';
        const component = shallow(<WrappedComponent {...props} />).dive();
        expect(toJson(component)).toMatchSnapshot();
    });
});
