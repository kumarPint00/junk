import * as React from 'react';
import { LogManager, Logger } from '@dexcare/circus-jupiter';
import { InactivityTimer } from '@common/InactivityTimer';
import {
    OwnProps,
    StateProps,
    State,
    DispatchProps,
} from './PostVisitSurveyInterfaces';

import * as styles from './PostVisitSurveyContainer.css';
import PostVisitProviderSurvey from '@components/PostVisitProviderSurvey/PostVisitProviderSurvey';
import PostVisitPatientSurvey from '@components/PostVisitPatientSurvey/PostVisitPatientSurvey';
import { endRoute } from '@utils/getRoutes';
import { UserType } from '../../../src/data/UserType';
import * as Redux from 'react-redux';
import { ThunkDispatch } from 'types/redux';
import { fetchVisitDetailsByVisitId, TState } from '@redux/modules/postConsult';
import { Store } from '../../redux/modules';
import { Action } from 'redux';
import { isProvider } from '@dexcare/circus-saturn';
import { FooterPage } from '@layout/PageLayout/FooterPage';
import { CircularProgress } from '@mui/material';
import { withRouter, RouterProps } from '../../common/withRouter';

export type Props = OwnProps &
    StateProps &
    DispatchProps &
    RouterProps<{ visitId: string }>;

const mapStateToProps = (state: Store['All']): StateProps => {
    return {
        visitId: state.postconsult.visitId,
        patientGuid: state.postconsult.patientGuid,
        providerId: state.postconsult.providerId,
        callStartTime: state.postconsult.callStartTime,
        callEndTime: state.postconsult.callEndTime,
        isTestVisit: state.postconsult.isTestVisit,
    };
};

const mapDispatchToProps: Redux.MapDispatchToPropsParam<
    ThunkDispatch<TState | Store['All'], unknown, Action>,
    OwnProps
> = (dispatch: ThunkDispatch<TState | Store['All'], unknown, Action>) => {
    return {
        fetchVisitDetailsByVisitId: async (
            visitId: string,
            isProvider: boolean,
        ) =>
            dispatch(
                fetchVisitDetailsByVisitId({
                    visitId,
                    isProvider,
                    isSurvey: true,
                }),
            ),
    };
};

export class PostVisitSurveyContainerComponent extends React.Component<
    Props,
    State
> {
    private logger: Logger;
    userType: UserType;
    visitId: string;

    constructor(props: Props) {
        super(props);

        //visitId from the URL
        this.visitId = this.props.router.params.visitId || 'default';

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'PostVisitSurveyStageContainer',
                userId: props.userDetails.id,
                visitId: props.visitId,
                isTestVisit: props.isTestVisit,
            },
            true,
        );

        this.userType = isProvider(this.props.userDetails)
            ? UserType.Provider
            : UserType.Patient;
    }

    public render() {
        const { visitId } = this.props;

        let survey;

        if (visitId) {
            if (this.userType === UserType.Provider) {
                survey = (
                    <PostVisitProviderSurvey
                        submit={this.onEndRoute}
                        skip={this.onSkipClick}
                        visitId={visitId}
                    />
                );
            } else {
                survey = (
                    <PostVisitPatientSurvey
                        submit={this.onEndRoute}
                        visitId={visitId}
                    />
                );
            }
        } else {
            survey = (
                <div className={styles.isLoading}>
                    <CircularProgress size={40} />
                </div>
            );
        }

        return (
            <div className={styles.footerContainer}>
                <FooterPage>
                    <div className={styles.content}>
                        <div className={styles.main}>{survey}</div>
                    </div>
                </FooterPage>
            </div>
        );
    }

    public componentDidMount() {
        this.logger.info({
            visitId: this.props.visitId,
            eventType: 'pageView',
        });

        this.props.fetchVisitDetailsByVisitId(
            this.visitId,
            this.userType == UserType.Provider,
        );

        InactivityTimer.attachTimeout();
    }

    public componentWillUnmount() {
        InactivityTimer.detachTimeout();
    }

    public onEndRoute = (): void => {
        this.props.router.navigate(endRoute(this.props.brand));
    };

    private onSkipClick = (): void => {
        this.onEndRoute();
        window.close();
    };
}

const PostVisitSurveyContainer = withRouter<OwnProps>(
    Redux.connect<StateProps, DispatchProps, OwnProps>(
        mapStateToProps,
        mapDispatchToProps,
    )(PostVisitSurveyContainerComponent),
);

export { PostVisitSurveyContainer };
