import { UserDetails } from '@dexcare/circus-saturn';

import { PaymentStatus } from '@redux/utils/PaymentStatus';

export interface OwnProps {
    brand: string;
    userDetails: UserDetails;
}

export interface StateProps {
    isTestVisit: boolean;
    chargedStatus: PaymentStatus;
    patientGuid: string;
}

export interface DispatchProps {
    chargeVisit(visitId: string): Promise<void>;
    waiveVisit(visitId: string, waiveReason: string): Promise<void>;
}

export interface State {
    snackError: unknown;
    requesting: boolean;
}
