import * as React from 'react';
import * as Redux from 'react-redux';
import { Action } from 'redux';

import { LogManager, Logger } from '@dexcare/circus-jupiter';
import { ErrorSnackbar } from '@components/ErrorSnackbar';

import {
    postConsultRoute,
    postVisitPatientSurveyRoute,
    postVisitProviderSurveyRoute,
} from '@utils/getRoutes';
import { PaymentStatus } from '@redux/utils/PaymentStatus';
import { FooterPage } from '../../layout/PageLayout/FooterPage';
import {
    OwnProps,
    StateProps,
    DispatchProps,
    State,
} from './PaymentStageContainerInterfaces';
import { Store } from '@redux/modules';
import { TState, chargeVisit, waiveVisit } from '@redux/modules/postConsult';
import { PaymentModule } from '@modules/Payment/PaymentModule';
import { submitGTMPageViewEvent } from '@services/analytics';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { ThunkDispatch } from 'types/redux';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import { isProvider } from '@dexcare/circus-saturn';
import { withRouter, RouterProps } from '../../common/withRouter';

export type Props = OwnProps &
    StateProps &
    DispatchProps &
    RouterProps<{ visitId: string }>;

const mapStateToProps = (state: Store['All']): StateProps => {
    const { isTestVisit, chargedStatus, patientGuid } = state.postconsult;
    return {
        isTestVisit,
        chargedStatus,
        patientGuid,
    };
};

const mapDispatchToProps: Redux.MapDispatchToPropsParam<
    ThunkDispatch<TState, unknown, Action>,
    OwnProps
> = (dispatch: ThunkDispatch<TState, unknown, Action>) => {
    return {
        chargeVisit: async (visitId: string) => dispatch(chargeVisit(visitId)),
        waiveVisit: async (visitId: string, waiveReason: string) =>
            dispatch(waiveVisit(visitId, waiveReason)),
    };
};

/**
 * @deprecated
 */
export class PaymentStageContainerComponent extends React.Component<
    Props,
    State
> {
    private logger: Logger;

    private missingWaiveReason = 'Please select a reason for waive.';

    public state = {
        snackError: {
            active: false,
            message: '',
            allowContinue: false,
        },
        requesting: false,
    };

    constructor(props: Props) {
        super(props);
        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'PaymentStateContainer',
                isTestVisit: props.isTestVisit,
                visitId: props.router.params.visitId,
            },
            true,
        );
    }

    private isProvider = () => {
        return isProvider(this.props.userDetails);
    };

    private handleWaive = (reason: string) => {
        const { router, waiveVisit: propsWaiveVisit } = this.props;
        if (!reason) {
            this.setState({
                snackError: { active: true, message: this.missingWaiveReason },
            });
        } else {
            V2Analytics.interactionEvent({
                eventName: 'waive_visit',
                reason,
                patient_id: this.props.patientGuid,
                visit_id: router.params.visitId,
            });
            void this.handlePaymentRequest(
                propsWaiveVisit,
                router.params.visitId,
                reason,
            );
        }
    };

    private handleCharge = () => {
        const { router, chargeVisit: propsChargeVisit } = this.props;
        V2Analytics.interactionEvent({
            eventName: 'charge_visit',
            patient_id: this.props.patientGuid,
            visit_id: router.params.visitId,
        });
        void this.handlePaymentRequest(propsChargeVisit, router.params.visitId);
    };

    private handlePaymentRequest = async (
        action: (...args: string[]) => Promise<void>,
        ...params: string[]
    ) => {
        const { isTestVisit } = this.props;
        try {
            if (!isTestVisit) {
                await action(...params);
            }
            this.goToNextPage();
        } catch (error) {
            this.logger.error('Failed to process payment' + error);
        }
    };

    private clearSnack = () => {
        this.setState({
            snackError: {
                active: false,
            },
        });
    };

    private goToNextPage = () => {
        const enablePostVisitSurveyConfig = getFeatureFlag(
            FeatureFlags.enablePostVisitSurveyConfig,
        );

        const { brand, router } = this.props;

        if (enablePostVisitSurveyConfig) {
            if (this.isProvider()) {
                router.navigate(
                    postVisitProviderSurveyRoute(router.params.visitId, brand),
                );
            } else {
                router.navigate(
                    postVisitPatientSurveyRoute(router.params.visitId, brand),
                );
            }
        } else {
            router.navigate(postConsultRoute(router.params.visitId, brand));
        }
    };

    public componentDidMount() {
        const { router } = this.props;
        this.logger.info({
            details: {
                userRoles: this.props.userDetails.roles,
            },
            eventType: 'pageView',
        });
        submitGTMPageViewEvent(router.params.visitId);
    }

    public render() {
        const { chargedStatus, router } = this.props;
        const { snackError, requesting } = this.state;
        const header =
            chargedStatus === PaymentStatus.none
                ? 'How should we process this visit?'
                : '';
        return (
            <FooterPage headerText={header}>
                <PaymentModule
                    handleWaive={this.handleWaive}
                    handleCharge={this.handleCharge}
                    chargedStatus={chargedStatus}
                    handleContinue={this.goToNextPage}
                    disabled={requesting}
                    visitId={router.params.visitId}
                />
                {
                    <ErrorSnackbar
                        open={snackError.active}
                        message={snackError.message}
                        onClose={this.clearSnack}
                        onDismiss={this.clearSnack}
                        type={'payment'}
                    />
                }
            </FooterPage>
        );
    }
}

const PaymentStageContainer = withRouter<OwnProps>(
    Redux.connect<StateProps, DispatchProps, OwnProps>(
        mapStateToProps,
        mapDispatchToProps,
    )(PaymentStageContainerComponent),
);

export { PaymentStageContainer };
