import React from 'react';
import { PaymentStageContainer } from '../PaymentStageContainer';
import { PaymentStatus } from '@redux/utils/PaymentStatus';
import { UserDetails } from '@dexcare/circus-saturn';
import { BrowserRouter } from 'react-router-dom';
import { Provider, ProviderProps } from 'react-redux';
import { Action, applyMiddleware, createStore } from 'redux';
import { rootReducer } from '@redux/modules/index';
import { ThunkDispatch } from 'types/redux';
import { Store } from '@redux/modules';
import thunkShim from '@redux/middleware/thunkShim';

export default {
    title: 'Stage Containers/Payment',
};

type MockStoreType = Omit<ProviderProps['store'], 'dispatch'> & {
    dispatch: ThunkDispatch<Store['All'], unknown, Action>;
};

const testState = {
    postconsult: {
        isTestVisit: true,
        patientGuid: 'patientGuid',
        chargedStatus: PaymentStatus.none,
    },
};

const mockStore: MockStoreType = createStore(
    rootReducer as any,
    testState as any,
    applyMiddleware(thunkShim as any),
) as any;

export const Default = () => {
    return (
        <Provider store={mockStore}>
            <BrowserRouter>
                <PaymentStageContainer
                    brand={'test'}
                    userDetails={
                        { roles: ['telehealth_provider'] } as UserDetails
                    }
                />
            </BrowserRouter>
        </Provider>
    );
};
