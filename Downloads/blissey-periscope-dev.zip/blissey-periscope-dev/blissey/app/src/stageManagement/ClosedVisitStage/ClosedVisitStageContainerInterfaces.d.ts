import { UserDetails } from '@dexcare/circus-saturn';

export interface OwnProps {
    brand: string;
    userDetails: UserDetails;
}

export interface StateProps {
    visitId: string;
}
