import * as React from 'react';
import * as Redux from 'react-redux';

import { LogManager, Logger } from '@dexcare/circus-jupiter';
import { submitGTMPageViewEvent } from '@services/analytics';

import { Store } from '../../redux/modules';
import { ClosedVisitModule } from '../../modules/ClosedVisit/ClosedVisitModule';
import { InactivityTimer } from '../../common/InactivityTimer';
import { OwnProps, StateProps } from './ClosedVisitStageContainerInterfaces';

import * as styles from './ClosedVisitStageContainer.css';
import { withRouter, RouterProps } from '../../common/withRouter';
import { VisitStatus } from '@clients/VisitService/VisitInterfaces';

const mapStateToProps = (state: Store['All']): StateProps => {
    return {
        visitId: state.postconsult.visitId,
    };
};

type Props = OwnProps & StateProps & RouterProps<{ closedReason: VisitStatus }>;

class ClosedVisitStageContainerComponent extends React.Component<Props> {
    private logger: Logger;

    constructor(props: Props) {
        super(props);

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'ClosedVisitStageContainer',
                userId: props.userDetails.id,
            },
            true,
        );
    }

    public render() {
        const closeReasonCode = this.props.router.params.closedReason;

        return (
            <div className={styles.main}>
                <ClosedVisitModule
                    closedReason={closeReasonCode}
                    visitId={this.props.visitId}
                />
            </div>
        );
    }

    public componentDidMount() {
        this.logger.info({
            eventType: 'pageView',
            visitId: this.props.visitId,
            details: {
                closedReason: this.props.router.params.closedReason,
            },
        });
        submitGTMPageViewEvent(this.props.visitId);

        InactivityTimer.attachTimeout();
    }

    public componentWillUnmount() {
        InactivityTimer.detachTimeout();
    }
}

const ClosedVisitStageContainer = withRouter<OwnProps>(
    Redux.connect<StateProps, OwnProps>(mapStateToProps)(
        ClosedVisitStageContainerComponent,
    ),
);

export { ClosedVisitStageContainer };
