import { UserDetails } from '@dexcare/circus-saturn';

export interface OwnProps {
    userDetails: UserDetails;
}

export interface StateProps {
    visitId: string;
    skipTimers?: boolean;
}
