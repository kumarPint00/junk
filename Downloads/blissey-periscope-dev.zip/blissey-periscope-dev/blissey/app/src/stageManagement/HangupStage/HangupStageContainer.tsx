import * as React from 'react';
import * as Redux from 'react-redux';

import { Store } from '@redux/modules';
import { HangupModule } from '@modules/Hangup/HangupModule';
import { InactivityTimer } from '@common/InactivityTimer';
import { TokenExpiryTimer } from '@common/TokenExpiryTimer';
import { VisitSummaryModule } from '@modules/VisitSummary/VisitSummaryModule';

import { LogManager, Logger, location } from '@dexcare/circus-jupiter';
import { isProvider } from '@dexcare/circus-saturn';
import { submitGTMPageViewEvent } from '@services/analytics';
import { StageId } from '../StageId';

import { OwnProps, StateProps } from './HangupStageContainerInterfaces';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import * as styles from './HangupStageContainer.css';
import { getExitSurveyInterface } from '@common/getExitSurveyInterface';
import { withRouter, RouterProps } from '../../common/withRouter';

const mapStateToProps = (state: Store['All']): StateProps => {
    return {
        visitId: state.postconsult.visitId,
    };
};

export type Props = OwnProps & StateProps & RouterProps;

/** session stage container, shown after call is terminated */
export class HangupStageContainerComponent extends React.PureComponent<Props> {
    private logger: Logger;

    constructor(props: Props) {
        super(props);

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'HangupStageContainer',
                userId: props.userDetails.id,
            },
            true,
        );
    }

    public render() {
        const { userDetails } = this.props;
        const endModule = isProvider(userDetails) ? (
            <HangupModule userDetails={userDetails} />
        ) : (
            <VisitSummaryModule
                onSignOut={this.signOutPatient}
                visitId={this.props.visitId}
            />
        );
        return <div className={styles.main}>{endModule}</div>;
    }

    public componentDidMount() {
        this.logger.info({
            visitId: this.props.visitId,
            eventType: 'pageView',
        });
        submitGTMPageViewEvent(this.props.visitId);

        if (!this.props.skipTimers) {
            if (!isProvider(this.props.userDetails)) {
                InactivityTimer.attachTimeout();
            }
            TokenExpiryTimer.attachTimeout(
                Number(this.props.userDetails.expiration.toString()),
                StageId.Hangup,
                '',
            );
        }
    }

    public componentWillUnmount() {
        if (!this.props.skipTimers) {
            InactivityTimer.detachTimeout();
            TokenExpiryTimer.detachTimeout();
        }
    }

    private signOutPatient = (): void => {
        V2Analytics.userEvent({
            eventName: 'logout',
            userId: this.props.userDetails.id,
            userType: 'patient',
            userStatus: 'member',
        });

        const surveyInterface = getExitSurveyInterface(window);

        if (surveyInterface) {
            surveyInterface();
        } else {
            location.setLocationPathname('/patientauth/logout');
        }
    };
}

const HangupStageContainer = withRouter<OwnProps>(
    Redux.connect<StateProps, Record<string, never>, OwnProps>(mapStateToProps)(
        HangupStageContainerComponent,
    ),
);

export { HangupStageContainer };
