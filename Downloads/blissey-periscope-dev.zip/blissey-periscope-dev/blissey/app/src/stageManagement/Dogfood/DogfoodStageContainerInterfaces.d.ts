import { UserDetails } from '@dexcare/circus-saturn';

export interface OwnProps {
    userDetails: UserDetails;
}
