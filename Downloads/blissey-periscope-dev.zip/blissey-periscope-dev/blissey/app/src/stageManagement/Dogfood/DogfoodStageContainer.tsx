import * as React from 'react';

import * as styles from './DogfoodStageContainer.css';
import { config } from '@dexcare/circus-jupiter';

import { AppConfig } from '../../../../server/config/configInterfaces';
import { DogFoodModule } from '../../modules/Dogfood/DogFoodModule';
import { Logger, LogManager } from '@dexcare/circus-jupiter';
import { TokenExpiryTimer } from '../../common/TokenExpiryTimer';
import { StageId } from '../StageId';
import { OwnProps } from './DogfoodStageContainerInterfaces';
import { Configuration } from 'types/configuration';
import { withRouter, RouterProps } from '../../common/withRouter';

type Props = OwnProps & RouterProps;

/** session stage container for consultation stage */
class DogfoodStageContainerComponent extends React.PureComponent<Props> {
    private logger: Logger;

    constructor(props: Props) {
        super(props);

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'DogfoodStageContainer',
                userId: props.userDetails.id,
            },
            true,
        );
    }

    public render() {
        const { brands }: AppConfig = (config as Configuration).getConfig();
        return (
            <div className={styles.main}>
                <DogFoodModule
                    userDetails={this.props.userDetails}
                    brands={brands}
                />
            </div>
        );
    }

    public componentDidMount() {
        this.logger.info({ eventType: 'pageView' });

        TokenExpiryTimer.attachTimeout(
            Number(this.props.userDetails.expiration.toString()),
            StageId.Dogfood,
            '',
        );
    }

    public componentWillUnmount() {
        TokenExpiryTimer.detachTimeout();
    }
}

const DogfoodStageContainer = withRouter<OwnProps>(
    DogfoodStageContainerComponent,
);

export { DogfoodStageContainer };
