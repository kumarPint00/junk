import * as React from 'react';
import { LogManager, Logger } from '@dexcare/circus-jupiter';
import { OwnProps } from '../PostConsult/PostConsultStageContainerInterfaces';
import * as styles from './PublicVisitSurveyContainer.css';
import PostVisitPatientSurvey from '@components/PostVisitPatientSurvey/PostVisitPatientSurvey';
import { endRoute } from '@utils/getRoutes';
import { UserType } from '../../../src/data/UserType';
import { FooterPage } from '@layout/PageLayout/FooterPage';
import { withRouter, RouterProps } from '@common/withRouter';

type Props = OwnProps & RouterProps<{ visitId: string }>;

class PublicVisitSurveyContainerComponent extends React.Component<Props> {
    private logger: Logger;
    userType: UserType;
    visitId: string;

    constructor(props: Props) {
        super(props);

        this.visitId = this.props?.router.params.visitId || 'default';

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'PublicVisitSurveyStageContainer',
                userId: props.userDetails.id,
                visitId: this.visitId,
            },
            true,
        );
    }

    public render() {
        return (
            <FooterPage>
                <div className={styles.main}>
                    <PostVisitPatientSurvey
                        submit={this.onEndRoute}
                        visitId={this.visitId}
                    />
                </div>
            </FooterPage>
        );
    }

    public componentDidMount() {
        this.logger.info({
            visitId: this.visitId,
            eventType: 'pageView',
        });
    }

    public onEndRoute = (): void => {
        this.props.router.navigate(endRoute(this.props.brand));
    };
}

const PublicVisitSurveyContainer = withRouter<OwnProps>(
    PublicVisitSurveyContainerComponent,
);

export { PublicVisitSurveyContainer };
