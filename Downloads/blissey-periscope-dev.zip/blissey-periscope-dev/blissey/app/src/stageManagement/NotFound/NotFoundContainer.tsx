import * as React from 'react';

import { LogManager, Logger } from '@dexcare/circus-jupiter';
import { isProvider } from '@dexcare/circus-saturn';

import { NotFoundContainerProps } from './NotFoundContainerInterfaces';
import { NotFoundModule } from '../../modules/NotFound/NotFoundModule';
import { withRouter, RouterProps } from '../../common/withRouter';

type Props = NotFoundContainerProps & RouterProps;

class NotFoundContainerComponent extends React.PureComponent<Props> {
    private logger: Logger;

    constructor(props: Props) {
        super(props);

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'NotFoundContainer',
                userId: props.userDetails.id,
            },
            true,
        );
    }

    public render() {
        return (
            <NotFoundModule
                isProvider={isProvider(this.props.userDetails)}
                visitId={this.props.visitId}
                invalidVisitReason={this.props.invalidVisitReason ?? null}
                isTokBoxTokenError={this.props.isTokBoxTokenError ?? false}
                tokboxTokenErrorMessage={
                    this.props.tokboxTokenErrorMessage ?? null
                }
            />
        );
    }

    public componentDidMount() {
        const path = this.props?.router.location.pathname ?? '';
        this.logger.info({
            eventType: 'pageView',
            path,
        });
    }
}

const NotFoundContainer = withRouter<NotFoundContainerProps>(
    NotFoundContainerComponent,
);

export { NotFoundContainer };
