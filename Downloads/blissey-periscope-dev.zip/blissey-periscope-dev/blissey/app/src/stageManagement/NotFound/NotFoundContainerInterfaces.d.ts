import { UserDetails } from '@dexcare/circus-saturn';

export interface NotFoundContainerProps {
    userDetails: UserDetails;
    invalidVisitReason?: string | null;
    isTokBoxTokenError?: boolean;
    tokboxTokenErrorMessage?: string | null;
    visitId?: string;
}

export interface NotFoundContainerState {}
