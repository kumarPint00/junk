import * as React from 'react';
import * as Redux from 'react-redux';

import { Store } from '../../redux/modules';
import {
    getOTPCode,
    submitOTPCode,
    resendOTPCode,
    setErrorMessage,
    TState,
} from '../../redux/modules/otp';
import {
    OwnProps,
    StateProps,
    DispatchProps,
    State,
} from './OTPFlowContainerInterfaces';
import { OTPModule } from '../../modules/OTPFlow/OTPModule';
import { Action } from 'redux';
import { ThunkDispatch } from 'types/redux';

const mapStateToProps = (state: Store['All']): StateProps => {
    return {
        windowToDisplay: state.otp.windowToDisplay,
        isLoading: state.otp.isLoading,
        errorMessage: state.otp.errorMessage,
    };
};

const mapDispatchToProps: Redux.MapDispatchToPropsParam<
    ThunkDispatch<Store['All'] | TState, unknown, Action>,
    OwnProps
> = (dispatch: ThunkDispatch<Store['All'] | TState, unknown, Action>) => {
    return {
        getOTPCode: async (otpMethod: string) =>
            dispatch(getOTPCode(otpMethod)),
        submitOTPCode: async (otpCode: string, otpMethod: string) =>
            dispatch(submitOTPCode(otpCode, otpMethod)),
        resendOTPCode: async () => dispatch(resendOTPCode()),
        setErrorMessage: (message: string | undefined) =>
            dispatch(setErrorMessage(message)),
    };
};

export type Props = OwnProps & StateProps & DispatchProps;

export class OTPFlowContainerComponent extends React.Component<Props, State> {
    public state = {
        otpMethod: 'email',
        otpCode: '',
    };

    constructor(props: Props) {
        super(props);
    }

    private setOTPMethod = (otpMethod: string) => {
        this.setState({ otpMethod });
    };

    private setOTPCode = (otpCode: string) => {
        this.setState({ otpCode });
    };

    private handleGetOTPCode = () => {
        void this.props.getOTPCode(this.state.otpMethod);
    };

    private handleSubmitOTPCode = () => {
        void this.props.submitOTPCode(this.state.otpCode, this.state.otpMethod);
    };

    private handleResendOTPCode = () => {
        this.setState({ otpCode: '' });
        void this.props.resendOTPCode();
    };

    private handleSetErrorMessage = (message: string | undefined) => {
        this.props.setErrorMessage(message);
    };

    public render() {
        const { windowToDisplay, userDetails, isLoading, errorMessage } =
            this.props;
        const { otpMethod, otpCode } = this.state;
        return (
            <OTPModule
                windowToDisplay={windowToDisplay}
                email={userDetails.email}
                sms={userDetails.sms}
                otpMethod={otpMethod}
                otpCode={otpCode}
                isLoading={isLoading}
                errorMessage={errorMessage}
                setOTPMethod={this.setOTPMethod}
                setOTPCode={this.setOTPCode}
                handleGetOTPCode={this.handleGetOTPCode}
                handleSubmitOTPCode={this.handleSubmitOTPCode}
                handleResendOTPCode={this.handleResendOTPCode}
                handleSetErrorMessage={this.handleSetErrorMessage}
            />
        );
    }
}

const OTPFlowContainer = Redux.connect<StateProps, DispatchProps, OwnProps>(
    mapStateToProps,
    mapDispatchToProps,
)(OTPFlowContainerComponent) as React.ComponentType<OwnProps>;

export { OTPFlowContainer };
