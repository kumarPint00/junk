// should the root definition of UserDetails include an sms or do
// we need this separate definition
export interface GuestUserDetails {
    id: string;
    email: string;
    sms: string;
}

export interface OwnProps {
    brand: string;
    userDetails: GuestUserDetails;
}

export interface StateProps {
    windowToDisplay: string;
    isLoading: boolean;
    errorMessage: string | undefined;
}

export interface DispatchProps {
    getOTPCode: (otpMethod: string) => Promise<void>;
    submitOTPCode: (otpCode: string, otpMethod: string) => Promise<void>;
    resendOTPCode: () => Promise<void>;
    setErrorMessage: (message: string | undefined) => void;
}

export interface State {
    otpMethod: string;
    otpCode: string;
}
