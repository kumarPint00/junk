/** enumeration of the stages */
export enum StageId {
    Login,
    PreConsult,
    InVisit,
    InConsult,
    PostConsult,
    Hangup,
    Notes,
    End,
    Dogfood,
    Schedule,
}
