import * as React from 'react';

import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';

import * as styles from './TokenForm.css';

export interface Tokens {
    waitingRoomToken: string;
    videoToken: string;
}
export const TokenForm = ({
    onSubmit,
}: {
    onSubmit: (tokens: Tokens) => void;
}) => {
    const [videoToken, setVideoToken] = React.useState('');
    const [waitingRoomToken, setWaitingRoomToken] = React.useState('');

    const changeEvent =
        (fn: (val: string) => void) =>
        (event: React.ChangeEvent<HTMLInputElement>) =>
            fn(event.target.value);
    const submit = () => onSubmit({ waitingRoomToken, videoToken });
    return (
        <div className={styles.tokenFormContainer}>
            <TextField
                label="Waiting Room Token"
                onChange={changeEvent(setWaitingRoomToken)}
                value={waitingRoomToken}
                variant="standard"
            />
            <TextField
                label="Video Token"
                onChange={changeEvent(setVideoToken)}
                value={videoToken}
                variant="standard"
            />
            <Button
                color="primary"
                variant="contained"
                data-uitest="dogfoodform-generatebutton"
                onClick={submit}
            >
                Set Tokens
            </Button>
        </div>
    );
};
