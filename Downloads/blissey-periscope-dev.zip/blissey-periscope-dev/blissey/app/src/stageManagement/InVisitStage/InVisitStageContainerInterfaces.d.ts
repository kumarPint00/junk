import { UserDetails } from '@dexcare/circus-saturn';
import { HealthInfo } from '@common/ConnectionTest/HealthInfo';
import { FetchTokensData } from '@redux/modules/postConsult';
import { TState as HealthState } from '@redux/modules/health';
import { VisitDetails } from '@clients/VisitService/VisitInterfaces';

interface OwnProps {
    brand: string;
    userDetails: UserDetails;
}

interface StateProps {
    invalidVisitId: boolean;
    invalidVisitReason: string | null;
    health: HealthState;
    healthInfo: HealthInfo;
    isTestVisit: boolean;
    audioDeviceId: string;
    videoDeviceId: string;
    callStartTime: number | null;
    isTokBox: boolean;
    tokBoxVideoSessionId?: string;
    tokBoxVideoToken: string;
    tokBoxTokenError: boolean;
    tokBoxTokenErrorMessage: string | null;
    consentTermsAccepted: boolean;
    isLoadingConsentTerms: boolean;
    consentTermsErrorMessage: string | null;
    messageDialogText: string | null;
}

interface DispatchProps {
    fetchVisitDetailsByVisitId(
        visitId: string,
        isProvider: boolean,
    ): Promise<VisitDetails>;
    fetchTestVisitDetailsByVisitId(
        visitId: string,
        providerId: string,
    ): Promise<{ visitDetails: VisitDetails; redirect?: string }>;
    fetchTokBoxTokens: (data: FetchTokensData) => Promise<void>;
    setCallStartTime(time: number): void;
    setCallEndTime(time: number): void;
    setAudioDeviceId(deviceId: string): void;
    setVideoDeviceId(deviceId: string): void;
    setTokBoxVideoToken: (token: string) => void;
    setTokBoxWaitingRoomToken: (token: string) => void;
    acceptConsentTerms: () => void;
    setConsentErrorMessage: (message: string | null) => void;
    cancelVisit: () => void;
    setMessageDialog: (value: string | null) => void;
}

interface State {
    isLoadingVisitDetails: boolean;
}
