import * as React from 'react';
import * as Redux from 'react-redux';
import { Action } from 'redux';
import CircularProgress from '@mui/material/CircularProgress';

import { isProvider, isPatient } from '@dexcare/circus-saturn';

import { BlisseyLogger as Logger } from '@utils/Logger';
import { TokenExpiryTimer } from '../../common/TokenExpiryTimer';
import { NotFoundModule } from '../../modules/NotFound/NotFoundModule';
import VideoCallModule from '../../modules/VideoCall/VideoCallModule';
import { StageId } from '../StageId';
import { Store } from '../../redux/modules';
import {
    fetchVisitDetailsByVisitId,
    fetchTestVisitDetailsByVisitId,
    setCallStartTime,
    setCallEndTime,
    fetchTokBoxTokens,
    setTokBoxVideoToken,
    setTokBoxWaitingRoomToken,
    FetchTokensData,
    acceptConsentTerms,
    cancelVisit,
    setConsentErrorMessage,
    setMessageDialog,
    TState,
} from '../../redux/modules/postConsult';
import {
    setAudioDeviceId,
    setVideoDeviceId,
} from '../../redux/modules/userSettings';
import { getHealthInfo } from '../../redux/selectors/getHealthInfo';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';

import {
    OwnProps,
    StateProps,
    DispatchProps,
    State,
} from './InVisitStageContainerInterfaces';
import { TokenForm, Tokens } from './TokenForm';
import { VisitDetails } from '@clients/VisitService/VisitInterfaces';
import { ConsentModule } from '@modules/Consent/ConsentModule';
import { MessageDialog } from '@components/MessageDialog/MessageDialog';
import * as styles from './InVisitStageContainer.css';
import { ThunkDispatch } from 'types/redux';
import { withRouter, RouterProps } from '../../common/withRouter';

export type Props = OwnProps &
    StateProps &
    DispatchProps &
    RouterProps<{ visitId: string }>;

const mapStateToProps = (state: Store['All']): StateProps => {
    return {
        invalidVisitId: state.postconsult.invalidVisitId,
        invalidVisitReason: state.postconsult.invalidVisitReason,
        health: state.health,
        healthInfo: getHealthInfo(state.health),
        isTestVisit: state.postconsult.isTestVisit,
        audioDeviceId: state.usersettings.audioDeviceId,
        videoDeviceId: state.usersettings.videoDeviceId,
        callStartTime: state.postconsult.callStartTime,
        isTokBox: state.postconsult.isTokBox,
        tokBoxVideoSessionId: state.postconsult.tokBoxVideoSessionId,
        tokBoxVideoToken: state.postconsult.tokBoxVideoToken,
        tokBoxTokenError: state.postconsult.tokBoxTokenError,
        tokBoxTokenErrorMessage: state.postconsult.tokBoxTokenErrorMessage,
        consentTermsAccepted: state.postconsult.consentTermsAccepted,
        isLoadingConsentTerms: state.postconsult.isLoadingConsentTerms,
        consentTermsErrorMessage: state.postconsult.consentTermsErrorMessage,
        messageDialogText: state.postconsult.messageDialog,
    };
};

const mapDispatchToProps: Redux.MapDispatchToPropsParam<
    ThunkDispatch<TState | Store['All'], unknown, Action>,
    OwnProps
> = (dispatch: ThunkDispatch<TState | Store['All'], unknown, Action>) => {
    return {
        fetchVisitDetailsByVisitId: async (
            visitId: string,
            isProvider: boolean,
        ) => dispatch(fetchVisitDetailsByVisitId({ visitId, isProvider })),
        fetchTestVisitDetailsByVisitId: (visitId: string, providerId: string) =>
            dispatch(fetchTestVisitDetailsByVisitId(visitId, providerId)),
        fetchTokBoxTokens: async (data: FetchTokensData) =>
            dispatch(fetchTokBoxTokens(data)),
        setCallStartTime: (time: number) => dispatch(setCallStartTime(time)),
        setCallEndTime: (time: number) => dispatch(setCallEndTime(time)),
        setAudioDeviceId: (deviceId: string) =>
            dispatch(setAudioDeviceId(deviceId)),
        setVideoDeviceId: (deviceId: string) =>
            dispatch(setVideoDeviceId(deviceId)),
        setTokBoxVideoToken: (token: string) =>
            dispatch(setTokBoxVideoToken(token)),
        setTokBoxWaitingRoomToken: (token: string) =>
            dispatch(setTokBoxWaitingRoomToken(token)),
        acceptConsentTerms: async () => dispatch(acceptConsentTerms()),
        setConsentErrorMessage: (message: string | null) =>
            dispatch(setConsentErrorMessage(message)),
        cancelVisit: async () => dispatch(cancelVisit()),
        setMessageDialog: (value: string | null) =>
            dispatch(setMessageDialog(value)),
    };
};

export class InVisitStageContainerComponent extends React.Component<
    Props,
    State
> {
    private visitId: string;
    public state: State;

    constructor(props: Props) {
        super(props);

        // Start with isLoading: true because we want to immediately load on mount
        this.state = {
            isLoadingVisitDetails: true,
        };
        this.visitId = this.props.router.params.visitId;
        Logger.addApplicationContext({
            userId: props.userDetails.id,
            visitId: this.visitId,
            isTestVisit: props.isTestVisit,
        });

        TokenExpiryTimer.attachTimeout(
            Number(this.props.userDetails.expiration.toString()),
            StageId.InVisit,
            this.visitId,
            isProvider(this.props.userDetails),
        );
    }

    private requireManualTokenEntry = (params: {
        tokBoxVideoToken?: string;
    }) => {
        const { tokBoxVideoToken } = params;
        const { userDetails, isTestVisit } = this.props;
        return isTestVisit && !isProvider(userDetails) && !tokBoxVideoToken;
    };

    private onTokenSubmit = (tokens: Tokens) => {
        this.props.setTokBoxVideoToken(tokens.videoToken);
        this.props.setTokBoxWaitingRoomToken(tokens.waitingRoomToken);
    };

    public render() {
        const { tokBoxVideoToken, tokBoxVideoSessionId } = this.props;
        if (this.state.isLoadingVisitDetails) {
            return (
                <div className={styles.progressBarContainer}>
                    <CircularProgress variant="indeterminate" />
                </div>
            );
        }
        if (this.requireManualTokenEntry({ tokBoxVideoToken })) {
            return <TokenForm onSubmit={this.onTokenSubmit} />;
        }
        if (this.props.invalidVisitId || this.props.tokBoxTokenError) {
            // todo need a better error page for a tokbox token error
            return (
                <NotFoundModule
                    isProvider={isProvider(this.props.userDetails)}
                    invalidVisitReason={
                        this.props.invalidVisitId
                            ? this.props.invalidVisitReason
                            : null
                    }
                    isTokBoxTokenError={this.props.tokBoxTokenError}
                    tokboxTokenErrorMessage={this.props.tokBoxTokenErrorMessage}
                    visitId={this.visitId}
                />
            );
        }
        // if terms and conditions for the visit are not agreed to collect them
        const requireConsentTerms =
            isPatient(this.props.userDetails) &&
            getFeatureFlag(FeatureFlags.requireConsentTerms);
        if (
            requireConsentTerms &&
            !this.props.consentTermsAccepted &&
            !this.props.isTestVisit
        ) {
            return (
                <ConsentModule
                    isLoading={this.props.isLoadingConsentTerms}
                    errorMessage={this.props.consentTermsErrorMessage}
                    isTestVisit={this.props.isTestVisit}
                    visitId={this.visitId}
                    userDetails={this.props.userDetails}
                    handleAcceptTerms={this.props.acceptConsentTerms}
                    handleCancel={this.props.cancelVisit}
                    handleSetErrorMessage={this.props.setConsentErrorMessage}
                />
            );
        }

        return (
            <div className={styles.main}>
                <VideoCallModule
                    brand={this.props.brand}
                    setCallStartTime={this.props.setCallStartTime}
                    setCallEndTime={this.props.setCallEndTime}
                    navigate={this.props.router.navigate}
                    health={this.props.health}
                    healthInfo={this.props.healthInfo}
                    isTestVisit={this.props.isTestVisit}
                    callStartTime={this.props.callStartTime}
                    tokBoxVideoToken={this.props.tokBoxVideoToken}
                    tokBoxVideoSessionId={tokBoxVideoSessionId!}
                    fetchVisitDetails={
                        this.fetchVisitDetails.bind(this) as () => void
                    }
                />
                <MessageDialog
                    active={Boolean(this.props.messageDialogText)}
                    messageText={this.props.messageDialogText}
                    onClose={() => this.props.setMessageDialog(null)}
                />
            </div>
        );
    }

    public async componentDidMount() {
        Logger.info({
            eventSource: 'InVisitStageContainer',
            eventType: 'pageView',
        });
        try {
            await this.loadAllData();
        } catch (err: unknown) {
            Logger.error(
                {
                    eventSource: 'InVisitStageContainer',
                    eventType: 'componentDidMount',
                    err,
                },
                'Failed to load the visit details so the video session will not be started.',
            );
        } finally {
            this.setState({ isLoadingVisitDetails: false });
        }
    }

    private async loadAllData() {
        const visitDetails = await this.fetchVisitDetails();
        await this.fetchTokboxTokens(visitDetails);
    }

    public async fetchTokboxTokens(visitDetails: VisitDetails) {
        const { tokBoxVisit } = visitDetails;
        if (
            !this.requireManualTokenEntry({
                tokBoxVideoToken: undefined,
            })
        ) {
            await this.props.fetchTokBoxTokens({
                videoSessionId: tokBoxVisit!.videoConferenceSession.sessionId,
                waitingRoomSessionId: tokBoxVisit!.waitingRoomSession.sessionId,
            });
        }
    }

    public async fetchVisitDetails() {
        let visitDetails: VisitDetails;
        if (this.props.isTestVisit) {
            const { visitDetails: testVisitDetails, redirect } =
                await this.props.fetchTestVisitDetailsByVisitId(
                    this.visitId,
                    this.props.userDetails?.id,
                );
            visitDetails = testVisitDetails;

            if (redirect) {
                this.props.router.navigate(redirect);
            }
        } else {
            visitDetails = await this.props.fetchVisitDetailsByVisitId(
                this.visitId,
                isProvider(this.props.userDetails),
            );
        }
        return visitDetails;
    }
}

const InVisitStageContainer = withRouter<OwnProps>(
    Redux.connect<StateProps, DispatchProps, OwnProps>(
        mapStateToProps,
        mapDispatchToProps,
    )(InVisitStageContainerComponent),
);

export { InVisitStageContainer };
