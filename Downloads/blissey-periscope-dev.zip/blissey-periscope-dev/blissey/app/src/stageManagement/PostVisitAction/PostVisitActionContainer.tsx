import { LogManager, Logger } from '@dexcare/circus-jupiter';
import {
    isProvider,
    PostVisitActionChange,
    PostVisitActions,
    SelectQueueOrProviderChange,
    SelectQueueOrProviderChangeType,
} from '@dexcare/circus-saturn';
import * as React from 'react';
import * as Redux from 'react-redux';
import { Action } from 'redux';
import { ErrorSnackbar } from '../../components/ErrorSnackbar';
import { FooterPage } from '../../layout/PageLayout/FooterPage';
import { PostVisitActionModule } from '../../modules/PostVisitAction/PostVisitActionModule';
import { Store } from '../../redux/modules';
import {
    TState,
    chargeVisit,
    convertModality,
    transferBackToQueue,
    transferToAnotherProvider,
    waiveVisit,
} from '../../redux/modules/postConsult';
import { PaymentStatus } from '../../redux/utils/PaymentStatus';
import { submitGTMPageViewEvent } from '../../services/analytics';
import { FeatureFlags, getFeatureFlag } from '../../utils';
import {
    postConsultRoute,
    postVisitPatientSurveyRoute,
    postVisitProviderSurveyRoute,
} from '../../utils/getRoutes';
import { DispatchProps, OwnProps, State, StateProps } from './interfaces';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { ThunkDispatch } from 'types/redux';
import { withRouter, RouterProps } from '../../common/withRouter';

export type Props = OwnProps &
    StateProps &
    DispatchProps &
    RouterProps<{ visitId: string }>;

const mapStateToProps = (state: Store['All']): StateProps => {
    const {
        isTestVisit,
        chargedStatus,
        patientGuid,
        isTravelingFromCallCenter,
    } = state.postconsult;
    return {
        isTestVisit,
        chargedStatus,
        patientGuid,
        isTravelingFromCallCenter,
    };
};

const mapDispatchToProps: Redux.MapDispatchToPropsParam<
    ThunkDispatch<Store['All'] | TState, unknown, Action>,
    OwnProps
> = (dispatch: ThunkDispatch<Store['All'] | TState, unknown, Action>) => {
    return {
        chargeVisit: async (visitId: string) => dispatch(chargeVisit(visitId)),
        convertModality: async (visitId: string, conversionReason: string) =>
            dispatch(convertModality(visitId, conversionReason)),
        waiveVisit: async (visitId: string, waiveReason: string) =>
            dispatch(waiveVisit(visitId, waiveReason)),
        transferBackToQueue: async (visitId: string) =>
            dispatch(transferBackToQueue(visitId)),
        transferToAnotherProvider: async (
            visitId: string,
            newProviderId: string,
        ) => dispatch(transferToAnotherProvider(visitId, newProviderId)),
    };
};

export class PostVisitActionContainerComponent extends React.Component<
    Props,
    State
> {
    private logger: Logger;
    public state = {
        snackError: {
            active: false,
            message: '',
        },
        requesting: false,
    };

    constructor(props: Props) {
        super(props);
        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'PostVisitActionContainer',
                props,
            },
            true,
        );
    }

    public componentDidMount() {
        submitGTMPageViewEvent(this.getVisitId());
    }

    private handleSubmit = (change: PostVisitActionChange) => {
        const { selectedAction } = change;
        if (selectedAction === PostVisitActions.Complete) {
            this.handleCharge();
        } else if (selectedAction === PostVisitActions.Waive) {
            this.handleWaive(change.selectedWaiveReason);
        } else if (selectedAction === PostVisitActions.Transfer) {
            this.handleTransfer(change.selectedQueueOrProvider);
        } else if (selectedAction === PostVisitActions.Convert) {
            this.handleConversion(change.selectedModalityConversionReason);
        }
    };

    private isProvider = () => {
        return isProvider(this.props.userDetails);
    };

    private handleCharge = () => {
        this.sendAnalytics('charge_visit');
        this.handleDispatch(this.props.chargeVisit, this.getVisitId());
    };

    private handleWaive = (waiveReason: string | undefined) => {
        if (!waiveReason) {
            this.snackError('Please select a reason for waive.');
            return;
        }
        this.sendAnalytics('waive_visit', waiveReason);
        this.handleDispatch(
            this.props.waiveVisit,
            this.getVisitId(),
            waiveReason,
        );
    };

    private handleTransfer = (change?: SelectQueueOrProviderChange) => {
        if (!change?.type) {
            this.snackError('Please select a transfer option');
            return;
        }

        if (change.type === SelectQueueOrProviderChangeType.Queue) {
            this.sendAnalytics('unassign_visit');
            this.handleDispatch(
                this.props.transferBackToQueue,
                this.getVisitId(),
            );
        } else if (change.type === SelectQueueOrProviderChangeType.Provider) {
            if (!change.providerId) {
                this.snackError('Please select a provider');
                return;
            }

            this.sendAnalytics('transfer_visit', change.providerId);
            this.handleDispatch(
                this.props.transferToAnotherProvider,
                this.getVisitId(),
                change.providerId,
            );
        }
        this.goToNextPage();
    };

    private handleConversion = (conversionReason: string | undefined) => {
        if (!conversionReason) {
            this.snackError('Please select a modality conversion reason');
            return;
        }

        this.sendAnalytics('modality_conversion_reason', conversionReason);
        this.handleDispatch(
            this.props.convertModality,
            this.getVisitId(),
            conversionReason,
        );
    };

    private sendAnalytics = (eventName: string, ...params: string[]) => {
        V2Analytics.interactionEvent({
            eventName,
            patient_id: this.props.patientGuid,
            visit_id: this.getVisitId(),
            ...params,
        });
    };

    private handleDispatch = (
        action: (...args: string[]) => unknown,
        ...params: string[]
    ) => {
        const { isTestVisit } = this.props;
        try {
            if (!isTestVisit) {
                action(...params);
            }
            this.goToNextPage();
        } catch (error) {
            this.logger.error('Failed to process payment' + error);
        }
    };

    private goToNextPage = () => {
        const enablePostVisitSurveyConfig = getFeatureFlag(
            FeatureFlags.enablePostVisitSurveyConfig,
        );

        if (enablePostVisitSurveyConfig) {
            if (this.isProvider()) {
                this.props.router.navigate(
                    postVisitProviderSurveyRoute(
                        this.getVisitId(),
                        this.props.brand,
                    ),
                );
            } else {
                this.props.router.navigate(
                    postVisitPatientSurveyRoute(
                        this.getVisitId(),
                        this.props.brand,
                    ),
                );
            }
        } else {
            this.props.router.navigate(
                postConsultRoute(this.getVisitId(), this.props.brand),
            );
        }
    };

    private getVisitId = (): string => {
        return this.props.router?.params?.visitId;
    };

    private snackError = (message: string) => {
        this.setState({
            snackError: {
                active: true,
                message,
            },
        });
    };

    private clearSnack = () => {
        this.setState({
            snackError: {
                active: false,
            },
        });
    };

    public render() {
        const { chargedStatus, isTravelingFromCallCenter } = this.props;
        const { snackError, requesting } = this.state;
        const header =
            chargedStatus === PaymentStatus.none
                ? 'How should we process this visit?'
                : '';
        // feature flag to show transfer options
        const showTransferOption = !!getFeatureFlag(
            FeatureFlags.endAndTransferVisit,
        );
        const enableVisitModalityConversion = !!getFeatureFlag(
            FeatureFlags.enableVisitModalityConversion,
        );
        const enableVisitModalityConversionForTravelPatientCallCenter =
            !!getFeatureFlag(
                FeatureFlags.enableVisitModalityConversionForTravelPatientCallCenter,
            );
        const shouldShowConvertModalityOption =
            enableVisitModalityConversion &&
            (enableVisitModalityConversionForTravelPatientCallCenter ||
                !isTravelingFromCallCenter);

        return (
            <FooterPage headerText={header}>
                <PostVisitActionModule
                    chargedStatus={chargedStatus}
                    onSubmit={this.handleSubmit}
                    disabled={requesting}
                    showTransferOption={showTransferOption}
                    showConvertModalityOption={shouldShowConvertModalityOption}
                    visitId={this.getVisitId()}
                />
                <ErrorSnackbar
                    open={snackError.active}
                    message={snackError.message}
                    onClose={this.clearSnack}
                    onDismiss={this.clearSnack}
                    type={'payment'}
                />
            </FooterPage>
        );
    }
}

const PostVisitActionContainer = withRouter<OwnProps>(
    Redux.connect<StateProps, DispatchProps, OwnProps>(
        mapStateToProps,
        mapDispatchToProps,
    )(PostVisitActionContainerComponent),
);

export { PostVisitActionContainer };
