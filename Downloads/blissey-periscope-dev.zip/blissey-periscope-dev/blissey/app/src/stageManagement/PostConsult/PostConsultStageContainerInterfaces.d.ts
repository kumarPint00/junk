import { UserDetails } from '@dexcare/circus-saturn';

interface OwnProps {
    brand: string;
    userDetails: UserDetails;
}

interface StateProps {
    visitId: string;
    patientGuid: string;
    providerId?: string | null;
    callStartTime: number | null;
    callEndTime: number | null;
    isTestVisit: boolean;
}

interface State {
    invalidVisitId: boolean;
    visitDetails: unknown;
    consult: unknown;
}
