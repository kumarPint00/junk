import * as React from 'react';
import * as Redux from 'react-redux';

import { LogManager, Logger } from '@dexcare/circus-jupiter';

import { InactivityTimer } from '@common/InactivityTimer';
import { CallSummaryModule } from '@modules/CallSummary/CallSummaryModule';
import { CallSummaryModuleProps } from '@modules/CallSummary/CallSummaryModuleInterfaces';
import { Store } from '@redux/modules';
import { endRoute } from '@utils/getRoutes';
import {
    OwnProps,
    StateProps,
    State,
} from './PostConsultStageContainerInterfaces';
import { withRouter, RouterProps } from '../../common/withRouter';
import * as styles from './PostConsultStageContainer.css';

type Props = OwnProps & StateProps & RouterProps<{ visitId: string }>;

const mapStateToProps = (state: Store['All']): StateProps => {
    return {
        visitId: state.postconsult.visitId,
        patientGuid: state.postconsult.patientGuid,
        providerId: state.postconsult.providerId,
        callStartTime: state.postconsult.callStartTime,
        callEndTime: state.postconsult.callEndTime,
        isTestVisit: state.postconsult.isTestVisit,
    };
};

class PostConsultStageContainerComponent extends React.Component<Props, State> {
    private logger: Logger;

    constructor(props: Props) {
        super(props);
        const visitId = this.props.router.params.visitId || 'default';

        this.logger = LogManager.getLogger().child(
            {
                eventSource: 'PostConsultStageContainer',
                userId: props.userDetails.id,
                visitId,
                isTestVisit: props.isTestVisit,
            },
            true,
        );

        if (!this.props.router.params.visitId) {
            this.logger.info('Attempted to join conference with no visit id');
        }
    }

    public render() {
        const callSummaryProps: CallSummaryModuleProps = {
            localUser: this.props.userDetails,
            visitId: this.props.router.params.visitId,
            // TODO conferenceId and conferenceSessionId used to send feedback.
            // can be removed once visit svc feedback endpont no longer requires
            conferenceId: '',
            conferenceSessionId: '',
            callStartTime: this.props.callStartTime,
            callEndTime: this.props.callEndTime,
            onFlowFinished: () =>
                this.props.router.navigate(endRoute(this.props.brand)),
            isTestVisit: this.props.isTestVisit,
            patientGuid: this.props.patientGuid,
            providerId: this.props.providerId,
        };

        return (
            <div className={styles.main}>
                <CallSummaryModule {...callSummaryProps} />
            </div>
        );
    }

    public componentDidMount() {
        this.logger.info({
            visitId: this.props.visitId,
            eventType: 'pageView',
        });

        InactivityTimer.attachTimeout();
    }

    public componentWillUnmount() {
        InactivityTimer.detachTimeout();
    }
}

const PostConsultStageContainer = withRouter<OwnProps>(
    Redux.connect<StateProps, OwnProps>(mapStateToProps)(
        PostConsultStageContainerComponent,
    ),
);

export { PostConsultStageContainer };
