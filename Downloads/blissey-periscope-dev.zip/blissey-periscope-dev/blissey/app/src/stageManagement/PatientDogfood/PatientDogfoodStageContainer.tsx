import * as React from 'react';

import { config } from '@dexcare/circus-jupiter';

import { DogFoodHeader } from '@components/Dogfood/DogFoodHeader';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import QRCode from 'react-qr-code';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';

import * as styles from './PatientDogfoodStageContainer.css';
import { Configuration } from 'types/configuration';
import { UserDetails } from '@dexcare/circus-saturn';

interface Props {
    brand: string;
    userDetails: UserDetails;
}

const byteSize = (str: string) => new Blob([str]).size;

const genTytoCareQRCode = (
    pairingDetails: object,
    wifiName: string,
    wifiPassword: string,
) => {
    const pairingDetailsString = JSON.stringify(pairingDetails);
    const wifiNameSize = byteSize(wifiName);
    const wifiPasswordSize = byteSize(wifiPassword);
    const utcTime = Math.floor(new Date().getTime() / 1000);
    const wifiNameEncoded = Buffer.from(wifiName).toString('base64');
    const wifiNameEncodedSize = byteSize(wifiNameEncoded);
    return `:V4:${wifiPasswordSize}::0:,,,${wifiNameSize},${wifiName}${wifiPassword},${utcTime},${wifiNameEncodedSize},${wifiNameEncoded},${pairingDetailsString},vExternal`;
};

const headerText = 'Patient Dogfood';
const explanationText =
    'Insert a visitId and enter WiFi credentials to generate a TytoCare pairing code and create a TytoCare account.  Please note, TytoCare Devices cannot connect to 5GHz WiFi';

type DropdownChange = React.ChangeEvent<{
    name?: string | undefined;
    value: unknown;
}>;
export const PatientDogfoodStageContainer = ({ brand }: Props) => {
    const domain = (config as Configuration).getConfig().brandConfig[brand]
        .domain;

    const [visitId, setVisitId] = React.useState('');
    const [wifiName, setWifiName] = React.useState('');
    const [wifiPassword, setWifiPassword] = React.useState('');
    const [tytoCareQRCode, setTytoCareQRCode] = React.useState('');

    const generateTytoCareQRCode = React.useCallback(() => {
        const generateCode = async () => {
            const {
                tytoCare: { pairingDetails },
            } = await visitServiceClient.generateTytoCareQRCode(
                visitId,
                domain,
            );
            const qrString = genTytoCareQRCode(
                pairingDetails,
                wifiName,
                wifiPassword,
            );
            setTytoCareQRCode(qrString);
        };
        void generateCode();
    }, [visitId, wifiName, wifiPassword, domain]);
    const updateWifiName = React.useCallback((event: DropdownChange) => {
        setWifiName(event.target.value as string);
    }, []);
    const updateWifiPassword = React.useCallback((event: DropdownChange) => {
        setWifiPassword(event.target.value as string);
    }, []);
    const updateVisitId = React.useCallback((event: DropdownChange) => {
        setVisitId(event.target.value as string);
    }, []);

    return (
        <div className={styles.container}>
            <Grid container spacing={2}>
                <Grid item xs={12}>
                    <DogFoodHeader
                        headerTextOverride={headerText}
                        explanationTextOverride={explanationText}
                    />
                </Grid>
                <Grid item xs={12}>
                    <TextField
                        classes={{ root: styles.nameInput }}
                        label={'Visit ID for TytoCare pairing'}
                        onChange={updateVisitId}
                        value={visitId}
                        variant="standard"
                    />
                </Grid>
                {visitId && (
                    <>
                        <Grid item xs={12}>
                            <TextField
                                classes={{ root: styles.nameInput }}
                                label={'Wifi Name'}
                                onChange={updateWifiName}
                                value={wifiName}
                                variant="standard"
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                classes={{ root: styles.nameInput }}
                                label={'Wifi Password'}
                                onChange={updateWifiPassword}
                                type={'password'}
                                value={wifiPassword}
                                variant="standard"
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <Button
                                color="primary"
                                variant="contained"
                                onClick={generateTytoCareQRCode}
                                classes={{ root: styles.generateButton }}
                                data-uitest="control-generateTytoCareQRCode"
                            >
                                Generate TytoCare QR Code
                            </Button>
                        </Grid>
                        {tytoCareQRCode && (
                            <Grid item xs={12}>
                                <QRCode value={tytoCareQRCode} />
                            </Grid>
                        )}
                    </>
                )}
            </Grid>
        </div>
    );
};
