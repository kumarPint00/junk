import * as React from 'react';
import * as redux from 'react-redux';
import thunk from '@redux/middleware/thunkShim';
import configureMockStore from 'redux-mock-store';

import {
    PhoneCancelScreen,
    PhoneCancelScreenProps,
} from '../PhoneCancelScreen';
import { StoryFn } from '@storybook/react';
import { BrowserRouter } from 'react-router-dom';

const state = {};
const middlewares = [thunk];

const Template = (props: PhoneCancelScreenProps) => {
    const mockStore = configureMockStore(middlewares);
    const mockStoreWithState = mockStore({
        ...state,
    });
    return (
        <BrowserRouter>
            <redux.Provider store={mockStoreWithState}>
                <PhoneCancelScreen {...{ ...props }} />
            </redux.Provider>
        </BrowserRouter>
    );
};

export const Default = Template.bind({}) as StoryFn<typeof PhoneCancelScreen>;

export default {
    title: 'Modules/PhoneCancel',
    component: PhoneCancelScreen,
    parameters: {
        layout: 'centered',
    },
    argTypes: {
        closedReason: {
            options: ['cancelled', 'staffdeclined', 'done', null],
            control: { type: 'radio' },
        },
    },
};
