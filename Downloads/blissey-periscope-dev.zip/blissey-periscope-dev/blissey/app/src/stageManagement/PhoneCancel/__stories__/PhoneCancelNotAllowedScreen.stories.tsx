import * as React from 'react';
import * as redux from 'react-redux';
import thunk from '@redux/middleware/thunkShim';
import configureMockStore from 'redux-mock-store';

import {
    PhoneCancelNotAllowed,
    PhoneCancelNotAllowedScreenProps,
} from '../PhoneCancelNotAllowedScreen';
import { StoryFn } from '@storybook/react';
import { BrowserRouter } from 'react-router-dom';

const state = {};
const middlewares = [thunk];

const Template = (props: PhoneCancelNotAllowedScreenProps) => {
    const mockStore = configureMockStore(middlewares);
    const mockStoreWithState = mockStore({
        ...state,
    });
    return (
        <BrowserRouter>
            <redux.Provider store={mockStoreWithState}>
                <PhoneCancelNotAllowed {...{ ...props }} />
            </redux.Provider>
        </BrowserRouter>
    );
};

export const Default = Template.bind({}) as StoryFn<
    typeof PhoneCancelNotAllowed
>;

export default {
    title: 'Modules/PhoneCancelNotAllowed',
    component: PhoneCancelNotAllowed,
    parameters: {
        layout: 'centered',
    },
    argTypes: {
        userDetails: {
            description:
                'User details object containing information about the user',
            control: { type: 'object' },
        },
    },
};
