import React from 'react';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { WithTranslation, withTranslation } from 'react-i18next';
import { Box, Typography, Container } from '@mui/material';
import { FooterPage } from '@layout/PageLayout/FooterPage';
import { useParams } from 'react-router-dom';
import type { UserDetails } from '@dexcare/circus-saturn';

export interface PhoneCancelNotAllowedScreenProps {
    userDetails: UserDetails;
}

const PhoneCancelScreenNotAllowedComponent: React.FC<
    PhoneCancelNotAllowedScreenProps & WithTranslation
> = (props) => {
    const params = useParams();
    const visitId = params?.visitId;
    V2Analytics.interactionEvent({
        eventName: 'visit_cancel_not_allowed',
        visit_id: visitId,
        user: props.userDetails,
    });

    let headerText = props.t('cancelWithReason.cannotCancel.header');
    if (headerText === 'cancelWithReason.cannotCancel.header')
        headerText =
            'You cannot cancel this appointment. It has already begun.';
    let bodyText = props.t('cancelWithReason.cannotCancel.body');
    if (bodyText === 'cancelWithReason.cannotCancel.body')
        bodyText =
            'Your provider will call you at the provided phone number soon. Please contact support if you have any questions. You may safely close this window.';

    const main = (
        <Container
            maxWidth="sm"
            sx={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: '100vh',
                textAlign: 'center',
                padding: 3,
                borderRadius: 2,
            }}
        >
            <Box mb={2}>
                <Typography variant="h6" component="h1" fontWeight="bold">
                    {headerText}
                </Typography>
            </Box>
            <Typography variant="body1">{bodyText}</Typography>
        </Container>
    );

    return <FooterPage>{main}</FooterPage>;
};

const PhoneCancelNotAllowed = withTranslation()(
    PhoneCancelScreenNotAllowedComponent,
) as React.ComponentType<PhoneCancelNotAllowedScreenProps>;

export { PhoneCancelNotAllowed };
