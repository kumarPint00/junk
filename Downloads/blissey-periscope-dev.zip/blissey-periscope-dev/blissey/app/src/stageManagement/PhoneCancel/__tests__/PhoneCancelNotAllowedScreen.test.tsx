import React from 'react';
import { render } from '@testing-library/react';
import { vi } from 'vitest';
import { ThemeProvider, createTheme } from '@mui/material';
import { grey } from '@mui/material/colors';
import {
    PhoneCancelNotAllowed,
    PhoneCancelNotAllowedScreenProps,
} from '../PhoneCancelNotAllowedScreen';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        interactionEvent: vi.fn(),
    },
}));

vi.mock('react-router-dom', () => ({
    useParams: vi.fn().mockReturnValue({ visitId: '123' }),
}));

const mockTheme = createTheme({
    palette: {
        silver: {
            main: grey[600],
            contrastText: '#fff',
        },
    },
});

describe('PhoneCancelNotAllowedScreen', () => {
    const defaultProps = {
        userDetails: {},
    } as unknown as PhoneCancelNotAllowedScreenProps;

    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('renders correctly with default text', () => {
        const { asFragment } = render(
            <ThemeProvider theme={mockTheme}>
                <PhoneCancelNotAllowed {...defaultProps} />
            </ThemeProvider>,
        );

        expect(asFragment()).toMatchSnapshot();
    });

    it('calls V2Analytics interactionEvent on render', () => {
        render(
            <ThemeProvider theme={mockTheme}>
                <PhoneCancelNotAllowed {...defaultProps} />
            </ThemeProvider>,
        );

        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'visit_cancel_not_allowed',
            visit_id: '123',
            user: defaultProps.userDetails,
        });
    });
});
