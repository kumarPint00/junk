import React from 'react';
import thunkShim from '@redux/middleware/thunkShim';
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';
import { render, fireEvent } from '@testing-library/react';
import { vi } from 'vitest';
import {
    PhoneCancelScreen,
    PhoneCancelScreenProps,
} from '../PhoneCancelScreen';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { createTheme, ThemeProvider } from '@mui/material';
import { grey } from '@mui/material/colors';
import { waitFor } from '@testing-library/react';
import { checkPhoneVisitStatusAndRedirect } from '@redux/modules/postConsult';

vi.mock('@redux/modules/postConsult', () => ({
    checkPhoneVisitStatusAndRedirect: vi.fn(),
    cancelPhoneWithReason: vi.fn(),
}));

const mockTheme = createTheme({
    palette: {
        silver: {
            main: grey[600],
            contrastText: '#fff',
        },
    },
});

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        interactionEvent: vi.fn(),
    },
}));

vi.mock('react-router-dom', () => ({
    useParams: vi.fn().mockReturnValue({}),
    useLocation: vi.fn().mockReturnValue({}),
    useNavigate: vi.fn().mockReturnValue(vi.fn()),
}));

const middlewares = [thunkShim as any];
const mockStore = configureStore(middlewares);
const store = mockStore({});

describe('PhoneCancelScreen', () => {
    const defaultProps = {
        userDetails: {},
    } as unknown as PhoneCancelScreenProps;

    beforeEach(() => {
        vi.clearAllMocks();
    });

    it('renders correctly', async () => {
    const mockDispatch = vi.fn(async () => Promise.resolve(undefined));
    (store as any).dispatch = mockDispatch;

        const { asFragment } = render(
            <ThemeProvider theme={mockTheme}>
                <Provider store={store}>
                    <PhoneCancelScreen {...defaultProps} />
                </Provider>
            </ThemeProvider>,
        );

        await waitFor(() => {
            expect(mockDispatch).toHaveBeenCalledWith(
                checkPhoneVisitStatusAndRedirect('123'),
            );
        });

        expect(asFragment()).toMatchSnapshot();
    });

    it('calls V2Analytics interactionEvent on button click', async () => {
    const mockDispatch = vi.fn(async () => Promise.resolve(undefined));
    (store as any).dispatch = mockDispatch;

        const { getByText } = render(
            <ThemeProvider theme={mockTheme}>
                <Provider store={store}>
                    <PhoneCancelScreen {...defaultProps} />
                </Provider>
            </ThemeProvider>,
        );

        await waitFor(() => {
            expect(mockDispatch).toHaveBeenCalledWith(
                checkPhoneVisitStatusAndRedirect('123'),
            );
        });

        const button = getByText('SUBMIT');
        fireEvent.click(button);

        expect(V2Analytics.interactionEvent).toHaveBeenCalled();
    });
});
