import * as React from 'react';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { WithTranslation, withTranslation } from 'react-i18next';
import {
    cancelPhoneWithReason,
    checkPhoneVisitStatusAndRedirect,
} from '@redux/modules/postConsult';
import { useDispatch } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { FooterPage } from '@layout/PageLayout/FooterPage';
import {
    useMediaQuery,
    Typography,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Button,
    Card,
    SelectChangeEvent,
    TypographyProps,
} from '@mui/material';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { ThunkDispatch } from 'types/redux';
import { AnyAction } from 'redux';
import { defaultReasonsForCancel } from '@utils/otUtils';
import CircularProgress from '@mui/material/CircularProgress';
import type { UserDetails } from '@dexcare/circus-saturn';

const PhoneCancelScreenTypography = (props: TypographyProps) => (
    <Typography
        {...props}
        sx={{
            ...(props.sx ?? {}),
            fontFamily: 'Open Sans',
        }}
    >
        {props.children}
    </Typography>
);

export interface PhoneCancelScreenProps {
    userDetails: UserDetails;
}

const PhoneCancelScreenComponent: React.FC<
    PhoneCancelScreenProps & WithTranslation
> = (props) => {
    const [loading, setLoading] = React.useState(true);

    let reasonsForCancel = props.t('cancelWithReason.reasons', {
        returnObjects: true,
    }) as unknown as { label: string; value: string }[];
    if (!Array.isArray(reasonsForCancel)) {
        reasonsForCancel = defaultReasonsForCancel;
    }
    let headerText = props.t('cancelWithReason.phone.header');
    if (headerText === 'cancelWithReason.phone.header')
        headerText = 'Your place in line is reserved.';
    let bodyText = props.t('cancelWithReason.phone.body');
    if (bodyText === 'cancelWithReason.phone.body')
        bodyText = 'Cancelling now will remove you from the queue.';
    let instructionText = props.t('cancelWithReason.phone.instruction');
    if (instructionText === 'cancelWithReason.phone.instruction')
        instructionText =
            'If you wish to keep the appointment, please close this window. Your provider will call you at the provided phone number when they are ready.';
    let reasonText = props.t('cancelWithReason.phone.reason');
    if (reasonText === 'cancelWithReason.phone.reason')
        reasonText =
            'If you still need to cancel, please select a reason below.';
    let label = props.t('cancelWithReason.phone.label');
    if (label === 'cancelWithReason.phone.label')
        label = 'Reason for cancelling';
    let button = props.t('cancelWithReason.phone.button');
    if (button === 'cancelWithReason.phone.button') button = 'SUBMIT';

    const params = useParams();
    const navigate = useNavigate();
    const visitId = params?.visitId;
    const dispatch: ThunkDispatch<unknown, void, AnyAction> = useDispatch();

    const urlParams = new URLSearchParams(window.location.search);
    const patientEmail = urlParams.get('email');

    const defaultReasonSelected = reasonsForCancel[0].value;
    const [reason, setReason] = React.useState<string | null>(
        defaultReasonSelected,
    );

    const isSmallScreen = useMediaQuery('(max-width:600px)');

    const cancelVisitHandler = () => {
        V2Analytics.interactionEvent({
            eventName: 'visit_cancel',
            visit_id: visitId,
            user: props.userDetails,
        });

        void dispatch(checkPhoneVisitStatusAndRedirect(visitId));
        void dispatch(cancelPhoneWithReason(visitId, reason, patientEmail));
        navigate('/publicvisit/closed/cancelled', { replace: true });
    };

    const handleReasonChange = (event: SelectChangeEvent<string>) => {
        setReason(event.target.value);
    };

    React.useEffect(() => {
        const checkStatusAndSetLoading = async () => {
            await dispatch(checkPhoneVisitStatusAndRedirect(visitId));
            setLoading(false);
        };

        void checkStatusAndSetLoading();
    }, [dispatch, visitId]);

    if (loading) {
        return (
            <div
                style={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'flex-start',
                    height: '50vh',
                    marginTop: '10vh',
                }}
            >
                <CircularProgress variant="indeterminate" />
            </div>
        );
    }

    const main = (
        <div>
            <Card
                sx={{
                    display: 'flex',
                    alignItems: 'center',
                    flexDirection: 'column',
                    position: 'relative',
                    m: { xs: 2, sm: 4 },
                    p: { xs: 2, sm: 4 },
                    pb: { xs: 10, sm: 0 },
                    width: { xs: '85vw', sm: 500 },
                    height: { xs: 'auto', sm: 500 },
                }}
            >
                <div style={{ flex: 1, width: '100%' }}>
                    <PhoneCancelScreenTypography
                        variant={isSmallScreen ? 'h6' : 'h4'}
                        sx={{ fontWeight: '600' }}
                    >
                        {headerText}
                    </PhoneCancelScreenTypography>
                    <PhoneCancelScreenTypography
                        variant={isSmallScreen ? 'body1' : 'h6'}
                        sx={{ fontWeight: '600', mt: 1.5 }}
                    >
                        {bodyText}
                    </PhoneCancelScreenTypography>
                    <PhoneCancelScreenTypography
                        variant="subtitle1"
                        sx={{ mt: 1 }}
                    >
                        {instructionText}
                    </PhoneCancelScreenTypography>
                    <PhoneCancelScreenTypography
                        variant="subtitle1"
                        sx={{ fontWeight: '500', mt: 1 }}
                    >
                        {reasonText}
                    </PhoneCancelScreenTypography>
                    <FormControl
                        fullWidth
                        variant="outlined"
                        margin="normal"
                        sx={{ mt: 4 }}
                    >
                        <InputLabel id="cancel-reason-label">
                            {label}
                        </InputLabel>
                        <Select
                            labelId="cancel-reason-label"
                            id="cancel-reason"
                            value={reason}
                            onChange={handleReasonChange}
                            label="Reason for cancelling"
                            IconComponent={KeyboardArrowDownIcon}
                        >
                            {reasonsForCancel.map((r) => (
                                <MenuItem key={r.value} value={r.value}>
                                    {r.label}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </div>
                <div
                    style={{
                        position: 'absolute',
                        bottom: 0,
                        right: 0,
                        margin: 16,
                    }}
                >
                    <Button
                        variant="contained"
                        sx={{ width: 140 }}
                        onClick={cancelVisitHandler}
                    >
                        {button}
                    </Button>
                </div>
            </Card>
        </div>
    );

    return <FooterPage>{main}</FooterPage>;
};

const PhoneCancelScreen = withTranslation()(
    PhoneCancelScreenComponent,
) as React.ComponentType<PhoneCancelScreenProps>;

export { PhoneCancelScreen };
