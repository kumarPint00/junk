import { vi } from 'vitest';
import { OTError, Device } from '@dexcare/yak';

const mockOT = {
    initPublisher: vi.fn(() => {
        return {
            off: vi.fn(),
            on: vi.fn(),
            destroy: vi.fn(),
            publishVideo: vi.fn(),
            publishAudio: vi.fn(),
            setVideoSource: vi.fn(),
            setAudioSource: vi.fn(),
            hasAudio: vi.fn(),
            hasVideo: vi.fn(),
        };
    }),
    getDevices: vi.fn(
        (
            callback: (error: OTError | undefined, devices?: Device[]) => void,
        ) => {
            callback(undefined, [
                {
                    label: 'Test Video Device',
                    deviceId: 'video1',
                    kind: 'videoInput',
                },
                {
                    label: 'Test Audio Device',
                    deviceId: 'audio1',
                    kind: 'audioInput',
                },
            ]);
        },
    ),
    TypingState: {
        TypingStopped: 0,
        TypingStarted: 1,
    },
    SessionHelper: vi.fn().mockReturnValue({
        destroy: vi.fn(),
        connect: vi.fn(),
        publish: vi.fn(),
        sendEndCall: vi.fn(),
        sendInstantMessage: vi.fn(),
        sendModalityConversion: vi.fn(),
        sendParticipantDetails: vi.fn(),
        getLocalConnectionData: vi.fn(),
    }),
};

module.exports = mockOT;
