import { vi } from 'vitest';

module.exports = {
    sendEvent: vi.fn(),
    sendPageView: vi.fn(),
};
