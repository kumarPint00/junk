import { vi } from 'vitest';

const mockLogger = vi.hoisted(() => {
    class Logger {
        info() {}
        warn() {}
        trace() {}
        debug() {}
        error() {}
        child() {
            return new Logger();
        }
    }
    return new Logger();
});

const jupiter = {
    LogManager: {
        addApplicationContext: vi.fn(),
        getLogger: () => mockLogger,
        mockLogger,
    },
    jupiterOptions: {},
    config: {
        getConfig: vi.fn(() => {
            return {
                reconnectingWebsocket: vi.fn,
                appTier: 'LOCAL',
                tokboxProjectKey: 'testKey',
                technicalSupportHelpNumber: '1-844-552-2734',
                atHomeVisitServer: 'http://mock-visit-server',
                inactivityTimeout: 5000,
                readMessageDelay: 5,
                maxConsultLength: 300,
                styles: {
                    primaryColor: '#ffffff',
                    secondaryColor: '#efefef',
                },
            };
        }),
    },
    location: {
        setLocationPathname: vi.fn(),
    },
};

module.exports = jupiter;
