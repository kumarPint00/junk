import * as React from 'react';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import createBlisseyTheme from '../src/utils/createBlisseyTheme';
import { config } from '@dexcare/circus-jupiter';
import { Configuration } from 'types/configuration';

export const MuiRippleDisabledWrapper = ({
    children,
}: React.PropsWithChildren<unknown>) => {
    return (
        <ThemeProvider
            theme={createTheme(
                createBlisseyTheme((config as Configuration).getConfig()),
                {
                    components: {
                        MuiButtonBase: {
                            defaultProps: {
                                disableRipple: true,
                            },
                        },
                    },
                    transitions: {
                        create: () => 'none',
                    },
                },
            )}
        >
            {children}
        </ThemeProvider>
    );
};
