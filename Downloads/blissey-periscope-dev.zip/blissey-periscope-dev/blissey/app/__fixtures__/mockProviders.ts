import { Provider } from '@clients/VisitService/VisitInterfaces';
export const mockProviders: Provider[] = [
    {
        id: '32069188-fc7d-4489-90c8-3dec0b36111c1',
        smsNumber: '2025551212',
        displayInfo: {
            name: 'DexCare Provider.121',
        },
        oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
        practiceRegions: [
            {
                id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                regionCode: 'MT',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                regionCode: 'WA',
                practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                market: {
                    id: '1b5f813d-3f49-4396-b82d-9c4704039f8d',
                    name: 'Backup',
                    description: 'Backup',
                },
            },
            {
                id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                regionCode: 'OR',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                regionCode: 'WA',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
        ],
        assignmentQualifiers: [
            {
                id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                name: 'pediatric',
            },
            {
                id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                name: 'adult',
            },
        ],
        modalities: [
            {
                id: '57ffd934-1226-41be-b93a-30af16c056e4',
                name: 'virtual',
            },
            {
                id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                name: 'phone',
            },
        ],
        visitId: null,
    },
    {
        id: '32069188-fc7d-4489-90c8-3dec0b36111c2',
        smsNumber: '2025551212',
        displayInfo: {
            name: 'DexCare Provider.122',
        },
        oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
        practiceRegions: [
            {
                id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                regionCode: 'MT',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                regionCode: 'WA',
                practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                market: {
                    id: '1b5f813d-3f49-4396-b82d-9c4704039f8d',
                    name: 'Backup',
                    description: 'Backup',
                },
            },
            {
                id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                regionCode: 'OR',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                regionCode: 'WA',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
        ],
        assignmentQualifiers: [
            {
                id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                name: 'pediatric',
            },
            {
                id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                name: 'adult',
            },
        ],
        modalities: [
            {
                id: '57ffd934-1226-41be-b93a-30af16c056e4',
                name: 'virtual',
            },
            {
                id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                name: 'phone',
            },
        ],
        visitId: null,
    },
    {
        id: '32069188-fc7d-4489-90c8-3dec0b36111c3',
        smsNumber: '2025551212',
        displayInfo: {
            name: 'DexCare Provider.123',
        },
        oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
        practiceRegions: [
            {
                id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                regionCode: 'MT',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                regionCode: 'WA',
                practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                market: {
                    id: '1b5f813d-3f49-4396-b82d-9c4704039f8d',
                    name: 'Backup',
                    description: 'Backup',
                },
            },
            {
                id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                regionCode: 'OR',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                regionCode: 'WA',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
        ],
        assignmentQualifiers: [
            {
                id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                name: 'pediatric',
            },
            {
                id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                name: 'adult',
            },
        ],
        modalities: [
            {
                id: '57ffd934-1226-41be-b93a-30af16c056e4',
                name: 'virtual',
            },
            {
                id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                name: 'phone',
            },
        ],
        visitId: null,
    },
    {
        id: '32069188-fc7d-4489-90c8-3dec0b36111c4',
        smsNumber: '2025551212',
        displayInfo: {
            name: 'DexCare Provider.124',
        },
        oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
        practiceRegions: [
            {
                id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                regionCode: 'MT',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                regionCode: 'WA',
                practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                market: {
                    id: '1b5f813d-3f49-4396-b82d-9c4704039f8d',
                    name: 'Backup',
                    description: 'Backup',
                },
            },
            {
                id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                regionCode: 'OR',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                regionCode: 'WA',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
        ],
        assignmentQualifiers: [
            {
                id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                name: 'pediatric',
            },
            {
                id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                name: 'adult',
            },
        ],
        modalities: [
            {
                id: '57ffd934-1226-41be-b93a-30af16c056e4',
                name: 'virtual',
            },
            {
                id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                name: 'phone',
            },
        ],
        visitId: null,
    },
    {
        id: '32069188-fc7d-4489-90c8-3dec0b36111c5',
        smsNumber: '2025551212',
        displayInfo: {
            name: 'DexCare Provider.122',
        },
        oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
        practiceRegions: [
            {
                id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                regionCode: 'MT',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                regionCode: 'WA',
                practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                market: {
                    id: '1b5f813d-3f49-4396-b82d-9c4704039f8d',
                    name: 'Backup',
                    description: 'Backup',
                },
            },
            {
                id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                regionCode: 'OR',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                regionCode: 'WA',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
        ],
        assignmentQualifiers: [
            {
                id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                name: 'pediatric',
            },
            {
                id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                name: 'adult',
            },
        ],
        modalities: [
            {
                id: '57ffd934-1226-41be-b93a-30af16c056e4',
                name: 'virtual',
            },
            {
                id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                name: 'phone',
            },
        ],
        visitId: null,
    },
    {
        id: '32069188-fc7d-4489-90c8-3dec0b36111c6',
        smsNumber: '2025551212',
        displayInfo: {
            name: 'DexCare Provider.122',
        },
        oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
        practiceRegions: [
            {
                id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                regionCode: 'MT',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                regionCode: 'WA',
                practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                market: {
                    id: '1b5f813d-3f49-4396-b82d-9c4704039f8d',
                    name: 'Backup',
                    description: 'Backup',
                },
            },
            {
                id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                regionCode: 'OR',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                regionCode: 'WA',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
        ],
        assignmentQualifiers: [
            {
                id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                name: 'pediatric',
            },
            {
                id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                name: 'adult',
            },
        ],
        modalities: [
            {
                id: '57ffd934-1226-41be-b93a-30af16c056e4',
                name: 'virtual',
            },
            {
                id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                name: 'phone',
            },
        ],
        visitId: null,
    },
    {
        id: '32069188-fc7d-4489-90c8-3dec0b36111c7',
        smsNumber: '2025551212',
        displayInfo: {
            name: 'DexCare Provider.122',
        },
        oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
        practiceRegions: [
            {
                id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                regionCode: 'MT',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                regionCode: 'WA',
                practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                market: {
                    id: '1b5f813d-3f49-4396-b82d-9c4704039f8d',
                    name: 'Backup',
                    description: 'Backup',
                },
            },
            {
                id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                regionCode: 'OR',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                regionCode: 'WA',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
        ],
        assignmentQualifiers: [
            {
                id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                name: 'pediatric',
            },
            {
                id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                name: 'adult',
            },
        ],
        modalities: [
            {
                id: '57ffd934-1226-41be-b93a-30af16c056e4',
                name: 'virtual',
            },
            {
                id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                name: 'phone',
            },
        ],
        visitId: null,
    },
    {
        id: '32069188-fc7d-4489-90c8-3dec0b36111c8',
        smsNumber: '2025551212',
        displayInfo: {
            name: 'DexCare Provider.122',
        },
        oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
        practiceRegions: [
            {
                id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                regionCode: 'MT',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                regionCode: 'WA',
                practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                market: {
                    id: '1b5f813d-3f49-4396-b82d-9c4704039f8d',
                    name: 'Backup',
                    description: 'Backup',
                },
            },
            {
                id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                regionCode: 'OR',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                regionCode: 'WA',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
        ],
        assignmentQualifiers: [
            {
                id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                name: 'pediatric',
            },
            {
                id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                name: 'adult',
            },
        ],
        modalities: [
            {
                id: '57ffd934-1226-41be-b93a-30af16c056e4',
                name: 'virtual',
            },
            {
                id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                name: 'phone',
            },
        ],
        visitId: null,
    },
    {
        id: '32069188-fc7d-4489-90c8-3dec0b36111c9',
        smsNumber: '2025551212',
        displayInfo: {
            name: 'DexCare Provider.122',
        },
        oncallPractice: '6996d161-cd16-4556-9577-f942c3f80c80',
        practiceRegions: [
            {
                id: '8a43204f-f0ef-4dcb-ac9d-4e68ddb2ca87',
                regionCode: 'MT',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '9a85e100-882e-49e8-9df5-9e6d5144d08d',
                regionCode: 'WA',
                practiceId: '9d664295-f17b-4421-95e3-20b4774a6f3f',
                market: {
                    id: '1b5f813d-3f49-4396-b82d-9c4704039f8d',
                    name: 'Backup',
                    description: 'Backup',
                },
            },
            {
                id: '4079564f-7f7d-4dbc-8723-f4b1ecc8d759',
                regionCode: 'OR',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
            {
                id: '47dfa34d-a73a-4d66-b300-fe9d4c8c3e01',
                regionCode: 'WA',
                practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
                market: {
                    id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                    name: 'Default',
                    description: 'Default',
                },
            },
        ],
        assignmentQualifiers: [
            {
                id: 'b48cc66e-5fc0-4e63-9b00-1a10f0c90317',
                name: 'pediatric',
            },
            {
                id: 'bf7a7c7d-a90d-4999-9162-796c8abe761a',
                name: 'adult',
            },
        ],
        modalities: [
            {
                id: '57ffd934-1226-41be-b93a-30af16c056e4',
                name: 'virtual',
            },
            {
                id: '5f928949-3ad4-4a41-8e1c-5dd4bd3dd097',
                name: 'phone',
            },
        ],
        visitId: null,
    },
];
