import { mockProviders } from './mockProviders';
export const successResponse = {
    providers: mockProviders,
    practiceRegions: [
        {
            id: '2dfdc1bf-ff7f-4e3f-a25f-c546aa5fcfbc',
            practiceId: '6996d161-cd16-4556-9577-f942c3f80c80',
            displayName: 'Washington Backup',
            regionCode: 'WA',
            active: true,
            availability: [
                {
                    start: '2023-09-17T07:00:00.000Z',
                    end: '2023-09-18T06:59:00.000Z',
                },
                {
                    start: '2023-09-18T07:00:00.000Z',
                    end: '2023-09-19T06:59:00.000Z',
                },
                {
                    start: '2023-09-19T07:00:00.000Z',
                    end: '2023-09-20T06:59:00.000Z',
                },
                {
                    start: '2023-09-20T07:00:00.000Z',
                    end: '2023-09-21T06:59:00.000Z',
                },
                {
                    start: '2023-09-21T07:00:00.000Z',
                    end: '2023-09-22T06:59:00.000Z',
                },
                {
                    start: '2023-09-22T07:00:00.000Z',
                    end: '2023-09-23T06:59:00.000Z',
                },
                {
                    start: '2023-09-23T07:00:00.000Z',
                    end: '2023-09-24T06:59:00.000Z',
                },
            ],
            busy: false,
            busyMessage: 'Providers are currently at capacity and closed',
            paymentAccountId: '3faed309-efd8-45ab-a9de-1bc149745bb2',
            visitPrice: 4900,
            orderWeight: 0,
            departments: [
                {
                    id: '4d2a72d5-41d5-462d-985b-9e2ce41c1570',
                    epicDepartmentId: '405772000',
                    ehrSystemName: 'org.providence.dig.epic.provorca',
                    defaultDepartmentName: 'Interstate',
                },
            ],
            market: {
                id: 'ecf8afd8-310e-4f78-99a6-3105fba34be1',
                name: 'Backup',
                description: 'Backup',
            },
            transferOptionBufferInMinutes: 700,
        },
    ],
};
