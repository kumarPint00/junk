// This plugin is a ripoff from https://github.com/Summer-andy/vite-plugin-transform-css-modules
// Is not working out of the box because of the import statement
import { transformSync } from 'esbuild';
const importRE =
    /import\s(\*\sas\s|)+([\S]+)\s+from\s+('|")([\S]+)\.(css|less|sass|scss|styl|stylus|postcss)(\?[\S]*)?('|")/;
const jsRE = /\.(js|mjs|ts|jsx|tsx)/;

function transform(code: string, { file }: { file: string }) {
    const parsePlugins = ['jsx'];

    if (/\.tsx?$/.test(file)) {
        parsePlugins.push('typescript');
    }

    const result = transformSync(code, {
        format: 'esm',
        sourcemap: true,
        sourcefile: file,
    });

    return {
        code: result.code.replaceAll('.css"', '.css?.module.styl"'),
        map: JSON.parse(result.map) as object,
    };
}

export default function viteTransformCSSModulesPlugin() {
    return {
        name: 'vite-plugin-transform-css-modules',
        transform(code: string, id: string) {
            if (jsRE.test(id) && importRE.test(code)) {
                const result = transform(code, {
                    file: id,
                });

                if (result) {
                    return result;
                }
            }

            return undefined;
        },
    };
}
