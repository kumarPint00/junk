import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';
import { nodePolyfills } from 'vite-plugin-node-polyfills';
import purgeCss from 'vite-plugin-purgecss';
import vitePluginTransformCssModules from './vitePluginTransformCssModules';
import paths from './paths';

export default defineConfig({
    resolve: {
        alias: {
            '@clients': path.join(paths.appSrc, 'clients'),
            '@common': path.join(paths.appSrc, 'common'),
            '@components': path.join(paths.appSrc, 'components'),
            '@layout': path.join(paths.appSrc, 'layout'),
            '@modules': path.join(paths.appSrc, 'modules'),
            '@transformers': path.join(paths.appSrc, 'transformers'),
            '@redux': path.join(paths.appSrc, 'redux'),
            '@context': path.join(paths.appSrc, 'context'),
            '@containers': path.join(paths.appSrc, 'containers'),
            '@services': path.join(paths.appSrc, 'services'),
            '@stageManagement': path.join(paths.appSrc, 'stageManagement'),
            '@utils': path.join(paths.appSrc, 'utils'),
            '@logic': path.join(paths.appSrc, 'logic'),
        },
        extensions: ['.scss', '.ts', '.tsx', '.js', '.json'],
    },
    plugins: [
        react({ tsDecorators: true }),
        vitePluginTransformCssModules(),
        purgeCss({ variables: true }),
        nodePolyfills(),
    ],
});
