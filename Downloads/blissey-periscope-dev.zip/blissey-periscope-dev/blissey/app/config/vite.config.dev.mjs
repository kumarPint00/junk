import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';
import { createHtmlPlugin } from 'vite-plugin-html';
import { nodePolyfills } from 'vite-plugin-node-polyfills';
import purgeCss from 'vite-plugin-purgecss';
import vitePluginTransformCssModules from './vitePluginTransformCssModules';
import { viteCommonjs } from '@originjs/vite-plugin-commonjs';
import paths from './paths';
import { visualizer } from 'rollup-plugin-visualizer';

export default defineConfig({
    mode: 'development',
    build: {
        outDir: paths.appBuild,
        sourcemap: true,
        rollupOptions: {
            output: {
                assetFileNames: 'static/[ext]/[name].[hash].[ext]',
                chunkFileNames: 'static/js/[name].[hash].js',
                entryFileNames: 'static/js/[name].[hash].js',
                format: 'es',
            },
        },
        target: ['es6'],
    },
    optimizeDeps: {
        esbuildOptions: {
            tsconfig: 'tsconfig.json',
        },
    },
    css: {
        transformer: 'lightningcss',
        lightningcss: {
            sourceMap: true,
            cssModules: true,
        },
    },
    resolve: {
        alias: {
            '@clients': path.join(paths.appSrc, 'clients'),
            '@common': path.join(paths.appSrc, 'common'),
            '@components': path.join(paths.appSrc, 'components'),
            '@layout': path.join(paths.appSrc, 'layout'),
            '@modules': path.join(paths.appSrc, 'modules'),
            '@transformers': path.join(paths.appSrc, 'transformers'),
            '@redux': path.join(paths.appSrc, 'redux'),
            '@context': path.join(paths.appSrc, 'context'),
            '@containers': path.join(paths.appSrc, 'containers'),
            '@services': path.join(paths.appSrc, 'services'),
            '@stageManagement': path.join(paths.appSrc, 'stageManagement'),
            '@utils': path.join(paths.appSrc, 'utils'),
            '@logic': path.join(paths.appSrc, 'logic'),
        },
        extensions: ['.scss', '.ts', '.tsx', '.js', '.json'],
    },
    define: {
        'process.env.NODE_ENV': '"development"',
    },
    plugins: [
        react({ tsDecorators: true }),
        createHtmlPlugin({
            entry: 'src/index.tsx',
            inject: {
                data: {
                    title: 'Express Care Virtual',
                    injectScript: `<script type="module" src="./inject.js"></script>`,
                },
            },
            template: 'index.html',
            minify: false,
        }),
        vitePluginTransformCssModules(),
        purgeCss({ variables: true }),
        nodePolyfills(),
        viteCommonjs({ skipPreBuild: true }),
        visualizer({
            template: 'treemap', // sunburst | treemap | network
            filename: '.stats.html',
            open: true,
        }),
    ],
    server: {
        port: 7777,
        strictPort: true,
    },
});

