import path from 'path';

export default {
    appBuild: path.resolve('build'),
    appHtml: path.resolve('index.html'),
    appFavicon: path.resolve('favicon.ico'),
    appPackageJson: path.resolve('package.json'),
    appSrc: path.resolve('src'),
    appAssets: path.resolve('assets'),
    appNodeModules: path.resolve('node_modules'),
    appTest: path.resolve('test'),
};
