import { defineConfig, splitVendorChunkPlugin } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'path';
import { createHtmlPlugin } from 'vite-plugin-html';
import commonjs from 'vite-plugin-commonjs';
import { nodePolyfills } from 'vite-plugin-node-polyfills';
import { optimizeCssModules } from 'vite-plugin-optimize-css-modules';
import purgeCss from 'vite-plugin-purgecss';
import vitePluginTransformCssModules from './vitePluginTransformCssModules';
import { viteStaticCopy } from 'vite-plugin-static-copy';
import paths from './paths';

export default defineConfig({
    mode: 'production',
    build: {
        outDir: paths.appBuild,
        sourcemap: false,
        rollupOptions: {
            output: {
                assetFileNames: 'static/[ext]/[name].[hash].[ext]',
                chunkFileNames: 'static/js/[name].[hash].js',
                entryFileNames: 'static/js/[name].[hash].js',
                format: 'es',
            },
        },
        target: ['es2020'],
    },
    optimizeDeps: {
        esbuildOptions: {
            tsconfig: 'tsconfig.json',
        },
    },
    css: {
        transformer: 'lightningcss',
        lightningcss: {
            sourceMap: true,
            cssModules: true,
        },
    },
    resolve: {
        alias: {
            '@clients': path.join(paths.appSrc, 'clients'),
            '@common': path.join(paths.appSrc, 'common'),
            '@components': path.join(paths.appSrc, 'components'),
            '@layout': path.join(paths.appSrc, 'layout'),
            '@modules': path.join(paths.appSrc, 'modules'),
            '@transformers': path.join(paths.appSrc, 'transformers'),
            '@redux': path.join(paths.appSrc, 'redux'),
            '@context': path.join(paths.appSrc, 'context'),
            '@containers': path.join(paths.appSrc, 'containers'),
            '@services': path.join(paths.appSrc, 'services'),
            '@stageManagement': path.join(paths.appSrc, 'stageManagement'),
            '@utils': path.join(paths.appSrc, 'utils'),
            '@logic': path.join(paths.appSrc, 'logic'),
        },
        extensions: ['.scss', '.ts', '.tsx', '.js', '.json'],
    },
    define: {
        'process.env.NODE_ENV': '"production"',
    },
    plugins: [
        react({ tsDecorators: true }),
        viteStaticCopy({
            targets: [
                { src: paths.appAssets, dest: '.' },
                { src: paths.appFavicon, dest: '.' },
            ],
        }),
        createHtmlPlugin({
            entry: 'src/index.tsx',
            inject: {
                data: {
                    title: 'Express Care Virtual',
                    injectScript: `<script type="module" src="./inject.js"></script>`,
                },
            },
            template: 'index.html',
            minify: {
                removeComments: true,
                collapseWhitespace: true,
                removeRedundantAttributes: true,
                useShortDoctype: true,
                removeEmptyAttributes: true,
                removeStyleLinkTypeAttributes: true,
                keepClosingSlash: true,
                minifyJS: true,
                minifyCSS: true,
                minifyURLs: true,
            },
        }),
        vitePluginTransformCssModules(),
        purgeCss({ variables: true }),
        optimizeCssModules(),
        splitVendorChunkPlugin(),
        nodePolyfills(),
        commonjs(),
    ],
    server: {
        port: 7777,
        strictPort: true,
    },
    preview: {
        port: 7777,
        strictPort: true,
    },
});
