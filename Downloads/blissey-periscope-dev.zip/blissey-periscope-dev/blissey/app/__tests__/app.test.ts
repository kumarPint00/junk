import { Mocked, vi } from 'vitest';
import { recoverGuestSessionFromAccessCode } from '../src/app';
import { backendFacade } from '../src/clients/Backend/BackendFacade';

vi.mock('../src/clients/Backend/BackendFacade', () => {
    return {
        backendFacade: {
            recoverGuestSession: vi.fn(),
        },
    };
});

const mockBackendFacade = backendFacade as Mocked<typeof backendFacade>;

describe('app.ts', () => {
    describe('recoverGuestSessionFromAccessCode', () => {
        function mockLocation(url: string) {
            return new URL(url) as unknown as Location;
        }

        afterEach(() => {
            vi.resetAllMocks();
        });

        it("recover access code when it's in the url hash", async () => {
            const location = mockLocation(
                'http://localhost:5000/visit/fcfa8a76-8def-4568-8452-17b3e78f2456?brand=providence&guest=patient&redirect=true#access-code=732b91e3053eed09ced5d4e7ccabe6c0',
            );

            await recoverGuestSessionFromAccessCode(location);

            expect(mockBackendFacade.recoverGuestSession).toHaveBeenCalledWith(
                '732b91e3053eed09ced5d4e7ccabe6c0',
            );
        });

        it.each([
            'http://localhost:5000/visit/fcfa8a76-8def-4568-8452-17b3e78f2456?brand=providence&guest=patient&redirect=true',
            'http://localhost:5000/visit/fcfa8a76-8def-4568-8452-17b3e78f2456?brand=providence&guest=patient&redirect=true#foo',
            'http://localhost:5000/',
        ])("recover access code when it's in the url hash", async (url) => {
            const location = mockLocation(url);

            await recoverGuestSessionFromAccessCode(location);

            expect(
                mockBackendFacade.recoverGuestSession,
            ).not.toHaveBeenCalled();
        });
    });
});
