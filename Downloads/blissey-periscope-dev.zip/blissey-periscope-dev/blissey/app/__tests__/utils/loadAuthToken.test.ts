import { JwtTokenHelper, initJwtStorage } from '../../src/utils/jwt-helper';
import { UserDetails } from '../../src/types/UserDetails';
import { ClientAppConfig } from '../../../server/config/configInterfaces';
import { loadAuthToken } from '../../src/utils/loadAuthToken';
import { MockedFunction, vi } from 'vitest';
import { FeatureFlags } from '@utils/FeatureFlags';

vi.mock('../../src/utils/jwt-helper');

const testSessionToken = 'testSessionToken';
const testAccessToken = 'testAccessToken';
const testJwt = 'testJwt';
const otherToken = 'randomToken';

describe('loadAuthToken', () => {
    const saveAuthenticationTokenStub = vi.fn();
    const initJwtStorageStub = initJwtStorage as MockedFunction<
        typeof initJwtStorage
    >;

    beforeAll(() => {
        initJwtStorageStub.mockReturnValue({
            saveAuthenticationToken: saveAuthenticationTokenStub,
        } as unknown as JwtTokenHelper);
    });

    afterEach(() => {
        vi.clearAllMocks();
    });

    it('when sharedSessionStoreEnabled is enabled, saves the session token and assigns it to the user details token field', () => {
        const userDetails = {
            sharedSessionStoreEnabled: true,
            sessionToken: testSessionToken,
            token: otherToken, // in reality, the `token` field usually matches the session token
        } as UserDetails;

        loadAuthToken(userDetails, {} as ClientAppConfig, 'someBrand');

        expect(saveAuthenticationTokenStub).toHaveBeenCalledWith(
            testSessionToken,
        );
        expect(userDetails.token).toEqual(testSessionToken);
    });

    describe('when sharedSessionStoreEnabled is disabled', () => {
        const testBrand = 'someBrand';

        it.each([
            // jwt
            {
                id: 'fooMyChartbar',
                roles: [],
                token: otherToken,
                useGuestFlowForPatientAuth: false,
                usePatientAccessTokenBearer: false,
                jwt: testJwt,
                accessToken: undefined,
                savedToken: testJwt,
                assignedToken: testJwt,
            },
            {
                id: 'fooMyChartbar',
                roles: ['telehealth_patient'],
                token: otherToken,
                useGuestFlowForPatientAuth: false,
                usePatientAccessTokenBearer: false,
                jwt: testJwt,
                accessToken: undefined,
                savedToken: testJwt,
                assignedToken: testJwt,
            },
            {
                id: 'someId',
                roles: ['telehealth_patient'],
                token: otherToken,
                useGuestFlowForPatientAuth: true,
                usePatientAccessTokenBearer: false,
                jwt: testJwt,
                accessToken: undefined,
                savedToken: testJwt,
                assignedToken: testJwt,
            },

            // access token
            {
                id: 'someId',
                roles: ['telehealth_patient'],
                token: otherToken,
                useGuestFlowForPatientAuth: false,
                usePatientAccessTokenBearer: true,
                jwt: undefined,
                accessToken: testAccessToken,
                savedToken: testAccessToken,
                assignedToken: testAccessToken,
            },
            {
                id: 'someId',
                roles: ['telehealth_patient'],
                token: otherToken,
                useGuestFlowForPatientAuth: false,
                usePatientAccessTokenBearer: true,
                jwt: testJwt,
                accessToken: testAccessToken,
                savedToken: testAccessToken,
                assignedToken: testAccessToken,
            },

            // other token
            {
                id: 'someId',
                roles: [],
                token: otherToken,
                useGuestFlowForPatientAuth: false,
                usePatientAccessTokenBearer: false,
                jwt: undefined,
                accessToken: undefined,
                savedToken: otherToken,
                assignedToken: otherToken,
            },
            {
                id: 'someId',
                roles: [],
                token: otherToken,
                useGuestFlowForPatientAuth: false,
                usePatientAccessTokenBearer: false,
                jwt: testJwt,
                accessToken: testAccessToken,
                savedToken: otherToken,
                assignedToken: otherToken,
            },
            // add other conditions/permutations that resolve to using userDetails.token
        ])(
            'Saves and assigns the correct token to the userdetails token field, depending on config and user details conditions',
            ({
                id,
                roles,
                token,
                useGuestFlowForPatientAuth,
                usePatientAccessTokenBearer,
                jwt,
                accessToken,
                savedToken,
                assignedToken,
            }) => {
                const userDetails = {
                    id,
                    roles,
                    sharedSessionStoreEnabled: false,
                    token,
                    jwt,
                    accessToken,
                } as UserDetails;
                const config = {
                    brandConfig: {
                        [testBrand]: {
                            usePatientAccessTokenBearer,
                        },
                    },
                    features: {
                        [FeatureFlags.enableGuestFlowForPatientAuth]:
                            useGuestFlowForPatientAuth,
                    },
                } as unknown as ClientAppConfig;

                loadAuthToken(userDetails, config, testBrand);

                expect(saveAuthenticationTokenStub).toHaveBeenCalledWith(
                    savedToken,
                );
                expect(userDetails.token).toEqual(assignedToken);
            },
        );
    });
});
