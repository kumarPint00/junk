import { renderHook, act, waitFor } from '@testing-library/react';
import { vi } from 'vitest';
import useVideoDevice from '@utils/useVideoDevice';

beforeAll(() => {
    global.navigator = {
        ...global.navigator,
        mediaDevices: {
            enumerateDevices: vi.fn(),
            ...global?.navigator?.mediaDevices,
        },
    };
});

const devices: MediaDeviceInfo[] = [
    {
        kind: 'videoinput',
        label: 'Front Camera',
        deviceId: 'front-123',
        groupId: 'group-123',
        toJSON: () => {},
    },
    {
        kind: 'videoinput',
        label: 'Back Camera',
        deviceId: 'back-456',
        groupId: 'group-456',
        toJSON: () => {},
    },
];

describe('useVideoDevice', () => {
    it('should initialize with null values and no error', () => {
        const { result } = renderHook(() => useVideoDevice());

        expect(result.current.currentCamera).toBeNull();
        expect(result.current.error).toBeUndefined();
    });

    it('should set front and back cameras correctly', async () => {
        (
            global?.navigator?.mediaDevices?.enumerateDevices as jest.Mock<
                Promise<MediaDeviceInfo[]>
            >
        ).mockResolvedValue(Promise.resolve(devices));

        const { result } = renderHook(() => useVideoDevice());

        await waitFor(() => expect(result.current.error).toBeUndefined());
        await waitFor(() =>
            expect(result.current.currentCamera).toBe('front-123'),
        );
    });

    it('should handle error if no video devices found', async () => {
        (
            global?.navigator?.mediaDevices?.enumerateDevices as jest.Mock<
                Promise<MediaDeviceInfo[]>
            >
        ).mockResolvedValue([]);

        const { result } = renderHook(() => useVideoDevice());
        await waitFor(() =>
            expect(result.current.error).toBe('Failed to get video devices'),
        );
    });

    it('should switch between front and back cameras', async () => {
        (
            global?.navigator?.mediaDevices?.enumerateDevices as jest.Mock<
                Promise<MediaDeviceInfo[]>
            >
        ).mockResolvedValue(Promise.resolve(devices));

        const { result } = renderHook(() => useVideoDevice());

        await waitFor(() =>
            expect(result.current.currentCamera).toBe('front-123'),
        );

        act(() => {
            result.current.switchCamera();
        });

        expect(result.current.currentCamera).toBe('back-456');

        act(() => {
            result.current.switchCamera();
        });

        expect(result.current.currentCamera).toBe('front-123');
    });
});
