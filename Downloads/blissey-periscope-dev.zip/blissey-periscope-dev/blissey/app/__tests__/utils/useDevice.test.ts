import { renderHook, act } from '@testing-library/react';
import useDevice from '@utils/useDevice';

describe('useDevice', () => {
    const originalUserAgent = navigator.userAgent;

    beforeAll(() => {
        Object.defineProperty(window.navigator, 'userAgent', {
            writable: true,
            value: originalUserAgent,
        });
    });

    it('should default to desktop', () => {
        const { result } = renderHook(() => useDevice());

        expect(result.current.isMobile).toBe(false);
    });

    it('should detect mobile user agent', () => {
        Object.defineProperty(window.navigator, 'userAgent', {
            writable: true,
            value: 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/14E5239e Safari/602.1',
        });

        const { result } = renderHook(() => useDevice());

        expect(result.current.isMobile).toBe(true);
    });

    it('should detect desktop user agent', () => {
        Object.defineProperty(window.navigator, 'userAgent', {
            writable: true,
            value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
        });

        const { result } = renderHook(() => useDevice());

        expect(result.current.isMobile).toBe(false);
    });

    it('should detect mobile Safari user agent', () => {
        Object.defineProperty(window.navigator, 'userAgent', {
            writable: true,
            value: 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/14E5239e Safari/602.1',
        });

        const { result } = renderHook(() => useDevice());

        expect(result.current.isMobile).toBe(true);
    });

    it('should update on resize', () => {
        Object.defineProperty(window.navigator, 'userAgent', {
            writable: true,
            value: originalUserAgent,
        });

        const { result } = renderHook(() => useDevice());

        expect(result.current.isMobile).toBe(false);

        Object.defineProperty(window.navigator, 'userAgent', {
            writable: true,
            value: 'Mozilla/5.0 (iPhone; CPU iPhone OS 10_3 like Mac OS X) AppleWebKit/602.1.50 (KHTML, like Gecko) Version/10.0 Mobile/14E5239e Safari/602.1',
        });

        act(() => {
            window.dispatchEvent(new Event('resize'));
        });

        expect(result.current.isMobile).toBe(true);
    });
});
