declare const window: Window & {
    HTMLMediaElement: {
        prototype: HTMLMediaElement;
    };
    Notification: Notification;
};

import { Mock, vi } from 'vitest';
import * as Notifications from '../../src/utils/Notification';

vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(() => ({
            notificationText: {
                notificationTitle: 'Express Care',
                newNotificationText:
                    'You have a notification from Express Care Virtual',
            },
        })),
    },
}));

vi.mock('../../src/utils/index', () => ({
    Logger: {
        info: vi.fn(),
    },
}));

const mockNotification = vi.fn();
Object.defineProperty(window, 'Notification', {
    value: mockNotification,
});

describe('Notification', () => {
    let staticMembers: {
        requestPermission: Mock;
        permission: string;
    };
    beforeEach(() => {
        staticMembers = {
            requestPermission: vi.fn().mockImplementation(() => {
                return 'granted';
            }),
            permission: 'granted',
        };
        window.HTMLMediaElement.prototype.play = () => undefined;
        Object.assign(window.Notification, staticMembers);
    });

    test('initNotifications will call requestPermission', () => {
        staticMembers.permission = 'denied';
        Object.assign(window.Notification, staticMembers);
        Notifications.initNotifications();
        expect(staticMembers.requestPermission.mock.calls).toHaveLength(1);
    });

    test('isDocumentVisible returns false because document is not hidden', () => {
        expect(Notifications.isDocumentVisible()).toBe(true);
    });

    test('notifyUser', () => {
        expect(
            Notifications.notifyUser(
                'mock notify',
                Notifications.NotificationType.alert,
            ),
        ).toMatchInlineSnapshot(`
          spy {
            "onclick": [Function],
          }
        `);
        expect(mockNotification).toHaveBeenCalledWith('Express Care', {
            body: 'mock notify',
            silent: true,
        });
    });
    test('notifyUser does not throw', () => {
        mockNotification.mockRejectedValueOnce('oops!');
        expect(
            Notifications.notifyUser(
                'mock notify',
                Notifications.NotificationType.alert,
            ),
        ).toEqual(undefined);
    });
});
