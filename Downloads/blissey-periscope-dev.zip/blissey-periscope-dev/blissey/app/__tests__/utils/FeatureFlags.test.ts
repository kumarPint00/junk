import * as jupiter from '@dexcare/circus-jupiter';

import {
    FeatureFlags,
    getFeatureFlag,
    getArrayFeatureFlag,
} from '@utils/FeatureFlags';
import { Mock, vi } from 'vitest';
interface Config {
    getConfig: Mock;
}
let config = {};
const mockGetConfig = () => {
    return config;
};
(jupiter.config as Config).getConfig = vi.fn(mockGetConfig);

test('feature flag true value returns correctly', () => {
    config = {
        features: {
            cancellation: true,
        },
    };
    const value = getFeatureFlag(FeatureFlags.cancellation);
    expect(value).toEqual(true);
});

test('feature flag false value returns correctly', () => {
    config = {
        features: {
            cancellation: false,
        },
    };
    const value = getFeatureFlag(FeatureFlags.cancellation);
    expect(value).toEqual(false);
});

// Lets not crash our prod app if someone makes a typo updating feature flags
test('feature flag missing key returns default correctly', () => {
    config = {};
    const value = getFeatureFlag(FeatureFlags.cancellation);
    expect(value).toEqual(false);
});

describe('getArrayFeatureFlag', () => {
    test('showBlurOption feature flag value returns correctly', () => {
        config = {
            features: {
                [FeatureFlags.showBlurOption]: [],
            },
        };
        const value = getArrayFeatureFlag(FeatureFlags.showBlurOption);
        expect(value).toEqual([]);
    });

    test('showBlurOption feature flag missing key returns default correctly', () => {
        config = {};
        const value = getArrayFeatureFlag(FeatureFlags.showBlurOption);
        expect(value).toEqual([]);
    });
});
