import { vi } from 'vitest';
import * as otUtils from '../../src/utils/otUtils';
import { BotPromptMessage, initPublisher, InstantMessage } from '@dexcare/yak';
import { UserDetails } from '../../src/types/UserDetails';

const testId = 'testId';
const callback = vi.fn();
const mockOverrides: OT.PublisherProperties = {
    audioSource: '2',
    videoSource: '3',
};

describe('otUtils', () => {
    describe('instantMessageToInstantMessageItemProps', () => {
        test('converts InstantMessage from patient to InstantMessageItemProps', () => {
            const im: InstantMessage = {
                uniqueId: '1234',
                message: 'test',
                creationTime: `${new Date().getTime()}`,
                isStaff: false,
                fromParticipant: 'patient',
                senderId: '1234',
            };
            const userDetails: UserDetails = {
                id: '1234',
                displayName: 'Patient',
                givenName: 'Dex',
                familyName: 'Adf',
                email: 'test@dexcarehealth.com',
                token: '1234',
                expiration: 123,
                sessionToken: 'asdf',
                sharedSessionStoreEnabled: true,
            };
            const result = otUtils.instantMessageToInstantMessageItemProps(
                im,
                userDetails,
            );
            expect(result).toEqual({
                key: '1234',
                content: 'test',
                timeSent: expect.any(Number),
                isOutgoing: true,
                senderName: 'You',
                isBot: false,
            });
        });
        test('converts InstantMessage from provider to InstantMessageItemProps', () => {
            const im: InstantMessage = {
                uniqueId: '1234',
                message: 'test',
                creationTime: `${new Date().getTime()}`,
                isStaff: true,
                fromParticipant: 'provider',
                senderId: '1234',
            };
            const userDetails: UserDetails = {
                id: '1234',
                displayName: 'Provider',
                givenName: 'Retail',
                familyName: 'Adf',
                email: 'test@dexcarehealth.com',
                token: '1234',
                expiration: 123,
                sessionToken: 'asdf',
                sharedSessionStoreEnabled: true,
            };
            const result = otUtils.instantMessageToInstantMessageItemProps(
                im,
                userDetails,
            );
            expect(result).toEqual({
                key: '1234',
                content: 'test',
                timeSent: expect.any(Number),
                isOutgoing: true,
                senderName: 'You',
                isBot: false,
            });
        });
        test('converts BotPromptMessage to InstantMessageItemProps', () => {
            const im: BotPromptMessage = {
                uniqueId: '1234',
                prompt: 'test',
                creationTime: `${new Date().getTime()}`,
                isBot: true,
                fromParticipant: 'bot',
                senderId: '1234',
                options: ['Yes', 'No'],
            };
            const userDetails: UserDetails = {
                id: '2234',
                displayName: 'Provider',
                givenName: 'Retail',
                familyName: 'Adf',
                email: 'test@dexcarehealth.com',
                token: '1234',
                expiration: 123,
                sessionToken: 'asdf',
                sharedSessionStoreEnabled: true,
            };
            const result = otUtils.instantMessageToInstantMessageItemProps(
                im,
                userDetails,
            );
            expect(result).toEqual({
                key: '1234',
                content: 'test',
                timeSent: expect.any(Number),
                isOutgoing: false,
                senderName: 'bot',
                isBot: true,
                botOptions: [
                    { label: 'Yes', primary: true },
                    { label: 'No', primary: false },
                ],
            });
        });
    });
    describe('constructDevicePropertyOverrides', () => {
        test('resturns empty object if no deviceIDs are passed in', () => {
            expect(otUtils.constructDevicePropertyOverrides({})).toEqual({});
        });

        test('resturns devices Ids', () => {
            expect(
                otUtils.constructDevicePropertyOverrides(mockOverrides),
            ).toEqual(mockOverrides);
        });
    });
    describe('createOTPublisher', () => {
        test('inits publisher', () => {
            otUtils.createOTPublisher(testId, callback, {});
            expect(initPublisher).toHaveBeenCalledWith(
                testId,
                {
                    insertMode: 'append',
                    fitMode: 'cover',
                    width: '100%',
                    height: '100%',
                    style: {
                        buttonDisplayMode: 'off',
                    },
                    // videoContentHint: 'detail',
                },
                callback,
            );
        });
    });

    test('inits publisher with overrides', () => {
        otUtils.createOTPublisher(testId, callback, mockOverrides);
        expect(initPublisher).toHaveBeenCalledWith(
            testId,
            {
                insertMode: 'append',
                fitMode: 'cover',
                width: '100%',
                height: '100%',
                style: {
                    buttonDisplayMode: 'off',
                },
                // videoContentHint: 'detail',
                ...mockOverrides,
            },
            callback,
        );
    });
});
