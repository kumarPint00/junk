import { checkTestVisit } from '../../src/utils';

describe('checkTestVisit', () => {
    it('should return true if pathname contains testvisit-', () => {
        const pathname = '/visit/testvisit-9UqDrKOH';
        const result = checkTestVisit(pathname);
        expect(result).toBe(true);
    });

    it('should return false if pathname does not contain testvisit-', () => {
        const pathname = '/visit/5b8fff5ceb84361a88cec97e';
        const result = checkTestVisit(pathname);
        expect(result).toBe(false);
    });
});
