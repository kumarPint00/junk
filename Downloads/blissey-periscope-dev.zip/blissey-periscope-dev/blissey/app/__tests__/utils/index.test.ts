import { vi } from 'vitest';
import { parsePatientAccessCodeFromUrl } from '../../src/utils';

describe('recoverGuestSessionFromAccessCode', () => {
    afterEach(() => {
        vi.resetAllMocks();
    });

    it('should return access code', () => {
        const location = new URL(
            'http://localhost:5000/visit/fcfa8a76-8def-4568-8452-17b3e78f2456?brand=providence&guest=patient&redirect=true#access-code=732b91e3053eed09ced5d4e7ccabe6c0',
        );
        const accessCode = parsePatientAccessCodeFromUrl(location);

        expect(accessCode).toEqual('732b91e3053eed09ced5d4e7ccabe6c0');
        expect(location.hash).toEqual('');
    });

    it('should preserve other hash params', () => {
        const location = new URL(
            'http://localhost:5000/visit/fcfa8a76-8def-4568-8452-17b3e78f2456?brand=providence&guest=patient&redirect=true#access-code=732b91e3053eed09ced5d4e7ccabe6c0&foo=bar',
        );
        parsePatientAccessCodeFromUrl(location);

        expect(location.hash).toEqual('#foo=bar');
    });

    it.each([
        'http://localhost:5000/visit/fcfa8a76-8def-4568-8452-17b3e78f2456?brand=providence&guest=patient&redirect=true',
        'http://localhost:5000/visit/fcfa8a76-8def-4568-8452-17b3e78f2456?brand=providence&guest=patient&redirect=true#foo=bar',
        'http://localhost:5000/',
    ])('should return null when access code is missing', (url) => {
        const location = new URL(url);

        const href = location.href;
        const res = parsePatientAccessCodeFromUrl(location);

        expect(res).toBeNull();
        expect(location.href).toEqual(href);
    });
});
