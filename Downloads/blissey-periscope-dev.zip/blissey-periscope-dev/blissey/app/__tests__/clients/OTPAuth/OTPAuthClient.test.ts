vi.mock('@utils/requestUtils');

import { Mock, vi } from 'vitest';
import { otpAuthClient } from '../../../src/clients/OTPAuth/OTPAuthClient';
import { createCorrelationId } from '@utils/requestUtils';

describe('OTPAuthClient', () => {
    beforeEach(() => {
        vi.resetAllMocks();
        fetchMock.resetMocks();
        (createCorrelationId as Mock).mockReturnValueOnce('some-id');
    });

    afterEach(() => {
        vi.clearAllMocks();
    });

    describe('requestPasscode', () => {
        it('resolves when successful', async () => {
            fetchMock.mockResponse(JSON.stringify({ response: '' }), {
                status: 201,
            });
            const result = await otpAuthClient.requestPasscode('otpMethodHere');
            expect(result).toEqual({ response: '' });
            expect(fetchMock.mock.calls.length).toEqual(1);
            expect(fetchMock.mock.calls[0]).toMatchSnapshot();
        });

        it('throws when error status code', async () => {
            fetchMock.mockResponse(JSON.stringify({ error: 'err!' }), {
                status: 403,
            });
            try {
                await otpAuthClient.requestPasscode('otpMethodHere');
            } catch (e) {
                expect((e as Error).message).toEqual('err!');
            }
        });

        it('throws when rejected', async () => {
            fetchMock.mockReject(new Error('rrrk!'));
            try {
                await otpAuthClient.requestPasscode('otpMethodHere');
            } catch (e) {
                expect((e as Error).message).toEqual('rrrk!');
            }
        });
    });

    describe('verifyPasscode', () => {
        it('resolves when successful', async () => {
            fetchMock.mockResponse(JSON.stringify({ response: 'things' }), {
                status: 201,
            });
            const result = await otpAuthClient.verifyPasscode(
                'otpCodeHere',
                'otpMethodHere',
            );
            expect(result).toEqual({ response: 'things' });
            expect(fetchMock.mock.calls.length).toEqual(1);
            expect(fetchMock.mock.calls[0]).toMatchSnapshot();
        });

        it('throws when error status code', async () => {
            fetchMock.mockResponse(JSON.stringify({ error: 'err!' }), {
                status: 403,
            });
            try {
                await otpAuthClient.verifyPasscode(
                    'otpCodeHere',
                    'otpMethodHere',
                );
            } catch (e) {
                expect((e as Error).message).toEqual('err!');
            }
        });

        it('throws when rejected', async () => {
            fetchMock.mockReject(new Error('rrrk!'));
            try {
                await otpAuthClient.verifyPasscode(
                    'otpCodeHere',
                    'otpMethodHere',
                );
            } catch (e) {
                expect((e as Error).message).toEqual('rrrk!');
            }
        });
    });
});
