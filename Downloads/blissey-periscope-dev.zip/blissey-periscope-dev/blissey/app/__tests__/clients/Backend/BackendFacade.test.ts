import {
    backendFacade,
    SessionTokenHeaderName,
} from '../../../src/clients/Backend/BackendFacade';
import { createCorrelationId } from '../../../src/utils/requestUtils';
import { Logger } from '../../../src/utils';
import { MockedFunction, vi } from 'vitest';

vi.mock('../../../src/utils/requestUtils', () => {
    return {
        createCorrelationId: vi.fn(),
    };
});

vi.mock('../../../src/utils', () => ({
    Logger: {
        debug: vi.fn(),
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
        addCustomHeaders: vi.fn(),
    },
}));

const mockLogWarn = vi.spyOn(Logger, 'warn');
const mockAddCustomHeaders = vi.spyOn(Logger, 'addCustomHeaders');

const mockCreateCorrelationId = createCorrelationId as MockedFunction<
    typeof createCorrelationId
>;

describe('BackendFacade', () => {
    beforeEach(() => {
        fetchMock.resetMocks();
        mockCreateCorrelationId.mockReturnValue(
            'baf99887-bbfb-4466-98ce-b341c2f7d744',
        );
    });
    afterEach(() => {
        vi.resetAllMocks();
    });

    it('should return an object', () => {
        expect(backendFacade).not.toBeNull();
    });

    it('should return version and brandConfig', async () => {
        const config = {
            version: 'version1',
            brandConfig: {
                brand: 'testBrand',
            },
        };

        fetchMock.mockResponseOnce(JSON.stringify(config), {
            status: 200,
        });

        const basicConfig = await backendFacade.getConfig();
        expect(basicConfig).toEqual(config);
    });

    it('should return favicon and siteTitle', async () => {
        const config = {
            siteTitle: 'Frosh',
            favicon: './favicon.ico',
        };

        fetchMock.mockResponseOnce(JSON.stringify(config), {
            status: 200,
        });

        const basicConfig = await backendFacade.getBasicConfig();
        expect(basicConfig).toEqual(config);
    });

    it('should call mimir', async () => {
        await backendFacade.sendPatientRejoinSuccessMimirEvent({
            visitId: 'visit id 123',
            generatedBy: 'cron_notify_sms',
        });
        const expectedBody = {
            visitId: 'visit id 123',
            generatedBy: 'cron_notify_sms',
        };
        expect(fetchMock.mock.calls[0]).toContainEqual(
            expect.objectContaining({
                body: JSON.stringify(expectedBody),
            }),
        );
    });

    it('should send end and transfer event', async () => {
        fetchMock.mockResponseOnce('{}', {
            status: 202,
        });
        await backendFacade.transferToAnotherProvider(
            'visit-id',
            'new-provider',
            'current-provider',
        );
        expect(fetchMock.mock.calls[0]).toEqual([
            '/visits/event',
            expect.objectContaining({
                body: '{"action":"updateProvider","data":{"visitId":"visit-id","assignmentMethod":"end_and_transfer","providerId":"new-provider","unassignProviderId":"current-provider","actorId":"current-provider"}}',
            }),
        ]);
    });
    it('should send unassign event', async () => {
        fetchMock.mockResponseOnce('{}', {
            status: 202,
        });
        await backendFacade.transferBackToQueue('visit-id', 'provider');

        expect(fetchMock.mock.calls[0]).toEqual([
            '/visits/event',
            expect.objectContaining({
                body: '{"action":"updateProvider","data":{"visitId":"visit-id","assignmentMethod":"unassign","unassignProviderId":"provider","actorId":"provider"}}',
            }),
        ]);
    });
    it('should recover guest session', async () => {
        fetchMock.mockResponseOnce('{}', { status: 200 });
        await backendFacade.recoverGuestSession('fakeaccesscode');

        expect(fetchMock).toHaveBeenCalledWith(
            '/guest/session/token',
            expect.objectContaining({
                method: 'POST',
                redirect: 'follow',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                    correlationId: 'baf99887-bbfb-4466-98ce-b341c2f7d744',
                },
                body: '{"accessCode":"fakeaccesscode"}',
            }),
        );
    });

    it('should recover guest session and include auth header in subsequent requests', async () => {
        const expectedSessionToken = 'session-token-12345';
        fetchMock.mockResponseOnce('{}', {
            status: 200,
            headers: { [SessionTokenHeaderName]: expectedSessionToken },
        });

        // first, recover the guest session
        await backendFacade.recoverGuestSession('fakeaccesscode');

        expect(fetchMock.mock.calls[0]).toEqual([
            '/guest/session/token',
            expect.objectContaining({
                method: 'POST',
                redirect: 'follow',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                    correlationId: 'baf99887-bbfb-4466-98ce-b341c2f7d744',
                },
                body: '{"accessCode":"fakeaccesscode"}',
            }),
        ]);

        expect(mockAddCustomHeaders).toHaveBeenCalledWith({
            [SessionTokenHeaderName]: expectedSessionToken,
        });

        fetchMock.resetMocks();
        fetchMock.mockResponseOnce('{}', { status: 200 });

        // next, confirm that the `x-blissey-session` header is present on subsequent requests
        await backendFacade.getUser();

        expect(fetchMock.mock.calls[0]).toEqual([
            '/user',
            expect.objectContaining({
                credentials: 'include',
                headers: {
                    correlationId: 'baf99887-bbfb-4466-98ce-b341c2f7d744',
                    [SessionTokenHeaderName]: expectedSessionToken,
                },
            }),
        ]);
    });

    it('should propogate errors when recover guest session fails', async () => {
        fetchMock.mockReject(new Error('http error'));
        const res = await backendFacade.recoverGuestSession('fakeaccesscode');

        expect(res).toBeNull();

        expect(mockLogWarn).toHaveBeenCalledWith(
            {
                err: new Error('http error'),
                options: {
                    body: '{"accessCode":"fakeaccesscode"}',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                        correlationId: 'baf99887-bbfb-4466-98ce-b341c2f7d744',
                    },
                    method: 'POST',
                    redirect: 'follow',
                },
                url: '/guest/session/token',
            },
            'Failed to recover guest session token',
        );
    });

    it('should send end and convert modality event', async () => {
        fetchMock.mockResponseOnce('{}', {
            status: 202,
        });
        await backendFacade.convertModality(
            'visit-id',
            'reason',
            'virtual',
            'phone',
            'actor-id',
        );
        expect(fetchMock.mock.calls[0]).toEqual([
            '/visits/event',
            expect.objectContaining({
                body: '{"action":"modalityConversion","data":{"visitId":"visit-id","conversionReason":"reason","originalModality":"virtual","targetModality":"phone","actorId":"actor-id"}}',
            }),
        ]);
    });

    it('should send the submit survey response mimir event (bearer token auth)', async () => {
        fetchMock.mockResponseOnce('{}', {
            status: 202,
        });

        await backendFacade.sendSubmitSurveyResponseMimirEvent({
            surveyId: 'survey123',
            visitId: 'visit123',
            userRole: 'Patient',
            survey: { question1: 'answer1', question2: 'answer2' },
        });
        expect(fetchMock.mock.calls[0]).toEqual([
            '/mimir/survey/submit',
            expect.objectContaining({
                method: 'POST',
                headers: {
                    Authorization: 'Bearer ',
                    'Content-Type': 'application/json',
                    'correlation-id': 'baf99887-bbfb-4466-98ce-b341c2f7d744',
                },
                body: '{"surveyId":"survey123","visitId":"visit123","userRole":"Patient","survey":{"question1":"answer1","question2":"answer2"}}',
            }),
        ]);
    });

    it('should get participant types', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify([
                {
                    id: '123',
                    name: 'translator',
                },
                {
                    id: '456',
                    name: 'translator',
                },
            ]),
            { status: 200 },
        );

        const response = await backendFacade.getParticipantTypes();
        expect(response).toMatchInlineSnapshot(`
          [
            {
              "id": "123",
              "name": "translator",
            },
            {
              "id": "456",
              "name": "translator",
            },
          ]
        `);
    });

    it('should throw error with server message for getParticipantTypes', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                error: 'Visit has max number of participants',
                code: 'BadRequest',
            }),
            { status: 400 },
        );

        await expect(backendFacade.getParticipantTypes()).rejects.toThrow(
            'Visit has max number of participants',
        );
    });

    it('should get visit participants', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify([
                {
                    id: '123',
                    name: 'John Doe',
                    role: 'Patient',
                },
            ]),
            { status: 200 },
        );

        const response = await backendFacade.getVisitParticipants('visit-id');

        expect(response).toMatchInlineSnapshot(`
          [
            {
              "createdAt": "",
              "id": "123",
              "name": "John Doe",
              "role": "Patient",
            },
          ]
        `);
        expect(fetchMock.mock.calls[0]).toMatchInlineSnapshot(`
          [
            "/visits/visit-id/participants",
            {
              "headers": {
                "Content-Type": "application/json",
                "correlationId": "baf99887-bbfb-4466-98ce-b341c2f7d744",
              },
              "method": "GET",
            },
          ]
        `);
    });

    it('should throw error with server message for getVisitParticipants', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                error: 'Visit does not exist',
                code: 'BadRequest',
            }),
            { status: 400 },
        );

        await expect(
            backendFacade.getVisitParticipants('visit-id'),
        ).rejects.toThrow('Visit does not exist');
    });

    it('should add participant to visit', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                id: '123',
                name: 'John Doe',
                role: 'Patient',
                createdBy: 'nhan',
            }),
            { status: 200 },
        );

        const response = await backendFacade.addVisitParticipant('visit-id', {
            email: 'mail@mail.com',
            participantTypeId: 'participant-type-id',
        });

        expect(response).toMatchInlineSnapshot(`
          {
            "createdAt": "",
            "createdBy": "nhan",
            "id": "123",
            "name": "John Doe",
            "role": "Patient",
          }
        `);
        expect(fetchMock.mock.calls[0]).toMatchInlineSnapshot(`
          [
            "/visits/visit-id/participants",
            {
              "body": "{"email":"mail@mail.com","participantTypeId":"participant-type-id"}",
              "headers": {
                "Content-Type": "application/json",
                "correlationId": "baf99887-bbfb-4466-98ce-b341c2f7d744",
              },
              "method": "POST",
            },
          ]
        `);
    });

    it('should throw error with server message for addVisitParticipant', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                error: 'Visit has max number of participants',
                code: 'BadRequest',
            }),
            { status: 400 },
        );

        await expect(
            backendFacade.addVisitParticipant('visit-id', {
                email: 'mail@mail.com',
                participantTypeId: 'participant-type-id',
            }),
        ).rejects.toThrow('Visit has max number of participants');
    });

    it('should remove participant from visit', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                id: '123',
                name: 'John Doe',
                role: 'Patient',
                deletedBy: 'nhan',
            }),
            { status: 200 },
        );

        const response = await backendFacade.deleteVisitParticipant(
            'visit-id',
            'participant-id',
        );

        expect(response).toMatchInlineSnapshot(`
          {
            "createdAt": "",
            "deletedBy": "nhan",
            "id": "123",
            "name": "John Doe",
            "role": "Patient",
          }
        `);
        expect(fetchMock.mock.calls[0]).toMatchInlineSnapshot(`
          [
            "/visits/visit-id/participants/participant-id",
            {
              "headers": {
                "Content-Type": "application/json",
                "correlationId": "baf99887-bbfb-4466-98ce-b341c2f7d744",
              },
              "method": "DELETE",
            },
          ]
        `);
    });

    it('should throw error with server message for deleteVisitParticipant', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                error: 'Visit does not exist',
                code: 'BadRequest',
            }),
            { status: 400 },
        );

        await expect(
            backendFacade.deleteVisitParticipant('visit-id', 'participant-id'),
        ).rejects.toThrow('Visit does not exist');
    });

    it('should admit a participant to visit', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                id: '123',
                name: 'John Doe',
                role: 'Patient',
                admittedBy: 'nhan',
            }),
            { status: 200 },
        );

        const response = await backendFacade.admitVisitParticipant(
            'visit-id',
            'participant-id',
        );

        expect(response).toMatchInlineSnapshot(`
          {
            "admittedBy": "nhan",
            "createdAt": "",
            "id": "123",
            "name": "John Doe",
            "role": "Patient",
          }
        `);
        expect(fetchMock.mock.calls[0]).toMatchInlineSnapshot(`
          [
            "/visits/visit-id/participants/participant-id",
            {
              "body": "{"admitted":true}",
              "headers": {
                "Content-Type": "application/json",
                "correlationId": "baf99887-bbfb-4466-98ce-b341c2f7d744",
              },
              "method": "PATCH",
            },
          ]
        `);
    });

    it('should throw error with server message for admitVisitParticipant', async () => {
        fetchMock.mockResponseOnce(
            JSON.stringify({
                error: 'Visit does not exist',
                code: 'BadRequest',
            }),
            { status: 400 },
        );

        await expect(
            backendFacade.admitVisitParticipant('visit-id', 'participant-id'),
        ).rejects.toThrow('Visit does not exist');
    });
});
