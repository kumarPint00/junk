import viteTransformCSSModulesPlugin from '../../config/vitePluginTransformCssModules';

test('transforms code correctly', () => {
    const inputCode = `
        import styles from "./styles.css";
    `;
    const plugin = viteTransformCSSModulesPlugin();
    const transformedResult = plugin.transform(inputCode, 'example.js');

    expect(transformedResult).toBeDefined();
    expect(transformedResult.code).toContain('.css?.module.styl"');
    expect(transformedResult.map).toBeInstanceOf(Object);
    expect(transformedResult).toBeDefined();
});
