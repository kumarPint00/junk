import {
    SECURITY_ROLE_PATIENT,
    SECURITY_ROLE_PROVIDER,
} from '@dexcare/circus-saturn';
import { getRoutes } from '../../src/routes';

describe('routes', () => {
    describe('guestflow routes', () => {
        it('should return default if no brand', () => {
            const userDetails = { requiresOTPAuth: true } as never;
            const routes = getRoutes(userDetails);
            expect(routes).toMatchSnapshot();
        });

        it('should return OTP routes', () => {
            const userDetails = { requiresOTPAuth: true } as never;
            const routes = getRoutes(userDetails, undefined, 'brand');
            expect(routes).toMatchSnapshot();
        });
    });

    describe('patient routes', () => {
        it('should return default if no brand', () => {
            const userDetails = { roles: [SECURITY_ROLE_PATIENT] } as never;
            const routes = getRoutes(userDetails);
            expect(routes).toMatchSnapshot();
        });

        it('should return patient routes', () => {
            const userDetails = { roles: [SECURITY_ROLE_PATIENT] } as never;
            const routes = getRoutes(userDetails, undefined, 'brand');
            expect(routes).toMatchSnapshot();
        });

        it('should return patient routes with dogfood', () => {
            const userDetails = { roles: [SECURITY_ROLE_PATIENT] } as never;
            const config = { patientDogfoodEnabled: true } as never;
            const routes = getRoutes(userDetails, config, 'brand');
            expect(routes).toMatchSnapshot();
        });
    });

    describe('provider routes', () => {
        it('should return default if no brand', () => {
            const userDetails = { roles: [SECURITY_ROLE_PROVIDER] } as never;
            const routes = getRoutes(userDetails);
            expect(routes).toMatchSnapshot();
        });

        it('should return provider routes', () => {
            const userDetails = { roles: [SECURITY_ROLE_PROVIDER] } as never;
            const routes = getRoutes(userDetails, undefined, 'brand');
            expect(routes).toMatchSnapshot();
        });
    });

    describe('auth header routes', () => {
        it('should return default if no brand', () => {
            const userDetails = { headerAuth: true } as never;
            const routes = getRoutes(userDetails);
            expect(routes).toMatchSnapshot();
        });

        it('should return auth header routes', () => {
            const userDetails = { headerAuth: true } as never;
            const routes = getRoutes(userDetails, undefined, 'brand');
            expect(routes).toMatchSnapshot();
        });
    });

    describe('public routes', () => {
        it('should return default if no brand', () => {
            const userDetails = { public: true } as never;
            const routes = getRoutes(userDetails);
            expect(routes).toMatchSnapshot();
        });

        it('should return public routes', () => {
            const userDetails = { public: true } as never;
            const routes = getRoutes(userDetails, undefined, 'brand');
            expect(routes).toMatchSnapshot();
        });
    });
});
