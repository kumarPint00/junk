import * as React from 'react';

vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(() => ({
            chat: {
                headerText:
                    'Chat with patient registration representatives is shared between staff for patient lookup and registration purposes. Any communications with this feature are used and shared only with the provider team. They are not saved or recorded on this website.',
            },
        })),
    },
}));

import { render } from '@testing-library/react';
import { ChatPage, ChatPageProps } from '@layout/PageLayout/ChatPage';
vi.mock('react-redux');
import { useSelector } from 'react-redux';
import { Mock, vi } from 'vitest';

const tMock = vi.fn().mockReturnValue('this has been translated, yo');

vi.mock('react-i18next', () => ({
    withTranslation:
        () =>
        <P extends object>(Component: React.FunctionComponent<P>) => {
            const WrappedComponent = (props: P) => (
                <Component {...props} t={tMock} i18n={{ t: vi.fn }} />
            );
            WrappedComponent.displayName = `withTranslation(${
                Component.displayName || Component.name || 'Component'
            })`;
            return WrappedComponent;
        },
}));

describe('<ChatPage />', () => {
    const defaultProps: ChatPageProps = {
        instantMessageProps: {
            ref: vi.fn(),
            hasRemoteStartedTyping: false,
            hasUnreadMessages: false,
            instantMessages: [],
            lostConnection: false,
            onSendMessage: vi.fn(),
            onInstantMessageTyping: vi.fn(),
            onAllMessagesRead: vi.fn(),
            resizeStyle: 'none',
            toggleChatIsVisible: vi.fn(),
        },
        tReady: true,
    } as unknown as ChatPageProps;

    test('verify when chat is closed', () => {
        (useSelector as Mock).mockImplementation(() => ({
            video: { isChatVisible: false },
        }));
        const { container } = render(
            <ChatPage {...defaultProps}>abc</ChatPage>,
        );
        expect(container).toMatchSnapshot();
    });

    test('verify when chat is open', () => {
        (useSelector as Mock).mockImplementation(() => ({
            video: { isChatVisible: true },
        }));
        const { container } = render(
            <ChatPage {...defaultProps}>abc</ChatPage>,
        );
        expect(container).toMatchSnapshot();
    });

    test('verify messages are sorted', () => {
        (useSelector as Mock).mockImplementation(() => ({
            video: { isChatVisible: true },
        }));
        const message2 = {
            key: '2',
            content: 'message2',
            timeSent: 2000,
            isOutgoing: false,
            senderName: 'sender2',
        };
        const message1 = {
            key: '1',
            content: 'message1',
            timeSent: 1000,
            isOutgoing: false,
            senderName: 'sender1',
        };
        defaultProps.instantMessageProps.instantMessages = [message2, message1];
        const { container } = render(
            <ChatPage {...defaultProps}>abc</ChatPage>,
        );
        expect(container).toMatchSnapshot();
    });

    test('verify send button text localization', () => {
        (useSelector as Mock).mockImplementation(() => ({
            video: { isChatVisible: true },
        }));
        const { container } = render(
            <ChatPage {...defaultProps}>abc</ChatPage>,
        );
        expect(container).toMatchSnapshot();
    });
});
