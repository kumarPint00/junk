import * as React from 'react';

import { render } from '@testing-library/react';

import { FooterPage } from '@layout/PageLayout/FooterPage';
import * as styles from '../../../src/modules/OTPFlow/OTPModule.css';

describe('<FooterPage />', () => {
    test('verify footer is rendered', () => {
        const { container } = render(<FooterPage>abc</FooterPage>);
        expect(container).toMatchSnapshot();
    });

    test('verify footer is rendered with custom styles', () => {
        const { container } = render(
            <FooterPage
                customStyles={{
                    main: styles.footerPageMainContainer,
                    content: styles.footerPageContent,
                    header: styles.footerPageHeader,
                }}
                headerText="Header"
            >
                abc
            </FooterPage>,
        );
        expect(container).toMatchSnapshot();
        expect(
            container.getElementsByClassName('footerPageContent').length,
        ).toBe(1);
    });
});
