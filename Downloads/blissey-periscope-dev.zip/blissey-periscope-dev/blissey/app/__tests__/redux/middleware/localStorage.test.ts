import { vi } from 'vitest';
import {
    getLocalState,
    localStorageMiddleware,
    addPath,
    _createInMemoryStore,
    _initStorage,
} from '../../../src/redux/middleware/localStorage';

declare let global: Window;

const next = () => undefined;
const action = 'action';

describe('redux/middleware/localStorage', () => {
    beforeEach(() => {
        vi.clearAllMocks();
    });

    describe('_initStorage', () => {
        describe('when localStorage is available', () => {
            test('uses browser localStorage by default', () => {
                const storage = _initStorage();
                expect(storage).toBeInstanceOf(Storage);
            });
        });

        describe('when localStorage is not available', () => {
            let originalLocalStorage: Storage;

            beforeAll(() => {
                if (typeof window !== 'undefined') {
                    global = window;
                }

                originalLocalStorage = global.localStorage;

                Object.defineProperty(global, 'localStorage', {
                    value: {
                        setItem: vi.fn(() => {
                            throw new Error('nope');
                        }),
                        getItem: vi.fn(() => {
                            throw new Error('not at all');
                        }),
                    },
                });
            });

            afterAll(() => {
                Object.defineProperty(global, 'localStorage', {
                    value: originalLocalStorage,
                });
            });

            test('uses in-memory storage implementation', () => {
                const storage = _initStorage();
                expect(storage).not.toBeInstanceOf(Storage);
                expect(storage).toHaveProperty('name', 'in-memory');
            });
        });
    });

    describe.each([
        ['browser localStorage', localStorage],
        ['in-memory storage', _createInMemoryStore()],
    ])('middleware tests using %s', (_, storage) => {
        beforeAll(() => {
            _initStorage(storage);
        });

        beforeEach(() => {
            storage.clear();
        });

        afterEach(() => {
            storage.clear();
        });

        test('Gets state from local storage', () => {
            storage.setItem('user.name', JSON.stringify('test'));
            storage.setItem('user.address', JSON.stringify('123 street'));
            storage.setItem('user.state', JSON.stringify('WA'));
            storage.setItem('auth.token', JSON.stringify('token'));

            addPath('user.name');
            addPath('user.address');
            const state = getLocalState(undefined);
            expect(state).toEqual({
                user: {
                    name: 'test',
                    address: '123 street',
                },
            });
        });

        test('Merge initial state with local storage state properly', () => {
            const initialState = {
                user: {
                    name: '',
                    address: '',
                    state: '',
                    zip: '',
                },
                auth: {
                    token: '',
                },
            };
            storage.setItem('user.name', JSON.stringify('test'));
            storage.setItem('user.address', JSON.stringify('123 street'));
            storage.setItem('user.state', JSON.stringify('WA'));
            storage.setItem('auth.token', JSON.stringify('token'));

            addPath('user.name');
            addPath('user.address');
            const state = getLocalState(initialState);
            expect(state).toEqual({
                user: {
                    name: 'test',
                    address: '123 street',
                    state: '',
                    zip: '',
                },
                auth: {
                    token: '',
                },
            });
        });

        test('Middleware will save state to local storage', async () =>
            new Promise<void>((done) => {
                addPath('user.name');
                addPath('user.address');
                const store = {
                    getState() {
                        return {
                            user: {
                                name: 'test',
                                address: '123 street',
                            },
                        };
                    },
                };
                localStorageMiddleware(store)(next)(action);
                setTimeout(() => {
                    expect(storage.getItem('user.name')).toBe(
                        JSON.stringify('test'),
                    );
                    expect(storage.getItem('user.address')).toBe(
                        JSON.stringify('123 street'),
                    );
                    done();
                }, 250);
            }));

        test('Middleware will correctly update state with last store', async () =>
            new Promise<void>((done) => {
                addPath('user.name');
                addPath('user.address');
                let store = {
                    getState() {
                        return {
                            user: {
                                name: 'test',
                                address: '123 street',
                            },
                        };
                    },
                };
                localStorageMiddleware(store)(next)(action);

                store = {
                    getState() {
                        return {
                            user: {
                                name: 'other',
                                address: 'place',
                            },
                        };
                    },
                };
                localStorageMiddleware(store)(next)(action);

                setTimeout(() => {
                    expect(storage.getItem('user.name')).toBe(
                        JSON.stringify('other'),
                    );
                    expect(storage.getItem('user.address')).toBe(
                        JSON.stringify('place'),
                    );
                    done();
                }, 250);
            }));
    });
});
