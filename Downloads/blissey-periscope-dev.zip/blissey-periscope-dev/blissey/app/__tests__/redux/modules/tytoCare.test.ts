import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import {
    loadingTytoCareVisit,
    reducer,
    setIsTytoCareVisit,
    setTytoCareProviderUrl,
    setTytoCareVisitError,
    loadTytoCareWidget,
    hideTytoCareWidet,
    actionTypes,
    clearTytoCareError,
} from '../../../src/redux/modules/tytoCare';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { vi } from 'vitest';
import { MockStoreType } from '../../../src/types/redux';
vi.mock('@clients/VisitService/VisitServiceClient');

const middlewares = [thunk];
const mockStore: (state?: unknown) => MockStoreType =
    configureMockStore(middlewares);

const mockClinicianUrl = 'http://mockClinicianUrl';
const mockVisitId = 'mock-visit-1';

const runErrorCase = async (error: string) => {
    visitServiceClient.startTytoCareVisit = vi
        .fn()
        .mockRejectedValue(new Error(error));
    const store = mockStore({
        postconsult: { visitId: mockVisitId },
    });
    await store.dispatch(loadTytoCareWidget());
    return store.getActions() as unknown[];
};

describe('tytoCare', () => {
    it('inits state', () => {
        expect(reducer(undefined, {})).toMatchInlineSnapshot(`
            {
              "error": undefined,
              "isTytoCareVisit": false,
              "loading": false,
              "providerVisitUrl": undefined,
            }
        `);
    });
    it('sets loading', () => {
        const newState = reducer(undefined, loadingTytoCareVisit(true));
        expect(newState.loading).toEqual(true);
    });
    it('sets isTytoCare', () => {
        const newState = reducer(undefined, setIsTytoCareVisit(true));
        expect(newState.isTytoCareVisit).toEqual(true);
    });
    it('sets error', () => {
        const newState = reducer(undefined, setTytoCareVisitError('error'));
        expect(newState.error).toEqual('error');
    });
    it('clears error', () => {
        const newState = reducer(undefined, setTytoCareVisitError('error'));
        expect(newState.error).toEqual('error');

        const finalState = reducer(undefined, clearTytoCareError());
        expect(finalState.error).toBeUndefined();
    });
    it('sets providerUrl', () => {
        const mockProviderUrl = 'providerUrl';
        const newState = reducer(
            undefined,
            setTytoCareProviderUrl(mockProviderUrl),
        );
        expect(newState.providerVisitUrl).toEqual(mockProviderUrl);
    });
    describe('hideTytoCareWidget', () => {
        it('dispatches expected actions', () => {
            const expectedActions = [
                {
                    payload: undefined,
                    type: actionTypes.SET_TYTO_CARE_PROVIDER_URL,
                },
            ];
            const store = mockStore({});
            store.dispatch(hideTytoCareWidet());
            expect(store.getActions()).toEqual(expectedActions);
        });
    });
    describe('loadTytoCareVisit', () => {
        it('dispatches expected actions on success', async () => {
            visitServiceClient.startTytoCareVisit = vi.fn().mockResolvedValue({
                tytoCare: {
                    visitUrl: mockClinicianUrl,
                },
            });
            const expectedActions = [
                {
                    payload: true,
                    type: actionTypes.SET_IS_LOADING_TYTO_CARE,
                },
                {
                    payload: undefined,
                    type: actionTypes.SET_TYTO_CARE_VISIT_ERROR,
                },
                {
                    payload: mockClinicianUrl,
                    type: actionTypes.SET_TYTO_CARE_PROVIDER_URL,
                },
                {
                    payload: false,
                    type: actionTypes.SET_IS_LOADING_TYTO_CARE,
                },
            ];
            const store = mockStore({
                postconsult: { visitId: mockVisitId },
            });
            await store.dispatch(loadTytoCareWidget());
            expect(store.getActions()).toEqual(expectedActions);
            expect(visitServiceClient.startTytoCareVisit).toHaveBeenCalledWith(
                mockVisitId,
            );
        });
        it('handles account conflict error', async () => {
            const actions = await runErrorCase(
                'add patient to account conflict',
            );
            expect(actions).toMatchSnapshot();
        });
        it('handles account not found error', async () => {
            const actions = await runErrorCase('account not found');
            expect(actions).toMatchSnapshot();
        });
        it('handles participant conflict error', async () => {
            const actions = await runErrorCase('a participant has a conflict');
            expect(actions).toMatchSnapshot();
        });
        it('handles patient conflict error', async () => {
            const actions = await runErrorCase(
                'patient already associated with an active visit',
            );
            expect(actions).toMatchSnapshot();
        });
        it('handles provider conflict error', async () => {
            const actions = await runErrorCase(
                'provider already associated with an active visit',
            );
            expect(actions).toMatchSnapshot();
        });
        it('handles unknown error', async () => {
            const actions = await runErrorCase('error!');
            expect(actions).toMatchSnapshot();
        });
    });
});
