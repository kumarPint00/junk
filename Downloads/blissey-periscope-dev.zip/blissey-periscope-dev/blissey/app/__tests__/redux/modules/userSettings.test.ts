import { MediaDevice } from '@common/video';
import {
    reducer,
    setAudioDeviceId,
    setAudioDevices,
    setVideoDeviceId,
    setVideoDevices,
} from '../../../src/redux/modules/userSettings';

describe('userSettings', () => {
    describe('set actions', () => {
        test('initial state', () => {
            expect(reducer(undefined, {})).toEqual({
                audioDeviceId: '',
                videoDeviceId: '',
                videoDevices: [],
                audioDevices: [],
            });
        });
        test('setAudioDeviceId', () => {
            const audioDeviceId = 'audioDeviceId';
            const newState = reducer(
                undefined,
                setAudioDeviceId(audioDeviceId),
            );
            expect(newState.audioDeviceId).toEqual(audioDeviceId);
        });
        test('setVideoDeviceId', () => {
            const videoDeviceId = 'videoDeviceId';
            const newState = reducer(
                undefined,
                setVideoDeviceId(videoDeviceId),
            );
            expect(newState.videoDeviceId).toEqual(videoDeviceId);
        });
        test('setVideoDevices', () => {
            const videoDevices: MediaDevice[] = [
                {
                    label: 'Camera One',
                    value: '123123123',
                },
            ];
            const newState = reducer(undefined, setVideoDevices(videoDevices));
            expect(newState.videoDevices).toEqual(videoDevices);
        });
        test('setAudioDevices', () => {
            const audioDevices: MediaDevice[] = [
                {
                    label: 'Mic One',
                    value: '56456',
                },
            ];
            const newState = reducer(undefined, setAudioDevices(audioDevices));
            expect(newState.audioDevices).toEqual(audioDevices);
        });
    });
});
