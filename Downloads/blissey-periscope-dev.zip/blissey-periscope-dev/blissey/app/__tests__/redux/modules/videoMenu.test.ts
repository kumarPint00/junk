import {
    reducer,
    resetVideoControls,
    setLocalMicExists,
    setLocalCamExists,
    setIsFullScreen,
    setIsMicEnabled,
    setIsCamEnabled,
    setIsChatVisible,
    setEndCallConfirmation,
    setIsBlurEnabled,
    setInstructionVideoVisible,
    TState,
    setCancelButtonVisible,
} from '../../../src/redux/modules/videoMenu';

describe('videoMenu', () => {
    const defaultMenuState: TState = {
        localMicExists: true,
        localCamExists: true,
        isFullScreen: false,
        isMicEnabled: true,
        isCamEnabled: true,
        isChatVisible: false,
        endCallConfirmation: false,
        isBlurEnabled: false,
        isInstructionVideoVisible: true,
        isCancelButtonVisible: true,
    };

    test('initial state', () => {
        expect(reducer(undefined, {})).toEqual(defaultMenuState);
    });

    it.each([
        { action: setLocalMicExists, prop: 'localMicExists', expected: false },
        { action: setLocalMicExists, prop: 'localMicExists', expected: true },
        { action: setIsFullScreen, prop: 'isFullScreen', expected: false },
        { action: setIsFullScreen, prop: 'isFullScreen', expected: true },
        { action: setIsMicEnabled, prop: 'isMicEnabled', expected: false },
        { action: setIsMicEnabled, prop: 'isMicEnabled', expected: true },
        { action: setLocalCamExists, prop: 'localCamExists', expected: false },
        { action: setLocalCamExists, prop: 'localCamExists', expected: true },
        { action: setIsCamEnabled, prop: 'isCamEnabled', expected: false },
        { action: setIsCamEnabled, prop: 'isCamEnabled', expected: true },
        { action: setIsBlurEnabled, prop: 'isBlurEnabled', expected: false },
        { action: setIsBlurEnabled, prop: 'isBlurEnabled', expected: true },
        { action: setIsChatVisible, prop: 'isChatVisible', expected: false },
        { action: setIsChatVisible, prop: 'isChatVisible', expected: true },
        {
            action: setInstructionVideoVisible,
            prop: 'isInstructionVideoVisible',
            expected: false,
        },
        {
            action: setInstructionVideoVisible,
            prop: 'isInstructionVideoVisible',
            expected: true,
        },
        {
            action: setCancelButtonVisible,
            prop: 'isCancelButtonVisible',
            expected: false,
        },
        {
            action: setCancelButtonVisible,
            prop: 'isCancelButtonVisible',
            expected: true,
        },
        {
            action: setEndCallConfirmation,
            prop: 'endCallConfirmation',
            expected: false,
        },
        {
            action: setEndCallConfirmation,
            prop: 'endCallConfirmation',
            expected: true,
        },
    ])('set $prop to $expected', ({ action, prop, expected }) => {
        const newState: TState = reducer(undefined, action(expected));

        expect(newState[prop]).toEqual(expected);
    });

    it('set end call confirmation to true should reset initial state', () => {
        const newState = reducer(undefined, setEndCallConfirmation(true));

        expect(newState).toEqual({
            ...defaultMenuState,
            isMicEnabled: true,
            endCallConfirmation: true,
        });
    });

    it('set end call confirmation to false should reset initial state', () => {
        const newState = reducer(undefined, setEndCallConfirmation(true));

        expect(newState).toEqual({
            ...defaultMenuState,
            isMicEnabled: true,
            endCallConfirmation: true,
        });
    });

    it('reset video controls', () => {
        let state = reducer(undefined, setIsFullScreen(true));
        state = reducer(state, setIsChatVisible(true));
        state = reducer(state, setIsMicEnabled(false));
        state = reducer(state, setIsCamEnabled(false));
        state = reducer(state, setIsBlurEnabled(true));

        expect(state).toEqual({
            ...defaultMenuState,
            isFullScreen: true,
            isChatVisible: true,
            isMicEnabled: false,
            isCamEnabled: false,
            isBlurEnabled: true,
        });

        state = reducer(state, resetVideoControls());

        expect(state).toEqual({
            ...defaultMenuState,
            isFullScreen: false,
            isChatVisible: false,
            isMicEnabled: true,
            isCamEnabled: true,
            isBlurEnabled: false,
        });
    });
});
