import {
    reducer,
    addWaitingInstantMessage,
    addVideoInstantMessage,
    setWaitingRoomHasUnread,
    setVideoHasUnread,
} from '../../../src/redux/modules/instantMessage';

describe('instantMessage', () => {
    const defaultMessage = {
        key: 'key1',
        content: 'test message',
        timeSent: 123,
        isOutgoing: false,
        senderName: 'doctor who',
    };
    test('initial state', () => {
        expect(reducer(undefined, {})).toEqual({
            waitingInstantMessages: [],
            videoInstantMessages: [],
            videoHasUnread: false,
            waitingRoomHasUnread: false,
        });
    });
    test('addWaitingInstantMessage', () => {
        const newState = reducer(
            undefined,
            addWaitingInstantMessage(defaultMessage),
        );
        expect(newState.waitingInstantMessages).toEqual([defaultMessage]);
    });
    test('addVideoInstantMessage', () => {
        const newState = reducer(
            undefined,
            addVideoInstantMessage(defaultMessage),
        );
        expect(newState.videoInstantMessages).toEqual([defaultMessage]);
    });
    test('waitinghasunread', () => {
        const newState = reducer(undefined, setWaitingRoomHasUnread(true));
        expect(newState.waitingRoomHasUnread).toEqual(true);
        expect(newState.videoHasUnread).toBeFalsy();
    });
    test('videohasunread', () => {
        const newState = reducer(undefined, setVideoHasUnread(true));
        expect(newState.videoHasUnread).toEqual(true);
        expect(newState.waitingRoomHasUnread).toBeFalsy();
    });
    test('addWaitingInstantMessage - duplicate', () => {
        const newState = reducer(
            {
                waitingInstantMessages: [defaultMessage],
                videoInstantMessages: [],
                videoHasUnread: false,
                waitingRoomHasUnread: false,
            },
            addWaitingInstantMessage({
                ...defaultMessage,
                senderName: 'differentname',
            }),
        );
        expect(newState.waitingInstantMessages).toHaveLength(1);
        expect(newState.waitingInstantMessages).toEqual([defaultMessage]);
    });
    test('addVideoMessage - duplicate', () => {
        const newState = reducer(
            {
                waitingInstantMessages: [],
                videoInstantMessages: [defaultMessage],
                videoHasUnread: false,
                waitingRoomHasUnread: false,
            },
            addVideoInstantMessage({
                ...defaultMessage,
                senderName: 'differentname',
            }),
        );
        expect(newState.videoInstantMessages).toHaveLength(1);
        expect(newState.videoInstantMessages).toEqual([defaultMessage]);
    });
});
