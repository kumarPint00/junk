import {
    reducer,
    setUserDetails,
} from '../../../src/redux/modules/userDetails';
import { UserDetails } from '../../../src/types/UserDetails';

describe('userDetails', () => {
    const defaultUser: UserDetails = {
        id: '123',
        displayName: 'user details',
        givenName: 'user',
        familyName: 'details',
        email: 'userdetails@email.com',
        token: '1234',
        expiration: -1,
        sharedSessionStoreEnabled: false,
    };
    test('initial state', () => {
        expect(reducer(undefined, {})).toEqual({
            userDetails: {
                id: '',
                displayName: '',
                givenName: '',
                familyName: '',
                email: '',
                token: '',
                expiration: -1,
                roles: [],
                sharedSessionStoreEnabled: false,
            },
        });
    });
    test('setUserDetails', () => {
        const newState = reducer(undefined, setUserDetails(defaultUser));
        expect(newState.userDetails).toEqual(defaultUser);
    });
});
