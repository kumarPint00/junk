import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';

import { PaymentStatus } from '@redux/utils/PaymentStatus';

import * as postConsult from '../../../src/redux/modules/postConsult';
import { VisitDetails } from '../../../src/clients/VisitService/VisitInterfaces';
import { backendFacade } from '../../../src/clients/Backend/BackendFacade';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { location } from '@dexcare/circus-jupiter';
import { PostVisitActions } from '@dexcare/circus-saturn';
import { vi } from 'vitest';
import { Logger } from '@utils/index';
import { MockStoreType } from '../../../src/types/redux';

const { mockNavigate } = vi.hoisted(() => ({ mockNavigate: vi.fn() }));

vi.mock('@clients/VisitService/VisitServiceClient');
vi.mock('../../../src/clients/Backend/BackendFacade');
vi.mock('../../../src/routes', () => ({
    navigate: mockNavigate,
}));

const middlewares = [thunk];
const mockStore: (state?: unknown) => MockStoreType =
    configureMockStore(middlewares);

describe('postConsult', () => {
    const initialState: postConsult.TState = {
        callStartTime: null,
        callEndTime: null,
        visitId: '',
        patientGuid: '',
        providerId: null,
        practiceId: '',
        invalidVisitId: false,
        invalidVisitReason: null,
        isTestVisit: false,
        chargedStatus: PaymentStatus.none,
        isTokBox: false,
        tokBoxVideoToken: '',
        tokBoxWaitingRoomToken: '',
        tokBoxTokenError: false,
        tokBoxTokenErrorMessage: null,
        consentTermsAccepted: false,
        consentTermsErrorMessage: null,
        isLoadingConsentTerms: false,
        messageDialog: null,
        postVisitAction: null,
        postVisitActionErrorMessage: null,
        timestamps: {
            cancelled: undefined,
            caregiverassigned: undefined,
            created: undefined,
            done: undefined,
            invisit: undefined,
            requested: undefined,
            staffdeclined: undefined,
            waitingroom: undefined,
            waitoffline: undefined,
        },
        visitStatus: '',
        isTravelingFromCallCenter: false,
    };

    describe('postConsult', () => {
        test('initial state', () => {
            expect(postConsult.reducer(undefined, {})).toEqual(initialState);
        });
        test('callStartTime', () => {
            const newValue = 809809822;
            const newState = postConsult.reducer(
                undefined,
                postConsult.setCallStartTime(newValue),
            );
            expect(newState.callStartTime).toEqual(newValue);
        });
        test('callEndTime', () => {
            const newValue = 12334564;
            const newState = postConsult.reducer(
                undefined,
                postConsult.setCallEndTime(newValue),
            );
            expect(newState.callEndTime).toEqual(newValue);
        });
        test('visitId', () => {
            const newValue = 'visitId123';
            const newState = postConsult.reducer(
                undefined,
                postConsult.setVisitId(newValue),
            );
            expect(newState.visitId).toEqual(newValue);
        });
        test('patientGuid', () => {
            const newValue = 'patientGuid123';
            const newState = postConsult.reducer(
                undefined,
                postConsult.setPatientGuid(newValue),
            );
            expect(newState.patientGuid).toEqual(newValue);
        });
        test('providerId', () => {
            const newValue = 'providerId123';
            const newState = postConsult.reducer(
                undefined,
                postConsult.setProviderId(newValue),
            );
            expect(newState.providerId).toEqual(newValue);
        });
        test('invalidVisitId', () => {
            const newValue = true;
            const newState = postConsult.reducer(
                undefined,
                postConsult.setInvalidVisitId(newValue),
            );
            expect(newState.invalidVisitId).toEqual(newValue);
        });
        test('invalidVisitReason', () => {
            const newValue = 'Invalid reason';
            const newState = postConsult.reducer(
                undefined,
                postConsult.setInvalidVisitReason(newValue),
            );
            expect(newState.invalidVisitReason).toEqual(newValue);
        });
        test('postConsult.setTokBoxVideoToken', () => {
            const token = 'token';
            const newState = postConsult.reducer(
                undefined,
                postConsult.setTokBoxVideoToken(token),
            );
            expect(newState.tokBoxVideoToken).toEqual(token);
        });
        test('postConsult.setTokBoxWaitingRoomToken', () => {
            const token = 'token';
            const newState = postConsult.reducer(
                undefined,
                postConsult.setTokBoxWaitingRoomToken(token),
            );
            expect(newState.tokBoxWaitingRoomToken).toEqual(token);
        });
        test('postConsult.setTokBoxVideoSessionId', () => {
            const sessionId = 'sessionId';
            const newState = postConsult.reducer(
                undefined,
                postConsult.setTokBoxVideoSessionId(sessionId),
            );
            expect(newState.tokBoxVideoSessionId).toEqual(sessionId);
        });
        test('postConsult.setTokBoxWaitingRoomSessionId', () => {
            const sessionId = 'sessionId';
            const newState = postConsult.reducer(
                undefined,
                postConsult.setTokBoxWaitingRoomSessionId(sessionId),
            );
            expect(newState.tokBoxWaitingRoomSessionId).toEqual(sessionId);
        });
        test('postConsult.setTokBoxTokenError', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setTokBoxTokenError(true),
            );
            expect(newState.tokBoxTokenError).toEqual(true);
        });
        test('postConsult.setTokBoxTokenError', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setTokBoxTokenError(true),
            );
            expect(newState.tokBoxTokenError).toEqual(true);
        });
        test('postConsult.setTokBoxTokenErrorMessage', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setTokBoxTokenErrorMessage('UNAUTHORIZED'),
            );
            expect(newState.tokBoxTokenErrorMessage).toEqual('UNAUTHORIZED');
        });
        test('postConsult.setTokBoxTokenErrorMessage', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setTokBoxTokenErrorMessage('UNAUTHORIZED'),
            );
            expect(newState.tokBoxTokenErrorMessage).toEqual('UNAUTHORIZED');
        });
        test('postConsult.setTokBoxTokenLoading', () => {
            const newState = postConsult.reducer(
                { tokBoxTokenError: true, ...initialState },
                postConsult.setTokBoxTokenLoading(),
            );
            expect(newState.tokBoxTokenError).toEqual(false);
        });
        test('postConsult.setIsTestVisit', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setIsTestVisit(true),
            );
            expect(newState.isTestVisit).toEqual(true);
        });
        test('postConsult.setChargedStatus', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setChargedStatus(1),
            );
            expect(newState.chargedStatus).toEqual(1);
        });
        test('postConsult.setConsentTermsAccepted', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setConsentTermsAccepted(true),
            );
            expect(newState.consentTermsAccepted).toEqual(true);
        });
        test('postConsult.setConsentErrorMessage', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setConsentErrorMessage('message'),
            );
            expect(newState.consentTermsErrorMessage).toEqual('message');
        });
        test('postConsult.setIsLoadingConsentTerms', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setIsLoadingConsentTerms(true),
            );
            expect(newState.isLoadingConsentTerms).toEqual(true);
        });
        test('postConsult.setMessageDialog', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setMessageDialog('dilaog'),
            );
            expect(newState.messageDialog).toEqual('dilaog');
        });
        test('postConsult.setVisitTimestamps', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setVisitTimestamps({}),
            );
            expect(newState.timestamps).toEqual({});
        });
        test('postConsult.setPracticeId', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setPracticeId('123456789'),
            );
            expect(newState.practiceId).toEqual('123456789');
        });
        test('postConsult.setVisitStatus', () => {
            const newState = postConsult.reducer(
                undefined,
                postConsult.setVisitStatus('status'),
            );
            expect(newState.visitStatus).toEqual('status');
        });
    });

    describe('transferBackToQueue', () => {
        const testVisitId = 'VISIT1234';
        const testLoggerData = {
            eventSource: 'postConsult',
            eventType: 'transferBackToQueue',
            visitId: testVisitId,
        };
        const store = mockStore({
            user: {
                userDetails: {
                    id: 'userId',
                },
            },
        });
        test('check success', async () => {
            backendFacade.transferBackToQueue = vi.fn(async (visitId) => {
                return Promise.resolve({
                    message: `The visit ${visitId} is successsully transfered`,
                } as never);
            });
            vi.spyOn(Logger, 'info');
            await store.dispatch(postConsult.transferBackToQueue(testVisitId));
            expect(Logger.info).toHaveBeenCalledWith(
                testLoggerData,
                'successfully transferred visit back to queue',
            );
        });

        test('check failure', async () => {
            backendFacade.transferBackToQueue = vi.fn(async () => {
                return new Promise((_resolve, reject) => {
                    reject(new Error('fail test'));
                });
            });
            vi.spyOn(Logger, 'error');
            await store.dispatch(postConsult.transferBackToQueue(testVisitId));
            expect(Logger.error).toHaveBeenCalledWith(
                { ...testLoggerData, error: new Error('fail test') },
                'Failed to transfer visit back to queue',
            );
        });
    });

    describe('transferToAnotherProvider', () => {
        const testVisitId = 'VISIT1234';
        const testProviderId = 'PROVIDER1234';
        const testLoggerData = {
            eventSource: 'postConsult',
            eventType: 'transferToAnotherProvider',
            visitId: testVisitId,
            providerId: testProviderId,
        };
        const store = mockStore({
            user: {
                userDetails: {
                    id: 'userId',
                },
            },
        });
        test('check success', async () => {
            backendFacade.transferToAnotherProvider = vi.fn(async (visitId) => {
                return Promise.resolve({
                    message: `The visit ${visitId} is successsully transfered`,
                } as never);
            });
            vi.spyOn(Logger, 'info');
            await store.dispatch(
                postConsult.transferToAnotherProvider(
                    testVisitId,
                    testProviderId,
                ),
            );
            expect(Logger.info).toHaveBeenCalledWith(
                testLoggerData,
                'successfully transferred visit to another provider',
            );
        });

        test('check failure', async () => {
            backendFacade.transferToAnotherProvider = vi.fn(async () => {
                return new Promise((_resolve, reject) => {
                    reject(new Error('fail test'));
                });
            });
            vi.spyOn(Logger, 'error');
            await store.dispatch(
                postConsult.transferToAnotherProvider(
                    testVisitId,
                    testProviderId,
                ),
            );
            expect(Logger.error).toHaveBeenCalledWith(
                { ...testLoggerData, error: new Error('fail test') },
                'failed to transfer visit to another provider',
            );
        });
    });

    describe('chargeVisit', () => {
        const testVisitId = 'VISIT1234';
        test('check success', async () => {
            const expectedActions = [
                {
                    payload: PaymentStatus.charged,
                    type: postConsult.actionTypes.SET_CHARGED_STATUS,
                },
            ];
            const store = mockStore({});
            visitServiceClient.chargeVisit = vi.fn(async (visitId) => {
                return new Promise((resolve) => {
                    resolve({
                        message: `The visit ${visitId} is successsully charged`,
                    });
                });
            });
            await store.dispatch(postConsult.chargeVisit(testVisitId));
            expect(store.getActions()).toEqual(expectedActions);
        });
        test('check failure', async () => {
            const store = mockStore({});
            visitServiceClient.chargeVisit = vi.fn(async () => {
                return Promise.reject(new Error('fail test'));
            });
            await expect(
                store.dispatch(postConsult.chargeVisit(testVisitId)),
            ).rejects.toThrow('fail test');
        });
    });

    describe('waiveVisit', () => {
        const testVisitId = 'VISIT1234';
        test('check success', async () => {
            const expectedActions = [
                {
                    payload: PaymentStatus.waived,
                    type: postConsult.actionTypes.SET_CHARGED_STATUS,
                },
            ];
            const store = mockStore({});
            visitServiceClient.waiveVisit = vi.fn(async (visitId) => {
                return new Promise((resolve) => {
                    resolve({
                        message: `The visit ${visitId} is successsully waived`,
                    });
                });
            });
            await store.dispatch(postConsult.waiveVisit(testVisitId, 'imNice'));
            expect(store.getActions()).toEqual(expectedActions);
        });

        test('check failure', async () => {
            const store = mockStore({});
            visitServiceClient.waiveVisit = vi.fn(async () => {
                return Promise.reject(new Error('fail test'));
            });
            await expect(
                store.dispatch(postConsult.waiveVisit(testVisitId)),
            ).rejects.toThrow('fail test');
        });
    });

    describe('fetchTokBoxVideoToken', () => {
        beforeEach(() => {
            vi.resetAllMocks();
        });
        const patientToken = 'patientToken';
        const providerToken = 'providerToken';
        const visitId = 'visitId';
        const id = 'userId';
        const tokBoxVideoSessionId = 'tokBoxVideoSessionId';
        const tokBoxWaitingRoomSessionId = 'tokBoxWaitingRoomSessionId';

        test('user is provider', async () => {
            const expectedActions = [
                {
                    payload: undefined,
                    type: postConsult.actionTypes.SET_TOKBOX_TOKEN_LOADING,
                },
                {
                    payload: providerToken,
                    type: postConsult.actionTypes.SET_TOKBOX_VIDEO_TOKEN,
                },
            ];

            const store = mockStore({
                postconsult: {
                    visitId,
                },
                user: {
                    userDetails: {
                        id,
                        roles: ['telehealth_provider'],
                    },
                },
            });
            backendFacade.generateTokboxProviderToken = vi
                .fn()
                .mockResolvedValue({ token: providerToken });
            await store.dispatch(
                postConsult.fetchTokBoxTokens({
                    videoSessionId: tokBoxVideoSessionId,
                    waitingRoomSessionId: tokBoxWaitingRoomSessionId,
                }),
            );

            expect(
                backendFacade.generateTokboxProviderToken,
            ).toHaveBeenCalledWith(tokBoxVideoSessionId, visitId, id);
            expect(
                visitServiceClient.generateTokboxPatientToken,
            ).not.toHaveBeenCalled();
            expect(store.getActions()).toEqual(expectedActions);
        });

        test('user is not a provider', async () => {
            const expectedActions = [
                {
                    payload: undefined,
                    type: postConsult.actionTypes.SET_TOKBOX_TOKEN_LOADING,
                },
                {
                    payload: patientToken,
                    type: postConsult.actionTypes.SET_TOKBOX_WAITING_ROOM_TOKEN,
                },
                {
                    payload: patientToken,
                    type: postConsult.actionTypes.SET_TOKBOX_VIDEO_TOKEN,
                },
            ];

            const store = mockStore({
                postconsult: {
                    visitId,
                    tokBoxVideoSessionId,
                    tokBoxWaitingRoomSessionId,
                },
                user: {
                    userDetails: {
                        roles: ['telehealth_patient'],
                    },
                },
            });
            visitServiceClient.generateTokboxPatientToken = vi
                .fn()
                .mockResolvedValue({ token: patientToken });

            await store.dispatch(
                postConsult.fetchTokBoxTokens({
                    videoSessionId: tokBoxVideoSessionId,
                    waitingRoomSessionId: tokBoxWaitingRoomSessionId,
                }),
            );

            expect(
                visitServiceClient.generateTokboxPatientToken,
            ).toHaveBeenCalledWith(tokBoxVideoSessionId, visitId);
            expect(
                visitServiceClient.generateTokboxPatientToken,
            ).toHaveBeenCalledWith(tokBoxWaitingRoomSessionId, visitId);

            expect(
                backendFacade.generateTokboxProviderToken,
            ).not.toHaveBeenCalled();
            expect(store.getActions()).toEqual(expectedActions);
        });

        test('error', async () => {
            const expectedActions = [
                {
                    payload: undefined,
                    type: postConsult.actionTypes.SET_TOKBOX_TOKEN_LOADING,
                },
                {
                    payload: true,
                    type: postConsult.actionTypes.SET_TOKBOX_TOKEN_ERROR,
                },
                {
                    payload: 'error',
                    type: postConsult.actionTypes
                        .SET_TOKBOX_TOKEN_ERROR_MESSAGE,
                },
            ];

            const store = mockStore({
                postconsult: {
                    visitId,
                    tokBoxVideoSessionId,
                },
                user: {
                    userDetails: {
                        roles: ['telehealth_patient'],
                    },
                },
            });
            visitServiceClient.generateTokboxPatientToken = vi
                .fn()
                .mockRejectedValue(new Error('error'));

            await store.dispatch(
                postConsult.fetchTokBoxTokens({
                    videoSessionId: tokBoxVideoSessionId,
                    waitingRoomSessionId: tokBoxWaitingRoomSessionId,
                }),
            );
            expect(store.getActions()).toEqual(expectedActions);
        });
    });

    describe('fetchVisitDetailsByVisitId', () => {
        const testVisitId = 'VISIT1234';
        let defaultVisitDetails: VisitDetails;
        beforeEach(() => {
            defaultVisitDetails = {
                visitId: testVisitId,
                patientGuid: 'patientGuid',
                providerId: 'providerId',
                practiceId: 'practiceId',
                isTokBox: true,
                tokBoxVisit: {
                    videoConferenceSession: { sessionId: 'TOK1' },
                    waitingRoomSession: { sessionId: 'TOK2' },
                },
                visitStatus: 'requested',
                modality: 'video',
                integrations: {
                    tytoCare: {
                        enabled: false,
                    },
                },
                acceptTerms: false,
                timestamps: {
                    cancelled: '2021-03-03T23:49:50.655Z',
                    caregiverassigned: '2021-03-03T23:49:50.655Z',
                    created: '2021-03-03T23:49:50.655Z',
                    done: '2021-03-03T23:49:50.655Z',
                    invisit: '2021-03-03T23:49:50.655Z',
                    requested: '2021-03-03T23:49:50.655Z',
                    staffdeclined: '2021-03-03T23:49:50.655Z',
                    waitingroom: '2021-03-03T23:49:50.655Z',
                    waitoffline: '2021-03-03T23:49:50.655Z',
                },
            };
        });

        test('check success', async () => {
            // arrange
            const expectedActions = [
                {
                    payload: 'VISIT1234',
                    type: postConsult.actionTypes.SET_VISIT_ID,
                },
                {
                    payload: 'TOK1',
                    type: postConsult.actionTypes.SET_TOKBOX_VIDEO_SESSION_ID,
                },
                {
                    payload: 'TOK2',
                    type: postConsult.actionTypes
                        .SET_TOKBOX_WAITING_ROOM_SESSION_ID,
                },
                {
                    payload: 'patientGuid',
                    type: postConsult.actionTypes.SET_PATIENT_GUID,
                },
                {
                    payload: false,
                    type: postConsult.actionTypes.SET_CONSENT_TERMS_ACCEPTED,
                },
                {
                    payload: {
                        cancelled: '2021-03-03T23:49:50.655Z',
                        caregiverassigned: '2021-03-03T23:49:50.655Z',
                        created: '2021-03-03T23:49:50.655Z',
                        done: '2021-03-03T23:49:50.655Z',
                        invisit: '2021-03-03T23:49:50.655Z',
                        requested: '2021-03-03T23:49:50.655Z',
                        staffdeclined: '2021-03-03T23:49:50.655Z',
                        waitingroom: '2021-03-03T23:49:50.655Z',
                        waitoffline: '2021-03-03T23:49:50.655Z',
                    },
                    type: postConsult.actionTypes.SET_VISIT_TIMESTAMPS,
                },
                {
                    payload: 'practiceId',
                    type: postConsult.actionTypes.SET_PRACTICE_ID,
                },
                {
                    payload: 'requested',
                    type: postConsult.actionTypes.SET_VISIT_STATUS,
                },
                {
                    payload: 'providerId',
                    type: postConsult.actionTypes.SET_PROVIDER_ID,
                },
                {
                    payload: false,
                    type: postConsult.actionTypes
                        .SET_IS_TRAVELING_FROM_CALL_CENTER,
                },
            ];
            const store = mockStore({});

            visitServiceClient.getVisitSummary = vi.fn(async () => {
                return new Promise((resolve) => {
                    resolve(defaultVisitDetails);
                });
            });

            // act
            const response = await store.dispatch(
                postConsult.fetchVisitDetailsByVisitId({
                    visitId: testVisitId,
                    isProvider: false,
                }),
            );

            // assert
            expect(store.getActions()).toEqual(expectedActions);
            expect(response).toBe(defaultVisitDetails);
        });

        test('check failed network request', async () => {
            // arrange
            const expectedActions = [
                {
                    payload: true,
                    type: postConsult.actionTypes.SET_INVALID_VISIT_ID,
                },
                {
                    payload: 'fail test',
                    type: postConsult.actionTypes.SET_INVALID_VISIT_REASON,
                },
            ];

            const store = mockStore({});

            visitServiceClient.getVisitSummary = vi.fn(async () => {
                return Promise.reject(new Error('fail test'));
            });

            // act
            const response = await store.dispatch(
                postConsult.fetchVisitDetailsByVisitId({
                    visitId: testVisitId,
                    isProvider: false,
                }),
            );

            // assert
            expect(store.getActions()).toEqual(expectedActions);
            expect(response).toBe(undefined);
        });

        test('check invalid conference type', async () => {
            defaultVisitDetails.isTokBox = false;
            // arrange
            const expectedActions = [
                {
                    payload: true,
                    type: postConsult.actionTypes.SET_INVALID_VISIT_ID,
                },
                {
                    payload: 'invalid conference type',
                    type: postConsult.actionTypes.SET_INVALID_VISIT_REASON,
                },
            ];

            const store = mockStore({});

            visitServiceClient.getVisitSummary = vi.fn(async () => {
                return new Promise((resolve) => {
                    resolve(defaultVisitDetails);
                });
            });

            // act
            const response = await store.dispatch(
                postConsult.fetchVisitDetailsByVisitId({
                    visitId: testVisitId,
                    isProvider: false,
                }),
            );

            // assert
            expect(store.getActions()).toEqual(expectedActions);
            expect(response).toBe(undefined);
        });

        describe('redirects', () => {
            test('done', async () => {
                // arrange
                const expectedActions = [
                    {
                        payload: 'VISIT1234',
                        type: postConsult.actionTypes.SET_VISIT_ID,
                    },
                    {
                        payload: 'TOK1',
                        type: postConsult.actionTypes
                            .SET_TOKBOX_VIDEO_SESSION_ID,
                    },
                    {
                        payload: 'TOK2',
                        type: postConsult.actionTypes
                            .SET_TOKBOX_WAITING_ROOM_SESSION_ID,
                    },
                    {
                        payload: 'patientGuid',
                        type: postConsult.actionTypes.SET_PATIENT_GUID,
                    },
                    {
                        payload: false,
                        type: postConsult.actionTypes
                            .SET_CONSENT_TERMS_ACCEPTED,
                    },
                    {
                        payload: {
                            cancelled: '2021-03-03T23:49:50.655Z',
                            caregiverassigned: '2021-03-03T23:49:50.655Z',
                            created: '2021-03-03T23:49:50.655Z',
                            done: '2021-03-03T23:49:50.655Z',
                            invisit: '2021-03-03T23:49:50.655Z',
                            requested: '2021-03-03T23:49:50.655Z',
                            staffdeclined: '2021-03-03T23:49:50.655Z',
                            waitingroom: '2021-03-03T23:49:50.655Z',
                            waitoffline: '2021-03-03T23:49:50.655Z',
                        },
                        type: postConsult.actionTypes.SET_VISIT_TIMESTAMPS,
                    },
                    {
                        payload: 'practiceId',
                        type: postConsult.actionTypes.SET_PRACTICE_ID,
                    },
                    {
                        payload: 'done',
                        type: postConsult.actionTypes.SET_VISIT_STATUS,
                    },
                    {
                        payload: 'providerId',
                        type: postConsult.actionTypes.SET_PROVIDER_ID,
                    },
                    {
                        payload: false,
                        type: postConsult.actionTypes
                            .SET_IS_TRAVELING_FROM_CALL_CENTER,
                    },
                ];
                const visitDetails = Object.assign({}, defaultVisitDetails, {
                    visitStatus: 'done',
                });

                const store = mockStore({});

                visitServiceClient.getVisitSummary = vi.fn(async () => {
                    return new Promise((resolve) => {
                        resolve(visitDetails);
                    });
                });

                // act
                const response = await store.dispatch(
                    postConsult.fetchVisitDetailsByVisitId({
                        visitId: testVisitId,
                        isProvider: false,
                    }),
                );

                // assert
                expect(store.getActions()).toEqual(expectedActions);
                expect(response).toBe(visitDetails);
            });

            test('declined', async () => {
                // arrange
                const expectedActions = [
                    {
                        payload: 'VISIT1234',
                        type: postConsult.actionTypes.SET_VISIT_ID,
                    },
                    {
                        payload: 'TOK1',
                        type: postConsult.actionTypes
                            .SET_TOKBOX_VIDEO_SESSION_ID,
                    },
                    {
                        payload: 'TOK2',
                        type: postConsult.actionTypes
                            .SET_TOKBOX_WAITING_ROOM_SESSION_ID,
                    },
                    {
                        payload: 'patientGuid',
                        type: postConsult.actionTypes.SET_PATIENT_GUID,
                    },
                    {
                        payload: false,
                        type: postConsult.actionTypes
                            .SET_CONSENT_TERMS_ACCEPTED,
                    },
                    {
                        payload: {
                            cancelled: '2021-03-03T23:49:50.655Z',
                            caregiverassigned: '2021-03-03T23:49:50.655Z',
                            created: '2021-03-03T23:49:50.655Z',
                            done: '2021-03-03T23:49:50.655Z',
                            invisit: '2021-03-03T23:49:50.655Z',
                            requested: '2021-03-03T23:49:50.655Z',
                            staffdeclined: '2021-03-03T23:49:50.655Z',
                            waitingroom: '2021-03-03T23:49:50.655Z',
                            waitoffline: '2021-03-03T23:49:50.655Z',
                        },
                        type: postConsult.actionTypes.SET_VISIT_TIMESTAMPS,
                    },
                    {
                        payload: 'practiceId',
                        type: postConsult.actionTypes.SET_PRACTICE_ID,
                    },
                    {
                        payload: 'staffdeclined',
                        type: postConsult.actionTypes.SET_VISIT_STATUS,
                    },
                    {
                        payload: 'providerId',
                        type: postConsult.actionTypes.SET_PROVIDER_ID,
                    },
                    {
                        payload: false,
                        type: postConsult.actionTypes
                            .SET_IS_TRAVELING_FROM_CALL_CENTER,
                    },
                ];

                const visitDetails = Object.assign({}, defaultVisitDetails, {
                    visitStatus: 'staffdeclined',
                });

                const store = mockStore({});

                visitServiceClient.getVisitSummary = vi.fn(async () => {
                    return new Promise((resolve) => {
                        resolve(visitDetails);
                    });
                });

                // act
                const response = await store.dispatch(
                    postConsult.fetchVisitDetailsByVisitId({
                        visitId: testVisitId,
                        isProvider: false,
                    }),
                );

                // assert
                expect(store.getActions()).toEqual(expectedActions);
                expect(response).toBe(visitDetails);
            });

            test('expired', async () => {
                // arrange
                const expectedActions = [
                    {
                        payload: 'VISIT1234',
                        type: postConsult.actionTypes.SET_VISIT_ID,
                    },
                    {
                        payload: 'TOK1',
                        type: postConsult.actionTypes
                            .SET_TOKBOX_VIDEO_SESSION_ID,
                    },
                    {
                        payload: 'TOK2',
                        type: postConsult.actionTypes
                            .SET_TOKBOX_WAITING_ROOM_SESSION_ID,
                    },
                    {
                        payload: 'patientGuid',
                        type: postConsult.actionTypes.SET_PATIENT_GUID,
                    },
                    {
                        payload: false,
                        type: postConsult.actionTypes
                            .SET_CONSENT_TERMS_ACCEPTED,
                    },
                    {
                        payload: {
                            cancelled: '2021-03-03T23:49:50.655Z',
                            caregiverassigned: '2021-03-03T23:49:50.655Z',
                            created: '2021-03-03T23:49:50.655Z',
                            done: '2021-03-03T23:49:50.655Z',
                            invisit: '2021-03-03T23:49:50.655Z',
                            requested: '2021-03-03T23:49:50.655Z',
                            staffdeclined: '2021-03-03T23:49:50.655Z',
                            waitingroom: '2021-03-03T23:49:50.655Z',
                            waitoffline: '2021-03-03T23:49:50.655Z',
                        },
                        type: postConsult.actionTypes.SET_VISIT_TIMESTAMPS,
                    },
                    {
                        payload: 'practiceId',
                        type: postConsult.actionTypes.SET_PRACTICE_ID,
                    },
                    {
                        payload: 'expired',
                        type: postConsult.actionTypes.SET_VISIT_STATUS,
                    },
                    {
                        payload: 'providerId',
                        type: postConsult.actionTypes.SET_PROVIDER_ID,
                    },
                    {
                        payload: false,
                        type: postConsult.actionTypes
                            .SET_IS_TRAVELING_FROM_CALL_CENTER,
                    },
                ];

                const visitDetails = Object.assign({}, defaultVisitDetails, {
                    visitStatus: 'expired',
                });

                const store = mockStore({});

                visitServiceClient.getVisitSummary = vi.fn(async () => {
                    return new Promise((resolve) => {
                        resolve(visitDetails);
                    });
                });

                // act
                const response = await store.dispatch(
                    postConsult.fetchVisitDetailsByVisitId({
                        visitId: testVisitId,
                        isProvider: false,
                    }),
                );

                // assert
                expect(store.getActions()).toEqual(expectedActions);
                expect(response).toBe(visitDetails);
            });

            test('waitingroom', async () => {
                // arrange
                const expectedActions = [
                    {
                        payload: 'VISIT1234',
                        type: postConsult.actionTypes.SET_VISIT_ID,
                    },
                    {
                        payload: 'TOK1',
                        type: postConsult.actionTypes
                            .SET_TOKBOX_VIDEO_SESSION_ID,
                    },
                    {
                        payload: 'TOK2',
                        type: postConsult.actionTypes
                            .SET_TOKBOX_WAITING_ROOM_SESSION_ID,
                    },
                    {
                        payload: 'patientGuid',
                        type: postConsult.actionTypes.SET_PATIENT_GUID,
                    },
                    {
                        payload: false,
                        type: postConsult.actionTypes
                            .SET_CONSENT_TERMS_ACCEPTED,
                    },
                    {
                        payload: {
                            cancelled: '2021-03-03T23:49:50.655Z',
                            caregiverassigned: '2021-03-03T23:49:50.655Z',
                            created: '2021-03-03T23:49:50.655Z',
                            done: '2021-03-03T23:49:50.655Z',
                            invisit: '2021-03-03T23:49:50.655Z',
                            requested: '2021-03-03T23:49:50.655Z',
                            staffdeclined: '2021-03-03T23:49:50.655Z',
                            waitingroom: '2021-03-03T23:49:50.655Z',
                            waitoffline: '2021-03-03T23:49:50.655Z',
                        },
                        type: postConsult.actionTypes.SET_VISIT_TIMESTAMPS,
                    },
                    {
                        payload: 'practiceId',
                        type: postConsult.actionTypes.SET_PRACTICE_ID,
                    },
                    {
                        payload: 'waitingroom',
                        type: postConsult.actionTypes.SET_VISIT_STATUS,
                    },
                    {
                        payload: 'providerId',
                        type: postConsult.actionTypes.SET_PROVIDER_ID,
                    },
                    {
                        payload: false,
                        type: postConsult.actionTypes
                            .SET_IS_TRAVELING_FROM_CALL_CENTER,
                    },
                ];

                const visitDetails = Object.assign({}, defaultVisitDetails, {
                    visitStatus: 'waitingroom',
                    modality: 'phone',
                });

                const store = mockStore({});

                visitServiceClient.getVisitSummary = vi.fn(async () => {
                    return new Promise((resolve) => {
                        resolve(visitDetails);
                    });
                });

                // act
                const response = await store.dispatch(
                    postConsult.fetchVisitDetailsByVisitId({
                        visitId: testVisitId,
                        isProvider: false,
                        isSurvey: true,
                    }),
                );

                // assert
                expect(store.getActions()).toEqual(expectedActions);
                expect(response).toBe(visitDetails);
            });
        });
    });

    describe('acceptConsentTerms', () => {
        const testVisitId = 'VISIT1234';
        test('check success', async () => {
            // arrange
            const expectedActions = [
                {
                    payload: true,
                    type: postConsult.actionTypes.SET_IS_LOADING_CONSENT_TERMS,
                },
                {
                    payload: true,
                    type: postConsult.actionTypes.SET_CONSENT_TERMS_ACCEPTED,
                },
                {
                    payload: false,
                    type: postConsult.actionTypes.SET_IS_LOADING_CONSENT_TERMS,
                },
            ];
            const store = mockStore({ postconsult: { visitId: testVisitId } });

            visitServiceClient.acceptConsentTerms = vi.fn(async (visitId) => {
                expect(visitId).toEqual(testVisitId);
                return new Promise((resolve) => {
                    resolve();
                });
            });

            // act
            await store.dispatch(postConsult.acceptConsentTerms());

            // assert
            expect(store.getActions()).toEqual(expectedActions);
        });

        test('check fail', async () => {
            const errorMessage = 'rrrk';
            // arrange
            const expectedActions = [
                {
                    payload: true,
                    type: postConsult.actionTypes.SET_IS_LOADING_CONSENT_TERMS,
                },
                {
                    payload: false,
                    type: postConsult.actionTypes.SET_CONSENT_TERMS_ACCEPTED,
                },
                {
                    payload: errorMessage,
                    type: postConsult.actionTypes.SET_CONSENT_ERROR_MESSAGE,
                },
                {
                    payload: false,
                    type: postConsult.actionTypes.SET_IS_LOADING_CONSENT_TERMS,
                },
            ];
            const store = mockStore({ postconsult: { visitId: testVisitId } });

            visitServiceClient.acceptConsentTerms = vi.fn(async () => {
                return Promise.reject(new Error(errorMessage));
            });

            // act
            await store.dispatch(postConsult.acceptConsentTerms());

            // assert
            expect(store.getActions()).toEqual(expectedActions);
        });
    });

    describe('cancelVisit', () => {
        const testVisitId = 'VISIT1234';
        const locationSpy = vi.spyOn(location, 'setLocationPathname');

        test('check success', async () => {
            const store = mockStore({ postconsult: { visitId: testVisitId } });
            visitServiceClient.cancelVisit = vi.fn(async (visitId) => {
                expect(visitId).toEqual(testVisitId);
                return new Promise((resolve) => {
                    resolve();
                });
            });
            await store.dispatch(postConsult.cancelVisit());
            expect(locationSpy).toHaveBeenCalledWith('/patientauth/end');
        });

        test('check fail', async () => {
            const errorMessage = 'rrrk';
            const store = mockStore({ postconsult: { visitId: testVisitId } });
            visitServiceClient.acceptConsentTerms = vi.fn(async () => {
                return Promise.reject(new Error(errorMessage));
            });
            await store.dispatch(postConsult.cancelVisit());
            expect(locationSpy).toHaveBeenCalledWith('/patientauth/end');
        });
    });

    describe('set post visit action', () => {
        it('dispatches the action', () => {
            const store = mockStore({});
            store.dispatch(
                postConsult.setPostVisitAction({
                    selectedAction: PostVisitActions.Complete,
                }),
            );
            expect(store.getActions()).toMatchInlineSnapshot(`
                [
                  {
                    "payload": {
                      "selectedAction": "complete-visit",
                    },
                    "type": "videoMenu/SET_POST_VISIT_ACTION",
                  },
                ]
            `);
        });

        it('updates state', () => {
            const result = postConsult.reducer(
                postConsult.initialState,
                postConsult.setPostVisitAction({
                    selectedAction: PostVisitActions.Complete,
                }),
            );
            expect(result.postVisitAction).toMatchInlineSnapshot(`
                {
                  "selectedAction": "complete-visit",
                }
            `);
        });
    });

    describe('set post visit action error message', () => {
        it('dispatches the action', () => {
            const store = mockStore({});
            store.dispatch(
                postConsult.setPostVisitActionErrorMessage('error oh no'),
            );
            expect(store.getActions()).toMatchInlineSnapshot(`
                [
                  {
                    "payload": "error oh no",
                    "type": "videoMenu/SET_POST_VISIT_ACTION_ERROR_MESSAGE",
                  },
                ]
            `);
        });

        it('updates state', () => {
            const result = postConsult.reducer(
                postConsult.initialState,
                postConsult.setPostVisitActionErrorMessage('error oh no'),
            );
            expect(result.postVisitActionErrorMessage).toEqual('error oh no');
        });
    });

    describe('fetchTestVisitDetailsByVisitId', () => {
        it('should create an action to fetch visit details by visit id', () => {
            const visitId = 'example-visit-id-requested';
            const patientGuid = 'patientGuid';
            const providerId = 'providerId';
            const tokBoxVideoSessionId = 'tokBoxVideoSessionId';
            const tokBoxWaitingRoomSessionId = 'tokBoxWaitingRoomSessionId';

            const expectedActions = [
                postConsult.setVisitId(visitId),
                postConsult.setPatientGuid(patientGuid),
                postConsult.setProviderId(providerId),
            ];

            const store = mockStore({
                postconsult: {
                    tokBoxVideoSessionId,
                    tokBoxWaitingRoomSessionId,
                },
            });

            const result: unknown = store.dispatch(
                postConsult.fetchTestVisitDetailsByVisitId(visitId, providerId),
            );

            const actions = store.getActions();
            expect(actions).toEqual(expectedActions);

            const expectedVisitDetails: {
                visitDetails: VisitDetails;
                redirect?: string;
            } = {
                visitDetails: {
                    visitId,
                    visitStatus: 'requested',
                    patientGuid: 'patientGuid',
                    providerId: providerId ?? 'providerId',
                    practiceId: 'practiceId',
                    acceptTerms: true,
                    integrations: {
                        tytoCare: {
                            enabled: false,
                        },
                    },
                    timestamps: initialState.timestamps,
                    isTokBox: true,
                    modality: 'video',
                    tokBoxVisit: {
                        waitingRoomSession: {
                            sessionId: tokBoxWaitingRoomSessionId,
                        },
                        videoConferenceSession: {
                            sessionId: tokBoxVideoSessionId,
                        },
                    },
                },
                redirect: '',
            };

            expect(result).toEqual(expectedVisitDetails);
        });
    });

    describe('convertModality', () => {
        const testVisitId = 'VISIT1234';
        const testReason = 'TECH_CHECK_FAIL';
        const testOriginalModality = 'virtual';
        const testTargetModality = 'phone';
        const testActorId = 'ACTOR1234';
        const testLoggerData = {
            eventSource: 'postConsult',
            eventType: 'modalityConversion',
            visitId: testVisitId,
            conversionReason: testReason,
            originalModality: testOriginalModality,
            targetModality: testTargetModality,
            actorId: testActorId,
        };
        const store = mockStore({
            user: {
                userDetails: {
                    id: testActorId,
                },
            },
        });

        test('check success', async () => {
            backendFacade.convertModality = vi.fn(
                async (
                    visitId,
                    conversionReason,
                    originalModality,
                    targetModality,
                    actorId,
                ) => {
                    return Promise.resolve({
                        message: `The visit ${visitId} is successsully converted [${conversionReason}, ${originalModality} -> ${targetModality}, ${actorId}]`,
                    } as never);
                },
            );
            vi.spyOn(Logger, 'info');
            await store.dispatch(
                postConsult.convertModality(
                    testVisitId,
                    testReason,
                    testOriginalModality,
                    testTargetModality,
                    testActorId,
                ),
            );
            expect(Logger.info).toHaveBeenCalledWith(
                testLoggerData,
                'successfully converted modality from video to phone',
            );
        });

        test('check failure', async () => {
            backendFacade.convertModality = vi.fn(async () => {
                return Promise.reject(new Error('fail test'));
            });
            vi.spyOn(Logger, 'error');
            await store.dispatch(
                postConsult.convertModality(
                    testVisitId,
                    testReason,
                    testOriginalModality,
                    testTargetModality,
                    testActorId,
                ),
            );
            expect(Logger.error).toHaveBeenCalledWith(
                { ...testLoggerData, error: new Error('fail test') },
                'failed to convert modality from video to phone',
            );
        });
    });

    describe('checkPhoneVisitStatusAndRedirect', () => {
        const testVisitId = 'VISIT1234';
        const store = mockStore();

        test('check success when status is done, staffdeclined or cancelled', async () => {
            const visitStatus = 'done';
            visitServiceClient.getVisitStatus = vi.fn(async () => {
                return Promise.resolve(visitStatus);
            });
            await store.dispatch(
                postConsult.checkPhoneVisitStatusAndRedirect(testVisitId),
            );
            expect(mockNavigate).toHaveBeenCalledWith(
                `/publicvisit/closed/${visitStatus}`,
                { replace: true },
            );
        });

        test('check success when status is not done, staffdeclined or cancelled', async () => {
            const visitStatus = 'invisit';
            visitServiceClient.getVisitStatus = vi.fn(async () => {
                return Promise.resolve(visitStatus);
            });
            vi.spyOn(Logger, 'error');
            await store.dispatch(
                postConsult.checkPhoneVisitStatusAndRedirect(testVisitId),
            );
            expect(mockNavigate).not.toHaveBeenCalledWith(
                `/publicvisit/closed/${visitStatus}`,
            );
            expect(Logger.error).not.toHaveBeenCalled();
        });

        test('check failure', async () => {
            visitServiceClient.getVisitStatus = vi.fn(async () => {
                return Promise.reject(new Error('fail test'));
            });
            vi.spyOn(Logger, 'error');
            await store.dispatch(
                postConsult.checkPhoneVisitStatusAndRedirect(testVisitId),
            );
            expect(Logger.error).toHaveBeenCalledWith(
                { visitId: testVisitId },
                'checkPhoneVisitStatusAndRedirect failed to check visit status and redirect',
            );
        });
    });
});
