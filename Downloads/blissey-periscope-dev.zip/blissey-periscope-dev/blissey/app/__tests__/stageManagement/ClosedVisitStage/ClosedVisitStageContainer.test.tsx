import * as React from 'react';
import { shallow } from 'enzyme';

import { ClosedVisitStageContainer } from '../../../src/stageManagement/ClosedVisitStage/ClosedVisitStageContainer';
import { vi } from 'vitest';
import toJson from 'enzyme-to-json';
import * as ReactRouter from 'react-router-dom';

vi.mock('react-router-dom', async () => {
    const original = await vi.importActual('react-router-dom');
    return {
        ...(original as object),
        useLocation: vi.fn().mockReturnValue({}),
        useNavigate: vi.fn().mockReturnValue(vi.fn()),
    };
});

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { pageViewEvent: vi.fn() },
}));

const user = {
    id: 'id',
    token: 'sometoken',
    expiration: 1527634681027,
    email: 'some@example.com',
    displayName: 'Name',
    givenName: 'givenName',
    familyName: 'familyName',
};

const paramsClosedDone = {
    closedReason: 'done',
};
const paramsClosedRejected = {
    closedReason: 'declined',
};
const paramsClosedCancelled = {
    closedReason: 'cancelled',
};
const paramsClosedExpired = {
    closedReason: 'expired',
};

const testState = {
    postconsult: {
        visitId: 'testVisitId',
        videoConferenceId: 'testVideoConferenceId',
        waitingConferenceId: 'testWaitingConferenceId',
    },
};

describe('<ClosedVisitStageContainer/>', () => {
    test('<ClosedVisitStageContainer/> visit done', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(
            paramsClosedDone,
        );
        const component = shallow(
            <ClosedVisitStageContainer
                userDetails={user}
                brand={'anyBrand'}
                {...testState.postconsult}
            />,
        );
        expect(toJson(component)).toMatchSnapshot();
    });

    test('<ClosedVisitStageContainer/> visit rejected', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(
            paramsClosedRejected,
        );
        const component = shallow(
            <ClosedVisitStageContainer
                userDetails={user}
                brand={'anyBrand'}
                {...testState.postconsult}
            />,
        );
        expect(toJson(component)).toMatchSnapshot();
    });

    test('<ClosedVisitStageContainer/> visit cancelled', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(
            paramsClosedCancelled,
        );
        const component = shallow(
            <ClosedVisitStageContainer
                userDetails={user}
                brand={'anyBrand'}
                {...testState.postconsult}
            />,
        );
        expect(toJson(component)).toMatchSnapshot();
    });

    test('<ClosedVisitStageContainer/> visit expired (unknown status)', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(
            paramsClosedExpired,
        );
        const component = shallow(
            <ClosedVisitStageContainer
                userDetails={user}
                brand={'anyBrand'}
                {...testState.postconsult}
            />,
        );
        expect(toJson(component)).toMatchSnapshot();
    });
});
