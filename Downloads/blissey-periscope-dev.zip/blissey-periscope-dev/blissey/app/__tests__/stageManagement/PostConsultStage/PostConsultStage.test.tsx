import * as React from 'react';
import { PostConsultStageContainer } from '../../../src/stageManagement/PostConsult/PostConsultStageContainer';
import { UserDetails } from '@dexcare/circus-saturn';
import { shallow } from 'enzyme';
import { vi } from 'vitest';
import toJson from 'enzyme-to-json';
import * as ReactRouter from 'react-router-dom';

vi.mock('@dexcare/festivus-aluminum-pole-analytics');

const testUserDetails: UserDetails = {
    id: 'testUserId',
    displayName: 'testDisplayName',
    givenName: 'testGivenName',
    familyName: 'testFamilyName',
    email: 'textEmail',
    token: 'testToken',
    expiration: 0,
};

const params = {
    visitId: 'testConferenceId',
};

const testState = {
    postconsult: {
        visitId: 'testvisitid',
        isTestVisit: false,
        videoConferenceId: 'testvideoconferenceid',
        conferenceSessionId: 'testconferenceSessionId',
        callStartTime: 1526447801,
        callEndTime: 1526448101,
    },
};

vi.mock('react-router-dom', async () => {
    const original = await vi.importActual('react-router-dom');
    return {
        ...(original as object),
        useLocation: vi.fn().mockReturnValue({}),
        useNavigate: vi.fn().mockReturnValue(vi.fn()),
    };
});

// TODO add tests for transforming state to props
describe('<PostConsultStageContainer/>', () => {
    test('Providence brand', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const component = shallow(
            <PostConsultStageContainer
                userDetails={testUserDetails}
                brand={'providence'}
                {...testState.postconsult}
            />,
        );
        expect(toJson(component)).toMatchSnapshot();
    });

    test('Swedish brand', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const component = shallow(
            <PostConsultStageContainer
                userDetails={testUserDetails}
                brand={'swedish'}
                {...testState.postconsult}
            />,
        );
        expect(toJson(component)).toMatchSnapshot();
    });
});
