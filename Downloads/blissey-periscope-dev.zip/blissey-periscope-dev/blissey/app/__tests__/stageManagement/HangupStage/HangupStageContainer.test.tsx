import * as React from 'react';
import { shallow } from 'enzyme';
import * as sinon from 'sinon';
import * as surveyUtils from '../../../src/common/getExitSurveyInterface';
import { withRouter } from '../../../src/common/withRouter';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        interactionEvent: vi.fn(),
        pageViewEvent: vi.fn(),
    },
}));

vi.mock('@common/i18n/i18nInstance', () => ({
    initI18nInstance: vi.fn(),
}));

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        userEvent: vi.fn(),
        pageViewEvent: vi.fn(),
    },
}));

vi.mock('@common/getExitSurveyInterface', () => ({
    getExitSurveyInterface: vi.fn(),
}));

vi.mock('react-router-dom', async () => {
    const original = await vi.importActual('react-router-dom');
    return {
        ...(original as object),
        useLocation: vi.fn().mockReturnValue({}),
        useNavigate: vi.fn().mockReturnValue(vi.fn()),
    };
});

import {
    Props,
    HangupStageContainer,
    HangupStageContainerComponent,
} from '../../../src/stageManagement/HangupStage/HangupStageContainer';
import { InactivityTimer } from '../../../src/common/InactivityTimer';
import { vi } from 'vitest';

function mockStorage() {
    const storage: Record<string, string> = {};
    return {
        setItem: vi.fn((key: string, value: string) => {
            storage[key] = value || '';
        }),
        getItem: vi.fn((key: string) => {
            return storage[key];
        }),
        removeItem: vi.fn((key: string) => {
            delete storage[key];
        }),
    };
}

const testState = {
    postconsult: {
        visitId: 'testVisitId',
    },
};

describe('<HangupStageContainer />', () => {
    const user = {
        id: 'id',
        token: 'sometoken',
        expiration: 15276,
        email: 'some@example.com',
        displayName: 'Name',
        givenName: 'givenName',
        familyName: 'familyName',
    };
    let timerStub: sinon.SinonSpy;
    let receiver;
    beforeEach(() => {
        timerStub = sinon.stub(InactivityTimer, 'attachTimeout');
        receiver = sinon.spy();
        Object.defineProperty(global, 'sessionStorage', {
            value: mockStorage(),
        });
    });

    afterEach(() => {
        sinon.restore(timerStub);
        sinon.restore(receiver);
        vi.clearAllMocks();
    });

    // const component = renderer.create(componentWithStore(
    //     <HangupStageContainer userDetails={user} history={{ push: vi.fn() }} />,
    //     mockStoreWithState));

    // it('renders as a <div>', () => {
    //     expect(component.toJSON()).toMatchSnapshot();
    // });

    it('timer not attached for providers', () => {
        Object.assign(user, {
            roles: ['telehealth_provider'],
        });
        const WrappedComponent = withRouter(
            HangupStageContainer,
        ) as React.ComponentClass<Props, unknown>;
        shallow(
            <WrappedComponent
                userDetails={user}
                visitId={testState.postconsult.visitId}
            />,
        ).dive();
        sinon.assert.notCalled(timerStub);
    });

    it('timer attached for non-providers', () => {
        Object.assign(user, {
            roles: ['telehealth_presenter'],
        });
        shallow(
            <HangupStageContainerComponent
                {...({} as Props)}
                visitId={testState.postconsult.visitId}
                userDetails={user}
            />,
        );
        sinon.assert.calledOnce(timerStub);
    });

    it('calls signOutPatient method', () => {
        const component = shallow(
            <HangupStageContainerComponent
                {...({} as Props)}
                visitId={testState.postconsult.visitId}
                userDetails={user}
            />,
        );
        const instance = component.instance() as InstanceType<
            typeof HangupStageContainerComponent
        >;
        const signOutPatientSpy = sinon.spy(instance, 'signOutPatient');
        instance.signOutPatient();
        sinon.assert.calledOnce(signOutPatientSpy);
    });

    it('calls surveyInterface', () => {
        const component = shallow(
            <HangupStageContainerComponent
                {...({} as Props)}
                visitId={testState.postconsult.visitId}
                userDetails={user}
            />,
        );
        const instance = component.instance() as InstanceType<
            typeof HangupStageContainerComponent
        >;
        const surveyInterfaceSpy = sinon.spy(
            surveyUtils,
            'getExitSurveyInterface',
        );
        instance.signOutPatient();
        sinon.assert.calledOnce(surveyInterfaceSpy);
    });
});
