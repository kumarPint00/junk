import * as React from 'react';
import { NotFoundContainer } from '../../../src/stageManagement/NotFound/NotFoundContainer';
import { render } from '@testing-library/react';
import { vi } from 'vitest';

vi.mock('react-router-dom', () => ({
    useParams: vi.fn().mockReturnValue({}),
    useLocation: vi.fn().mockReturnValue({}),
    useNavigate: vi.fn().mockReturnValue(vi.fn()),
}));

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        errorEvent: vi.fn(),
        pageViewEvent: vi.fn(),
    },
    Analytics: {
        sendPageView: vi.fn(),
    },
}));

const user = {
    id: 'id',
    token: 'sometoken',
    expiration: Date.now(),
    email: 'some@example.com',
    displayName: 'Name',
    givenName: 'givenName',
    familyName: 'familyName',
};

describe('<NotFoundContainer/>', () => {
    test('verify default snapshot', () => {
        const { container } = render(<NotFoundContainer userDetails={user} />);
        expect(container).toMatchSnapshot();
    });
});
