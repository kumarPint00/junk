import * as React from 'react';
import * as redux from 'react-redux';
import { shallow, mount, ShallowWrapper } from 'enzyme';
import configureMockStore from 'redux-mock-store';
import { waitFor } from '@testing-library/react';
import { I18nextProvider } from 'react-i18next';
import { initI18nInstance } from '@common/i18n/i18nInstance';

import thunk from 'redux-thunk';

import { PaymentModule } from '@modules/Payment/PaymentModule';
import {
    Props,
    PaymentStageContainer,
    PaymentStageContainerComponent,
} from '../../../src/stageManagement/Payment/PaymentStageContainer';
import { PaymentStatus } from '@redux/utils/PaymentStatus';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';
import { BrandConfig } from '../../../../server/config/configInterfaces';
import toJson from 'enzyme-to-json';
import {
    OwnProps,
    State,
} from '@stageManagement/Payment/PaymentStageContainerInterfaces';
import { AnyAction, Store } from 'redux';
import * as FeatureFlags from '@utils/FeatureFlags';
import {
    postConsultRoute,
    postVisitProviderSurveyRoute,
} from '@utils/getRoutes';
import * as ReactRouter from 'react-router-dom';
import { withRouter, RouterProps } from '../../../src/common/withRouter';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        pageViewEvent: vi.fn(),
        interactionEvent: vi.fn(),
    },
}));
vi.mock('@redux/modules/postConsult', () => ({
    waiveVisit: vi.fn(),
    chargeVisit: vi.fn(),
}));
const middlewares = [thunk];
const testState = {
    postconsult: {
        isTestVisit: false,
        chargedStatus: PaymentStatus.none,
    },
};

vi.mock('react-router-dom', async () => {
    const original = await vi.importActual('react-router-dom');
    return {
        ...(original as object),
        useLocation: vi.fn().mockReturnValue({}),
        useNavigate: vi.fn().mockReturnValue(vi.fn()),
    };
});

vi.mock('@utils/FeatureFlags', async () => {
    const original = await vi.importActual('@utils/FeatureFlags');
    return {
        ...(original as object),
        getFeatureFlag: vi.fn(),
    };
});

const mockStore = configureMockStore(middlewares);
const mockStoreWithState = mockStore(testState);

const params = {
    visitId: '123232',
};

const componentProps = {
    brand: 'swedish',
    userDetails: {
        id: 'id',
        displayName: 'robert',
        givenName: 'string',
        familyName: 'string',
        email: 'string',
        token: 'string',
        expiration: 22,
    },
    patientGuid: 'mockPatientGuid',
};
// todo
const fakeI18nInstance = {
    brandName: 'brandName',
    auth0Domain: 'auth0Domain',
    auth0ClientId: 'auth0ClientId',
    authConfigKey: 'authConfigKey',
    logoutReturnTo: 'logoutReturnTo',
    domain: 'domain',
    greyLogo: 'greyLogo',
    logo: 'logo',
    iosStoreLink: 'iosStoreLink',
    androidStoreLink: 'androidStoreLink',
    footer: {
        copyright: 'copyright',
        urlTerms: 'urlTerms',
        linkTerms: 'linkTerms',
        urlDisclaimer: 'urlDisclaimer',
        linkDisclaimer: 'linkDisclaimer',
        urlPrivacy: 'urlPrivacy',
        linkPrivacy: 'linkPrivacy',
        urlNonDiscrimination: 'urlNonDiscrimination',
        linkNonDiscrimination: 'linkNonDiscrimination',
        emergencyNumber: 'emergencyNumber',
        needHelp: 'needHelp',
        helpPhone: 'helpPhone',
    },
};

const wrappedProps = {
    ...componentProps,
    ...testState.postconsult,
    router: {
        navigate: vi.fn(),
        location: {},
        params,
    } as unknown as RouterProps<{ visitId: string }>['router'],

    chargeVisit: vi.fn().mockResolvedValue('success'),
    waiveVisit: vi.fn().mockResolvedValue('success'),
    isProvider: vi.fn().mockReturnValue(true),
};

type PaymentStageContainerWrapper = ShallowWrapper<
    OwnProps & Props,
    Readonly<State>,
    PaymentStageContainerComponent
>;

describe('<PaymentStageContainer/>', () => {
    let wrapper: PaymentStageContainerWrapper;
    let store: Store<unknown, AnyAction>;
    beforeEach(() => {
        const mockStore = configureMockStore();
        store = mockStore(testState);
        wrappedProps.chargeVisit = vi.fn();
        wrappedProps.waiveVisit = vi.fn();
        wrappedProps.isTestVisit = false;
        wrappedProps.chargedStatus = PaymentStatus.none;
    });

    test('The Redux store attributes should be correctly mapped to props.', () => {
        wrapper = shallow(
            <PaymentStageContainer {...({ store } as unknown as Props)} />,
        )
            .dive()
            .dive() as PaymentStageContainerWrapper;

        const props = wrapper.props();
        expect(props.isTestVisit).toEqual(testState.postconsult.isTestVisit);
        expect(props.chargedStatus).toEqual(
            testState.postconsult.chargedStatus,
        );
    });

    test('All actions should be correctly mapped to props.', () => {
        wrapper = shallow(
            <PaymentStageContainer {...({ store } as unknown as Props)} />,
        )
            .dive()
            .dive() as PaymentStageContainerWrapper;

        const props = wrapper.props();

        expect(props.waiveVisit).toBeDefined();
        expect(props.chargeVisit).toBeDefined();
    });

    test.skip('verify default snapshot with store', async () => {
        const i18nInstance = await initI18nInstance(
            fakeI18nInstance as unknown as BrandConfig,
        );
        const wrapper = mount(
            <redux.Provider store={mockStoreWithState}>
                <I18nextProvider i18n={i18nInstance}>
                    <PaymentStageContainer {...componentProps} />
                </I18nextProvider>
            </redux.Provider>,
        );
        expect(toJson(wrapper)).toMatchSnapshot();
        expect(V2Analytics.pageViewEvent).toHaveBeenCalled();
    });

    test('verify shallow', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow(<WrappedComponent {...wrappedProps} />).dive();
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    test('verify shallow, visit payment already decided', () => {
        wrappedProps.chargedStatus = PaymentStatus.waived;
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow(<WrappedComponent {...wrappedProps} />).dive();
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    test('handleWaive success', async () => {
        const mockNavigate = vi.fn();
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        vi.spyOn(ReactRouter, 'useNavigate').mockReturnValueOnce(mockNavigate);
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow(<WrappedComponent {...wrappedProps} />)
            .dive()
            .dive();
        const payment = instance.find(PaymentModule);
        payment.props().handleWaive('im nice');
        expect(wrappedProps.waiveVisit).toHaveBeenCalledWith(
            params.visitId,
            'im nice',
        );
        await waitFor(() => expect(mockNavigate).toHaveBeenCalled());
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'waive_visit',
            reason: 'im nice',
            patient_id: 'mockPatientGuid',
            visit_id: '123232',
        });
    });

    test('handleWaive test visit', async () => {
        const mockNavigate = vi.fn();
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        vi.spyOn(ReactRouter, 'useNavigate').mockReturnValueOnce(mockNavigate);
        wrappedProps.isTestVisit = true;
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow(<WrappedComponent {...wrappedProps} />)
            .dive()
            .dive();
        const payment = instance.find(PaymentModule);
        payment.props().handleWaive('im nice');
        expect(wrappedProps.waiveVisit).not.toHaveBeenCalled();
        await waitFor(() => expect(mockNavigate).toHaveBeenCalled());
    });

    test('handleWaive error', () => {
        wrappedProps.waiveVisit = vi.fn(() => {
            throw new Error('Oops!');
        });
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow<React.ComponentClass<Props, unknown>>(
            <WrappedComponent {...wrappedProps} />,
        ).dive();
        const payment = instance.find(PaymentModule);
        payment.props().handleWaive('im nice');
        expect(
            (instance.instance().state as Readonly<{ snackError: unknown }>)
                .snackError,
        ).toEqual({
            active: false,
            allowContinue: false,
            message: '',
        });
    });

    test('handleWaive empty reason', () => {
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow<PaymentStageContainerComponent>(
            <WrappedComponent {...wrappedProps} />,
        ).dive();
        const payment = instance.find(PaymentModule);
        payment.props().handleWaive('');
        expect(
            (instance.instance().state as Readonly<{ snackError: unknown }>)
                .snackError,
        ).toEqual({
            active: true,
            message: 'Please select a reason for waive.',
        });
    });

    test('handleCharge test visit', async () => {
        const mockNavigate = vi.fn();
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        vi.spyOn(ReactRouter, 'useNavigate').mockReturnValueOnce(mockNavigate);
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        wrappedProps.isTestVisit = true;
        const instance = shallow(<WrappedComponent {...wrappedProps} />).dive();
        const payment = instance.find(PaymentModule);
        payment.props().handleCharge();
        expect(wrappedProps.chargeVisit).not.toHaveBeenCalled();
        await waitFor(() => expect(mockNavigate).toHaveBeenCalled());
    });

    test('handleCharge success', async () => {
        const mockNavigate = vi.fn();
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        vi.spyOn(ReactRouter, 'useNavigate').mockReturnValueOnce(mockNavigate);
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow(<WrappedComponent {...wrappedProps} />).dive();
        const payment = instance.find(PaymentModule);
        payment.props().handleCharge();
        expect(wrappedProps.chargeVisit).toHaveBeenCalledWith(params.visitId);
        await waitFor(() => expect(mockNavigate).toHaveBeenCalled());
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'charge_visit',
            patient_id: 'mockPatientGuid',
            visit_id: '123232',
        });
    });

    test('handleCharge error', () => {
        const mockNavigate = vi.fn();
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        vi.spyOn(ReactRouter, 'useNavigate').mockReturnValueOnce(mockNavigate);
        wrappedProps.chargeVisit = vi.fn(() => {
            throw new Error('Oops!');
        });
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow<PaymentStageContainerComponent>(
            <WrappedComponent {...wrappedProps} />,
        ).dive();
        const payment = instance.find(PaymentModule);
        payment.props().handleCharge();
        expect(
            (instance.instance().state as Readonly<{ snackError: unknown }>)
                .snackError,
        ).toEqual({
            active: false,
            allowContinue: false,
            message: '',
        });
    });

    test('clearSnack updates snackError state', () => {
        const wrapper = mount(
            <PaymentStageContainerComponent {...wrappedProps} />,
        );
        const instance = wrapper.instance() as PaymentStageContainerComponent;
        instance.clearSnack();

        expect(instance.state.snackError).toEqual(
            expect.objectContaining({
                active: false,
            }),
        );
    });

    test('goToNextPage when enablePostVisitSurveyConfig is true and user is a provider', () => {
        wrappedProps.isTestVisit = false;
        wrappedProps.chargedStatus = PaymentStatus.none;

        const mockNavigate = vi.fn();
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        vi.spyOn(ReactRouter, 'useNavigate').mockReturnValueOnce(mockNavigate);
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow(<WrappedComponent {...wrappedProps} />)
            .dive()
            .instance();

        if (instance instanceof PaymentStageContainerComponent) {
            expect(typeof instance.isProvider).toBe('function');

            vi.spyOn(FeatureFlags, 'getFeatureFlag').mockReturnValue(true);
            vi.spyOn(instance, 'isProvider').mockReturnValue(true);

            instance.goToNextPage();

            expect(mockNavigate).toHaveBeenCalledWith(
                postVisitProviderSurveyRoute(
                    params.visitId,
                    wrappedProps.brand,
                ),
            );
        } else {
            fail('Instance of PaymentStageContainer expected.');
        }
    });

    test('goToNextPage when enablePostVisitSurveyConfig is false', () => {
        wrappedProps.isTestVisit = false;
        wrappedProps.chargedStatus = PaymentStatus.none;

        const mockNavigate = vi.fn();
        vi.spyOn(ReactRouter, 'useParams').mockReturnValue(params);
        vi.spyOn(ReactRouter, 'useNavigate').mockReturnValue(mockNavigate);
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow(<WrappedComponent {...wrappedProps} />)
            .dive()
            .instance();

        if (instance instanceof PaymentStageContainerComponent) {
            expect(typeof instance.isProvider).toBe('function');

            vi.spyOn(FeatureFlags, 'getFeatureFlag').mockReturnValue(false);
            vi.spyOn(instance, 'isProvider').mockReturnValue(true);

            instance.goToNextPage();

            expect(mockNavigate).toHaveBeenCalledWith(
                postConsultRoute(params.visitId, wrappedProps.brand),
            );
        } else {
            fail('Instance of PaymentStageContainer expected.');
        }
    });

    test('goToNextPage when user is not a provider', () => {
        wrappedProps.isTestVisit = false;
        wrappedProps.chargedStatus = PaymentStatus.none;

        const mockNavigate = vi.fn();
        vi.spyOn(ReactRouter, 'useParams').mockReturnValue(params);
        vi.spyOn(ReactRouter, 'useNavigate').mockReturnValue(mockNavigate);
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow(<WrappedComponent {...wrappedProps} />)
            .dive()
            .instance();
        if (instance instanceof PaymentStageContainerComponent) {
            expect(typeof instance.isProvider).toBe('function');

            vi.spyOn(FeatureFlags, 'getFeatureFlag').mockReturnValue(false);
            vi.spyOn(instance, 'isProvider').mockReturnValue(false);

            instance.goToNextPage();

            expect(mockNavigate).toHaveBeenCalledWith(
                postConsultRoute(params.visitId, wrappedProps.brand),
            );
        } else {
            fail('Instance of PaymentStageContainer expected.');
        }
    });

    test('goToNextPage when chargedStatus is not none', () => {
        wrappedProps.isTestVisit = false;
        wrappedProps.chargedStatus = PaymentStatus.waived;

        const mockNavigate = vi.fn();
        vi.spyOn(ReactRouter, 'useParams').mockReturnValue(params);
        vi.spyOn(ReactRouter, 'useNavigate').mockReturnValue(mockNavigate);
        const WrappedComponent = withRouter(
            PaymentStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const instance = shallow(<WrappedComponent {...wrappedProps} />)
            .dive()
            .instance();

        if (instance instanceof PaymentStageContainerComponent) {
            expect(typeof instance.isProvider).toBe('function');

            vi.spyOn(FeatureFlags, 'getFeatureFlag').mockReturnValue(false);
            vi.spyOn(instance, 'isProvider').mockReturnValue(false);

            instance.goToNextPage();

            expect(mockNavigate).toHaveBeenCalledWith(
                postConsultRoute(params.visitId, wrappedProps.brand),
            );
        } else {
            fail('Instance of PaymentStageContainer expected.');
        }
    });
});
