import * as React from 'react';
import { shallow } from 'enzyme';

vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(() => ({
            brandConfig: {
                testBrand: {
                    domain: 'testDomain',
                },
            },
        })),
    },
    LogManager: {
        getLogger: () => ({
            child: () => ({
                info: vi.fn(),
            }),
        }),
    },
    jupiterOptions: {
        applicationName: 'blissey',
        logSource: 'development',
        metricsEndpoint: '/appMetrics',
        logLevel: 'debug',
    },
}));

import { PatientDogfoodStageContainer } from '../../../src/stageManagement/PatientDogfood/PatientDogfoodStageContainer';
import { visitServiceClient } from '@clients/VisitService/VisitServiceClient';
import { vi } from 'vitest';
import toJson from 'enzyme-to-json';

describe('<PatientDogfoodStageContainer.test/>', () => {
    beforeEach(() => {
        vi.spyOn(
            visitServiceClient,
            'generateTytoCareQRCode',
        ).mockResolvedValue({ tytoCare: { pairingDetails: {} } });
    });

    test('renders without the section dependent on the visitId.', () => {
        const component = shallow(
            <PatientDogfoodStageContainer brand="testBrand" />,
        );
        expect(component.find({ label: 'Wifi Name' }).exists()).toBeFalsy();
        expect(toJson(component)).toMatchSnapshot();
    });

    test('renders with the section dependent on the visitId.', () => {
        const component = shallow(
            <PatientDogfoodStageContainer brand="testBrand" />,
        );
        component
            .find({ label: 'Visit ID for TytoCare pairing' })
            .simulate('change', { target: { value: 'test-visit-id' } });

        expect(component.find({ label: 'Wifi Name' }).exists()).toBeTruthy();
        expect(toJson(component)).toMatchSnapshot();
    });

    test('calls generateTytoCareQRCode when generateTytoCareQRCode is called', () => {
        const component = shallow(
            <PatientDogfoodStageContainer brand="testBrand" />,
        );
        component
            .find({ label: 'Visit ID for TytoCare pairing' })
            .simulate('change', { target: { value: 'test-visit-id' } });
        component
            .find({ label: 'Wifi Name' })
            .simulate('change', { target: { value: 'test-wifi-name' } });
        component
            .find({ label: 'Wifi Password' })
            .simulate('change', { target: { value: 'test-wifi-password' } });
        component
            .find({ 'data-uitest': 'control-generateTytoCareQRCode' })
            .simulate('click');
        expect(visitServiceClient.generateTytoCareQRCode).toHaveBeenCalled();
        expect(toJson(component)).toMatchSnapshot();
    });
});
