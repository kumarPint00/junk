import * as React from 'react';
// import * as redux from 'react-redux';
import { ShallowWrapper, shallow } from 'enzyme';

// import thunk from 'redux-thunk';

import {
    OTPFlowContainerComponent,
    OTPFlowContainer as WrappedOTPFlowContainer,
    Props,
} from '../../../src/stageManagement/OTPFlow/OTPFlowContainer';
import { vi } from 'vitest';
import toJson from 'enzyme-to-json';
import {
    OwnProps,
    State,
} from '@stageManagement/OTPFlow/OTPFlowContainerInterfaces';
import { AnyAction, Store } from 'redux';
import configureMockStore from 'redux-mock-store';
import * as ReactRouter from 'react-router-dom';
// const { V2Analytics } = require('@dexcare/festivus-aluminum-pole-analytics');

vi.mock('react-router-dom', async () => {
    const original = await vi.importActual('react-router-dom');
    return {
        ...(original as object),
        useLocation: vi.fn().mockReturnValue({}),
        useNavigate: vi.fn().mockReturnValue(vi.fn()),
    };
});

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        pageViewEvent: vi.fn(),
        interactionEvent: vi.fn(),
    },
}));

vi.mock('@redux/modules/otp', () => ({
    getOTPCode: vi.fn(),
    submitOTPCode: vi.fn(),
    resendOTPCode: vi.fn(),
    setErrorMessage: vi.fn(),
}));

// const middlewares = [thunk];
const testState = {
    otp: {
        windowToDisplay: 'get',
        isLoading: false,
        errorMessage: undefined,
    },
};

// const mockStore = configureMockStore(middlewares);
// const mockStoreWithState = mockStore(testState);

const params = {
    visitId: '123232',
};

const componentProps = {
    brand: 'swedish',
    userDetails: {
        id: 'id',
        email: 'string',
        sms: 'string',
        requiresOTPAuth: true,
    },
    patientGuid: 'mockPatientGuid',
};

// const fakeI18nInstance = {
//     brandName: 'brandName',
//     auth0Domain: 'auth0Domain',
//     auth0ClientId: 'auth0ClientId',
//     authConfigKey: 'authConfigKey',
//     logoutReturnTo: 'logoutReturnTo',
//     domain: 'domain',
//     greyLogo: 'greyLogo',
//     logo: 'logo',
//     iosStoreLink: 'iosStoreLink',
//     androidStoreLink: 'androidStoreLink',
//     footer: {
//         copyright: 'copyright',
//         urlTerms: 'urlTerms',
//         linkTerms: 'linkTerms',
//         urlDisclaimer: 'urlDisclaimer',
//         linkDisclaimer: 'linkDisclaimer',
//         urlPrivacy: 'urlPrivacy',
//         linkPrivacy: 'linkPrivacy',
//         urlNonDiscrimination: 'urlNonDiscrimination',
//         linkNonDiscrimination: 'linkNonDiscrimination',
//         emergencyNumber: 'emergencyNumber',
//         needHelp: 'needHelp',
//         helpPhone: 'helpPhone',
//     },
// };

const wrappedProps = {
    ...componentProps,
    ...testState.otp,
    getOTPCode: vi.fn().mockResolvedValue('success'),
    submitOTPCode: vi.fn().mockResolvedValue('success'),
    resendOTPCode: vi.fn().mockResolvedValue('success'),
    setErrorMessage: vi.fn().mockResolvedValue('success'),
};

type OTPFlowContainerWrapper = ShallowWrapper<
    OwnProps & Props,
    Readonly<State>,
    React.Component<OwnProps, State>
>;

describe('<PaymentStageContainer/>', () => {
    let wrapper: OTPFlowContainerWrapper;
    let store: Store<unknown, AnyAction>;
    beforeEach(() => {
        const mockStore = configureMockStore();
        store = mockStore(testState);
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
    });

    test('The Redux store attributes should be correctly mapped to props.', () => {
        wrapper = shallow(
            <WrappedOTPFlowContainer {...({ store } as unknown as Props)} />,
        ).dive() as OTPFlowContainerWrapper;

        const props = wrapper.props();
        expect(props.windowToDisplay).toEqual(testState.otp.windowToDisplay);
        expect(props.errorMessage).toEqual(testState.otp.errorMessage);
        expect(props.isLoading).toEqual(testState.otp.isLoading);
    });

    test('All actions should be correctly mapped to props.', () => {
        wrapper = shallow(
            <WrappedOTPFlowContainer {...({ store } as unknown as Props)} />,
        ).dive() as OTPFlowContainerWrapper;

        const props = wrapper.props();

        expect(props.getOTPCode).toBeDefined();
        expect(props.submitOTPCode).toBeDefined();
        expect(props.resendOTPCode).toBeDefined();
        expect(props.setErrorMessage).toBeDefined();
    });
    test('verify shallow', () => {
        const wrapper = shallow(
            <OTPFlowContainerComponent {...wrappedProps} />,
        ).dive();
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    test('verify shallow, show verify window', () => {
        wrappedProps.windowToDisplay = 'verify';
        const wrapper = shallow(
            <OTPFlowContainerComponent {...wrappedProps} />,
        ).dive();
        expect(toJson(wrapper)).toMatchSnapshot();
    });
});
