import * as React from 'react';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import { render, waitFor } from '@testing-library/react';
import { ShallowWrapper, mount, shallow } from 'enzyme';
import { initI18nInstance } from '@common/i18n/i18nInstance';
import { I18nextProvider } from 'react-i18next';
import CircularProgress from '@mui/material/CircularProgress';

import { BlisseyLogger } from '@utils/Logger';
import { TestStatus } from '@common/video';
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';

import {
    Props,
    InVisitStageContainerComponent,
    InVisitStageContainer as ConnectedInVisitStageContainer,
} from '@stageManagement/InVisitStage/InVisitStageContainer';
import { VisitDetails } from '@clients/VisitService/VisitInterfaces';
import { TokenForm } from '@stageManagement/InVisitStage/TokenForm';
import { VideoCallModuleProps } from '@modules/VideoCall/VideoCallInterfaces';
import { SECURITY_ROLE_PROVIDER } from '@dexcare/circus-saturn';
import { vi, Mock } from 'vitest';
import { BrandConfig } from '../../../../server/config/configInterfaces';
import { AnyAction, Store } from 'redux';
import { OwnProps } from '@stageManagement/InVisitStage/InVisitStageContainerInterfaces';
import * as ReactRouter from 'react-router-dom';
import { withRouter } from '../../../src/common/withRouter';

vi.mock('react-router-dom', async () => {
    const original = await vi.importActual('react-router-dom');
    return {
        ...(original as object),
        useLocation: vi.fn().mockReturnValue({}),
        useNavigate: vi.fn().mockReturnValue(vi.fn()),
    };
});

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: {
        sendEvent: vi.fn(),
        sendPageView: vi.fn(),
    },
    V2Analytics: { pageViewEvent: vi.fn() },
}));

vi.mock('@utils/Notification', () => ({
    isDocumentVisible: vi.fn().mockReturnValue(false),
    notifyUser: vi.fn(),
    initNotifications: vi.fn(),
    NotificationType: {},
}));

vi.mock('@utils/FeatureFlags', () => ({
    getFeatureFlag: vi.fn().mockReturnValue(true),
    FeatureFlags: {
        requireConsentTerms: 'flag-name',
    },
}));

vi.mock('@redux/modules/postConsult', () => ({
    fetchVisitDetailsByVisitId: vi.fn(),
    fetchTestVisitDetailsByVisitId: vi.fn(),
    fetchTokBoxTokens: vi.fn(),
    setCallStartTime: vi.fn(),
    setCallEndTime: vi.fn(),
    setTokBoxVideoToken: vi.fn(),
    setTokBoxWaitingRoomToken: vi.fn(),
    acceptConsentTerms: vi.fn(),
    setConsentErrorMessage: vi.fn(),
    cancelVisit: vi.fn(),
    setMessageDialog: vi.fn(),
}));

vi.mock('@redux/modules/userSettings', () => ({
    setVideoDeviceId: vi.fn(),
    setAudioDeviceId: vi.fn(),
}));

interface State {
    isLoadingVisitDetails?: boolean;
}

const middlewares = [thunk];
const mocki18ndata = {
    brandName: 'test',
    auth0Domain: 'test',
    auth0ClientId: 'test',
    authConfigKey: 'test',
    logoutReturnTo: 'test',
    domain: 'test',
    greyLogo: 'test',
    logo: 'test',
    iosStoreLink: 'test',
    androidStoreLink: 'test',
    footer: {
        copyright: 'test',
        urlTerms: 'test',
        linkTerms: 'test',
        urlDisclaimer: 'test',
        linkDisclaimer: 'test',
        urlPrivacy: 'test',
        linkPrivacy: 'test',
        urlNonDiscrimination: 'test',
        linkNonDiscrimination: 'test',
        emergencyNumber: 'test',
        needHelp: 'test',
        helpPhone: 'test',
    },
};

const testState = {
    postconsult: {
        visitId: 'testVisitId',
        isTestVisit: false,
        isTokBox: false,
        waitingConferenceId: 'waitingconferenceid',
        videoConferenceId: 'videoconferenceid',
        consult: {},
    },
    health: {
        healthCheckProgress: 0,
        networkStatus: TestStatus.NotRun,
        signalingStatus: TestStatus.NotRun,
        camStatus: TestStatus.NotRun,
        micStatus: TestStatus.NotRun,
        iceCandidateStatus: TestStatus.NotRun,
        localConnectStatus: TestStatus.NotRun,
        remoteConnectStatus: TestStatus.NotRun,
    },
    usersettings: {
        audioDeviceId: 'audioDeviceId',
        videoDeviceId: 'videoDeviceId',
        setAudioDeviceId: () => undefined,
        setVideoDeviceId: () => undefined,
    },
    video: {
        localCamExists: true,
        localMicExists: true,
        isFullScreen: false,
        endCallConfirmation: false,
        isChatVisible: false,
    },
    instantMessage: {
        waitingInstantMessages: [],
        videoInstantMessages: [],
        waitingRoomHasUnread: false,
        videoHasUnread: false,
    },
    user: {
        userDetails: {
            id: '',
            displayName: '',
            givenName: '',
            familyName: '',
            email: '',
            token: '',
            expiration: -1,
        },
    },
    otConnection: {
        otConnectionStatus: 'sessionConnected',
    },
    runTests: () => undefined,
};
const mockStore = configureMockStore(middlewares);
const mockStoreWithState = mockStore(testState);

const userDetails = {
    id: 'id',
    token: 'sometoken',
    expiration: 1533151649915,
    email: 'some@example.com',
    displayName: 'Name',
    givenName: 'givenName',
    familyName: 'familyName',
    roles: ['telehealth_patient'],
};
const mockTokBoxVisitDetails: VisitDetails = {
    patientGuid: 'patientGuid',
    waitingConferenceId: 'waitingRoomId',
    videoConferenceId: 'videoId',
    visitId: 'visitId',
    visitStatus: 'requested',
    isTokBox: true,
    tokBoxVisit: {
        waitingRoomSession: {
            sessionId: 'tokboxSessionId',
        },
        videoConferenceSession: {
            sessionId: 'tokboxConferenceId',
        },
    },
    integrations: {
        tytoCare: {
            enabled: false,
        },
    },
} as VisitDetails;

const params = {
    visitId: '123232',
};

const defaultProps: Props = {
    brand: 'swedish',
    userDetails,
    invalidVisitId: false,
    isTokBox: false,
    tokBoxVideoToken: 'tokboxvideotoken',
    tokBoxVideoSessionId: 'tokboxsessionid',
    tokBoxTokenError: false,
    tokBoxTokenErrorMessage: null,
    fetchTokBoxTokens: vi.fn(),
    health: {
        healthCheckProgress: 0,
        networkStatus: TestStatus.NotRun,
        signalingStatus: TestStatus.NotRun,
        camStatus: TestStatus.NotRun,
        micStatus: TestStatus.NotRun,
        iceCandidateStatus: TestStatus.NotRun,
        localConnectStatus: TestStatus.NotRun,
        remoteConnectStatus: TestStatus.NotRun,
    },
    healthInfo: {
        healthCheckStatus: HealthCheckStatus.Healthy,
    },
    fetchVisitDetailsByVisitId: vi.fn(),
    setCallStartTime: vi.fn(),
    setCallEndTime: vi.fn(),
    videoDeviceId: 'videoDeviceId',
    audioDeviceId: 'audioDeviceId',
    setVideoDeviceId: vi.fn(),
    setAudioDeviceId: vi.fn(),
    setTokBoxVideoToken: vi.fn(),
    setTokBoxWaitingRoomToken: vi.fn(),
    isTestVisit: false,
    callStartTime: 123,
    fetchTestVisitDetailsByVisitId: vi.fn(),
    consentTermsAccepted: true,
    isLoadingConsentTerms: false,
    consentTermsErrorMessage: null,
    acceptConsentTerms: vi.fn(),
    setConsentErrorMessage: vi.fn(),
    cancelVisit: vi.fn(),
} as unknown as Props;

const getInitialState = (defaultProps: Props) => ({
    postconsult: {
        isTestVisit: defaultProps.isTestVisit,
        callStartTime: defaultProps.callStartTime,
        invalidVisitId: defaultProps.invalidVisitId,
        isTokBox: defaultProps.isTokBox,
        tokBoxVideoSessionId: defaultProps.tokBoxVideoSessionId,
        tokBoxVideoToken: defaultProps.tokBoxVideoToken,
        tokBoxTokenError: defaultProps.tokBoxTokenError,
        tokBoxTokenErrorMessage: defaultProps.tokBoxTokenErrorMessage,
        consentTermsAccepted: defaultProps.consentTermsAccepted,
        isLoadingConsentTerms: defaultProps.isLoadingConsentTerms,
        consentTermsErrorMessage: defaultProps.consentTermsErrorMessage,
        messageDialogText: defaultProps.messageDialogText,
    },
    usersettings: {
        audioDeviceId: defaultProps.audioDeviceId,
        videoDeviceId: defaultProps.videoDeviceId,
    },
    health: defaultProps.health,
});

type InVisitStageContainerWrapper = ShallowWrapper<
    OwnProps & Props,
    Readonly<State>,
    React.Component<OwnProps, State>
>;
describe('<InVisitStageContainer/>', () => {
    let componentProps: Props;
    let wrapper: InVisitStageContainerWrapper;
    let store: Store<unknown, AnyAction>;
    let initialState;
    beforeEach(() => {
        componentProps = { ...defaultProps };
        initialState = getInitialState(componentProps);
        const mockStore = configureMockStore();
        store = mockStore(initialState);
    });

    test('The Redux store attributes should be correctly mapped to props.', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce({
            visitId: defaultProps.invalidVisitId as unknown as string,
        });

        wrapper = shallow(
            <ConnectedInVisitStageContainer
                {...({ store } as unknown as Props)}
            />,
        )
            .dive()
            .dive() as InVisitStageContainerWrapper;

        const props = wrapper.props();
        expect(props.health).toEqual(defaultProps.health);
        expect(props.isTestVisit).toEqual(defaultProps.isTestVisit);
        expect(props.audioDeviceId).toEqual(defaultProps.audioDeviceId);
        expect(props.videoDeviceId).toEqual(defaultProps.videoDeviceId);
        expect(props.callStartTime).toEqual(defaultProps.callStartTime);
        expect(props.invalidVisitId).toEqual(defaultProps.invalidVisitId);
        expect(props.isTokBox).toEqual(defaultProps.isTokBox);
        expect(props.tokBoxVideoSessionId).toEqual(
            defaultProps.tokBoxVideoSessionId,
        );
        expect(props.tokBoxVideoToken).toEqual(defaultProps.tokBoxVideoToken);
        expect(props.tokBoxTokenError).toEqual(defaultProps.tokBoxTokenError);
        expect(props.tokBoxTokenErrorMessage).toEqual(
            defaultProps.tokBoxTokenErrorMessage,
        );
        expect(props.consentTermsAccepted).toEqual(
            defaultProps.consentTermsAccepted,
        );
        expect(props.isLoadingConsentTerms).toEqual(
            defaultProps.isLoadingConsentTerms,
        );
        expect(props.consentTermsErrorMessage).toEqual(
            defaultProps.consentTermsErrorMessage,
        );
        expect(props.messageDialogText).toEqual(defaultProps.messageDialogText);
    });

    test('All actions should be correctly mapped to props.', () => {
        wrapper = shallow(
            <ConnectedInVisitStageContainer
                {...({ store } as unknown as Props)}
            />,
        )
            .dive()
            .dive() as InVisitStageContainerWrapper;

        const props = wrapper.props();

        expect(props.cancelVisit).toBeDefined();
        expect(props.fetchVisitDetailsByVisitId).toBeDefined();
        expect(props.fetchTestVisitDetailsByVisitId).toBeDefined();
        expect(props.fetchTokBoxTokens).toBeDefined();
        expect(props.setCallStartTime).toBeDefined();
        expect(props.setCallEndTime).toBeDefined();
        expect(props.setAudioDeviceId).toBeDefined();
        expect(props.setVideoDeviceId).toBeDefined();
        expect(props.setTokBoxVideoToken).toBeDefined();
        expect(props.setTokBoxWaitingRoomToken).toBeDefined();
        expect(props.setConsentErrorMessage).toBeDefined();
        expect(props.acceptConsentTerms).toBeDefined();
        expect(props.setMessageDialog).toBeDefined();
    });

    describe('Connected component', () => {
        it('verify default snapshot', async () => {
            vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
            const i18nInstance = await initI18nInstance({
                brandName: 'string',
                authConfigKey: 'string',
                logoutReturnTo: 'string',
                domain: 'string',
                greyLogo: 'string',
                logo: 'string',
                iosStoreLink: 'string',
                androidStoreLink: 'string',
                footer: {
                    copyright: 'string',
                    urlTerms: 'string',
                    linkTerms: 'string',
                    urlDisclaimer: 'string',
                    linkDisclaimer: 'string',
                    urlPrivacy: 'string',
                    linkPrivacy: 'string',
                    urlNonDiscrimination: 'string',
                    linkNonDiscrimination: 'string',
                    emergencyNumber: 'string',
                    needHelp: 'string',
                    helpPhone: 'string',
                },
            } as BrandConfig);
            const { container } = render(
                <Provider store={mockStoreWithState}>
                    <I18nextProvider i18n={i18nInstance}>
                        <ConnectedInVisitStageContainer
                            brand={'swedish'}
                            userDetails={userDetails}
                        />
                    </I18nextProvider>
                </Provider>,
            );
            expect(container).toMatchSnapshot();
        });

        // TODO: test tests are causing timeouts
        describe.skip('logging', () => {
            beforeAll(async () => {
                vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
                const i18nInstance = await initI18nInstance(
                    mocki18ndata as unknown as BrandConfig,
                );
                mount(
                    <Provider store={mockStoreWithState}>
                        <I18nextProvider i18n={i18nInstance}>
                            <ConnectedInVisitStageContainer
                                brand={'swedish'}
                                userDetails={userDetails}
                            />
                        </I18nextProvider>
                    </Provider>,
                );
            });

            it('addApplicationContext', () => {
                expect(
                    BlisseyLogger.addApplicationContext,
                ).toHaveBeenCalledWith({
                    isTestVisit: false,
                    userId: userDetails.id,
                    visitId: params.visitId,
                });
            });

            it('pageView', () => {
                expect(BlisseyLogger.info).toHaveBeenCalledWith({
                    eventType: 'pageView',
                    eventSource: 'InVisitStageContainer',
                });
            });
        });
    });

    it('VCM renders after loading', async () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        componentProps.fetchVisitDetailsByVisitId = vi
            .fn()
            .mockResolvedValue(mockTokBoxVisitDetails);

        const WrappedComponent = withRouter(
            InVisitStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow<InVisitStageContainerComponent, unknown, State>(
            <WrappedComponent {...componentProps} />,
            {
                disableLifecycleMethods: true,
            },
        ).dive() as InVisitStageContainerWrapper;

        let state = wrapper.state();
        expect(state.isLoadingVisitDetails).toBe(true);
        expect(wrapper.find(CircularProgress)).toHaveLength(1);
        expect(wrapper.find('Connect(VideoCallModule)')).toHaveLength(0);
        expect(wrapper.find('Translate(NotFoundModule)')).toHaveLength(0);

        wrapper.instance().componentDidMount();
        await waitFor(() =>
            expect(
                componentProps.fetchVisitDetailsByVisitId,
            ).toHaveBeenCalled(),
        );
        wrapper.update();

        state = wrapper.state();
        expect(state.isLoadingVisitDetails).toBe(false);

        expect(wrapper.find(TokenForm)).toHaveLength(0);
        expect(wrapper.find(CircularProgress)).toHaveLength(0);
        expect(wrapper.find('Connect(VideoCallModule)')).toHaveLength(1);
        expect(wrapper.find('Translate(NotFoundModule)')).toHaveLength(0);
        expect(
            (componentProps.fetchVisitDetailsByVisitId as Mock).mock.calls
                .length,
        ).toBe(1);
    });

    it('tokbox visit mounts', async () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const props = {
            ...componentProps,
            isTokBoxVideoConference: true,
            fetchVisitDetailsByVisitId: vi
                .fn()
                .mockResolvedValue(mockTokBoxVisitDetails),
            fetchConferenceMetaData: vi.fn().mockResolvedValue(''),
            fetchTokBoxTokens: vi.fn(),
        };

        const WrappedComponent = withRouter(
            InVisitStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow<InVisitStageContainerComponent, unknown, State>(
            <WrappedComponent {...props} />,
            {
                disableLifecycleMethods: true,
            },
        ).dive() as InVisitStageContainerWrapper;

        let state = wrapper.state();
        expect(state.isLoadingVisitDetails).toBe(true);
        expect(wrapper.find(CircularProgress)).toHaveLength(1);
        expect(wrapper.find('Connect(VideoCallModule)')).toHaveLength(0);
        expect(wrapper.find('Translate(NotFoundModule)')).toHaveLength(0);

        wrapper.instance().componentDidMount();
        await waitFor(() =>
            expect(props.fetchVisitDetailsByVisitId).toHaveBeenCalled(),
        );
        wrapper.update();

        state = wrapper.state();
        expect(state.isLoadingVisitDetails).toBe(false);

        expect(wrapper.find(TokenForm)).toHaveLength(0);
        expect(wrapper.find(CircularProgress)).toHaveLength(0);
        expect(wrapper.find('Connect(VideoCallModule)')).toHaveLength(1);
        expect(wrapper.find('Translate(NotFoundModule)')).toHaveLength(0);
        expect(props.fetchVisitDetailsByVisitId).toHaveBeenCalledTimes(1);
        expect(props.fetchConferenceMetaData).toHaveReturnedTimes(0);
        expect(props.fetchTokBoxTokens).toHaveBeenCalledTimes(1);
        expect(props.fetchTokBoxTokens).toHaveBeenCalledWith({
            videoSessionId:
                mockTokBoxVisitDetails.tokBoxVisit.videoConferenceSession
                    .sessionId,
            waitingRoomSessionId:
                mockTokBoxVisitDetails.tokBoxVisit.waitingRoomSession.sessionId,
        });
    });

    it('passes fetchVisitDetails to VideoCallModule', async () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const props = {
            ...componentProps,
            isTokBoxVideoConference: true,
            fetchVisitDetailsByVisitId: vi
                .fn()
                .mockResolvedValue(mockTokBoxVisitDetails),
            fetchConferenceMetaData: vi.fn().mockResolvedValue(''),
            fetchTokBoxTokens: vi.fn(),
        };
        const WrappedComponent = withRouter(
            InVisitStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow(<WrappedComponent {...props} />, {
            disableLifecycleMethods: true,
        }).dive();

        wrapper.instance().componentDidMount();
        await waitFor(() =>
            expect(props.fetchVisitDetailsByVisitId).toHaveBeenCalled(),
        );
        wrapper.update();

        expect(props.fetchVisitDetailsByVisitId).toHaveBeenCalledTimes(1);
        (
            wrapper
                .find('Connect(VideoCallModule)')
                .props() as VideoCallModuleProps
        ).fetchVisitDetails();
        expect(props.fetchVisitDetailsByVisitId).toHaveBeenCalledTimes(2);
    });

    it('tokbox patient visit requires manual entry for tokens', async () => {
        const props = {
            ...componentProps,
            userDetails: {
                ...userDetails,
                roles: ['telehealth_patient'],
            },
            isTokBox: true,
            tokBoxVideoToken: undefined,
            isTestVisit: true,
            fetchVisitDetailsByVisitId: vi
                .fn()
                .mockResolvedValue(mockTokBoxVisitDetails),
            fetchConferenceMetaData: vi.fn().mockResolvedValue(''),
        };
        const WrappedComponent = withRouter(
            InVisitStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow(<WrappedComponent {...props} />).dive();
        await (wrapper
            .instance()
            .componentDidMount() as unknown as Promise<void>);

        expect(wrapper.find(TokenForm)).toHaveLength(1);
    });

    it('NotFoundModule renders after error', async () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        componentProps.fetchVisitDetailsByVisitId = vi.fn(async () => {
            return Promise.reject(new Error(''));
        });
        componentProps.invalidVisitId = true;
        const WrappedComponent = withRouter(
            InVisitStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow<InVisitStageContainerComponent, unknown, State>(
            <WrappedComponent {...componentProps} />,
            {
                disableLifecycleMethods: true,
            },
        ).dive() as InVisitStageContainerWrapper;

        let state = wrapper.state();
        expect(state.isLoadingVisitDetails).toBe(true);
        expect(wrapper.find(CircularProgress)).toHaveLength(1);
        expect(wrapper.find('Connect(VideoCallModule)')).toHaveLength(0);
        expect(wrapper.find('NotFoundModule')).toHaveLength(0);

        wrapper.instance().componentDidMount();
        await waitFor(() =>
            expect(
                componentProps.fetchVisitDetailsByVisitId,
            ).toHaveBeenCalled(),
        );
        wrapper.update();

        state = wrapper.state();
        expect(state.isLoadingVisitDetails).toBe(false);
        expect(wrapper.find(CircularProgress)).toHaveLength(0);
        expect(wrapper.find('Connect(VideoCallModule)')).toHaveLength(0);
        expect(wrapper.find('NotFoundModule')).toHaveLength(1);
    });

    it('NotFoundModule renders if tokboxtokenerror', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            InVisitStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow<InVisitStageContainerComponent, unknown, State>(
            <WrappedComponent
                {...{ ...componentProps, tokBoxTokenError: true }}
            />,
            {
                disableLifecycleMethods: true,
            },
        ).dive() as InVisitStageContainerWrapper;
        wrapper.setState({ isLoadingVisitDetails: false });
        expect(wrapper.find('Connect(VideoCallModule)')).toHaveLength(0);
        expect(wrapper.find('NotFoundModule')).toHaveLength(1);
    });

    it('ConsentModule renders if consent gethering is required', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            InVisitStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow<InVisitStageContainerComponent, unknown, State>(
            <WrappedComponent
                {...{ ...componentProps, consentTermsAccepted: false }}
            />,
            {
                disableLifecycleMethods: true,
            },
        ).dive() as InVisitStageContainerWrapper;
        wrapper.setState({ isLoadingVisitDetails: false });
        expect(wrapper.find('Connect(VideoCallModule)')).toHaveLength(0);
        expect(
            wrapper.find('withI18nextTranslation(ConsentModule)'),
        ).toHaveLength(1);
    });

    it('ConsentModule does not render if consent gethering is required but user is not patient', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        const WrappedComponent = withRouter(
            InVisitStageContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const wrapper = shallow<InVisitStageContainerComponent, unknown, State>(
            <WrappedComponent
                {...{
                    ...componentProps,
                    consentTermsAccepted: false,
                    userDetails: {
                        ...userDetails,
                        roles: [SECURITY_ROLE_PROVIDER],
                    },
                }}
            />,
            {
                disableLifecycleMethods: true,
            },
        ).dive() as InVisitStageContainerWrapper;
        wrapper.setState({ isLoadingVisitDetails: false });
        expect(wrapper.find('Connect(VideoCallModule)')).toHaveLength(1);
        expect(
            wrapper.find('withI18nextTranslation(ConsentModule)'),
        ).toHaveLength(0);
    });
});
