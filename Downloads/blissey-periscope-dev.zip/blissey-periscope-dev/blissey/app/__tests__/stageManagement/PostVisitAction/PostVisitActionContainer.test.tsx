import { PaymentStatus } from '@redux/utils/PaymentStatus';
import { ShallowWrapper, shallow } from 'enzyme';
import * as React from 'react';
import { AnyAction, Store } from 'redux';
import configureMockStore from 'redux-mock-store';
import {
    Props,
    PostVisitActionContainerComponent,
    PostVisitActionContainer as WrappedPostVisitActionContainer,
} from '../../../src/stageManagement/PostVisitAction/PostVisitActionContainer';
import { MockedFunction, vi } from 'vitest';
import toJson from 'enzyme-to-json';
import { OwnProps, State } from '@stageManagement/PostVisitAction/interfaces';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import { fireEvent, render } from '@testing-library/react';
import * as ReactRouter from 'react-router-dom';
import { withRouter } from '../../../src/common/withRouter';

vi.mock('react-router-dom', async () => {
    const original = await vi.importActual('react-router-dom');
    return {
        ...(original as object),
        useLocation: vi.fn().mockReturnValue({}),
        useNavigate: vi.fn().mockReturnValue(vi.fn()),
    };
});

vi.mock('@components/ErrorSnackbar', () => ({
    ErrorSnackbar: vi.fn().mockReturnValue(null),
}));

vi.mock('@utils/FeatureFlags', () => ({
    getFeatureFlag: vi.fn(),
    FeatureFlags: {
        enableVisitModalityConversion: 'enable-visit-modality-conversion',
        enableVisitModalityConversionForTravelPatientCallCenter:
            'enable-visit-modality-conversion-for-travel-patient-call-center',
    },
}));

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        pageViewEvent: vi.fn(),
        interactionEvent: vi.fn(),
    },
}));

vi.mock('@redux/modules/postConsult', () => ({
    waiveVisit: vi.fn(),
    chargeVisit: vi.fn(),
    convertModality: vi.fn(),
    transferBackToQueue: vi.fn(),
    transferToAnotherProvider: vi.fn(),
}));

const getFeatureFlagMock = getFeatureFlag as MockedFunction<
    typeof getFeatureFlag
>;

const testState = {
    postconsult: {
        isTestVisit: false,
        chargedStatus: PaymentStatus.none,
    },
};

const params = {
    visitId: '123232',
};

const componentProps = {
    brand: 'swedish',
    userDetails: {
        id: 'id',
        displayName: 'robert',
        givenName: 'string',
        familyName: 'string',
        email: 'string',
        token: 'string',
        expiration: 22,
    },
    patientGuid: 'mockPatientGuid',
};

const wrappedProps: Props = {
    ...componentProps,
    ...testState.postconsult,
    chargeVisit: vi.fn().mockResolvedValue('success'),
    convertModality: vi.fn().mockResolvedValue('success'),
    waiveVisit: vi.fn().mockResolvedValue('success'),
    transferBackToQueue: vi.fn().mockResolvedValue('success'),
    transferToAnotherProvider: vi.fn().mockResolvedValue('success'),
} as unknown as Props;

type PostVisitActionContainerWrapper = ShallowWrapper<
    OwnProps & Props,
    Readonly<State>,
    React.Component<OwnProps, State>
>;
describe('<PostVisitActionContainer/>', () => {
    let wrapper: PostVisitActionContainerWrapper;
    let store: Store<unknown, AnyAction>;
    beforeEach(() => {
        const mockStore = configureMockStore();
        store = mockStore(testState);
        wrappedProps.chargeVisit = vi.fn();
        wrappedProps.convertModality = vi.fn();
        wrappedProps.waiveVisit = vi.fn();
        wrappedProps.transferBackToQueue = vi.fn();
        wrappedProps.transferToAnotherProvider = vi.fn();
        wrappedProps.isTestVisit = false;
        wrappedProps.chargedStatus = PaymentStatus.none;
    });

    test('The Redux store attributes should be correctly mapped to props.', () => {
        wrapper = shallow(
            <WrappedPostVisitActionContainer
                {...({ store } as unknown as Props)}
            />,
        )
            .dive()
            .dive() as PostVisitActionContainerWrapper;

        const props = wrapper.props();
        expect(props.isTestVisit).toEqual(testState.postconsult.isTestVisit);
        expect(props.chargedStatus).toEqual(
            testState.postconsult.chargedStatus,
        );
    });

    test('All actions should be correctly mapped to props.', () => {
        wrapper = shallow(
            <WrappedPostVisitActionContainer
                {...({ store } as unknown as Props)}
            />,
        )
            .dive()
            .dive() as PostVisitActionContainerWrapper;

        const props = wrapper.props();

        expect(props.waiveVisit).toBeDefined();
        expect(props.chargeVisit).toBeDefined();
        expect(props.convertModality).toBeDefined();
        expect(props.transferBackToQueue).toBeDefined();
        expect(props.transferToAnotherProvider).toBeDefined();
    });

    test('should initialize with payment not decided', () => {
        const wrapper = shallow(
            <PostVisitActionContainerComponent {...wrappedProps} />,
        ).dive();
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    test('should initialize with a payment decided', () => {
        wrappedProps.chargedStatus = PaymentStatus.waived;
        const wrapper = shallow(
            <PostVisitActionContainerComponent {...wrappedProps} />,
        ).dive();
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    test('should initialize with convert modality', () => {
        getFeatureFlagMock.mockImplementation((flag) => {
            if (
                [
                    FeatureFlags.enableVisitModalityConversion,
                    FeatureFlags.enableVisitModalityConversionForTravelPatientCallCenter,
                ].includes(flag)
            ) {
                return true;
            }

            return false;
        });
        const wrapper = shallow(
            <PostVisitActionContainerComponent {...wrappedProps} />,
        ).dive();
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    test('should trigger modality conversion', () => {
        vi.spyOn(ReactRouter, 'useParams').mockReturnValueOnce(params);
        getFeatureFlagMock.mockImplementation((flag) => {
            if (
                [
                    FeatureFlags.enableVisitModalityConversion,
                    FeatureFlags.enableVisitModalityConversionForTravelPatientCallCenter,
                ].includes(flag)
            ) {
                return true;
            }

            return false;
        });
        const WrappedComponent = withRouter(
            PostVisitActionContainerComponent,
        ) as React.ComponentClass<Props, unknown>;
        const { container, getByRole, getAllByRole } = render(
            <WrappedComponent {...wrappedProps} />,
        );
        fireEvent.click(getByRole('radio', { name: 'Convert Modality' }));
        fireEvent.mouseDown(
            getByRole('combobox', { name: 'Reason for Conversion' }),
        );
        fireEvent.click(getByRole('option', { name: 'Reason 1' }));

        fireEvent.click(getAllByRole('button').at(0));
        expect(wrappedProps.convertModality).toHaveBeenCalledWith(
            '123232',
            'REASON_1',
        );
        expect(container).toMatchSnapshot();
    });

    test('should trigger modality conversion and throw', () => {
        getFeatureFlagMock.mockImplementation((flag) => {
            if (
                [
                    FeatureFlags.enableVisitModalityConversion,
                    FeatureFlags.enableVisitModalityConversionForTravelPatientCallCenter,
                ].includes(flag)
            ) {
                return true;
            }

            return false;
        });

        const { container, getByRole } = render(
            <PostVisitActionContainerComponent {...wrappedProps} />,
        );
        fireEvent.click(getByRole('radio', { name: 'Convert Modality' }));
        fireEvent.click(getByRole('button'));
        expect(wrappedProps.convertModality).not.toHaveBeenCalled();
        expect(container).toMatchSnapshot();
    });

    test('should not render modality conversion', () => {
        getFeatureFlagMock.mockImplementation((flag) => {
            if (flag === FeatureFlags.enableVisitModalityConversion) {
                return true;
            }

            return false;
        });
        wrappedProps.isTravelingFromCallCenter = true;

        const { container } = render(
            <PostVisitActionContainerComponent {...wrappedProps} />,
        );
        const radioElements = container.querySelectorAll('[type="radio"]');

        expect(radioElements.length).toEqual(2);
        expect(radioElements[0].getAttribute('value')).toEqual(
            'complete-visit',
        );
        expect(radioElements[1].getAttribute('value')).toEqual('waive-visit');
    });
});
