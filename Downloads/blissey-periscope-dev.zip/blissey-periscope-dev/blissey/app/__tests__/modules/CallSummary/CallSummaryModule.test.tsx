import * as React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import { FeedbackQuestionType } from '../../../src/clients/Feedback/FeedbackQuestionType';

import { CallSummaryModule } from '../../../src/modules/CallSummary/CallSummaryModule';
import { UserDetails } from '@dexcare/circus-saturn';
import { CallSummaryModuleProps } from '../../../src/modules/CallSummary/CallSummaryModuleInterfaces';
import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: {
        sendEvent: vi.fn(),
        sendPageView: vi.fn(),
    },
    V2Analytics: {
        interactionEvent: vi.fn(),
        pageViewEvent: vi.fn(),
    },
}));

vi.mock('@clients/VisitService/VisitServiceClient');

describe('<CallSummaryModule />', () => {
    const defaultUser: UserDetails = {
        id: 'id',
        displayName: 'displayName',
        givenName: 'givenName',
        familyName: 'familyName',
        email: 'email@example.com',
        token: 'token',
        expiration: Date.now(),
    };

    const defaultProps: CallSummaryModuleProps = {
        localUser: defaultUser,
        visitId: 'testvisitid',
        conferenceId: 'testconferenceId',
        conferenceSessionId: 'testconferenceSessionId',
        callStartTime: 1526447801,
        callEndTime: 1526448101,
        patientGuid: 'testpatientguid',
        onFlowFinished: vi.fn(),
    };

    it('Check provider version renders properly', () => {
        const callSummaryProps = Object.assign({}, defaultProps);
        callSummaryProps.localUser = Object.assign({}, defaultUser);
        callSummaryProps.localUser.roles = ['telehealth_provider'];
        const { container } = render(
            <CallSummaryModule {...callSummaryProps} />,
        );
        expect(container).toMatchSnapshot();
    });

    it('Check patient version renders properly', () => {
        const callSummaryProps = Object.assign({}, defaultProps);
        const { container } = render(
            <CallSummaryModule {...callSummaryProps} />,
        );
        expect(container).toMatchSnapshot();
    });

    it('calls analytics on mount', () => {
        const callSummaryProps = Object.assign({}, defaultProps);
        shallow(<CallSummaryModule {...callSummaryProps} />);

        expect(V2Analytics.pageViewEvent).toHaveBeenCalled();
        expect(Analytics.sendPageView).toHaveBeenCalledWith({
            destinationURL: '/postconsult/feedback',
        });
    });

    it('calls analytics 2 times on skip', () => {
        const callSummaryProps = Object.assign({}, defaultProps);
        const wrapper = shallow(<CallSummaryModule {...callSummaryProps} />);
        (wrapper.instance() as CallSummaryModule).onPatientSubmit(
            [
                {
                    id: 'rating',
                    type: FeedbackQuestionType.Number,
                    text: 'label',
                    answers: [
                        {
                            id: 'ratingAnswer',
                            type: 'number',
                            value: 10,
                        },
                    ],
                },
                {
                    id: 'feedback',
                    type: FeedbackQuestionType.Text,
                    text: 'label',
                    answers: [
                        {
                            id: 'feedbackValue',
                            type: 'text',
                            value: 'not bad',
                        },
                    ],
                },
                {
                    id: 'followUp',
                    type: FeedbackQuestionType.Boolean,
                    text: 'label',
                    answers: [
                        {
                            id: 'followUpAnswer',
                            type: 'check',
                            value: true,
                        },
                    ],
                },
            ],
            true,
        );

        expect(Analytics.sendEvent).toHaveBeenCalledWith({
            eventAction: 'formSubmission',
            formEngagement: {
                fieldName: 'rating',
                fieldValue: 'skip',
                formName: 'Visit Questionnaire',
            },
        });
        expect(Analytics.sendEvent).toHaveBeenCalledWith({
            eventAction: 'formSubmission',
            formEngagement: {
                fieldName: 'followUp',
                fieldValue: 'skip',
                formName: 'Visit Questionnaire',
            },
        });
    });

    it('calls analytics 2 times on submit', () => {
        const callSummaryProps = Object.assign({}, defaultProps);
        const wrapper = shallow(<CallSummaryModule {...callSummaryProps} />);
        (wrapper.instance() as CallSummaryModule).onPatientSubmit([
            {
                id: 'rating',
                type: FeedbackQuestionType.Number,
                text: 'label',
                answers: [
                    {
                        id: 'ratingAnswer',
                        type: 'number',
                        value: 10,
                    },
                ],
            },
            {
                id: 'feedback',
                type: FeedbackQuestionType.Text,
                text: 'label',
                answers: [
                    {
                        id: 'feedbackValue',
                        type: 'text',
                        value: 'not bad',
                    },
                ],
            },
            {
                id: 'followUp',
                type: FeedbackQuestionType.Boolean,
                text: 'label',
                answers: [
                    {
                        id: 'followUpAnswer',
                        type: 'check',
                        value: true,
                    },
                ],
            },
        ]);

        expect(Analytics.sendEvent).toHaveBeenCalledWith({
            eventAction: 'formSubmission',
            formEngagement: {
                fieldName: 'rating',
                fieldValue: 10,
                formName: 'Visit Questionnaire',
            },
        });
        expect(Analytics.sendEvent).toHaveBeenCalledWith({
            eventAction: 'formSubmission',
            formEngagement: {
                fieldName: 'followUp',
                fieldValue: true,
                formName: 'Visit Questionnaire',
            },
        });
    });
});
