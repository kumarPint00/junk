import { UserType } from '../../../src/data/UserType';
import { FeedbackQuestionType } from '@clients/Feedback/FeedbackQuestionType';
import { createQuestionBank } from '@modules/CallSummary/data/FeedbackQuestionsList';

describe('FeedbackQuestionsList', () => {
    it('has one provider question', () => {
        const questions = createQuestionBank(UserType.Provider);
        expect(questions.getFeedbackQuestions().size).toBe(1);

        const question = questions.getFeedbackQuestions().get('rating');
        expect(question.id).toBe('rating');
        expect(question.answers.length).toBe(1);
        expect(question.answers[0].id).toBe('ratingAnswer');
        expect(question.answers[0].type).toBe(FeedbackQuestionType.Number);
    });

    it('has no patient questions', () => {
        const questions = createQuestionBank(UserType.Patient);
        expect(questions.getFeedbackQuestions().size).toBe(0);
    });

    it('has no PRR questions', () => {
        const questions = createQuestionBank(UserType.PRR);
        expect(questions.getFeedbackQuestions().size).toBe(0);
    });
});
