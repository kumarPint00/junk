import { QuestionBank } from '@modules/CallSummary/data/QuestionBank';
import { FeedbackQuestion } from '@clients/Feedback/FeedbackQuestion';
import { FeedbackQuestionType } from '@clients/Feedback/FeedbackQuestionType';

const numberQuestionId = 'numberQuestion';
const textQuestionId = 'textQuestion';
const radioQuestionId = 'radioQuestion';

const testQuestions = new Map<string, FeedbackQuestion>([
    [
        numberQuestionId,
        {
            id: numberQuestionId,
            text: 'Test Number',
            type: FeedbackQuestionType.Number,
            answers: [
                {
                    id: 'NumberValue',
                    type: FeedbackQuestionType.Number,
                    value: 0,
                },
            ],
        },
    ],
    [
        textQuestionId,
        {
            id: textQuestionId,
            text: 'Test Text',
            type: FeedbackQuestionType.Text,
            answers: [
                {
                    id: 'TextValue',
                    type: FeedbackQuestionType.Text,
                    value: '',
                },
            ],
        },
    ],
    [
        radioQuestionId,
        {
            id: radioQuestionId,
            text: 'Test radio',
            type: FeedbackQuestionType.MultipleChoice,
            answers: [
                {
                    id: 'Id1',
                    text: 'Id One',
                    type: FeedbackQuestionType.MultipleChoice,
                    value: false,
                },
                {
                    id: 'Id2',
                    text: 'Id Two',
                    type: FeedbackQuestionType.MultipleChoice,
                    value: false,
                },
                {
                    id: 'Id3',
                    text: 'Id Three',
                    type: FeedbackQuestionType.MultipleChoice,
                    value: false,
                },
            ],
        },
    ],
]);

describe('QuestionBank', () => {
    let bank: QuestionBank;
    beforeEach(() => {
        bank = new QuestionBank(testQuestions);
    });

    it('set and get null feedback map', () => {
        bank = new QuestionBank(null);
        expect(bank.getFeedbackQuestions()).toBeNull();
    });

    it('set and get non-null feedback map', () => {
        expect(bank.getFeedbackQuestions()).toEqual(testQuestions);
    });

    it('updates answer value on type number', () => {
        const newNumber = 1;
        bank.updateValue(
            numberQuestionId,
            newNumber,
            testQuestions.get(numberQuestionId).answers[0].id,
        );
        const updatedValue = bank.getFeedbackQuestions().get(numberQuestionId)
            .answers[0].value;
        expect(updatedValue).toEqual(newNumber);
    });

    it('updates answer value on type text', () => {
        const newText = 'I love virtual visits!';
        bank.updateValue(
            textQuestionId,
            newText,
            testQuestions.get(textQuestionId).answers[0].id,
        );
        const updatedValue = bank.getFeedbackQuestions().get(textQuestionId)
            .answers[0].value;
        expect(updatedValue).toEqual(newText);
    });

    it('updates answer value on type radio', () => {
        bank.updateValue(
            radioQuestionId,
            testQuestions.get(radioQuestionId).answers[0].id,
        );
        const updatedValue = bank.getFeedbackQuestions().get(radioQuestionId)
            .answers[0].value;
        expect(updatedValue).toEqual(true);
    });
});
