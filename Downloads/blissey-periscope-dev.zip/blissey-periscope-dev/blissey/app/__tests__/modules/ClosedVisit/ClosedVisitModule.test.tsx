import * as React from 'react';
import { ClosedVisitModule } from '../../../src/modules/ClosedVisit/ClosedVisitModule';
import configureMockStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux';
import { render } from '@testing-library/react';
import { vi } from 'vitest';

vi.mock('react-router-dom', () => ({
    useParams: vi.fn().mockReturnValue({}),
    useLocation: vi.fn().mockReturnValue({}),
    useNavigate: vi.fn().mockReturnValue(vi.fn()),
}));

vi.mock('@dexcare/circus-jupiter', async (importOriginal) => {
    const actual = await importOriginal();
    return {
        ...(actual as object),
        config: {
            getConfig: vi.fn(() => ({
                technicalSupportHelpNumber: '555-555-5555',
                displaySupportNumberOnError: false,
            })),
        },
        jupiterOptions: {
            applicationName: 'blissey',
            logSource: 'development',
            metricsEndpoint: '/appMetrics',
            logLevel: 'debug',
        },
        LogManager: {
            getLogger: () => {
                return {
                    child: () => {
                        return { warn: vi.fn(), info: vi.fn() };
                    },
                };
            },
        },
    };
});

const middlewares = [thunk];
const testState = {};
const mockStore = configureMockStore(middlewares);
const mockStoreWithState = mockStore(testState);

describe('<ClosedVisitModule />', () => {
    test('Providence brand and visit done', () => {
        const result = render(
            <Provider store={mockStoreWithState}>
                <ClosedVisitModule
                    closedReason={'done'}
                    t={(key: string) => key}
                />
                ,
            </Provider>,
        );
        expect(result).toMatchSnapshot();
    });

    test('Providence brand and visit staff-declined', () => {
        const result = render(
            <Provider store={mockStoreWithState}>
                <ClosedVisitModule
                    closedReason={'staffdeclined'}
                    t={(key: string) => key}
                />
                ,
            </Provider>,
        );
        expect(result).toMatchSnapshot();
    });

    test('Providence brand and visit cancelled', () => {
        const result = render(
            <Provider store={mockStoreWithState}>
                <ClosedVisitModule
                    closedReason={'cancelled'}
                    t={(key: string) => key}
                />
                ,
            </Provider>,
        );
        expect(result).toMatchSnapshot();
    });

    test('Unknown visit status displays done response', () => {
        const result = render(
            <Provider store={mockStoreWithState}>
                <ClosedVisitModule
                    closedReason={'expired'}
                    t={(key: string) => key}
                />
                ,
            </Provider>,
        );
        expect(result).toMatchSnapshot();
    });

    it('should render with waitoffline status', () => {
        const result = render(
            <Provider store={mockStoreWithState}>
                <ClosedVisitModule
                    closedReason={'waitoffline'}
                    t={(key: string) => key}
                />
                ,
            </Provider>,
        );
        expect(result).toMatchSnapshot();
    });

    it('should render with requested status', () => {
        const result = render(
            <Provider store={mockStoreWithState}>
                <ClosedVisitModule
                    closedReason={'waitingroom'}
                    t={(key: string) => key}
                />
                ,
            </Provider>,
        );
        expect(result).toMatchSnapshot();
    });
});
