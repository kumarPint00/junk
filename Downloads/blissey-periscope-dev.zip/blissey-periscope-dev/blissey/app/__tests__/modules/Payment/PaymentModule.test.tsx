import * as React from 'react';
import { PaymentModule } from '@modules/Payment/PaymentModule';
import { PaymentStatus } from '@redux/utils/PaymentStatus';
import { shallow, mount, ReactWrapper } from 'enzyme';
import {
    ChargeOrWaiveSelector,
    ChargeOrWaiveSelectorProps,
} from '@dexcare/charge-or-waive-selector';
import { act } from 'react-dom/test-utils';
import { vi } from 'vitest';
import toJson from 'enzyme-to-json';
import { fireEvent, render } from '@testing-library/react';

const props = {
    handleWaive: vi.fn(),
    handleCharge: vi.fn(),
    chargedStatus: PaymentStatus.none,
    handleContinue: vi.fn(),
    disabled: false,
    visitId: 'testVisitId',
};
describe('<PaymentModule />', () => {
    beforeEach(() => {
        props.handleWaive = vi.fn();
        props.handleCharge = vi.fn();
        props.handleContinue = vi.fn();
        props.chargedStatus = PaymentStatus.none;
    });

    test('no initial value selected', () => {
        expect(toJson(shallow(<PaymentModule {...props} />))).toMatchSnapshot();
    });

    test('payment already waived', () => {
        props.chargedStatus = PaymentStatus.waived;
        expect(toJson(shallow(<PaymentModule {...props} />))).toMatchSnapshot();
    });

    test('payment already charged', () => {
        props.chargedStatus = PaymentStatus.waived;
        expect(toJson(shallow(<PaymentModule {...props} />))).toMatchSnapshot();
    });

    test('payment already waived, onclick', () => {
        props.chargedStatus = PaymentStatus.waived;
        const wrapper = mount(<PaymentModule {...props} />);
        wrapper
            .find('button[data-uitest="payment-continueButton"]')
            .simulate('click');
        expect(props.handleContinue).toBeCalled();
    });

    test('select waive', () => {
        const { container } = render(<PaymentModule {...props} />);
        const input = container.querySelector('input[value="waive"]');
        fireEvent.click(input);
        expect(container).toMatchSnapshot();
    });

    test('on click, charge selected', () => {
        const wrapper = shallow(<PaymentModule {...props} />);
        wrapper.find('[uiTestTag="payment-continueButton"]').simulate('click');
        expect(props.handleCharge).toBeCalled();
    });

    test('on click, waive selected', () => {
        const wrapper = mount(<PaymentModule {...props} />);
        wrapper.find('input[value="waive"]').simulate('click');
        act(() => {
            const chargeOrWaiveSelector = wrapper.find(
                ChargeOrWaiveSelector,
            ) as ReactWrapper<ChargeOrWaiveSelectorProps>;
            chargeOrWaiveSelector.props().handleChargeChoiceChange('waive');
            chargeOrWaiveSelector.props().handleWaiveReasonChange('demo');
        });
        wrapper
            .find('button[data-uitest="payment-continueButton"]')
            .simulate('click');
        expect(props.handleWaive).toBeCalledWith('demo');
    });
});
