import * as React from 'react';

import { NotFoundModule } from '../../../src/modules/NotFound/NotFoundModule';
import { render } from '@testing-library/react';
import { shallow } from 'enzyme';
import { jwtTokenHelper } from '@utils/jwt-helper';
import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: {
        sendEvent: vi.fn(),
        sendPageView: vi.fn(),
    },
    V2Analytics: { errorEvent: vi.fn(), pageViewEvent: vi.fn() },
}));

describe('<NotFoundModule />', () => {
    test('verify provider snapshot', () => {
        const { container } = render(
            <NotFoundModule isProvider={true} visitId={'visitId'} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('verify non-provider snapshot', () => {
        const { container } = render(
            <NotFoundModule isProvider={false} visitId={'visitId'} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('verify analytics call on mount', () => {
        render(<NotFoundModule isProvider={false} visitId={'visitId'} />);
        expect(V2Analytics.pageViewEvent).toHaveBeenCalled();
        expect(Analytics.sendPageView).toHaveBeenCalledWith({
            destinationURL: '/',
            pageName: '404 Page Not Found',
        });
    });

    test('verify session invalidated on mount', () => {
        jwtTokenHelper.saveAuthenticationToken('some token');
        expect(jwtTokenHelper.getAuthenticationToken()).toEqual('some token');

        shallow(<NotFoundModule isProvider={false} visitId={'visitId'} />);

        expect(jwtTokenHelper.getAuthenticationToken()).toBeFalsy();
    });
});
