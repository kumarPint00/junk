import * as React from 'react';
// import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import { initI18nInstance } from '@common/i18n/i18nInstance';
import { I18nextProvider } from 'react-i18next';
import { render } from '@testing-library/react';
import { shallow } from 'enzyme';
import {
    OTPModule,
    OTPModuleProps,
    RawOTPModule,
} from '../../../src/modules/OTPFlow/OTPModule';
import { GetPasscodeOTPComponent } from '../../../src/components/OTPFlow/GetPasscodeOTPComponent';
import { vi } from 'vitest';
import { BrandConfig } from '../../../../server/config/configInterfaces';

const middlewares = [thunk];
const mocki18ndata = {
    brandName: 'test',
    auth0Domain: 'test',
    auth0ClientId: 'test',
    authConfigKey: 'test',
    logoutReturnTo: 'test',
    domain: 'test',
    greyLogo: 'test',
    logo: 'test',
    iosStoreLink: 'test',
    androidStoreLink: 'test',
    footer: {
        copyright: 'test',
        urlTerms: 'test',
        linkTerms: 'test',
        urlDisclaimer: 'test',
        linkDisclaimer: 'test',
        urlPrivacy: 'test',
        linkPrivacy: 'test',
        urlNonDiscrimination: 'test',
        linkNonDiscrimination: 'test',
        emergencyNumber: 'test',
        needHelp: 'test',
        helpPhone: 'test',
    },
};
const testState = {};

const mockStore = configureMockStore(middlewares);
const mockStoreWithState = mockStore(testState);

describe('<OTPModule />', () => {
    const setOTPMethod = vi.fn();
    const setOTPCode = vi.fn();
    const handleGetOTPCode = vi.fn();
    const handleSubmitOTPCode = vi.fn();
    const handleResendOTPCode = vi.fn();

    let defaultProps;
    let fauxI18NProps;
    beforeEach(() => {
        defaultProps = {
            windowToDisplay: 'get',
            email: 'example@example.com',
            sms: '1234567890',
            otpMethod: 'email',
            otpCode: '',
            isLoading: false,
            setOTPMethod,
            setOTPCode,
            handleGetOTPCode,
            handleSubmitOTPCode,
            handleResendOTPCode,
        };
        fauxI18NProps = {
            ...defaultProps,
            t: () => undefined,
        } as OTPModuleProps;
    });

    afterEach(() => {
        vi.resetAllMocks();
    });

    it('displays the component with defaults with translation wrapper', async () => {
        const i18Instance = await initI18nInstance(
            mocki18ndata as unknown as BrandConfig,
        );
        const wrapper = shallow(
            <Provider store={mockStoreWithState}>
                <I18nextProvider i18n={i18Instance}>
                    <OTPModule {...defaultProps} />,
                </I18nextProvider>
            </Provider>,
        );
        expect(wrapper).toMatchSnapshot();
    });

    it('displays the component with defaults without translation wrapper', () => {
        const { container } = render(<RawOTPModule {...fauxI18NProps} />);
        expect(container).toMatchSnapshot();
    });

    it('uses default text when translations dont exist', () => {
        const wrapper = shallow(<RawOTPModule {...fauxI18NProps} />);
        expect(
            wrapper
                .find(GetPasscodeOTPComponent)
                .dive()
                .find('b')
                .first()
                .text(),
        ).toEqual('Get Passcode');
    });

    it('uses translation when translations do exist', () => {
        const translationDefinedProps = {
            ...defaultProps,
            t: () => 'test',
        } as OTPModuleProps;
        const wrapper = shallow(<RawOTPModule {...translationDefinedProps} />);
        expect(
            wrapper
                .find(GetPasscodeOTPComponent)
                .dive()
                .find('b')
                .first()
                .text(),
        ).toEqual('test');
    });
});
