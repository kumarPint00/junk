import * as React from 'react';
// import { mount } from 'enzyme';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';
import configureMockStore from 'redux-mock-store';
import { initI18nInstance } from '@common/i18n/i18nInstance';
import { I18nextProvider } from 'react-i18next';
import { render } from '@testing-library/react';
import { shallow } from 'enzyme';
import {
    ConsentModule,
    ConsentModuleProps,
    RawConsentModule,
} from '../../../src/modules/Consent/ConsentModule';
import { ConsentComponent } from '@components/Consent/ConsentComponent';
import { vi } from 'vitest';
import { BrandConfig } from '../../../../server/config/configInterfaces';

const middlewares = [thunk];
const mocki18ndata = {
    brandName: 'test',
    auth0Domain: 'test',
    auth0ClientId: 'test',
    authConfigKey: 'test',
    logoutReturnTo: 'test',
    domain: 'test',
    greyLogo: 'test',
    logo: 'test',
    iosStoreLink: 'test',
    androidStoreLink: 'test',
    footer: {
        copyright: 'test',
        urlTerms: 'test',
        linkTerms: 'test',
        urlDisclaimer: 'test',
        linkDisclaimer: 'test',
        urlPrivacy: 'test',
        linkPrivacy: 'test',
        urlNonDiscrimination: 'test',
        linkNonDiscrimination: 'test',
        emergencyNumber: 'test',
        needHelp: 'test',
        helpPhone: 'test',
    },
} as unknown as BrandConfig;
const testState = {};

const mockStore = configureMockStore(middlewares);
const mockStoreWithState = mockStore(testState);

vi.mock('react-router-dom', () => ({
    useParams: vi.fn().mockReturnValue({}),
    useLocation: vi.fn().mockReturnValue({}),
    useNavigate: vi.fn().mockReturnValue(vi.fn()),
}));

vi.mock('@dexcare/circus-jupiter', async () => {
    const original = await vi.importActual('@dexcare/circus-jupiter');
    return {
        ...(original as object),
        config: {
            getConfig: vi.fn().mockReturnValue({ features: {} }),
        },
    };
});

describe('<ConsentModule />', () => {
    const setTermsAccepted = vi.fn();
    const handleAcceptTerms = vi.fn();
    const handleCancel = vi.fn();

    let defaultProps;
    let fauxI18NProps;
    beforeEach(() => {
        defaultProps = {
            termsAccepted: true,
            isLoading: false,
            setTermsAccepted,
            handleAcceptTerms,
            handleCancel,
        };
        fauxI18NProps = {
            ...defaultProps,
            t: () => undefined,
        } as ConsentModuleProps;
    });

    it('displays the component with defaults with translation wrapper', async () => {
        const i18nInstance = await initI18nInstance(mocki18ndata);
        const wrapper = shallow(
            <Provider store={mockStoreWithState}>
                <I18nextProvider i18n={i18nInstance}>
                    <ConsentModule {...defaultProps} />,
                </I18nextProvider>
            </Provider>,
        );
        expect(wrapper).toMatchSnapshot();
    });

    it('displays the component with defaults without translation wrapper', () => {
        const { container } = render(
            <Provider store={mockStoreWithState}>
                <RawConsentModule {...fauxI18NProps} />
            </Provider>,
        );
        expect(container).toMatchSnapshot();
    });

    it('uses default text when translations dont exist', () => {
        const wrapper = shallow(<RawConsentModule {...fauxI18NProps} />);
        expect(
            wrapper.find(ConsentComponent).dive().find('b').first().text(),
        ).toEqual("You're almost done");
    });

    it('uses translation when translations do exist', () => {
        const translationDefinedProps = {
            ...defaultProps,
            t: () => 'test',
        } as ConsentModuleProps;
        const wrapper = shallow(
            <RawConsentModule {...translationDefinedProps} />,
        );
        expect(
            wrapper.find(ConsentComponent).dive().find('b').first().text(),
        ).toEqual('test');
    });
});
