import * as React from 'react';

import { DogFoodModule } from '../../../src/modules/Dogfood/DogFoodModule';
import { render } from '@testing-library/react';
import { MuiRippleDisabledWrapper } from '../../../__mocks__/theme-provider';

describe('<DogFoodModule />', () => {
    const testUserDetails = {
        id: 'testId',
        displayName: 'testName',
        givenName: 'testName',
        familyName: 'testName',
        email: 'testEmail',
        token: 'token',
        expiration: 10,
    };
    const testBrands = ['testBrand'];

    test('verify snapshot', () => {
        const { container } = render(
            <MuiRippleDisabledWrapper>
                <DogFoodModule
                    brands={testBrands}
                    userDetails={testUserDetails}
                />
            </MuiRippleDisabledWrapper>,
        );
        expect(container).toMatchSnapshot();
    });
});
