import * as React from 'react';
import { shallow } from 'enzyme';
import * as sinon from 'sinon';
import { render } from '@testing-library/react';

import { Button } from '@components/Button';
import { VisitSummaryModule } from '@modules/VisitSummary/VisitSummaryModule';

import { Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: {
        sendEvent: vi.fn(),
        sendPageView: vi.fn(),
    },
}));

vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(() => ({
            visitSummaryText: {
                header: 'Thanks!',
                thanks: 'Thank you for choosing Express Care Virtual.',
                conclude: 'This concludes your visit.',
                treatmentPlan:
                    'A treatment plan summary will be sent to you via secure email within 24 hours.',
                prescription: 'If you received a prescription please allow ',
                time: '30 minutes',
                orCall: ' or call the pharmacy to ensure it is ready for pick up before you arrive.',
                signOutButton: 'SIGN OUT',
            },
        })),
    },
    LogManager: {
        getLogger: () => ({
            child: () => ({
                info: vi.fn(),
            }),
        }),
    },
}));

describe('<VisitSummaryModule />', () => {
    test('verify snapshot', () => {
        const { container } = render(
            <VisitSummaryModule onSignOut={() => {}} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('verify on signout click', () => {
        const onSignOut = sinon.stub();
        const testSummaryModule = <VisitSummaryModule onSignOut={onSignOut} />;
        const wrapper = shallow(testSummaryModule).dive();
        wrapper.find(Button).simulate('click');
        sinon.assert.calledOnce(onSignOut);

        expect(Analytics.sendPageView).toBeCalledWith({
            destinationURL: '/end',
        });
    });
});
