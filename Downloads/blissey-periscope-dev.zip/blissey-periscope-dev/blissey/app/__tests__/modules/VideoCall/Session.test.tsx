import * as React from 'react';
import { shallow, ShallowWrapper } from 'enzyme';
import toJson from 'enzyme-to-json';
import { v4 } from 'uuid';
import WrappedSessionComponent, {
    SessionProps,
    Props,
    SessionComponent,
    SessionComponentState,
} from '@modules/VideoCall/Session';
import {
    Event,
    Stream,
    Connection,
    IntegrationAlert,
    SessionHelper,
    SessionHelperInit,
    StreamCreatedEvent,
    StreamPropertyChangedEvent,
    BotPromptMessage,
} from '@dexcare/yak';
import { VideoCallRenderState } from '@modules/VideoCall/VideoCallRenderState';
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';
import { AnteRoomComponent } from '@components/AnteRoom/AnteRoomComponent';
import { WaitingRoomComponent } from '@components/WaitingRoom/WaitingRoomComponent';
import { ChatPage, ChatPageProps } from '@layout/PageLayout/ChatPage';
import { ConferenceError } from '@modules/VideoCall/ConferenceError';
import { MultiParticipantDisplay } from '@components/MultiPartipicantDisplay/MultiParticipantDisplay';
import { Publisher, TestStatus } from '@common/video';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { WaitingRoomProps } from '@components/WaitingRoom/WaitingRoomInterfaces';
import { Mock, Mocked, MockedClass, MockedFunction, vi } from 'vitest';
import { AnyAction, Store } from 'redux';
import configureMockStore from 'redux-mock-store';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import { PostVisitActionDialogProps } from '@modules/PostVisitActionDialog/PostVisitActionDialog';
import { getConfig } from '@utils/config';

vi.mock('@dexcare/yak');
vi.mock('@common/video');
vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        interactionEvent: vi.fn(),
    },
}));
vi.mock('@clients/VisitService/VisitServiceClient');
vi.mock('@redux/modules/tytoCare', () => ({
    setIsTytoCareVisit: vi.fn(),
}));
vi.mock('@redux/modules/selfView', () => ({
    initSelfView: vi.fn(),
}));
vi.mock('@redux/modules/userSettings', () => ({
    setAudioDeviceId: vi.fn(),
    setVideoDeviceId: vi.fn(),
}));
vi.mock('@redux/modules/videoMenu', () => ({
    toggleIsChatVisible: vi.fn(),
    setIsCamEnabled: vi.fn(),
    setIsMicEnabled: vi.fn(),
    setIsBlurEnabled: vi.fn(),
    setEndCallConfirmation: vi.fn(),
}));
vi.mock('@redux/modules/instantMessage', () => ({
    setVideoHasUnread: vi.fn(),
    setWaitingRoomHasUnread: vi.fn(),
}));
vi.mock('@redux/modules/postConsult', () => ({
    waiveVisit: vi.fn(),
    chargeVisit: vi.fn(),
    setMessageDialog: vi.fn(),
    setPostVisitAction: vi.fn(),
    transferBackToQueue: vi.fn(),
    transferToAnotherProvider: vi.fn(),
    convertModality: vi.fn(),
    fetchVisitDetailsByVisitId: vi.fn(),
    setPostVisitActionErrorMessage: vi.fn(),
    fetchTestVisitDetailsByVisitId: vi.fn(),
}));
vi.mock('@utils/FeatureFlags', () => ({
    FeatureFlags: {
        enableVisitModalityConversion: 'enable-visit-modality-conversion',
        enableVisitModalityConversionForTravelPatientCallCenter:
            'enable-visit-modality-conversion-for-travel-patient-call-center',
        endAndTransferVisit: 'end-and-transfer-visit',
        enableAiAssistant: 'enable-ai-assistant',
    },
    getFeatureFlag: vi.fn().mockReturnValue(false),
}));

const mockConnection: Connection = {
    connectionId: '2',
    creationTime: 15000,
    data: 'connection_data',
};
const mockStream: Stream = {
    streamId: 'mock_streamId',
    creationTime: 2000,
    frameRate: 2,
    hasAudio: true,
    hasVideo: true,
    name: 'mock_stream_name',
    videoDimensions: {
        width: 60,
        height: 60,
    },
    videoType: 'camera',
    connection: mockConnection,
    initials: 'mock_stream_initials',
};
const videoSessionId = 'TEST_VIDEO_SESSION_ID';
let updateWaitingRoomMessageMock: Mock;
let updateVideoInstantMessageMock: Mock;
let alertOfTytoCareIntegrationMock: Mock;
let getFeatureFlagMock: MockedFunction<typeof getFeatureFlag>;

type SessionWrapper = ShallowWrapper<
    SessionProps & Props,
    Readonly<SessionComponentState>,
    React.Component<SessionProps, SessionComponentState>
>;
const mockRunHealthCheck = (wrapper: SessionWrapper, full = true) => {
    wrapper.setProps({ health: { healthCheckProgress: 100 } as never });
    if (full) {
        wrapper.setProps({ health: { healthCheckProgress: 0 } as never });
    }
};
const buildProps = (): Props => {
    updateWaitingRoomMessageMock = vi.fn();
    updateVideoInstantMessageMock = vi.fn();
    alertOfTytoCareIntegrationMock = vi.fn();
    getFeatureFlagMock = getFeatureFlag as MockedFunction<
        typeof getFeatureFlag
    >;

    return {
        postVisitAction: null,
        postVisitActionErrorMessage: null,
        chargeVisit: vi.fn(),
        waiveVisit: vi.fn(),
        transferBackToQueue: vi.fn(),
        transferToAnotherProvider: vi.fn(),
        convertModality: vi.fn(),
        endCallConfirmation: false,
        enableCancelButton: true,
        blurEnabled: false,
        videoToken: 'MOCK_TOKEN',
        waitingRoomToken: 'MOCK_WAITING_ROOM_TOKEN',
        userDetails: {
            id: '1',
            displayName: 'provider',
            givenName: 'Provider',
            familyName: 'ofProviders',
            email: 'provider@fakeEmail.com',
            token: 'fakeToken',
            expiration: 2,
            roles: ['telehealth_provider'],
            sharedSessionStoreEnabled: false,
        },
        updateStreamCount: vi.fn(),
        updateInstantMessages: (sessionId: string) => {
            if (sessionId === videoSessionId) {
                return updateVideoInstantMessageMock;
            } else {
                return updateWaitingRoomMessageMock;
            }
        },
        onRemoteConnectionDetected: vi.fn(),
        endCall: vi.fn(),
        modalityConversion: vi.fn(),
        modalityConversionError: vi.fn(),
        transferOptions: {
            loading: false,
            providers: [],
            practiceRegions: [],
        },
        enableInstructionVideo: true,
        setPostVisitActionErrorMessage: vi.fn(),
        onCriticalError: vi.fn(),
        clearVideoRoomHasUnread: vi.fn(),
        clearWaitingRoomHasUnread: vi.fn(),
        toggleChatIsVisible: vi.fn(),
        initSelfView: vi.fn(),
        setBlurEnabled: vi.fn(),
        setPostVisitAction: vi.fn(),
        setEndCallConfirmation: vi.fn(),
        visitId: 'TEST_VISIT_ID',
        providerId: '1',
        isTestVisit: false,
        isChatVisible: false,
        videoSessionId,
        waitingRoomSessionId: 'TEST_WAITING_ROOM_SESSION_ID',
        instantMessages: {
            waitingInstantMessages: [],
            waitingRoomHasUnread: false,
            videoHasUnread: false,
            videoInstantMessages: [],
        },
        providerSelfCheckCompleted: false,
        handleSelfCheckClick: vi.fn(),
        health: {
            healthCheckProgress: 0,
            networkStatus: TestStatus.NotRun,
            camStatus: TestStatus.NotRun,
            micStatus: TestStatus.NotRun,
            mediaPermissionStatus: 'allowed',
            publishStatus: TestStatus.NotRun,
        },
        healthInfo: {
            healthCheckStatus: HealthCheckStatus.Healthy,
        },
        brand: 'swedish',
        runTests: vi.fn(),
        visitState: VideoCallRenderState.MultiParticipantDisplay,
        cancelVisit: vi.fn(),
        onReconnect: vi.fn(),
        handleNotification: vi.fn(),
        alertOfTytoCareIntegration: alertOfTytoCareIntegrationMock,
        videoEnabled: true,
        micEnabled: true,
        setCamEnabled: vi.fn(),
        setMicEnabled: vi.fn(),
        changeCam: vi.fn(),
        changeMic: vi.fn(),
        patientGuid: 'patientGuid',
        endCallAndTransfer: vi.fn(),
        endCallAndTransferError: vi.fn(),
        setMessageDialog: vi.fn(),
        fetchVisitDetailsByVisitId: vi.fn(),
        fetchTestVisitDetailsByVisitId: vi.fn(),
        setVisitStatus: vi.fn(),
    } as never;
};
const getSessionHelper = (wrapper: SessionWrapper) =>
    (wrapper.instance() as SessionComponent)
        .sessionHelper as Mocked<SessionHelper>;
const getPublisher = (wrapper: SessionWrapper) =>
    (wrapper.instance() as SessionComponent).selfViewPublisher;
const getWaitingRoomSessionHelper = (wrapper: SessionWrapper) =>
    (wrapper.instance() as SessionComponent).waitingRoomSessionHelper;
const getSessionHelperParams = (): SessionHelperInit =>
    (SessionHelper as MockedClass<typeof SessionHelper>).mock.calls[0][0];
const getWaitingRoomSessionHelperParams = (): SessionHelperInit =>
    (SessionHelper as MockedClass<typeof SessionHelper>).mock.calls[1][0];
const getWrapper = (props: Props): SessionWrapper =>
    shallow(<SessionComponent {...props} />) as SessionWrapper;
const createMockEvent: <T>(type: T) => Event<T, unknown> = (type) => ({
    type,
    target: {},
    cancelable: false,
    isDefaultPrevented: vi.fn(),
    preventDefault: vi.fn(),
});
const mockStore = configureMockStore();
const getInitialState = (defaultProps: Props) => ({
    postconsult: {
        visitId: defaultProps.visitId,
        providerId: defaultProps.providerId,
        patientGuid: defaultProps.patientGuid,
        isTestVisit: defaultProps.isTestVisit,
        postVisitAction: defaultProps.postVisitAction,
        postVisitActionErrorMessage: defaultProps.postVisitActionErrorMessage,
        isTravelingFromCallCenter: false,
    },
    patientNudges: 0,
    instantMessage: defaultProps.instantMessages,
    user: {
        userDetails: defaultProps.userDetails,
    },
    video: {
        isChatVisible: defaultProps.isChatVisible,
        isCamEnabled: defaultProps.videoEnabled,
        isMicEnabled: defaultProps.micEnabled,
        isBlurEnabled: defaultProps.blurEnabled,
        endCallConfirmation: defaultProps.endCallConfirmation,
        isInstructionVideoVisible: defaultProps.enableInstructionVideo,
        isCancelButtonVisible: defaultProps.enableCancelButton,
    },
    transferOptions: defaultProps.transferOptions,
});

describe('<Session />', () => {
    let defaultProps: Props;
    let wrapper: SessionWrapper;
    let mockStreamCreatedEvent: Event<string, unknown>;
    let mockStoreWithState: Store<unknown, AnyAction>;

    beforeEach(() => {
        vi.clearAllMocks();
        (SessionHelper as MockedClass<typeof SessionHelper>).mockClear();
        defaultProps = buildProps();
        mockStreamCreatedEvent =
            createMockEvent<'streamCreated'>('streamCreated');
        mockStoreWithState = mockStore(getInitialState(defaultProps));
    });
    test('The Redux store attributes should be correctly mapped to props.', () => {
        wrapper = shallow(
            <WrappedSessionComponent
                {...({ store: mockStoreWithState } as unknown as Props)}
            />,
        ).dive() as SessionWrapper;

        const sessionComponentProps = wrapper.props();

        expect(sessionComponentProps.visitId).toEqual(defaultProps.visitId);
        expect(sessionComponentProps.providerId).toEqual(
            defaultProps.providerId,
        );
        expect(sessionComponentProps.micEnabled).toEqual(
            defaultProps.micEnabled,
        );
        expect(sessionComponentProps.patientGuid).toEqual(
            defaultProps.patientGuid,
        );
        expect(sessionComponentProps.isTestVisit).toEqual(
            defaultProps.isTestVisit,
        );
        expect(sessionComponentProps.blurEnabled).toEqual(
            defaultProps.blurEnabled,
        );
        expect(sessionComponentProps.videoEnabled).toEqual(
            defaultProps.videoEnabled,
        );
        expect(sessionComponentProps.isChatVisible).toEqual(
            defaultProps.isChatVisible,
        );
        expect(sessionComponentProps.postVisitAction).toEqual(
            defaultProps.postVisitAction,
        );
        expect(sessionComponentProps.enableCancelButton).toEqual(
            defaultProps.enableCancelButton,
        );
        expect(sessionComponentProps.endCallConfirmation).toEqual(
            defaultProps.endCallConfirmation,
        );
        expect(sessionComponentProps.enableInstructionVideo).toEqual(
            defaultProps.enableInstructionVideo,
        );
        expect(sessionComponentProps.postVisitActionErrorMessage).toEqual(
            defaultProps.postVisitActionErrorMessage,
        );

        expect(sessionComponentProps.userDetails).toBe(
            defaultProps.userDetails,
        );
        expect(sessionComponentProps.instantMessages).toBe(
            defaultProps.instantMessages,
        );
    });
    test('All actions should be correctly mapped to props.', () => {
        wrapper = shallow(
            <WrappedSessionComponent
                {...({ store: mockStoreWithState } as unknown as Props)}
            />,
        ).dive() as SessionWrapper;

        const sessionComponentProps = wrapper.props();

        expect(sessionComponentProps.runTests).toBeDefined();
        expect(sessionComponentProps.changeCam).toBeDefined();
        expect(sessionComponentProps.changeMic).toBeDefined();
        expect(sessionComponentProps.waiveVisit).toBeDefined();
        expect(sessionComponentProps.chargeVisit).toBeDefined();
        expect(sessionComponentProps.initSelfView).toBeDefined();
        expect(sessionComponentProps.setCamEnabled).toBeDefined();
        expect(sessionComponentProps.setMicEnabled).toBeDefined();
        expect(sessionComponentProps.setBlurEnabled).toBeDefined();
        expect(sessionComponentProps.setMessageDialog).toBeDefined();
        expect(sessionComponentProps.setPostVisitAction).toBeDefined();
        expect(sessionComponentProps.transferBackToQueue).toBeDefined();
        expect(sessionComponentProps.toggleChatIsVisible).toBeDefined();
        expect(sessionComponentProps.setEndCallConfirmation).toBeDefined();
        expect(sessionComponentProps.clearVideoRoomHasUnread).toBeDefined();
        expect(sessionComponentProps.clearWaitingRoomHasUnread).toBeDefined();
        expect(sessionComponentProps.transferToAnotherProvider).toBeDefined();
        expect(sessionComponentProps.alertOfTytoCareIntegration).toBeDefined();
        expect(sessionComponentProps.fetchVisitDetailsByVisitId).toBeDefined();
        expect(
            sessionComponentProps.setPostVisitActionErrorMessage,
        ).toBeDefined();
        expect(
            sessionComponentProps.fetchTestVisitDetailsByVisitId,
        ).toBeDefined();
        expect(sessionComponentProps.convertModality).toBeDefined();
    });
    test('error in mount', () => {
        defaultProps.videoToken = undefined;
        wrapper = getWrapper(defaultProps);

        expect(wrapper.state().otConnectionStatus).toEqual('error');
    });
    describe('waitingroom', () => {
        beforeEach(() => {
            defaultProps.userDetails.roles = ['telehealth_patient'];
            defaultProps.visitState = VideoCallRenderState.PatientWaitingRoom;
            vi.useFakeTimers();
        });

        test('mounts and inits waitingroom session if user is a patient', () => {
            wrapper = getWrapper(defaultProps);
            expect(toJson(wrapper)).toMatchSnapshot();

            expect(SessionHelper).toHaveBeenCalledTimes(2);
            expect(
                getWaitingRoomSessionHelper(wrapper).connect,
            ).toHaveBeenCalledWith(
                defaultProps.waitingRoomToken,
                expect.any(Function),
            );
            expect(getSessionHelper(wrapper).connect).not.toHaveBeenCalledWith(
                defaultProps.videoToken,
                expect.any(Function),
            );
        });
        test('inits video session when healthcheck completes', () => {
            wrapper = getWrapper(defaultProps);

            expect(getSessionHelper(wrapper).connect).not.toHaveBeenCalledWith(
                defaultProps.videoToken,
                expect.any(Function),
            );

            mockRunHealthCheck(wrapper);
            expect(getSessionHelper(wrapper).connect).toHaveBeenCalledWith(
                defaultProps.videoToken,
                expect.any(Function),
            );
        });
        test('does not init video session before healthcheck completes', () => {
            wrapper = getWrapper(defaultProps);

            expect(getSessionHelper(wrapper).connect).not.toHaveBeenCalledWith(
                defaultProps.videoToken,
                expect.any(Function),
            );

            mockRunHealthCheck(wrapper, false);
            expect(getSessionHelper(wrapper).connect).not.toHaveBeenCalledWith(
                defaultProps.videoToken,
                expect.any(Function),
            );
        });
        test('waiting room snapshot', () => {
            wrapper = getWrapper(defaultProps);
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        test('waiting room calls props cancel', () => {
            wrapper = getWrapper(defaultProps);
            (
                wrapper
                    .find(WaitingRoomComponent)
                    .first()
                    .props() as WaitingRoomProps
            ).cancelVisit();

            expect(defaultProps.cancelVisit).toHaveBeenCalledTimes(1);
        });
        test('waiting room toggles chat', () => {
            wrapper = getWrapper(defaultProps);
            (
                wrapper
                    .find(WaitingRoomComponent)
                    .first()
                    .props() as WaitingRoomProps
            ).onChatClick();

            expect(defaultProps.toggleChatIsVisible).toHaveBeenCalledTimes(1);
        });
        test('waiting room read all messages', () => {
            wrapper = getWrapper(defaultProps);
            (
                wrapper.find(ChatPage).first().props() as ChatPageProps
            ).instantMessageProps.onAllMessagesRead();

            expect(
                defaultProps.clearWaitingRoomHasUnread,
            ).toHaveBeenCalledTimes(1);
        });
        test('calls runtests', () => {
            wrapper = getWrapper(defaultProps);
            (
                wrapper
                    .find(WaitingRoomComponent)
                    .first()
                    .props() as WaitingRoomProps
            ).runTests({} as Publisher);

            expect(defaultProps.runTests).toHaveBeenCalledTimes(1);
        });
        test('calls clearWaitingRoomHasUnread', () => {
            wrapper = getWrapper(defaultProps);
            (
                wrapper.find(ChatPage).first().props() as ChatPageProps
            ).instantMessageProps.onAllMessagesRead();

            expect(
                defaultProps.clearWaitingRoomHasUnread,
            ).toHaveBeenCalledTimes(1);
        });
        test('onInstantMessage outgoing', () => {
            wrapper = getWrapper(defaultProps);
            const message = {
                fromParticipant: 'me!',
                senderId: defaultProps.userDetails.id,
                creationTime: '800',
                uniqueId: 'unique',
                message: 'this is an instant message!',
            };
            getWaitingRoomSessionHelperParams().signalingHandlers.onInstantMessage(
                message,
            );
            expect(updateWaitingRoomMessageMock).toHaveBeenCalledTimes(1);
            expect(updateWaitingRoomMessageMock).toHaveBeenCalledWith(message);
        });
        test('onInstantMessage incoming', () => {
            wrapper = getWrapper(defaultProps);
            const message = {
                fromParticipant: 'provider',
                senderId: 'providerId',
                creationTime: '800',
                uniqueId: 'unique',
                message: 'this is an instant message!',
            };

            getWaitingRoomSessionHelperParams().signalingHandlers.onInstantMessage(
                message,
            );
            expect(updateWaitingRoomMessageMock).toHaveBeenCalledTimes(1);
            expect(updateWaitingRoomMessageMock).toHaveBeenCalledWith(message);
        });
        test('onTypingMessage', () => {
            wrapper = getWrapper(defaultProps);
            const mockTypingState = {
                typingState: 1,
                displayName: 'fastTyper',
            };
            getWaitingRoomSessionHelperParams().signalingHandlers.onTypingStateChange(
                mockTypingState,
            );

            expect(wrapper.state().waitingRoomRemoteTypingState).toEqual(
                mockTypingState,
            );
        });
        test('handleNotification', () => {
            wrapper = getWrapper(defaultProps);

            getWaitingRoomSessionHelperParams().signalingHandlers.onNotification();

            expect(defaultProps.handleNotification).toHaveBeenCalledTimes(1);
        });
        test('staffdeclined ends the call', () => {
            wrapper = getWrapper(defaultProps);

            getWaitingRoomSessionHelperParams().signalingHandlers.onVisitStatusChange(
                'staffdeclined',
            );

            expect(defaultProps.endCall).toHaveBeenCalled();
        });
        test('sendBotPromptResponse - send bot prompt', () => {
            (
                getFeatureFlag as MockedFunction<typeof getFeatureFlag>
            ).mockImplementation((ff) => {
                if (ff === FeatureFlags.enableAiAssistant) {
                    return true;
                }
                return false;
            });
            wrapper = getWrapper(defaultProps);

            const instantMessage: BotPromptMessage = {
                fromParticipant: 'University Health AI',
                senderId: 'meow',
                creationTime: `${new Date().getTime()}`,
                uniqueId: v4(),
                prompt: '',
                options: ['Yes', 'No'],
                isBot: true,
            };

            getWaitingRoomSessionHelperParams().signalingHandlers.onBotPromptMessage(
                instantMessage,
            );
            expect(updateWaitingRoomMessageMock).toHaveBeenCalledTimes(1);
        });
        test('sendBotPromptResponse - send bot prompt - behind feature flag', () => {
            (
                getFeatureFlag as MockedFunction<typeof getFeatureFlag>
            ).mockReturnValue(false);
            wrapper = getWrapper(defaultProps);

            const instantMessage: BotPromptMessage = {
                fromParticipant: 'University Health AI',
                senderId: 'meow',
                creationTime: `${new Date().getTime()}`,
                uniqueId: v4(),
                prompt: '',
                options: ['Yes', 'No'],
                isBot: true,
            };

            getWaitingRoomSessionHelperParams().signalingHandlers.onBotPromptMessage(
                instantMessage,
            );
            expect(updateWaitingRoomMessageMock).toHaveBeenCalledTimes(0);
        });
        test('sendBotPromptResponse - send patient response', () => {
            (
                getFeatureFlag as MockedFunction<typeof getFeatureFlag>
            ).mockImplementation((ff) => {
                if (ff === FeatureFlags.enableAiAssistant) {
                    return true;
                }
                return false;
            });
            wrapper = getWrapper(defaultProps);

            const instantMessage: BotPromptMessage = {
                fromParticipant: 'Patient',
                senderId: 'meow',
                creationTime: `${new Date().getTime()}`,
                uniqueId: v4(),
                prompt: 'are bees real',
                options: ['Yes', 'No'],
                isBot: false,
                selectedOption: 'Yes',
            };

            getWaitingRoomSessionHelperParams().signalingHandlers.onBotPromptMessage(
                instantMessage,
            );
            expect(updateWaitingRoomMessageMock).not.toHaveBeenCalled();
        });
        test('sendBotPromptResponse - sends reminder message', () => {
            (
                getFeatureFlag as MockedFunction<typeof getFeatureFlag>
            ).mockImplementation((ff) => {
                if (ff === FeatureFlags.enableAiAssistant) {
                    return true;
                }
                return false;
            });
            wrapper = getWrapper(defaultProps);

            const instantMessage: BotPromptMessage = {
                fromParticipant: 'University Health AI',
                senderId: 'meow',
                creationTime: `${new Date().getTime()}`,
                uniqueId: v4(),
                prompt: 'reminder',
                options: ['Yes', 'No'],
                isBot: true,
            };

            getWaitingRoomSessionHelperParams().signalingHandlers.onBotPromptMessage(
                instantMessage,
            );
            const {
                chatbot: { botPatientResponseTimeSeconds, patientNudgeLimit },
            } = getConfig();
            let patientNudges = 0;
            wrapper.setState({ patientNudges: patientNudges });
            // run above patient nudge limit to ensure another message is not sent
            for (let i = 0; i < patientNudgeLimit + 1; i++) {
                patientNudges += 1;
                wrapper.setState({ patientNudges: patientNudges });
                vi.advanceTimersByTime(botPatientResponseTimeSeconds * 1000);
            }
            expect(updateWaitingRoomMessageMock).toHaveBeenCalledTimes(3);
        });
        test('unknown visit state does not end the call', () => {
            wrapper = getWrapper(defaultProps);

            getWaitingRoomSessionHelperParams().signalingHandlers.onVisitStatusChange(
                'invisit',
            );

            expect(defaultProps.endCall).not.toHaveBeenCalled();
        });
    });
    describe('anteroom', () => {
        beforeEach(() => {
            defaultProps.visitState = VideoCallRenderState.AnteRoom;
        });
        afterAll(() => {
            defaultProps.fetchVisitDetailsByVisitId = vi.fn();
        });
        test('connects on selfCheckClick if assigned provider', async () => {
            defaultProps.fetchVisitDetailsByVisitId = vi
                .fn()
                .mockReturnValueOnce({ providerId: '1' });
            wrapper = getWrapper(defaultProps);
            await (
                wrapper.find(AnteRoomComponent).first().props() as {
                    onConnect: () => Promise<void>;
                }
            ).onConnect();

            expect(getSessionHelper(wrapper).connect).toHaveBeenCalled();
            expect(getSessionHelper(wrapper).connect).toHaveBeenCalledWith(
                defaultProps.videoToken,
                expect.any(Function),
            );
            expect(defaultProps.handleSelfCheckClick).toHaveBeenCalledTimes(1);
        });
        test('displays message dialog on selfCheckClick if not assigned provider', async () => {
            defaultProps.fetchVisitDetailsByVisitId = vi
                .fn()
                .mockReturnValueOnce({ providerId: 'testprovider' });
            wrapper = getWrapper(defaultProps);
            await (
                wrapper.find(AnteRoomComponent).first().props() as {
                    onConnect: () => Promise<void>;
                }
            ).onConnect();

            expect(defaultProps.setMessageDialog).toHaveBeenCalled();
        });
        test('calls runtests', () => {
            wrapper = getWrapper(defaultProps);
            (
                wrapper.find(AnteRoomComponent).first().props() as {
                    runTests: (publisher: Publisher) => void;
                }
            ).runTests({} as Publisher);

            expect(defaultProps.runTests).toHaveBeenCalledTimes(1);
        });
    });
    describe('invisit', () => {
        beforeEach(() => {
            defaultProps.visitState =
                VideoCallRenderState.MultiParticipantDisplay;
        });
        test('mounts', () => {
            wrapper = getWrapper(defaultProps);
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        test('calls publish', async () => {
            wrapper = getWrapper(defaultProps);
            await (
                wrapper.find(MultiParticipantDisplay).first().props() as {
                    publish: () => Promise<void>;
                }
            ).publish();
            expect(getSessionHelper(wrapper).publish).toHaveBeenCalledTimes(1);
            expect(getSessionHelper(wrapper).publish).toHaveBeenCalledWith(
                {},
                expect.any(Function),
            );
            expect(wrapper.state().otPublishingStatus).toEqual(
                'publishStarted',
            );
        });
        test('publish success sets state', async () => {
            wrapper = getWrapper(defaultProps);
            await (
                wrapper.find(MultiParticipantDisplay).first().props() as {
                    publish: () => Promise<void>;
                }
            ).publish();

            const successFn =
                getSessionHelper(wrapper).publish.mock.calls[0][1];
            successFn();
            expect(wrapper.state().otPublishingStatus).toEqual(
                'publishSuccess',
            );
        });
        test('publish error sets state', async () => {
            wrapper = getWrapper(defaultProps);
            await (
                wrapper.find(MultiParticipantDisplay).first().props() as {
                    publish: () => Promise<void>;
                }
            ).publish();

            const successFn =
                getSessionHelper(wrapper).publish.mock.calls[0][1];
            successFn({ name: '', message: 'error!' });
            expect(wrapper.state().otPublishingStatus).toEqual(
                'publishFailure',
            );
        });
    });
    test('onStreamCreated', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        getSessionHelperParams().sessionHandlers.onStreamCreated({
            ...mockStreamCreatedEvent,
            stream: mockStream,
        } as StreamCreatedEvent);

        expect(defaultProps.updateStreamCount).toHaveBeenCalledTimes(1);
        expect(defaultProps.updateStreamCount).toHaveBeenCalledWith(1);
        expect(wrapper.state().otStreams.length).toEqual(1);
        expect(wrapper.state().otStreams[0]).toEqual(mockStream);
    });
    test('onStreamPropertyChanged - calls forceVideoEnabled when state mismatches', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (
            getSessionHelper(wrapper).getLocalConnectionData as Mock
        ).mockReturnValue({ connectionId: mockStream.connection.connectionId });
        getSessionHelperParams().sessionHandlers.onStreamPropertyChanged({
            changedProperty: 'hasVideo',
            oldValue: true,
            newValue: false,
            stream: mockStream,
        } as StreamPropertyChangedEvent);

        expect(getPublisher(wrapper).publishVideo).toHaveBeenCalledTimes(1);
        expect(getPublisher(wrapper).publishVideo).toHaveBeenCalledWith(true);
    });
    test('onStreamPropertyChanged - does not call forceVideoEnabled when state matches', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (
            getSessionHelper(wrapper).getLocalConnectionData as Mock
        ).mockReturnValue({ connectionId: mockStream.connection.connectionId });
        getSessionHelperParams().sessionHandlers.onStreamPropertyChanged({
            changedProperty: 'hasVideo',
            oldValue: false,
            newValue: true,
            stream: mockStream,
        } as StreamPropertyChangedEvent);

        expect(getPublisher(wrapper).publishVideo).not.toHaveBeenCalled();
    });
    test('onStreamPropertyChanged - does not call forceVideoEnabled when state mismatches if it is a different participant', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (
            getSessionHelper(wrapper).getLocalConnectionData as Mock
        ).mockReturnValue({ connectionId: 'someoneElse' });
        getSessionHelperParams().sessionHandlers.onStreamPropertyChanged({
            changedProperty: 'hasVideo',
            oldValue: true,
            newValue: false,
            stream: mockStream,
        } as StreamPropertyChangedEvent);

        expect(getPublisher(wrapper).publishVideo).not.toHaveBeenCalled();
    });
    test('onStreamPropertyChanged - calls forceAudioEnabled when state mismatches', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (
            getSessionHelper(wrapper).getLocalConnectionData as Mock
        ).mockReturnValue({ connectionId: mockStream.connection.connectionId });
        getSessionHelperParams().sessionHandlers.onStreamPropertyChanged({
            changedProperty: 'hasAudio',
            oldValue: true,
            newValue: false,
            stream: mockStream,
        } as StreamPropertyChangedEvent);

        expect(getPublisher(wrapper).publishAudio).toHaveBeenCalledTimes(1);
        expect(getPublisher(wrapper).publishAudio).toHaveBeenCalledWith(true);
    });
    test('onStreamPropertyChanged - does not call forceAudioEnabled when state mismatches if it is a different participant', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (
            getSessionHelper(wrapper).getLocalConnectionData as Mock
        ).mockReturnValue({ connectionId: 'someoneElse' });
        getSessionHelperParams().sessionHandlers.onStreamPropertyChanged({
            changedProperty: 'hasAudio',
            oldValue: true,
            newValue: false,
            stream: mockStream,
        } as StreamPropertyChangedEvent);

        expect(getPublisher(wrapper).publishAudio).not.toHaveBeenCalled();
    });
    test('onStreamDestroyed', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        getSessionHelperParams().sessionHandlers.onStreamCreated({
            ...mockStreamCreatedEvent,
            stream: mockStream,
        } as StreamCreatedEvent);
        expect(defaultProps.updateStreamCount).toHaveBeenCalledWith(1);
        expect(wrapper.state().otStreams.length).toEqual(1);

        const destroyedEvent =
            createMockEvent<'streamDestroyed'>('streamDestroyed');
        getSessionHelperParams().sessionHandlers.onStreamDestroyed({
            ...destroyedEvent,
            stream: mockStream,
            reason: 'DENIED',
        } as never);

        expect(defaultProps.updateStreamCount).toHaveBeenCalledTimes(2);
        expect(defaultProps.updateStreamCount).toHaveBeenCalledWith(0);
        expect(wrapper.state().otStreams.length).toEqual(0);
    });
    test('onSessionConnected', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const mockEvent =
            createMockEvent<'sessionConnected'>('sessionConnected');

        getSessionHelperParams().sessionHandlers.onSessionConnected(
            mockEvent as never,
        );
        expect(wrapper.state().otConnectionStatus).toEqual('sessionConnected');
    });
    test('onSessionReconnected', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const mockEvent =
            createMockEvent<'sessionReconnected'>('sessionReconnected');
        getSessionHelperParams().sessionHandlers.onSessionReconnected(
            mockEvent as never,
        );

        expect(wrapper.state().otConnectionStatus).toEqual(
            'sessionReconnected',
        );
    });
    test('onSessionReconnecting', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const mockEvent = createMockEvent<'sessionReconnecting'>(
            'sessionReconnecting',
        );
        getSessionHelperParams().sessionHandlers.onSessionReconnecting(
            mockEvent as never,
        );
        expect(wrapper.state().otConnectionStatus).toEqual(
            'sessionReconnecting',
        );
    });
    test('onSessionDisconnected', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const mockEvent = createMockEvent<'sessionDisconnected'>(
            'sessionDisconnected',
        );
        getSessionHelperParams().sessionHandlers.onSessionDisconnected({
            ...mockEvent,
            reason: 'denied!',
        } as never);
        expect(wrapper.state().otConnectionStatus).toEqual(
            'sessionDisconnected',
        );
    });
    test('onSessionDisconnected fires analytics event on patient side', () => {
        defaultProps.userDetails.roles = ['telehealth_patient'];
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const mockEvent = createMockEvent<'sessionDisconnected'>(
            'sessionDisconnected',
        );
        getSessionHelperParams().sessionHandlers.onSessionDisconnected({
            ...mockEvent,
            reason: 'denied!',
        } as never);
        expect(wrapper.state().otConnectionStatus).toEqual(
            'sessionDisconnected',
        );
        expect(V2Analytics.interactionEvent).toHaveBeenCalledTimes(1);
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'patient_disconnects',
            patient_id: 'patientGuid',
            visit_id: 'TEST_VISIT_ID',
        });
    });
    test('onRemoteParticipantConnectionCreated', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const mockEvent =
            createMockEvent<'connectionCreated'>('connectionCreated');

        getSessionHelperParams().sessionHandlers.onRemoteParticipantConnectionCreated(
            {
                ...mockEvent,
                connection: mockConnection,
            } as never,
        );
        expect(defaultProps.onRemoteConnectionDetected).toHaveBeenCalledTimes(
            1,
        );
    });
    test('onIntegrationAlert', () => {
        wrapper = getWrapper(defaultProps);
        const mockIntegrationAlert: IntegrationAlert = {
            integration: 'tytocare',
            details: {
                activated: true,
            },
        };
        getSessionHelperParams().signalingHandlers.onIntegrationAlert(
            mockIntegrationAlert,
        );
        expect(alertOfTytoCareIntegrationMock).toHaveBeenCalledTimes(1);
    });
    test('onIntegrationAlert not called for unsupported integration', () => {
        wrapper = getWrapper(defaultProps);
        const mockIntegrationAlert: IntegrationAlert = {
            integration: 'not-supported-integration',
            details: {
                activated: true,
            },
        };
        getSessionHelperParams().signalingHandlers.onIntegrationAlert(
            mockIntegrationAlert,
        );
        expect(alertOfTytoCareIntegrationMock).not.toHaveBeenCalled();
    });
    test('onIntegrationAlert is not called for the patient', () => {
        defaultProps.userDetails.roles = ['telehealth_patient'];
        wrapper = getWrapper(defaultProps);
        const mockIntegrationAlert: IntegrationAlert = {
            integration: 'tytocare',
            details: {
                activated: true,
            },
        };
        getSessionHelperParams().signalingHandlers.onIntegrationAlert(
            mockIntegrationAlert,
        );
        expect(alertOfTytoCareIntegrationMock).not.toHaveBeenCalled();
    });
    test('onInstantMessage outgoing', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const message = {
            fromParticipant: 'me!',
            senderId: defaultProps.userDetails.id,
            creationTime: '800',
            uniqueId: 'unique',
            message: 'this is an instant message!',
        };
        getSessionHelperParams().signalingHandlers.onInstantMessage(message);
        expect(updateVideoInstantMessageMock).toHaveBeenCalledTimes(1);
        expect(updateVideoInstantMessageMock).toHaveBeenCalledWith(message);
    });
    test('onInstantMessage incoming', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const message = {
            fromParticipant: 'patient',
            senderId: 'patientId',
            creationTime: '800',
            uniqueId: 'unique',
            message: 'this is an instant message!',
        };

        getSessionHelperParams().signalingHandlers.onInstantMessage(message);
        expect(updateVideoInstantMessageMock).toHaveBeenCalledTimes(1);
        expect(updateVideoInstantMessageMock).toHaveBeenCalledWith(message);
    });
    test('onTypingMessage', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const mockTypingState = {
            typingState: 1,
            displayName: 'fastTyper',
        };
        getSessionHelperParams().signalingHandlers.onTypingStateChange(
            mockTypingState,
        );

        expect(wrapper.state().videoRemoteTypingState).toEqual(mockTypingState);
    });
    test('onVisitStatusChange - declined ends call', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        getSessionHelperParams().signalingHandlers.onVisitStatusChange(
            'staffdeclined',
        );

        expect(defaultProps.endCall).toHaveBeenCalledTimes(1);
        expect(defaultProps.endCall).toHaveBeenCalledWith('declined');
    });
    test('onVisitStatusChange - not declined does not end call', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        getSessionHelperParams().signalingHandlers.onVisitStatusChange(
            'notstaffdeclined',
        );

        expect(defaultProps.endCall).not.toHaveBeenCalled();
    });
    test('onVisitStatusChange - waitingroom does not end call', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        getSessionHelperParams().signalingHandlers.onVisitStatusChange(
            'waitingroom',
        );

        expect(defaultProps.modalityConversion).not.toHaveBeenCalled();
    });
    test('onParticipantLeft', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        getSessionHelperParams().signalingHandlers.onParticipantLeft();

        expect(defaultProps.endCall).toHaveBeenCalledTimes(1);
        expect(defaultProps.endCall).toHaveBeenCalledWith('remote');
    });
    test('onParticipantDetails - remote is not provider so onCriticalError not called', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        getSessionHelperParams().signalingHandlers.onParticipantDetails({
            isProvider: false,
            senderId: 'patientId',
            connectionCreationTime: 800,
        });

        expect(defaultProps.onCriticalError).not.toHaveBeenCalled();
    });
    test('onParticipantDetails - same provider joins - local joined first, so onCriticalError called with joinedElsewhere', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (
            wrapper.instance() as SessionComponent
        ).sessionHelper.getLocalConnectionData = vi.fn(() => {
            return {
                creationTime: 50000,
                connectionId: 'mockConnectionId',
                data: 'mockData',
            };
        });
        getSessionHelperParams().signalingHandlers.onParticipantDetails({
            isProvider: true,
            senderId: defaultProps.userDetails.id,
            connectionCreationTime: 80000,
        });

        expect(defaultProps.onCriticalError).toHaveBeenCalledTimes(1);
        expect(defaultProps.onCriticalError).toHaveBeenCalledWith(
            ConferenceError.JoinedElsewhere,
        );
    });
    test('onParticipantDetails - same provider joins - local joined second, so onCriticalError not called', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (
            wrapper.instance() as SessionComponent
        ).sessionHelper.getLocalConnectionData = vi.fn(() => {
            return {
                creationTime: 50000,
                connectionId: 'mockConnectionId',
                data: 'mockData',
            };
        });
        getSessionHelperParams().signalingHandlers.onParticipantDetails({
            isProvider: true,
            senderId: defaultProps.userDetails.id,
            connectionCreationTime: 30000,
        });

        expect(defaultProps.onCriticalError).not.toHaveBeenCalled();
    });
    test('onParticipantDetails - different provider joins - local joined second, so onCriticalError called', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (
            wrapper.instance() as SessionComponent
        ).sessionHelper.getLocalConnectionData = vi.fn(() => {
            return {
                creationTime: 50000,
                connectionId: 'mockConnectionId',
                data: 'mockData',
            };
        });
        getSessionHelperParams().signalingHandlers.onParticipantDetails({
            isProvider: true,
            senderId: 'different_provider',
            connectionCreationTime: 30000,
        });

        expect(defaultProps.onCriticalError).toHaveBeenCalledTimes(1);
        expect(defaultProps.onCriticalError).toHaveBeenCalledWith(
            ConferenceError.ConferenceFull,
        );
    });
    test('onParticipantDetails - different provider joins - local joined first, so onCriticalError not called', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (
            wrapper.instance() as SessionComponent
        ).sessionHelper.getLocalConnectionData = vi.fn(() => {
            return {
                creationTime: 50000,
                connectionId: 'mockConnectionId',
                data: 'mockData',
            };
        });
        getSessionHelperParams().signalingHandlers.onParticipantDetails({
            isProvider: true,
            senderId: 'different_provider',
            connectionCreationTime: 80000,
        });

        expect(defaultProps.onCriticalError).not.toHaveBeenCalled();
    });
    test('sendMessage', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const message = 'I am an instant Message!';
        (wrapper.instance() as SessionComponent).sendVideoConferenceMessage(
            message,
        );
        const expectedMessage = {
            fromParticipant: defaultProps.userDetails.displayName,
            senderId: defaultProps.userDetails.id,
            creationTime: expect.any(String) as string,
            uniqueId: expect.any(String) as string,
            message,
        };
        expect(getSessionHelper(wrapper).sendInstantMessage).toBeCalledTimes(1);
        expect(getSessionHelper(wrapper).sendInstantMessage).toBeCalledWith(
            expectedMessage,
            expect.any(Function),
        );
    });
    test('sendEndCall', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (wrapper.instance() as SessionComponent).sendEndCall();

        expect(getSessionHelper(wrapper).sendEndCall).toBeCalledTimes(1);
        expect(getSessionHelper(wrapper).sendEndCall).toBeCalledWith(
            expect.any(Function),
        );
    });
    test('endCallSuccess', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (wrapper.instance() as SessionComponent).endCallSuccess();

        expect(defaultProps.endCall).toBeCalledTimes(1);
        expect(defaultProps.endCall).toBeCalledWith('user');
    });
    test('endCallSuccess fires analytics on patient side', () => {
        defaultProps.userDetails.roles = ['telehealth_patient'];
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        (wrapper.instance() as SessionComponent).endCallSuccess();

        expect(defaultProps.endCall).toBeCalledTimes(1);
        expect(defaultProps.endCall).toBeCalledWith('user');
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'patient_ends_session',
            patient_id: 'patientGuid',
            visit_id: 'TEST_VISIT_ID',
        });
    });
    test('handle endCallAndTransfer', () => {
        wrapper = getWrapper(defaultProps);

        getSessionHelperParams().signalingHandlers.onEndCallAndTransfer();

        expect(defaultProps.endCallAndTransfer).toHaveBeenCalledTimes(1);
    });
    test('handle endCallAndTransferError', () => {
        wrapper = getWrapper(defaultProps);

        getSessionHelperParams().signalingHandlers.onEndCallAndTransferError();

        expect(defaultProps.endCallAndTransferError).toHaveBeenCalledTimes(1);
    });
    test('handle onModalityConversion', () => {
        defaultProps.userDetails.roles = ['telehealth_patient'];
        wrapper = getWrapper(defaultProps);

        getSessionHelperParams().signalingHandlers.onModalityConversion();

        expect(defaultProps.modalityConversion).toHaveBeenCalledTimes(1);
    });
    test('handle onModalityConversionError', () => {
        wrapper = getWrapper(defaultProps);

        getSessionHelperParams().signalingHandlers.onModalityConversionError();

        expect(defaultProps.modalityConversionError).toHaveBeenCalledTimes(1);
    });
    test('handle post visit action dialog confirm', () => {
        getFeatureFlagMock.mockImplementation(() => true);
        defaultProps.postVisitAction = {
            selectedAction: 'convert-visit',
            selectedModalityConversionReason: 'Reason 1',
        };
        wrapper = getWrapper(defaultProps);

        const postVisitActionDialog = wrapper
            .find('PostVisitActionDialog')
            .props() as unknown as PostVisitActionDialogProps;

        postVisitActionDialog.onConfirm();

        expect(postVisitActionDialog.showConvertModalityOption).toBe(true);
        expect(defaultProps.convertModality).toHaveBeenCalledWith(
            'TEST_VISIT_ID',
            'Reason 1',
        );
    });
    test('handle visit for traveling patient from a call center', () => {
        getFeatureFlagMock.mockImplementation(
            (flag) => flag === FeatureFlags.enableVisitModalityConversion,
        );
        defaultProps.isTravelingFromCallCenter = true;
        wrapper = getWrapper(defaultProps);

        const postVisitActionDialog = wrapper
            .find('PostVisitActionDialog')
            .props() as unknown as PostVisitActionDialogProps;

        expect(postVisitActionDialog.showConvertModalityOption).toBe(false);
    });
    test('unmount cleans up', () => {
        wrapper = shallow(
            <SessionComponent {...defaultProps} />,
        ) as SessionWrapper;
        const sessionHelper = getSessionHelper(wrapper);
        wrapper.unmount();

        expect(sessionHelper.destroy).toHaveBeenCalledTimes(1);
    });
});
