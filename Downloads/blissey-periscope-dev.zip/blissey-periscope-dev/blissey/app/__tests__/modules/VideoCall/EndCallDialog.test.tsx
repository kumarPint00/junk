import * as React from 'react';
import { vi } from 'vitest';
import {
    RawEndCallDialog,
    EndCallDialog,
    EndCallDialogProps,
} from '@modules/VideoCall/EndCallDialog';
import { Provider } from 'react-redux';
import { render } from '@testing-library/react';
import { getLocalState } from '@redux/middleware/localStorage';
import { initialState } from '@redux/modules';
import configureStore from 'redux-mock-store';
import * as redux from 'react-redux';
import { i18n } from 'i18next';

const localState = getLocalState(initialState);
const mockStore = configureStore([]);
const store = mockStore(localState);

describe('<EndCallDialog />', () => {
    const defaultProps = {
        onEndCall: vi.fn(),
        t: vi.fn().mockReturnValue(''),
    };
    const props = {
        ...defaultProps,
        i18n: {} as i18n,
        tReady: false,
    } as unknown as EndCallDialogProps;
    test('displays the component', () => {
        const { container } = render(
            <Provider store={store}>
                <EndCallDialog {...defaultProps} />
            </Provider>,
        );
        expect(container).toMatchSnapshot();
    });

    test('Test end call dialog', () => {
        vi.spyOn(redux, 'useSelector').mockReturnValue({
            video: { endCallConfirmation: true },
        });
        vi.spyOn(redux, 'useDispatch').mockReturnValue(vi.fn());
        const { container } = render(
            <Provider store={store}>
                <RawEndCallDialog {...props} />
            </Provider>,
        );
        expect(container).toMatchSnapshot();
    });
});
