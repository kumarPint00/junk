import * as React from 'react';
import * as sinon from 'sinon';
// import { mount } from 'enzyme'; // May be needed for commented test
import { ShallowWrapper, shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import thunk from 'redux-thunk';
import { Provider } from 'react-redux';
import { render, configure } from '@testing-library/react';
import configureMockStore from 'redux-mock-store';

import { UserDetails } from '@dexcare/circus-saturn';
import WrappedVideoCallModule, {
    VideoCallModule,
    Props as AllProps,
    Props,
} from '../../../src/modules/VideoCall/VideoCallModule';
import { TestStatus } from '@common/video';
import { HealthCheckStatus } from '../../../src/common/ConnectionTest/HealthCheckStatus';
import Session, { SessionProps } from '@modules/VideoCall/Session';
import { TState as HealthCheckState } from '@redux/modules/health';
import { VideoCallRenderState } from '@modules/VideoCall/VideoCallRenderState';
import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';
import {
    VideoCallModuleProps,
    VideoCallModuleState,
} from '@modules/VideoCall/VideoCallInterfaces';
import { AnyAction, Store } from 'redux';

interface VideoCallModuleWrapperProps {
    visitState: keyof VideoCallRenderState;
    updateStreamCount: (arg: number) => void;
    endCall: (arg: string) => Promise<void>;
    endCallAndTransfer: () => void;
    endCallAndTransferError: (arg: unknown) => void;
}

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: {
        sendEvent: vi.fn(),
        sendPageView: vi.fn(),
    },
    V2Analytics: {
        errorEvent: vi.fn(),
        interactionEvent: vi.fn(),
        pageViewEvent: vi.fn(),
    },
}));

vi.mock('@utils/Notification', () => ({
    isDocumentVisible: vi.fn().mockReturnValue(false),
    notifyUser: vi.fn(),
    initNotifications: vi.fn(),
    NotificationType: {},
}));

vi.mock('@utils/callDuration', () => ({
    getDuration: vi.fn().mockReturnValue({
        durationNumber: 610000,
        durationString: '00:10:02',
    }),
}));

vi.mock('@redux/modules/postConsult', () => ({
    cancelVisit: vi.fn(),
    chargeVisit: vi.fn(),
    setPostVisitActionErrorMessage: vi.fn(),
    setMessageDialog: vi.fn(),
}));

vi.mock('@redux/modules/postConsult', async (importOriginal) => {
    const actual = await importOriginal();
    return {
        ...(actual as object),
        cancelVisit: vi.fn(),
        chargeVisit: vi.fn(),
        setPostVisitActionErrorMessage: vi.fn(),
        setMessageDialog: vi.fn(),
    };
});

vi.mock('@redux/modules/instantMessage', async (importOriginal) => {
    const actual = await importOriginal();
    return {
        ...(actual as object),
        addWaitingInstantMessages: vi.fn(),
        addVideoInstantMessage: vi.fn(),
        setVideoHasUnread: vi.fn(),
        setWaitingRoomHasUnread: vi.fn(),
    };
});

vi.mock('@redux/modules/videoMenu', async (importOriginal) => {
    const actual = await importOriginal();
    return {
        ...(actual as object),
        setFullScreen: vi.fn(),
        resetVideoControls: vi.fn(),
        setIsChatVisible: vi.fn(),
        setIsFullScreen: vi.fn(),
        setInstructionVideoVisible: vi.fn(),
        setCancelButtonVisible: vi.fn(),
    };
});

const isProviderAnteRoomMock = () => false;

const testVisitId = 'VISIT1234';

const providerUserDetails: UserDetails = {
    id: 'testId',
    displayName: 'testDisplayName',
    givenName: 'testGivenName',
    familyName: 'testFamilyName',
    email: 'email@email.com',
    roles: ['telehealth_provider'],
    token: 'testToken',
    expiration: 1,
};

const patientUserDetails: UserDetails = {
    id: 'testPatientId',
    displayName: 'sickMonkey',
    givenName: 'sick',
    familyName: 'monkey',
    email: 'email@example.com',
    roles: [],
    token: 'testTokenPatient',
    expiration: 1,
};

const healthChecks: HealthCheckState = {
    healthCheckProgress: 0,
    networkStatus: TestStatus.NotRun,
    camStatus: TestStatus.NotRun,
    micStatus: TestStatus.NotRun,
    mediaPermissionStatus: undefined,
    publishStatus: TestStatus.NotRun,
};
const healthInfoUnrun = {
    healthCheckStatus: HealthCheckStatus.Unknown,
    errorNumber: 0,
    errorMessage: '',
};

const buildProps = (isProvider: boolean, overrides?: object): AllProps => {
    const defaultProps: AllProps = {
        setCallStartTime: vi.fn(),
        setCallEndTime: vi.fn(),
        navigate: vi.fn(),
        visitId: testVisitId,
        brand: 'providence',
        health: healthChecks,
        healthInfo: healthInfoUnrun,
        // runTests: vi.fn(),
        callStartTime: undefined,
        isFullScreen: false,
        isChatVisible: false,
        endCallConfirmation: false,
        waitingInstantMessages: [],
        videoInstantMessages: [],
        waitingRoomHasUnread: false,
        userDetails: isProvider ? providerUserDetails : patientUserDetails,
        videoHasUnread: false,
        setFullScreen: vi.fn(),
        setIsChatVisible: vi.fn(),
        addWaitingInstantMessages: vi.fn(),
        addVideoInstantMessage: vi.fn(),
        setVideoHasUnread: vi.fn(),
        setWaitingRoomHasUnread: vi.fn(),
        setIsFullScreen: vi.fn(),
        tokBoxVideoSessionId: 'tok_video_session_id',
        tokBoxWaitingRoomSessionId: 'tok_waiting_room',
        tokBoxWaitingRoomToken: 'tok_waiting_room_token',
        chargeVisit: vi.fn(),
        publishStatus: TestStatus.NotRun,
        patientGuid: 'mockPatientGuid',
        providerId: 'mockProviderId',
        callEndTime: 1526448101,
        fetchVisitDetails: vi.fn(),
        cancelVisit: vi.fn(),
        resetVideoControls: vi.fn(),
        setMessageDialog: vi.fn(),
        setInstructionVideoVisible: vi.fn(),
        setPostVisitActionErrorMessage: vi.fn(),
        setCancelButtonVisible: vi.fn(),
    } as unknown as AllProps;
    return { ...defaultProps, ...overrides };
};

type VideoCallModuleWrapper = ShallowWrapper<
    VideoCallModuleProps & Props,
    Readonly<VideoCallModuleState>,
    React.Component<VideoCallModuleProps, VideoCallModuleState>
>;

const getInitialState = (defaultProps: Props) => ({
    postconsult: {
        visitId: defaultProps.visitId,
        providerId: defaultProps.providerId,
        patientGuid: defaultProps.patientGuid,
        isTestVisit: defaultProps.isTestVisit,
        tokBoxWaitingRoomSessionId: defaultProps.tokBoxWaitingRoomSessionId,
        tokBoxWaitingRoomToken: defaultProps.tokBoxWaitingRoomToken,
        callEndTime: defaultProps.callEndTime,
    },
    user: {
        userDetails: defaultProps.userDetails,
    },
    health: defaultProps.health,
    video: {
        isChatVisible: defaultProps.isChatVisible,
        endCallConfirmation: defaultProps.endCallConfirmation,
        isFullScreen: defaultProps.isFullScreen,
    },
    instantMessage: {
        waitingInstantMessages: defaultProps.waitingInstantMessages,
        videoInstantMessages: defaultProps.videoInstantMessages,
        videoHasUnread: defaultProps.videoHasUnread,
        waitingRoomHasUnread: defaultProps.waitingRoomHasUnread,
    },
    usersettings: {
        videoDeviceId: 'mockVideoDeviceId',
        audioDeviceId: 'mockAudioDeviceId',
    },
});

vi.mock('react-i18next', () => ({
    withTranslation:
        () =>
        <P extends object>(Component: React.FunctionComponent<P>) => {
            const WrappedComponent = (props: P) => (
                <Component {...props} t={() => ''} i18n={{ t: () => '' }} />
            );
            WrappedComponent.displayName = `withTranslation(${
                Component.displayName || Component.name || 'Component'
            })`;
            return WrappedComponent;
        },
}));

describe('<VideoCallModule />', () => {
    configure({ testIdAttribute: 'data-uitest' });
    const mediaMatchFn = () => {
        return {
            matches: false,
            addListener: vi.fn(),
            removeListener: vi.fn(),
            media: '',
        } as unknown as MediaQueryList;
    };
    window.matchMedia = window.matchMedia || mediaMatchFn;

    let wrapper: VideoCallModuleWrapper;
    let store: Store<unknown, AnyAction>;
    let defaultProps: Props;
    beforeEach(() => {
        const mockStore = configureMockStore([thunk]);
        defaultProps = buildProps(false);
        store = mockStore(getInitialState(defaultProps));
    });

    afterEach(() => {
        vi.clearAllMocks();
    });

    test('The Redux store attributes should be correctly mapped to props.', () => {
        wrapper = shallow(
            <WrappedVideoCallModule {...({ store } as unknown as Props)} />,
        ).dive() as VideoCallModuleWrapper;

        const props = wrapper.props();
        expect(props.userDetails).toEqual(defaultProps.userDetails);
        expect(props.visitId).toEqual(defaultProps.visitId);
        expect(props.patientGuid).toEqual(defaultProps.patientGuid);
        expect(props.providerId).toEqual(defaultProps.providerId);
        expect(props.tokBoxWaitingRoomSessionId).toEqual(
            defaultProps.tokBoxWaitingRoomSessionId,
        );
        expect(props.tokBoxWaitingRoomToken).toEqual(
            defaultProps.tokBoxWaitingRoomToken,
        );
        expect(props.publishStatus).toEqual(defaultProps.publishStatus);
        expect(props.callEndTime).toEqual(defaultProps.callEndTime);
        expect(props.waitingInstantMessages).toEqual(
            defaultProps.waitingInstantMessages,
        );
        expect(props.videoInstantMessages).toEqual(
            defaultProps.videoInstantMessages,
        );
        expect(props.videoHasUnread).toEqual(defaultProps.videoHasUnread);
        expect(props.waitingRoomHasUnread).toEqual(
            defaultProps.waitingRoomHasUnread,
        );
        expect(props.isFullScreen).toEqual(defaultProps.isFullScreen);
        expect(props.isChatVisible).toEqual(defaultProps.isChatVisible);
        expect(props.endCallConfirmation).toEqual(
            defaultProps.endCallConfirmation,
        );
    });

    test('All actions should be correctly mapped to props.', () => {
        wrapper = shallow(
            <WrappedVideoCallModule {...({ store } as unknown as Props)} />,
        ).dive() as VideoCallModuleWrapper;

        const props = wrapper.props();

        expect(props.cancelVisit).toBeDefined();
        expect(props.chargeVisit).toBeDefined();
        expect(props.setPostVisitActionErrorMessage).toBeDefined();
        expect(props.setMessageDialog).toBeDefined();
        expect(props.addWaitingInstantMessages).toBeDefined();
        expect(props.addVideoInstantMessage).toBeDefined();
        expect(props.setVideoHasUnread).toBeDefined();
        expect(props.setWaitingRoomHasUnread).toBeDefined();
        expect(props.setFullScreen).toBeDefined();
        expect(props.resetVideoControls).toBeDefined();
        expect(props.setIsChatVisible).toBeDefined();
        expect(props.setIsFullScreen).toBeDefined();
        expect(props.setInstructionVideoVisible).toBeDefined();
        expect(props.setCancelButtonVisible).toBeDefined();
    });

    test('Test Waiting Room', () => {
        const wrapper = shallow(<VideoCallModule {...buildProps(false)} />);
        expect(toJson(wrapper)).toMatchSnapshot();
        expect(V2Analytics.pageViewEvent).toHaveBeenCalled();
    });
    it('Keeps patient in waiting room even though provider is present if healthcheck is running', () => {
        const props = buildProps(false);
        props.health.healthCheckProgress = 50;
        const wrapper = shallow(
            <VideoCallModule
                {...{ publishStatus: TestStatus.Passed, ...props }}
            />,
        );
        const videoCallModuleProps = wrapper
            .find(Session)
            .first()
            .props() as VideoCallModuleWrapperProps;
        expect(videoCallModuleProps.visitState).toEqual(
            VideoCallRenderState.PatientWaitingRoom,
        );
        videoCallModuleProps.updateStreamCount(1);
        expect(videoCallModuleProps.visitState).toEqual(
            VideoCallRenderState.PatientWaitingRoom,
        );
    });
    it('Keeps patient in waiting room even though provider is present if publish failed', () => {
        const props = buildProps(false);
        props.health.healthCheckProgress = 50;

        const wrapper = shallow(
            <VideoCallModule
                {...{ publishStatus: TestStatus.Failed, ...props }}
            />,
        );
        const videoCallModuleProps = wrapper
            .find(Session)
            .first()
            .props() as VideoCallModuleWrapperProps;
        expect(videoCallModuleProps.visitState).toEqual(
            VideoCallRenderState.PatientWaitingRoom,
        );
        videoCallModuleProps.updateStreamCount(1);
        expect(videoCallModuleProps.visitState).toEqual(
            VideoCallRenderState.PatientWaitingRoom,
        );
    });
    it('bumps patient to video conference after provider joins and healthcheck completes and publish passes', () => {
        const props = buildProps(false);
        props.health.healthCheckProgress = 50;
        const wrapper = shallow(
            <VideoCallModule
                {...{ publishStatus: TestStatus.Failed, ...props }}
            />,
        );
        const videoCallModuleProps = wrapper
            .find(Session)
            .first()
            .props() as VideoCallModuleWrapperProps;
        expect(videoCallModuleProps.visitState).toEqual(
            VideoCallRenderState.PatientWaitingRoom,
        );
        videoCallModuleProps.updateStreamCount(1);
        wrapper.setProps({
            health: { healthCheckProgress: 0 },
            publishStatus: TestStatus.Passed,
        });
        expect(
            (
                wrapper.find(Session).first().props() as {
                    visitState: keyof VideoCallRenderState;
                }
            ).visitState,
        ).toEqual(VideoCallRenderState.MultiParticipantDisplay);
    });
    test('Test Ante Room', () => {
        const props = buildProps(false);
        props.health.healthCheckProgress = 50;
        const { container } = render(
            <Provider store={store}>
                <VideoCallModule {...buildProps(true)} />
            </Provider>,
        );
        expect(container).toMatchSnapshot();
    });
    test('Test chat not visible', () => {
        const wrapper = shallow(<VideoCallModule {...buildProps(true)} />);
        sinon.stub(
            wrapper.instance(),
            'isProviderAnteRoom',
            isProviderAnteRoomMock,
        );
        wrapper.setProps({ isChatVisible: false });
        expect(toJson(wrapper)).toMatchSnapshot();
    });
    test('Test Provider goes to ante room, and calls handleSelfCheckClick', () => {
        const wrapper = shallow(<VideoCallModule {...buildProps(true)} />);
        const instance = wrapper.instance() as React.Component<
            AllProps,
            { providerSelfCheckCompleted: boolean },
            object
        > & { handleSelfCheckClick: () => void };
        expect(instance.state.providerSelfCheckCompleted).toEqual(false);
        instance.handleSelfCheckClick();
        expect(instance.state.providerSelfCheckCompleted).toEqual(true);
    });
    test('provider should stay in video conference when patient ends the call', async () => {
        const patientProps = buildProps(false);
        const providerProps = buildProps(true);
        const patientVideoCallModuleWrapper = shallow(
            <VideoCallModule {...patientProps} />,
        );
        const providerVideoCallModuleWrapper = shallow(
            <VideoCallModule {...providerProps} />,
        );

        const patientVideoCallModuleWrapperProps = patientVideoCallModuleWrapper
            .find(Session)
            .first()
            .props() as VideoCallModuleWrapperProps;
        const providerVideoCallModuleWrapperProps =
            providerVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;

        // Expect patient to be in waiting room
        expect(patientVideoCallModuleWrapperProps.visitState).toEqual(
            VideoCallRenderState.PatientWaitingRoom,
        );

        // Expect provider to be in ante room
        expect(providerVideoCallModuleWrapperProps.visitState).toEqual(
            VideoCallRenderState.AnteRoom,
        );

        // Move patient to video conference
        patientVideoCallModuleWrapperProps.updateStreamCount(1);
        patientVideoCallModuleWrapper.setProps({
            health: { healthCheckProgress: 0 },
            publishStatus: TestStatus.Passed,
        });

        const patientVideoCallModuleWrapperNextProps =
            patientVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;
        expect(patientVideoCallModuleWrapperNextProps.visitState).toEqual(
            VideoCallRenderState.MultiParticipantDisplay,
        );

        // Move provider to video conference
        // providerVideoCallModuleWrapper.find(Session).first().props().updateStreamCount(1);
        providerVideoCallModuleWrapper.setState({
            providerSelfCheckCompleted: true,
            otRemoteConnectionDetected: true,
        });

        const providerVideoCallModuleWrapperNextProps =
            providerVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;
        expect(providerVideoCallModuleWrapperNextProps.visitState).toEqual(
            VideoCallRenderState.MultiParticipantDisplay,
        );

        // Patient hangs out call
        await patientVideoCallModuleWrapperNextProps.endCall('user');
        expect(patientProps.navigate).toHaveBeenCalledWith(
            `/postconsult/${testVisitId}?brand=providence`,
        );

        // Provider shouldn't get redirected to anyt other screen
        await providerVideoCallModuleWrapperNextProps.endCall('remote');
        expect(providerProps.navigate).not.toHaveBeenCalled();
    });
    test.each([
        ['setMessageDialog', 'Another provider will be with you shortly.'],
        ['setInstructionVideoVisible', false],
        ['setCancelButtonVisible', false],
    ])(
        'when provider ends and transfers %s is called with %s',
        (prop: string, expected) => {
            const patientProps = buildProps(false);

            const patientVideoCallModuleWrapper = shallow(
                <VideoCallModule {...patientProps} />,
            );

            const patientVideoCallModuleWrapperProps =
                patientVideoCallModuleWrapper
                    .find(Session)
                    .first()
                    .props() as VideoCallModuleWrapperProps;

            // Move patient to video conference
            patientVideoCallModuleWrapperProps.updateStreamCount(1);
            patientVideoCallModuleWrapper.setProps({
                health: { healthCheckProgress: 0 },
                publishStatus: TestStatus.Passed,
            });

            const patientVideoCallModuleWrapperNextProps =
                patientVideoCallModuleWrapper
                    .find(Session)
                    .first()
                    .props() as VideoCallModuleWrapperProps;
            expect(patientVideoCallModuleWrapperNextProps.visitState).toEqual(
                VideoCallRenderState.MultiParticipantDisplay,
            );

            patientVideoCallModuleWrapperNextProps.endCallAndTransfer();
            expect(patientProps[prop]).toHaveBeenCalledWith(expected);
        },
    );

    test('patient should not get a message on end and transfer error', () => {
        const patientProps = buildProps(false);
        const patientVideoCallModuleWrapper = shallow(
            <VideoCallModule {...patientProps} />,
        );

        const patientVideoCallModuleWrapperProps = patientVideoCallModuleWrapper
            .find(Session)
            .first()
            .props() as VideoCallModuleWrapperProps;

        // Move patient to video conference
        patientVideoCallModuleWrapperProps.updateStreamCount(1);
        patientVideoCallModuleWrapper.setProps({
            health: { healthCheckProgress: 0 },
            publishStatus: TestStatus.Passed,
        });

        const patientVideoCallModuleWrapperNextProps =
            patientVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;
        expect(patientVideoCallModuleWrapperNextProps.visitState).toEqual(
            VideoCallRenderState.MultiParticipantDisplay,
        );

        patientVideoCallModuleWrapperNextProps.endCallAndTransferError({
            visitId: 'visit-id',
            actorId: 'actor',
            timestamp: Date.now(),
            error: {
                code: 'whoops',
                message: 'doh',
            },
        });
        expect(patientProps.setMessageDialog).not.toHaveBeenCalled();
        expect(
            patientProps.setPostVisitActionErrorMessage,
        ).not.toHaveBeenCalled();
    });
    test('provider should be sent to post consult route when end and transfer visit', () => {
        const patientProps = buildProps(false);
        const providerProps = buildProps(true);

        const patientVideoCallModuleWrapper = shallow(
            <VideoCallModule {...patientProps} />,
        );
        const providerVideoCallModuleWrapper = shallow(
            <VideoCallModule {...providerProps} />,
        );

        const patientVideoCallModuleWrapperProps = patientVideoCallModuleWrapper
            .find(Session)
            .first()
            .props() as VideoCallModuleWrapperProps;
        const providerVideoCallModuleWrapperProps =
            providerVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;

        // Expect patient to be in waiting room
        expect(patientVideoCallModuleWrapperProps.visitState).toEqual(
            VideoCallRenderState.PatientWaitingRoom,
        );

        // Expect provider to be in ante room
        expect(providerVideoCallModuleWrapperProps.visitState).toEqual(
            VideoCallRenderState.AnteRoom,
        );

        // Move patient to video conference
        patientVideoCallModuleWrapperProps.updateStreamCount(1);
        patientVideoCallModuleWrapper.setProps({
            health: { healthCheckProgress: 0 },
            publishStatus: TestStatus.Passed,
        });

        const patientVideoCallModuleWrapperNextProps =
            patientVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;
        expect(patientVideoCallModuleWrapperNextProps.visitState).toEqual(
            VideoCallRenderState.MultiParticipantDisplay,
        );

        // Move provider to video conference
        // providerVideoCallModuleWrapper.find(Session).first().props().updateStreamCount(1);
        providerVideoCallModuleWrapper.setState({
            providerSelfCheckCompleted: true,
            otRemoteConnectionDetected: true,
        });
        const providerVideoCallModuleWrapperNextProps =
            providerVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;
        expect(providerVideoCallModuleWrapperNextProps.visitState).toEqual(
            VideoCallRenderState.MultiParticipantDisplay,
        );

        providerVideoCallModuleWrapperNextProps.endCallAndTransfer();
        expect(providerProps.navigate).toHaveBeenCalledWith(
            `/postconsult/${testVisitId}?brand=providence`,
        );
    });
    test('patient should reset video controls when end and transfer visit', () => {
        const patientProps = buildProps(false);

        const patientVideoCallModuleWrapper = shallow(
            <VideoCallModule {...patientProps} />,
        );

        const patientVideoCallModuleWrapperProps = patientVideoCallModuleWrapper
            .find(Session)
            .first()
            .props() as VideoCallModuleWrapperProps;
        patientVideoCallModuleWrapperProps.updateStreamCount(1);
        patientVideoCallModuleWrapper.setProps({
            health: { healthCheckProgress: 0 },
            publishStatus: TestStatus.Passed,
        });
        patientVideoCallModuleWrapperProps.endCallAndTransfer();

        expect(patientProps.resetVideoControls).toHaveBeenCalled();
    });

    test('provider should shown error on end and transfer error', () => {
        const patientProps = buildProps(false);
        const providerProps = buildProps(true);
        const patientVideoCallModuleWrapper = shallow(
            <VideoCallModule {...patientProps} />,
        );
        const providerVideoCallModuleWrapper = shallow(
            <VideoCallModule {...providerProps} />,
        );

        const patientVideoCallModuleWrapperProps = patientVideoCallModuleWrapper
            .find(Session)
            .first()
            .props() as VideoCallModuleWrapperProps;
        const providerVideoCallModuleWrapperProps =
            providerVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;

        // Expect patient to be in waiting room
        expect(patientVideoCallModuleWrapperProps.visitState).toEqual(
            VideoCallRenderState.PatientWaitingRoom,
        );

        // Expect provider to be in ante room
        expect(providerVideoCallModuleWrapperProps.visitState).toEqual(
            VideoCallRenderState.AnteRoom,
        );

        // Move patient to video conference
        patientVideoCallModuleWrapperProps.updateStreamCount(1);
        patientVideoCallModuleWrapper.setProps({
            health: { healthCheckProgress: 0 },
            publishStatus: TestStatus.Passed,
        });

        const patientVideoCallModuleWrapperNextProps =
            patientVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;

        expect(patientVideoCallModuleWrapperNextProps.visitState).toEqual(
            VideoCallRenderState.MultiParticipantDisplay,
        );

        // Move provider to video conference
        // providerVideoCallModuleWrapper.find(Session).first().props().updateStreamCount(1);
        providerVideoCallModuleWrapper.setState({
            providerSelfCheckCompleted: true,
            otRemoteConnectionDetected: true,
        });
        const providerVideoCallModuleWrapperNextProps =
            providerVideoCallModuleWrapper
                .find(Session)
                .first()
                .props() as VideoCallModuleWrapperProps;
        expect(providerVideoCallModuleWrapperNextProps.visitState).toEqual(
            VideoCallRenderState.MultiParticipantDisplay,
        );

        providerVideoCallModuleWrapperNextProps.endCallAndTransferError({
            visitId: 'visit-id',
            actorId: 'actor',
            timestamp: Date.now(),
            error: {
                code: 'whoops',
                message: 'doh',
            },
        });
        expect(providerProps.navigate).not.toHaveBeenCalled();
        expect(
            providerProps.setPostVisitActionErrorMessage,
        ).toHaveBeenCalledWith(
            'An error occurred trying to transfer the visit. Please try again.',
        );
    });
    describe('connection tests', () => {
        describe('Check the skeleton', () => {
            it('initially contains the OTSession component', () => {
                const wrapper = shallow(
                    <VideoCallModule {...buildProps(false)} />,
                );

                expect(wrapper.find(Session).length).toBe(1);
            });
        });

        describe('Check that methods are run', () => {
            const props = { ...buildProps(true) };
            const wrapper = shallow(<VideoCallModule {...props} />);

            it('unmounts provider side', () => {
                const instance = wrapper.instance() as VideoCallModule;
                instance.componentWillUnmount();
                expect(Analytics.sendEvent).toBeCalledWith({
                    eventAction: 'videoEnd',
                    eventName: 'Video Conference End',
                    type: 'success',
                });
                expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                    eventName: 'virtual_session_complete',
                    visit_id: props.visitId,
                    duration: '00:10:02',
                    patient_id: 'mockPatientGuid',
                });
            });

            it('unmounts patient side', () => {
                const instance = shallow(
                    <VideoCallModule {...buildProps(false)} />,
                ).instance() as VideoCallModule;
                instance.componentWillUnmount();
                expect(Analytics.sendEvent).toBeCalledWith({
                    eventAction: 'videoEnd',
                    eventName: 'Video Conference End',
                    type: 'success',
                });
                expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                    eventName: 'virtual_session_complete',
                    visit_id: props.visitId,
                    duration: '00:10:02',
                    provider_id: 'mockProviderId',
                });
            });
        });
    });

    test('modalityConversion should call postConsultRoute if is a provider', () => {
        const wrapper = shallow(<VideoCallModule {...buildProps(true)} />);
        const wrapperProps = wrapper.props() as VideoCallModuleProps;

        (
            wrapper.find(Session).first().props() as SessionProps
        ).modalityConversion();
        expect(wrapperProps.navigate).toHaveBeenCalledWith(
            '/closed/waitingroom',
        );
    });

    test('modalityConversion should call getClosedVisitRoute if is a patient', () => {
        const wrapper = shallow(<VideoCallModule {...buildProps(false)} />);
        const wrapperProps = wrapper.props() as VideoCallModuleProps;

        (
            wrapper.find(Session).first().props() as SessionProps
        ).modalityConversion();
        expect(wrapperProps.navigate).toHaveBeenCalledWith(
            '/closed/waitingroom',
        );
    });

    test('modalityConversionError should call setPostVisitActionErrorMessage if is a provider', () => {
        const providerProps = buildProps(true);
        const wrapper = shallow(<VideoCallModule {...providerProps} />);

        (
            wrapper.find(Session).first().props() as SessionProps
        ).modalityConversionError({
            visitId: 'visit-id',
            actorId: 'actor',
            targetModality: 'phone',
            timestamp: expect.any(Number),
            error: {
                code: 'error',
                message: 'error',
            },
        });

        expect(
            providerProps.setPostVisitActionErrorMessage,
        ).toHaveBeenCalledWith(
            'An error occurred trying to convert visit modality. Please try again.',
        );
    });

    test('modalityConversionError should not call setPostVisitActionErrorMessage if is a patient', () => {
        const patientProps = buildProps(false);
        const wrapper = shallow(<VideoCallModule {...patientProps} />);

        (
            wrapper.find(Session).first().props() as SessionProps
        ).modalityConversionError({
            visitId: 'visit-id',
            actorId: 'actor',
            targetModality: 'phone',
            timestamp: expect.any(Number),
            error: {
                code: 'error',
                message: 'error',
            },
        });

        expect(
            patientProps.setPostVisitActionErrorMessage,
        ).not.toHaveBeenCalled();
    });
});
