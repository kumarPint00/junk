import * as React from 'react';
vi.mock('../src/app', () => ({
    recoverGuestSessionFromAccessCode: vi.fn(),
}));
vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        setConfig: vi.fn(),
        getConfig: vi.fn(),
    },
    addMetric: vi.fn(),
}));
vi.mock('../src/clients/Backend/BackendFacade', () => ({
    backendFacade: {
        getUser: vi.fn(),
        getConfig: vi.fn(),
        getBasicConfig: vi.fn(),
    },
}));
vi.mock('../src/redux/middleware/localStorage', () => ({
    getLocalState: vi.fn(),
    localStorageMiddleware: vi.fn(),
}));
vi.mock('../src/redux/modules/index', () => ({
    initialState: vi.fn(),
    rootReducer: vi.fn(),
}));
vi.mock('../src/redux/modules/postConsult', () => ({
    setIsTestVisit: vi.fn(),
    setTokBoxVideoSessionId: vi.fn(),
    setTokBoxWaitingRoomSessionId: vi.fn(),
}));
vi.mock('../src/routes', () => ({
    getRoutes: vi.fn(),
}));
vi.mock('../src/utils', () => ({
    Logger: {
        addApplicationContext: vi.fn(),
        info: vi.fn(),
    },
    checkTestVisit: vi.fn(),
}));
vi.mock('../src/clients/VisitService/VisitServiceClient', () => ({
    initVisitServiceClient: vi.fn(),
}));
vi.mock('../src/utils/loadAuthToken', () => ({
    loadAuthToken: vi.fn(),
}));
vi.mock('redux', () => ({
    createStore: vi.fn(),
    applyMiddleware: vi.fn(),
    compose: vi.fn(),
}));
vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: {
        setup: vi.fn(),
    },
    isAdobeEnabled: vi.fn(),
    V2Analytics: {
        setup: vi.fn(),
    },
}));
vi.mock('@utils/initRum');

const mockComponent = (name: string) => {
    interface Props {
        children: object;
    }
    const MockedComponent = ({ children }: Props) => {
        return <div title={name}>{children}</div>;
    };

    MockedComponent.displayName = 'MockedComponent';

    return MockedComponent;
};

vi.mock('react-i18next', () => ({
    I18nextProvider: mockComponent('I18nextProvider'),
}));
vi.mock('react-redux', () => ({
    Provider: mockComponent('Provider'),
}));
vi.mock('react-router-dom', async (importOriginal) => {
    const actual = await importOriginal();
    return {
        ...(actual as object),
        RouterProvider: mockComponent('RouterProvider'),
    };
});
vi.mock('../src/rendering/AppStageContainer', () => ({
    AppStageContainer: mockComponent('AppStageContainer'),
}));

import { recoverGuestSessionFromAccessCode } from '../src/app';
import { backendFacade } from '../src/clients/Backend/BackendFacade';
import { createStore } from 'redux';
import { config } from '@dexcare/circus-jupiter';
import { vi, Mock } from 'vitest';
import * as featureFlags from '@utils/FeatureFlags';
import { waitFor } from '@testing-library/react';
import {
    SECURITY_ROLE_PATIENT,
    SECURITY_ROLE_PROVIDER,
} from '@dexcare/circus-saturn';
// import * as ReactDOM from 'react-dom';

interface Config {
    getConfig: Mock;
}

describe('index.tsx', () => {
    let loggedInUser;
    let wrapperConfig;
    let basicConfig;
    let store;
    let circusConfig;
    beforeEach(() => {
        loggedInUser = {
            sharedSessionStoreEnabled: true,
        };
        wrapperConfig = {
            brands: ['brand'],
            brandConfig: {
                brand: {},
            },
        };
        basicConfig = {
            siteTitle: 'blissey',
        };
        store = {
            dispatch: vi.fn(),
            subscribe: vi.fn(),
            getState: vi.fn().mockReturnValue({}),
        };
        circusConfig = {
            gtmContainerUrl: 'some-gtm-url.js',
            footerScripts: [{ src: 'some-footer-script.js' }],
            headScripts: [{ src: 'some-head-script.js' }],
            styles: {
                primaryColor: '#ffffff',
                secondaryColor: '#efefef',
            },
            consentScripts: [
                {
                    src: 'https://test-script.js',
                    attributes: {
                        'data-some-attribute': 'true',
                        charset: 'UTF-8',
                    },
                    prepend: true,
                },
                {
                    src: 'function TestFunction() { }',
                    inline: true,
                },
            ],
        };
        vi.spyOn(featureFlags, 'getFeatureFlag').mockReturnValue(true);
        (backendFacade.getUser as Mock).mockResolvedValue(loggedInUser);
        (backendFacade.getConfig as Mock).mockResolvedValue(wrapperConfig);
        (backendFacade.getBasicConfig as Mock).mockResolvedValue(basicConfig);
        (recoverGuestSessionFromAccessCode as Mock).mockResolvedValue(true);
        (createStore as Mock).mockReturnValue(store);
        (config as Config).getConfig.mockReturnValue(circusConfig);
        const root = document.createElement('div');
        root.setAttribute('id', 'root');
        document.body.appendChild(root);
    });

    afterEach(() => {
        document.body.innerHTML = '';
        vi.resetModules();
    });

    test('renders the base layout', async () => {
        await import('../src/index');
        expect(document.body).toMatchSnapshot();
    }, 600000);

    test('does not insert consent scripts from config when the user is a provider', async () => {
        loggedInUser = {
            sharedSessionStoreEnabled: true,
            roles: [SECURITY_ROLE_PROVIDER],
        };
        (backendFacade.getUser as Mock).mockResolvedValue(loggedInUser);
        await import('../src/index');

        await waitFor(() => {
            const script = document.querySelector(
                'script[src="https://test-script.js"]',
            );
            expect(script).not.toBeInTheDocument();
        });
    });

    test('inserts consent scripts from config when the user is a patient', async () => {
        loggedInUser = {
            sharedSessionStoreEnabled: true,
            roles: [SECURITY_ROLE_PATIENT],
        };
        (backendFacade.getUser as Mock).mockResolvedValue(loggedInUser);
        await import('../src/index');

        await waitFor(() => {
            const script = document.querySelector(
                'script[src="https://test-script.js"]',
            );
            expect(script).toBeInTheDocument();
            expect(script).toHaveAttribute('data-some-attribute', 'true');
        });
    });
});
