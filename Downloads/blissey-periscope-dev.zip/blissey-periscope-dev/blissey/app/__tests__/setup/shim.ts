interface Global {
    requestAnimationFrame: (callback: FrameRequestCallback) => void;
}
(global as Global).requestAnimationFrame = (callback: FrameRequestCallback) => {
    setTimeout(callback, 0);
};
