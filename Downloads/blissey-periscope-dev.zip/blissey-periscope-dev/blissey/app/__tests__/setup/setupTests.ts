import * as Enzyme from 'enzyme';
import Adapter from '@cfaester/enzyme-adapter-react-18';
import { vi } from 'vitest';
import createFetchMock from 'vitest-fetch-mock';
import { init } from '@common/ConferenceErrorMessage';
import '@testing-library/jest-dom';

Enzyme.configure({ adapter: new Adapter() });

vi.mock('@utils/config');
vi.mock('@dexcare/circus-jupiter');
vi.mock('@dexcare/festivus-aluminum-pole-analytics');
vi.mock('@dexcare/yak');
vi.mock('@common/i18n/i18nInstance', () => {
    const mockI18n = {
        t: (s: string) => s,
        use: () => mockI18n,
        init: () => mockI18n,
    };

    return {
        getI18nInstance: () => ({
            t: (s: string) => s,
        }),
        initI18nInstance: async () => Promise.resolve(mockI18n),
    };
});

init();

const fetchMocker = createFetchMock(vi);
fetchMocker.enableMocks();
