import * as React from 'react';
import { shallow } from 'enzyme';

import { AppStageContainer } from '../../src/rendering/AppStageContainer';
import toJson from 'enzyme-to-json';

describe('<AppStageContainer />', () => {
    const expirationDate = Date.now() / 1000 + 360000; // Divided by 1000 to match token-expiry. Added one hour.
    const user = {
        id: 'id',
        token: 'sometoken',
        expiration: expirationDate,
        email: 'some@example.com',
        displayName: 'Name',
        roles: ['telehealth_presenter'],
        givenName: 'givenName',
        familyName: 'familyName',
    };

    describe('Check the skeleton by shallow rendering', () => {
        const wrapper = shallow(<AppStageContainer user={user} />);

        it('renders', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
    });
});
