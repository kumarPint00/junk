import * as React from 'react';
import { shallow } from 'enzyme';

import { UserNotAuthenticated } from '../../src/rendering/UserNotAuthenticated';
import toJson from 'enzyme-to-json';

describe('<UserNotAuthenticated />', () => {
    describe('Check the skeleton by shallow rendering', () => {
        const wrapper = shallow(
            <UserNotAuthenticated siteTitle="Frosh" favicon="./favicon.ico" />,
        );

        it('renders', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
    });
});
