import * as React from 'react';
import { render } from '@testing-library/react';
import { VisitSummaryCard } from '@components/VisitSummary/VisitSummaryCard';
import { config } from '@dexcare/circus-jupiter';
import { submitGTMPageViewEvent } from '@services/analytics';
import { vi, Mock } from 'vitest';

vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(),
    },
}));

vi.mock('@services/analytics', () => ({
    submitGTMPageViewEvent: vi.fn(),
}));

vi.mock('react-i18next', () => ({
    // this mock makes sure any components using the translate HoC receive the t function as a prop
    withTranslation: () => (Component: { defaultProps: object }) => {
        Component.defaultProps = { ...Component.defaultProps, t: () => '' };
        return Component;
    },
}));

const mockT = vi.fn();

interface Config {
    getConfig: Mock;
}

describe('VisitSummaryCard', () => {
    beforeEach(() => {
        mockT.mockReturnValueOnce({
            advertisements: [],
        });
    });

    it('should render VisitSummaryCard', () => {
        (config as Config).getConfig.mockReturnValue({
            visitSummaryText: {
                disablePrescriptionText: false,
            },
        });
        const { container } = render(
            <VisitSummaryCard
                thanksText={'thanks text'}
                concludeText={'conclude text'}
                treatmentPlanText={'get treated text'}
                treatmentPlanAltText={''}
                treatmentPlanAltURL={''}
                treatmentPlanAltTimeText={''}
                treatmentPlanAltAdditionalText={''}
                prescriptionText={'get a prescription text '}
                timeText={'never'}
                followupText={'We will follow up'}
                visitId='123'
                t={mockT}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(submitGTMPageViewEvent).toHaveBeenCalled();
    });

    it('should render VisitSummaryCard with disablePrescriptionText', () => {
        (config as Config).getConfig.mockReturnValue({
            visitSummaryText: {
                disablePrescriptionText: true,
            },
        });
        const { container } = render(
            <VisitSummaryCard
                thanksText={'thanks text'}
                concludeText={'conclude text'}
                treatmentPlanText={'get treated text'}
                treatmentPlanAltText={''}
                treatmentPlanAltURL={''}
                treatmentPlanAltTimeText={''}
                treatmentPlanAltAdditionalText={''}
                prescriptionText={'get a prescription text '}
                timeText={'never'}
                followupText={''}
                visitId='123'
                t={mockT}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(submitGTMPageViewEvent).toHaveBeenCalled();
    });

    it('should render VisitSummaryCard with an alternate treatment plan format', () => {
        (config as Config).getConfig.mockReturnValue({
            visitSummaryText: {
                disablePrescriptionText: true,
            },
        });
        const { container } = render(
            <VisitSummaryCard
                thanksText={'thanks text'}
                concludeText={'conclude text'}
                treatmentPlanText={'get treated text '}
                treatmentPlanAltText={'go here'}
                treatmentPlanAltURL={'www.url.com'}
                treatmentPlanAltTimeText={'treatment plan with time text '}
                treatmentPlanAltAdditionalText={' more treatment plan text'}
                prescriptionText={'get a prescription text '}
                timeText={'some time'}
                followupText={''}
                visitId='123'
                t={mockT}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(submitGTMPageViewEvent).toHaveBeenCalled();
    });
});
