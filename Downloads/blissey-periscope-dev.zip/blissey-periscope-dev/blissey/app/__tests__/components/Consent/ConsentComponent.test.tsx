import * as React from 'react';
import { mount } from 'enzyme';
import { ConsentComponent } from '../../../src/components/Consent/ConsentComponent';
import { vi } from 'vitest';
import { fireEvent, render } from '@testing-library/react';

describe('<ConsentComponent />', () => {
    const onConsentButtonClick = vi.fn();
    const onConsentCancelLinkClick = vi.fn();
    const setTermsAccepted = vi.fn();
    const handleSetErrorMessage = vi.fn();
    const defaultProps = {
        localizedText: {
            consentHeaderText: 'consent header text',
            consentInstructionText: 'instruction body text',
            consentCheckboxLabelText: 'consent checkbox text',
            consentButtonText: 'button text',
            consentCancelLinkText: 'link text',
            errorMessageText: undefined,
            dismissErrorModalText: 'dismiss',
        },
        onConsentButtonClick,
        onConsentCancelLinkClick,
        setTermsAccepted,
        handleSetErrorMessage,
        termsAccepted: true,
        isLoading: false,
    };

    beforeEach(() => {
        vi.resetAllMocks();
    });

    it('displays the component', () => {
        const { container } = render(<ConsentComponent {...defaultProps} />);
        expect(container).toMatchSnapshot();
    });

    it('calls onConsentButtonClick when submit button is clicked', () => {
        const { container } = render(<ConsentComponent {...defaultProps} />);
        const acceptTermsButton = container.querySelector(
            '[data-uitest="accept-terms-button"]',
        );
        fireEvent.click(acceptTermsButton);
        expect(onConsentButtonClick).toHaveBeenCalled();
    });

    it('calls setTermsAccepted when checkbox is changed', () => {
        const wrapper = mount(<ConsentComponent {...defaultProps} />);
        wrapper
            .update()
            .find({ 'data-uitest': 'consent-checkbox' })
            .first()
            .simulate('change');
        expect(setTermsAccepted).toHaveBeenCalledWith(true);
    });
});
