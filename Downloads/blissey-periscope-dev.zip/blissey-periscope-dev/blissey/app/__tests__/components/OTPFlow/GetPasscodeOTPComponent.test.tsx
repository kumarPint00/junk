import * as React from 'react';
import { mount } from 'enzyme';
import { GetPasscodeOTPComponent } from '../../../src/components/OTPFlow/GetPasscodeOTPComponent';
import { vi } from 'vitest';
import { fireEvent, render } from '@testing-library/react';

describe('<GetPasscodeOTPComponent />', () => {
    const onGetPasscodeButtonClick = vi.fn();
    const setOTPMethod = vi.fn();
    const handleSetErrorMessage = vi.fn();
    const defaultProps = {
        patientInfo: {
            sms: '1234567890',
            email: 'example@example.com',
        },
        localizedText: {
            getOTPInstructionHeaderText: 'instruction header text',
            getOTPInstructionBodyText: 'instruction body text',
            getOTPDisclaimerText: 'disclaimer text',
            getOTPButtonText: 'button text',
            errorMessageText: undefined,
            dismissErrorModalText: 'dismiss text',
        },
        onGetPasscodeButtonClick,
        otpMethod: 'email',
        setOTPMethod,
        isLoading: false,
        handleSetErrorMessage,
    };

    beforeEach(() => {
        vi.resetAllMocks();
    });

    it('displays the component', () => {
        const { container } = render(
            <GetPasscodeOTPComponent {...defaultProps} />,
        );
        expect(container).toMatchSnapshot();
    });

    it('calls onGetPasscodeButtonClick when submit button is clicked', () => {
        const { container } = render(
            <GetPasscodeOTPComponent {...defaultProps} />,
        );
        const submitButton = container.querySelector(
            '[data-uitest="get-otp-password-button"]',
        );
        fireEvent.click(submitButton);
        expect(onGetPasscodeButtonClick).toHaveBeenCalled();
    });

    it('calls setOTPMethod when radio group is changed', () => {
        const wrapper = mount(<GetPasscodeOTPComponent {...defaultProps} />);
        wrapper
            .update()
            .find({ 'data-uitest': 'sms-radio' })
            .first()
            .simulate('change');
        expect(setOTPMethod).toHaveBeenCalledWith('sms');
    });
});
