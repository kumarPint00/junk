import * as React from 'react';
import { shallow } from 'enzyme';
import { render } from '@testing-library/react';
import {
    VerifyOTPComponent,
    VerifyOTPComponentProps,
} from '../../../src/components/OTPFlow/VerifyOTPComponent';
import { vi } from 'vitest';

describe('<VerifyOTPComponent />', () => {
    const onVerifyPasscodeButtonClick = vi.fn();
    const onVerifyDidNotReceiveCode = vi.fn();
    const setOTPCode = vi.fn();

    let defaultProps: VerifyOTPComponentProps;
    beforeEach(() => {
        defaultProps = {
            localizedText: {
                verifyInstructionHeaderText: 'instruction header text',
                verifyInstructionLineValid: 'instruction line valid',
                verifyModifiedInstructionPhone: 'instruction phone',
                verifyModifiedInstructionEmail: 'instruction email',
                verifyButtonText: 'button text',
                verifyLinkText: 'link text',
            },
            onVerifyPasscodeButtonClick,
            onVerifyDidNotReceiveCode,
            otpMethod: 'email',
            otpCode: 'secretcode',
            setOTPCode,
            isLoading: false,
        } as unknown as VerifyOTPComponentProps;
    });

    afterEach(() => {
        vi.resetAllMocks();
    });

    it('displays email variation', () => {
        const { container } = render(<VerifyOTPComponent {...defaultProps} />);
        expect(container).toMatchSnapshot();
    });

    it('displays phone variation', () => {
        defaultProps.otpMethod = 'phone';
        const { container } = render(<VerifyOTPComponent {...defaultProps} />);
        expect(container).toMatchSnapshot();
    });

    it('submit button is disabled if code not entered', () => {
        defaultProps.otpCode = '';
        const wrapper = shallow(<VerifyOTPComponent {...defaultProps} />);
        const button = wrapper.find({ 'data-uitest': 'verify-otp-button' });
        expect(button.prop('disabled')).toEqual(true);
    });

    it('allows submit', () => {
        const wrapper = shallow(<VerifyOTPComponent {...defaultProps} />);
        const button = wrapper.find({ 'data-uitest': 'verify-otp-button' });
        expect(button.prop('disabled')).toEqual(false);
        button.simulate('click');
        expect(onVerifyPasscodeButtonClick).toHaveBeenCalled();
    });

    it('allows submit with did not receive code link', () => {
        const wrapper = shallow(<VerifyOTPComponent {...defaultProps} />);
        wrapper.find({ 'data-uitest': 'verify-otp-link' }).simulate('click');
        expect(onVerifyDidNotReceiveCode).toHaveBeenCalled();
    });

    it('calls to set otp code when text is changed', () => {
        const wrapper = shallow(<VerifyOTPComponent {...defaultProps} />);
        wrapper
            .find({ 'data-uitest': 'verify-otp-input' })
            .simulate('change', { target: { value: 'Hello' } });
        expect(setOTPCode).toHaveBeenCalledWith('Hello');
    });
});
