import * as React from 'react';
import { shallow } from 'enzyme';

import { CallLengthTimer } from '@components/CallLengthTimer/CallLengthTimer';

describe('<CallLengthTimer />', () => {
    const currentTime = new Date().getTime();
    it('Does not render when time is null', () => {
        const wrapper = shallow(<CallLengthTimer callStartTime={null} />);
        expect(wrapper.find('div')).toHaveLength(0);
    });

    it('Does render when time exists', () => {
        const wrapper = shallow(
            <CallLengthTimer callStartTime={currentTime} />,
        );
        expect(wrapper.find('div')).toHaveLength(1);
    });

    it('Will show 999 as max value', () => {
        const wrapper = shallow(<CallLengthTimer callStartTime={1} />);
        expect(wrapper.find('div').text()).toEqual(
            expect.stringContaining('999'),
        );
    });

    it('Will show 1 as min value', () => {
        const wrapper = shallow(
            <CallLengthTimer callStartTime={currentTime - 10000} />,
        );
        expect(wrapper.find('div').text()).toEqual(
            expect.stringContaining('1'),
        );
    });
});
