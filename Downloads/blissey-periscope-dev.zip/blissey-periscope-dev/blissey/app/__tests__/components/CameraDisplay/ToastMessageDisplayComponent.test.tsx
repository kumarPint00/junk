import * as React from 'react';
import { render } from '@testing-library/react';
import { ToastMessageDisplayComponent } from '@components/CameraDisplay/ToastMessageDisplayComponent';
import { AppConfig } from '../../../../server/config/configInterfaces';
import { init as initMessageMap } from '@common/ConferenceErrorMessage';
import { Mocked, vi } from 'vitest';

let mockConfig: Mocked<typeof import('@utils/config')>;

vi.mock('@mui/material/Snackbar', () => ({
    default: () => null,
}));
vi.mock('@mui/material/Alert', () => ({
    default: () => null,
}));

describe('<ToastMessageDisplayComponent />', () => {
    beforeEach(async () => {
        mockConfig = (await import('@utils/config')) as Mocked<
            typeof import('@utils/config')
        >;
        initMessageMap();
    });
    afterEach(() => {
        vi.clearAllMocks();
    });
    test('provider without warning message', () => {
        const { container } = render(
            <ToastMessageDisplayComponent micExists={true} camExists={true} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('provider warning message with showMediaWarning false', () => {
        const { container } = render(
            <ToastMessageDisplayComponent micExists={true} camExists={false} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('provider with warning message mic does not exist', () => {
        const { container } = render(
            <ToastMessageDisplayComponent micExists={false} camExists={true} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('provider with warning message cam does not exist', () => {
        const { container } = render(
            <ToastMessageDisplayComponent micExists={true} camExists={false} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('provider with warning message mic does not exist shows overridden config values', () => {
        mockConfig.getConfig.mockReturnValue({
            videoUserMessages: {
                micMuted: 'override mic muted',
            },
            technicalSupportHelpNumber: '1-844-552-2734',
        } as AppConfig);
        initMessageMap();
        const { container } = render(
            <ToastMessageDisplayComponent micExists={false} camExists={true} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('provider with warning message cam does not exist shows overridden config values', () => {
        mockConfig.getConfig.mockReturnValue({
            videoUserMessages: {
                camMuted: 'override cam muted',
            },
            technicalSupportHelpNumber: '1-844-552-2734',
        } as AppConfig);
        initMessageMap();
        const { container } = render(
            <ToastMessageDisplayComponent micExists={true} camExists={false} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('provider with warning message when both mic and cam does not exist', () => {
        const { container } = render(
            <ToastMessageDisplayComponent
                micExists={false}
                camExists={false}
            />,
        );
        expect(container).toMatchSnapshot();
    });
});
