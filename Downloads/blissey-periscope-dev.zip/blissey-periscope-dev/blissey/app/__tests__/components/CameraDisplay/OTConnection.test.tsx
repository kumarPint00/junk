import * as React from 'react';
import { mount } from 'enzyme';
import { OTConnectionView } from '@components/CameraDisplay/OTConnection';
import { Connection } from '@components/CameraDisplay/Connection';
import { RTCConnectionState } from '@utils/RTCConnectionState';
import { vi } from 'vitest';
vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: {
        sendEvent: vi.fn(),
    },
}));
vi.mock('react-redux', () => ({
    useSelector: () => ({
        postconsult: {
            visitId: 'testvisit',
            isTestVisit: false,
        },
    }),
}));

const wrappedComponent = (props, overrides) => {
    return mount(<OTConnectionView {...{ ...props, ...overrides }} />);
};

describe('<OTConnectionView />', () => {
    let defaultProps;
    beforeEach(() => {
        defaultProps = {
            onReconnect: vi.fn(),
        };
    });
    test('sessionReconnecting displays connection component', () => {
        const wrapper = wrappedComponent(
            {
                otStreams: [],
                otConnectionStatus: 'sessionReconnecting',
                otPublishingStatus: 'publishingStarted',
            },
            defaultProps,
        );

        expect(wrapper.find(Connection)).toHaveLength(1);
        expect(wrapper.find(Connection).prop('rtcConnectionState')).toEqual(
            RTCConnectionState.Reconnecting,
        );
    });

    test('sessionDisconnected displays connection component', () => {
        const wrapper = wrappedComponent(
            {
                otStreams: [],
                otConnectionStatus: 'sessionDisconnected',
                otPublishingStatus: 'publishingStarted',
            },
            defaultProps,
        );

        expect(wrapper.find(Connection)).toHaveLength(1);
        expect(wrapper.find(Connection).prop('rtcConnectionState')).toEqual(
            RTCConnectionState.Closed,
        );
    });

    test('sessionConnected with no remote participants displays connection component', () => {
        const wrapper = wrappedComponent(
            {
                otStreams: [],
                otConnectionStatus: 'sessionConnected',
                otPublishingStatus: 'publishSuccess',
            },
            defaultProps,
        );

        expect(wrapper.find(Connection)).toHaveLength(0);
        expect(
            expect(wrapper.text()).toContain(
                'video-conference.error-messages.otherParticipantDropped',
            ),
        );
    });

    test('sessionConnected with remote participants is empty', () => {
        const wrapper = wrappedComponent(
            {
                otStreams: [{}],
                otConnectionStatus: 'sessionConnected',
                otPublishingStatus: 'publishSuccess',
            },
            defaultProps,
        );
        expect(wrapper.find(Connection)).toHaveLength(0);
    });

    test('sessionConnected while publishing ', () => {
        const wrapper = wrappedComponent(
            {
                otStreams: [{}],
                otConnectionStatus: 'sessionConnected',
                otPublishingStatus: 'publishStarted',
            },
            defaultProps,
        );
        expect(wrapper.find(Connection)).toHaveLength(1);
        expect(wrapper.find(Connection).prop('rtcConnectionState')).toEqual(
            RTCConnectionState.Connecting,
        );
    });

    test('sessionConnected with subscribeStarted', () => {
        const wrapper = wrappedComponent(
            {
                otStreams: [{}],
                otConnectionStatus: 'sessionConnected',
                otPublishingStatus: 'publishSuccess',
                otSubscribingStatus: 'subscribeStarted',
            },
            defaultProps,
        );
        expect(wrapper.find(Connection)).toHaveLength(1);
        expect(wrapper.find(Connection).prop('rtcConnectionState')).toEqual(
            RTCConnectionState.Connecting,
        );
    });

    test('sessionConnected with subscribeFailure', () => {
        const wrapper = wrappedComponent(
            {
                otStreams: [{}],
                otConnectionStatus: 'sessionConnected',
                otPublishingStatus: 'publishSuccess',
                otSubscribingStatus: 'subscribeFailure',
            },
            defaultProps,
        );
        expect(wrapper.find(Connection)).toHaveLength(1);
        expect(wrapper.find(Connection).prop('rtcConnectionState')).toEqual(
            RTCConnectionState.Closed,
        );
    });

    test('sessionConnected with subscribeSuccess', () => {
        const wrapper = wrappedComponent(
            {
                otStreams: [{}],
                otConnectionStatus: 'sessionConnected',
                otPublishingStatus: 'publishSuccess',
                otSubscribingStatus: 'subscribeSuccess',
            },
            defaultProps,
        );
        expect(wrapper.find(Connection)).toHaveLength(0);
    });
});
