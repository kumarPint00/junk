import * as React from 'react';
import { render } from '@testing-library/react';
import { mount } from 'enzyme';
import { Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: { sendEvent: vi.fn() },
}));

import { Connection } from '../../../src/components/CameraDisplay/Connection';
import { RTCConnectionState } from '@utils/RTCConnectionState';
import { vi } from 'vitest';

const onReconnect = () => null;

const user = {
    id: 'id',
    token: 'sometoken',
    expiration: new Date(),
    email: 'some@example.com',
    displayName: 'Name',
    givenName: 'givenName',
    familyName: 'familyName',
};

const testVisitId = 'testVisitId';

test('<Connection /> reconnecting', () => {
    const { container } = render(
        <Connection
            disableAvatar={false}
            onReconnect={onReconnect}
            user={user}
            rtcConnectionState={RTCConnectionState.Reconnecting}
            disableSelfView={true}
            visitId={testVisitId}
        />,
    );
    expect(container).toMatchSnapshot();
});

test('<Connection /> reconnecting, avatar disabled', () => {
    const { container } = render(
        <Connection
            disableAvatar={true}
            onReconnect={onReconnect}
            user={user}
            rtcConnectionState={RTCConnectionState.Reconnecting}
            disableSelfView={true}
            visitId={testVisitId}
        />,
    );
    expect(container).toMatchSnapshot();
});

test('<Connection /> reconnecting calls analytics', () => {
    mount(
        <Connection
            disableAvatar={true}
            onReconnect={onReconnect}
            user={user}
            rtcConnectionState={RTCConnectionState.Reconnecting}
            disableSelfView={true}
            visitId={testVisitId}
        />,
    );
    expect(Analytics.sendEvent).toHaveBeenCalledWith({
        eventAction: 'RTC connection lost - attempt reconnection',
        eventName: 'error',
        type: 'error',
    });
});

test('<Connection /> disconnected', () => {
    const { container } = render(
        <Connection
            disableAvatar={false}
            onReconnect={onReconnect}
            user={user}
            disableSelfView={true}
            rtcConnectionState={RTCConnectionState.Closed}
            visitId={testVisitId}
        />,
    );
    expect(container).toMatchSnapshot();
});

test('<Connection /> connecting', () => {
    const { container } = render(
        <Connection
            disableAvatar={false}
            onReconnect={onReconnect}
            user={user}
            disableSelfView={true}
            rtcConnectionState={RTCConnectionState.Connecting}
            visitId={testVisitId}
        />,
    );
    expect(container).toMatchSnapshot();
});
