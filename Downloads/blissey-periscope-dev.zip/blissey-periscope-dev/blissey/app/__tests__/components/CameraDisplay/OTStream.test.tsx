import * as React from 'react';
import { shallow } from 'enzyme';
import { OTStream } from '@components/CameraDisplay/OTStream';
import toJson from 'enzyme-to-json';

describe('<OTStream />', () => {
    test('sessionReconnecting displays connection component', () => {
        const wrapper = shallow(<OTStream id={'testId'} />);
        expect(toJson(wrapper)).toMatchSnapshot();
    });
});
