import * as React from 'react';
import { render } from '@testing-library/react';
import { ThanksComponent } from '../../../src/components/SessionSummary/ThanksComponent';

test('<ThanksComponent/> render text', () => {
    const { container } = render(<ThanksComponent />);
    expect(container).toMatchSnapshot();
});
