import * as React from 'react';
import { render } from '@testing-library/react';

import { DisabledSelfView } from '../../../src/components/DisabledSelfView/DisabledSelfView';

describe('<DisabledSelfView />', () => {
    test('should match snapshot', () => {
        const { container } = render(<DisabledSelfView />);
        expect(container).toMatchSnapshot();
    });
});
