import * as React from 'react';
import { Footer } from '../../../src/components/Footer/Footer';
import { render } from '@testing-library/react';
import { shallow } from 'enzyme';

describe('<Footer/>', () => {
    test('verify default snapshot', () => {
        const { container } = render(
            <Footer.WrappedComponent t={(key: string) => key} />,
        );
        expect(container).toMatchSnapshot();
    });

    test('verify footer has current year in copyright', () => {
        const wrapper = shallow(
            <Footer.WrappedComponent
                t={(key: string, options: { year: string }) =>
                    key === 'branding:footer.copyright'
                        ? `© ${options.year} Company Center. All Rights Reserved.`
                        : key
                }
            />,
        );

        const copyrightElement = wrapper.find('.copyright');
        const copyrightText = copyrightElement.text();
        const currentYear = new Date().getFullYear().toString();

        expect(copyrightText).toContain(currentYear);
    });
});
