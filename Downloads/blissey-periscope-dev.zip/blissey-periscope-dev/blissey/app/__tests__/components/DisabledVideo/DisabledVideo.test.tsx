import * as React from 'react';
import { render } from '@testing-library/react';

import { DisabledVideo } from '../../../src/components/DisabledVideo/DisabledVideo';

test('<DisabledVideo /> with name', () => {
    const { container } = render(<DisabledVideo muterDisplayName="Name" />);
    expect(container).toMatchSnapshot();
});

test('<DisabledVideo /> without name', () => {
    const { container } = render(<DisabledVideo muterDisplayName="" />);
    expect(container).toMatchSnapshot();
});
