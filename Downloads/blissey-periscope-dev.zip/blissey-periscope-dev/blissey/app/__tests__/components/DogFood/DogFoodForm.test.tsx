import * as React from 'react';
import { render } from '@testing-library/react';
import { DogFoodForm } from '../../../src/components/Dogfood/DogFoodForm';
import { MuiRippleDisabledWrapper } from '../../../__mocks__/theme-provider';

test('<DogFoodForm /> with patientWaitingRoomToken and waitingRoomSessionId', () => {
    const { container } = render(
        <MuiRippleDisabledWrapper>
            <DogFoodForm
                onBrandChange={() => jest.fn()}
                brands={[
                    {
                        label: 'Brand 1',
                        value: 'BRAND_1',
                    },
                    {
                        label: 'Brand 2',
                        value: 'BRAND_2',
                    },
                ]}
                selectedBrand={'BRAND_1'}
                onGenerateClick={() => jest.fn()}
                patientWaitingRoomToken={'1234'}
                waitingRoomSessionId={'1234'}
            />
        </MuiRippleDisabledWrapper>,
    );
    expect(container).toMatchSnapshot();
});

test('<DogFoodForm /> with patientVideoToken and videoSessionId', () => {
    const { container } = render(
        <MuiRippleDisabledWrapper>
            <DogFoodForm
                onBrandChange={() => jest.fn()}
                brands={[
                    {
                        label: 'Brand 1',
                        value: 'BRAND_1',
                    },
                    {
                        label: 'Brand 2',
                        value: 'BRAND_2',
                    },
                ]}
                selectedBrand={'BRAND_1'}
                onGenerateClick={() => jest.fn()}
                patientVideoToken={'1234'}
                videoSessionId={'1234'}
            />
        </MuiRippleDisabledWrapper>,
    );
    expect(container).toMatchSnapshot();
});
