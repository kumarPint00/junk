import * as React from 'react';
import { render } from '@testing-library/react';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

import { NotFoundComponent } from '../../../src/components/NotFound/NotFoundComponent';
import { vi } from 'vitest';

vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(() => ({
            technicalSupportHelpNumber: '555-555-5555',
            displaySupportNumberOnError,
        })),
    },
}));

vi.mock('@utils/Logger', () => ({
    BlisseyLogger: { info: vi.fn() },
}));

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { errorEvent: vi.fn() },
}));

let displaySupportNumberOnError = true;

describe('<NotFoundComponent />', () => {
    test('isProvider true', () => {
        const { container } = render(
            <NotFoundComponent.WrappedComponent
                t={(key: string) => key}
                isProvider={true}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: 'try going back',
            type: 'not found',
        });
    });

    test('isProvider false', () => {
        const { container } = render(
            <NotFoundComponent.WrappedComponent
                t={(key: string) => key}
                isProvider={false}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: 'go back or call to schedule',
            type: 'not found',
        });
    });

    test('isProvider false, display link instead of support number', () => {
        displaySupportNumberOnError = false;
        const { container } = render(
            <NotFoundComponent.WrappedComponent
                t={(key: string) => key}
                isProvider={false}
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: 'try the scheduling page',
            type: 'not found',
        });
    });
});
