vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(),
    },
}));
import { InstructionVideoComponent } from '@components/WaitingRoom/InstructionVideoComponent';
import { config } from '@dexcare/circus-jupiter';
import IconButton from '@mui/material/IconButton';
import { ShallowWrapper, shallow } from 'enzyme';
import * as React from 'react';
import Youtube from 'react-youtube';
import ReactPlayer from 'react-player';
import { vi, Mock } from 'vitest';
import toJson from 'enzyme-to-json';

interface Config {
    getConfig: Mock;
}

describe('<InstructionVideoComponent />', () => {
    let onPlayVideo: Mock,
        onEndVideo: Mock,
        onVideoReady: Mock,
        onVideoError: Mock,
        onPauseVideo: Mock,
        onExitVideo: Mock;
    beforeEach(() => {
        onPlayVideo = vi.fn();
        onEndVideo = vi.fn();
        onVideoReady = vi.fn();
        onVideoError = vi.fn();
        onPauseVideo = vi.fn();
        onExitVideo = vi.fn();
        (config as Config).getConfig.mockImplementation(() => ({
            instructionVideoId: 'aBcDeFgHiJk',
            instructionVideoHostingSource: 'youtube',
        }));
    });
    describe('videoId has a default', () => {
        let wrapper: ShallowWrapper<unknown>;
        beforeEach(() => {
            (config as Config).getConfig.mockImplementation(() => ({}));

            wrapper = shallow(
                <InstructionVideoComponent
                    videoIsActive={true}
                    onPlayVideo={onPlayVideo}
                    onEndVideo={onEndVideo}
                    onVideoReady={onVideoReady}
                    onVideoError={onVideoError}
                    onPauseVideo={onPauseVideo}
                    onExitVideo={onExitVideo}
                />,
            );
        });

        it('matches snapshot', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
    });

    describe('video is active', () => {
        let wrapper: ShallowWrapper;
        beforeEach(() => {
            wrapper = shallow(
                <InstructionVideoComponent
                    videoIsActive={true}
                    onPlayVideo={onPlayVideo}
                    onEndVideo={onEndVideo}
                    onVideoReady={onVideoReady}
                    onVideoError={onVideoError}
                    onPauseVideo={onPauseVideo}
                    onExitVideo={onExitVideo}
                />,
            ) as ShallowWrapper;
        });

        it('matches snapshot', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });

        it('renders x button', () => {
            expect(wrapper.dive().find(IconButton).length).toBe(1);
        });

        it('calls onExitVideo when button is clicked', () => {
            wrapper.dive().find(IconButton).simulate('click');
            expect(onExitVideo).toHaveBeenCalledTimes(1);
        });
    });

    describe('video is not active', () => {
        let wrapper: ShallowWrapper;
        beforeEach(() => {
            wrapper = shallow(
                <InstructionVideoComponent
                    videoIsActive={false}
                    onPlayVideo={onPlayVideo}
                    onEndVideo={onEndVideo}
                    onVideoReady={onVideoReady}
                    onVideoError={onVideoError}
                    onPauseVideo={onPauseVideo}
                    onExitVideo={onExitVideo}
                />,
            ) as ShallowWrapper;
        });

        it('matches snapshot', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });

        it('does not render x button', () => {
            expect(wrapper.find(IconButton).length).toBe(0);
        });
    });

    describe('youtube functions', () => {
        let wrapper: ShallowWrapper;
        beforeEach(() => {
            wrapper = shallow(
                <InstructionVideoComponent
                    videoIsActive={true}
                    onPlayVideo={onPlayVideo}
                    onEndVideo={onEndVideo}
                    onVideoReady={onVideoReady}
                    onVideoError={onVideoError}
                    onPauseVideo={onPauseVideo}
                    onExitVideo={onExitVideo}
                />,
            ) as ShallowWrapper;
        });

        it('calls onEndVideo when video is ended', () => {
            expect(onEndVideo).toHaveBeenCalledTimes(0);
            wrapper.dive().find(Youtube).simulate('end');
            expect(onEndVideo).toHaveBeenCalledTimes(1);
        });

        it('calls onPlayVideo when video is played', () => {
            expect(onPlayVideo).toHaveBeenCalledTimes(0);
            wrapper.dive().find(Youtube).simulate('play');
            expect(onPlayVideo).toHaveBeenCalledTimes(1);
        });

        it('calls onVideoReady when video is ready', () => {
            expect(onVideoReady).toHaveBeenCalledTimes(0);
            wrapper.dive().find(Youtube).simulate('ready');
            expect(onVideoReady).toHaveBeenCalledTimes(1);
        });

        it('calls onVideoError when video has an error', () => {
            expect(onVideoError).toHaveBeenCalledTimes(0);
            wrapper.dive().find(Youtube).simulate('error');
            expect(onVideoError).toHaveBeenCalledTimes(1);
        });

        it('calls onPauseVideo when video is paused', () => {
            expect(onPauseVideo).toHaveBeenCalledTimes(0);
            wrapper.dive().find(Youtube).simulate('pause');
            expect(onPauseVideo).toHaveBeenCalledTimes(1);
        });
    });

    describe('vimeo video and functions', () => {
        let wrapper: ShallowWrapper;
        let onVideoReadyVimeo: Mock;
        let onVideoErrorVimeo: Mock;
        let onPlayVideoVimeo: Mock;
        let onPauseVideoVimeo: Mock;
        let onEndVideoVimeo: Mock;
        let onExitVideoVimeo: Mock;
        let vimeoProps: {
            [key: string]: Mock | boolean;
        };

        beforeEach(() => {
            onPlayVideo = vi.fn();
            onEndVideo = vi.fn();
            onVideoReady = vi.fn();
            onVideoError = vi.fn();
            onPauseVideo = vi.fn();
            onExitVideo = vi.fn();
            onPlayVideoVimeo = vi.fn();
            onEndVideoVimeo = vi.fn();
            onVideoReadyVimeo = vi.fn();
            onVideoErrorVimeo = vi.fn();
            onPauseVideoVimeo = vi.fn();
            onExitVideoVimeo = vi.fn();
            vimeoProps = {
                onVideoReadyVimeo,
                onVideoErrorVimeo,
                onPlayVideoVimeo,
                onPauseVideoVimeo,
                onEndVideoVimeo,
                onExitVideoVimeo,
                vimeoPlaying: true,
            };

            wrapper = shallow(
                <InstructionVideoComponent
                    videoIsActive={true}
                    onPlayVideo={onPlayVideo}
                    onEndVideo={onEndVideo}
                    onVideoReady={onVideoReady}
                    onVideoError={onVideoError}
                    onPauseVideo={onPauseVideo}
                    onExitVideo={onExitVideo}
                    vimeoProps={vimeoProps}
                />,
            ) as ShallowWrapper;
            (config as Config).getConfig.mockImplementation(() => ({
                instructionVideoId: 'aBcDeFgHiJk',
                instructionVideoHostingSource: 'vimeo',
                videoDirectUrl: 'https://vimeo.com/761626618/6bd48bd2e9',
            }));
        });
        afterEach(() => vi.resetAllMocks());

        it('renders properly', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });

        it('finds the react player', () => {
            expect(wrapper.dive().find(ReactPlayer).length).toBe(1);
        });

        it('finds the x button', () => {
            expect(wrapper.dive().find(IconButton).length).toBe(1);
        });

        it('calls onExitVideo when button is clicked', () => {
            wrapper.dive().find(IconButton).simulate('click');
            expect(onExitVideoVimeo).toHaveBeenCalledTimes(1);
        });
    });
});
