vi.mock('@utils/FeatureFlags');

import * as React from 'react';
import thunk from 'redux-thunk';
import configureStore from 'redux-mock-store';
import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { CancelVisitDialog } from '@components/WaitingRoom/CancelVisitDialog';
import { MockedFunction, vi } from 'vitest';
import { getFeatureFlag } from '@utils/FeatureFlags';
import { createTheme, ThemeProvider } from '@mui/material';
import { grey } from '@mui/material/colors';

vi.mock('react-router-dom', () => ({
    useParams: vi.fn().mockReturnValue({}),
    useLocation: vi.fn().mockReturnValue({}),
    useNavigate: vi.fn().mockReturnValue(vi.fn()),
}));

const mockTheme = createTheme({
    palette: {
        silver: {
            main: grey[600],
            contrastText: '#fff',
        },
    },
});

const getFeatureFlagMock = getFeatureFlag as MockedFunction<
    typeof getFeatureFlag
>;

const middlewares = [thunk];
const mockStore = configureStore(middlewares);
const store = mockStore({});

test('<CancelVisitDialog /> renders open correctly flag off', () => {
    const wrapper = render(
        <ThemeProvider theme={mockTheme}>
            <Provider store={store}>
                <CancelVisitDialog
                    active={true}
                    closeCancelVisitDialog={vi.fn()}
                    endCall={vi.fn()}
                />
            </Provider>
        </ThemeProvider>,
    );
    expect(wrapper).toMatchSnapshot();
});

test('<CancelVisitDialog /> renders closed correctly flag on', () => {
    getFeatureFlagMock.mockReturnValue({ video: true });
    const wrapper = render(
        <ThemeProvider theme={mockTheme}>
            <Provider store={store}>
                <CancelVisitDialog
                    active={true}
                    closeCancelVisitDialog={vi.fn()}
                    endCall={vi.fn()}
                />
            </Provider>
        </ThemeProvider>,
    );
    expect(wrapper).toMatchSnapshot();
});
