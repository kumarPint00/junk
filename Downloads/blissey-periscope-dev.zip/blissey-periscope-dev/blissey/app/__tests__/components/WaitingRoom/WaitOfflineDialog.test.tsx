import * as React from 'react';
import { shallow } from 'enzyme';
import Button from '@mui/material/Button';
import { WaitOfflineDialog } from '@components/WaitingRoom/WaitOfflineDialog';

import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';
import toJson from 'enzyme-to-json';
vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { interactionEvent: vi.fn() },
}));

describe('WaitOfflineDialog', () => {
    it('<WaitOfflineDialog /> initial modal renders open correctly', () => {
        const wrapper = shallow(
            <WaitOfflineDialog
                active={true}
                closeWaitOfflineDialog={vi.fn()}
                handleSendPatientEnterWaitOffline={vi.fn()}
                patientEnterWaitOfflineStatus={null}
            />,
        ).dive();
        expect(wrapper.find(Button).length).toBe(2);
        expect(toJson(wrapper)).toMatchSnapshot();
        wrapper.find(Button).at(1).simulate('click');
        expect(V2Analytics.interactionEvent).toHaveBeenCalled();
    });

    it('<WaitOfflineDialog /> initial modal closes dialog correctly', () => {
        const closeDialog = vi.fn();
        const wrapper = shallow(
            <WaitOfflineDialog
                active={false}
                closeWaitOfflineDialog={closeDialog}
                handleSendPatientEnterWaitOffline={vi.fn()}
                patientEnterWaitOfflineStatus={null}
            />,
        ).dive();
        wrapper.find(Button).at(0).simulate('click');
        expect(closeDialog.mock.calls.length).toBe(1);
    });

    it('<WaitOfflineDialog /> initial modal renders the failure message properly', () => {
        const wrapper = shallow(
            <WaitOfflineDialog
                active={true}
                closeWaitOfflineDialog={vi.fn()}
                handleSendPatientEnterWaitOffline={vi.fn()}
                patientEnterWaitOfflineStatus={'failure'}
            />,
        ).dive();
        expect(wrapper.find(Button).length).toBe(2);
        expect(toJson(wrapper)).toMatchSnapshot();
        wrapper.find(Button).at(1).simulate('click');
        expect(V2Analytics.interactionEvent).toHaveBeenCalled();
    });

    it('<WaitOfflineDialog /> success modal renders open properly', () => {
        const handlePatientRedirectAfterWaitOfflineMock = vi.fn();
        const wrapper = shallow(
            <WaitOfflineDialog
                active={true}
                closeWaitOfflineDialog={vi.fn()}
                handleSendPatientEnterWaitOffline={vi.fn()}
                patientEnterWaitOfflineStatus={'success'}
                handlePatientRedirectAfterWaitOffline={
                    handlePatientRedirectAfterWaitOfflineMock
                }
            />,
        ).dive();
        expect(wrapper.find(Button).length).toBe(1);
        expect(toJson(wrapper)).toMatchSnapshot();
        wrapper.find(Button).at(0).simulate('click');
        expect(handlePatientRedirectAfterWaitOfflineMock).toHaveBeenCalled();
    });
});
