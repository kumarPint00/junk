import Link from '@mui/material/Link';
import { shallow } from 'enzyme';
import * as React from 'react';
import { render } from '@testing-library/react';
import { Provider } from 'react-redux';
import { getLocalState } from '@redux/middleware/localStorage';
import { initialState } from '@redux/modules';
import configureStore from 'redux-mock-store';

import { UserDetails } from '@dexcare/circus-saturn';

import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';
import { TestStatus } from '@common/video';
import CallSelfCheckComponent from '@components/CallSelfCheck/CallSelfCheckComponent';
import { ChatButton } from '@components/WaitingRoom/ChatButton';
import { InstructionVideoComponent } from '@components/WaitingRoom/InstructionVideoComponent';
import { WaitingRoomComponent } from '@components/WaitingRoom/WaitingRoomComponent';
import {
    VideoStatus,
    WaitingRoomProps,
} from '@components/WaitingRoom/WaitingRoomInterfaces';
import { config } from '@dexcare/circus-jupiter';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import { getWaitTime } from '@utils/getWaitTime';
import toJson from 'enzyme-to-json';
import { when } from 'jest-when';
import { getPantryConfig } from '@clients/Pantry/getPantryConfig';

interface Config {
    getConfig: Mock;
}

import * as featureFlags from '@utils/FeatureFlags';

import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';
import { vi, Mock, MockedFunction } from 'vitest';
import { InstructionVideoComponentProps } from '@components/WaitingRoom/InstructionVideoInterfaces';
vi.mock('@dexcare/festivus-aluminum-pole-analytics');

vi.mock('react-router-dom', () => ({
    useParams: vi.fn().mockReturnValue({}),
    useLocation: vi.fn().mockReturnValue({}),
    useNavigate: vi.fn().mockReturnValue(vi.fn()),
}));

vi.mock('@dexcare/circus-jupiter', async (importOriginal) => {
    const actual = await importOriginal();
    return {
        ...(actual as object),
        config: {
            getConfig: vi.fn(),
        },
        jupiterOptions: {},
        LogManager: {
            getLogger: () => {
                return {
                    child: () => {
                        return { warn: vi.fn(), info: vi.fn(), error: vi.fn() };
                    },
                };
            },
        },
    };
});

vi.mock('@common/video');
vi.mock('@utils/BrowserCheck', () => ({
    getBrowser() {
        return 'chrome';
    },
}));
vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: {
        sendEvent: vi.fn(),
        sendPageView: vi.fn(),
    },
    V2Analytics: { interactionEvent: vi.fn() },
}));
vi.mock('@utils/FeatureFlags', async () => {
    const originalFeatureFlags: typeof import('@utils/FeatureFlags') =
        await vi.importActual('@utils/FeatureFlags');
    return {
        ...originalFeatureFlags,
        getFeatureFlag: vi.fn(),
        getArrayFeatureFlag: vi.fn(),
    };
});
vi.mock('@utils/getWaitTime', () => ({
    getWaitTime: vi.fn(),
}));

vi.useFakeTimers();
vi.mock('../../../src/clients/Backend/BackendFacade');
vi.mock('@clients/Pantry/getPantryConfig', () => ({
    getPantryConfig: vi.fn(),
}));

const presenterUserDetailsNoEmail: Omit<UserDetails, 'email'> = {
    id: 'testId',
    displayName: 'testDisplayName',
    givenName: 'testGivenName',
    familyName: 'testFamilyName',
    roles: ['telehealth_presenter'],
    token: 'testToken',
    expiration: 1,
};

const presenterUserDetails: UserDetails = {
    ...presenterUserDetailsNoEmail,
    email: 'email@email.com',
};

const healthChecks = {
    healthCheckProgress: 0,
    networkStatus: TestStatus.NotRun,
    signalingStatus: TestStatus.NotRun,
    camStatus: TestStatus.NotRun,
    micStatus: TestStatus.NotRun,
    iceCandidateStatus: TestStatus.NotRun,
    localConnectStatus: TestStatus.NotRun,
    remoteConnectStatus: TestStatus.NotRun,
};

const healthInfoPassed = {
    healthCheckStatus: HealthCheckStatus.Healthy,
    errorNumber: 0,
    errorMessage: '',
};

const healthInfoNotPassed = {
    healthCheckStatus: HealthCheckStatus.Unknown,
    errorNumber: 0,
    errorMessage: '',
};

const mockGetFeatureFlag = getFeatureFlag as MockedFunction<
    typeof getFeatureFlag
>;
const mockGetPantryConfig = getPantryConfig as MockedFunction<
    typeof getPantryConfig
>;

const localState = getLocalState(initialState);
const mockStore = configureStore([]);
const store = mockStore(localState);

describe('<WaitingRoomComponent />', () => {
    let defaultProps: WaitingRoomProps;
    const testDeviceId = 'test';

    beforeEach(() => {
        vi.clearAllMocks();
        (config as Config).getConfig.mockImplementation(() => ({
            troubleshootingLinks: {
                webkit: 'troubleshootingUrl',
                chrome: 'troubleshootingUrl',
                unknown: 'troubleshootingUrl',
            },
        }));
        defaultProps = {
            visitId: 'testVisitID',
            onChatClick: vi.fn(),
            userDetails: presenterUserDetails,
            brand: 'providence',
            health: healthChecks,
            healthInfo: healthInfoPassed,
            runTests: vi.fn(),
            endCall: vi.fn(),
            cancelVisit: vi.fn(),
            selfCheckCompleted: true,
            audioDeviceId: 'testAudioDeviceId',
            videoDeviceId: 'testAudioDeviceId',
            setAudioDeviceId: vi.fn(),
            setVideoDeviceId: vi.fn(),
            chatIsVisible: false,
            waitingRoomChatDelayInMs: 1,
        } as unknown as WaitingRoomProps;
        mockGetPantryConfig.mockResolvedValue({
            minimumWaitTimeForWaitOffline: 600,
        });
    });

    test('render', () => {
        const { container } = render(
            <Provider store={store}>
                <WaitingRoomComponent {...defaultProps} />
            </Provider>,
        );
        expect(container).toMatchSnapshot();
    });

    test('calls getWaitTime', () => {
        vi.spyOn(global, 'setTimeout');
        shallow(<WaitingRoomComponent {...defaultProps} />).dive();
        expect(setTimeout).toHaveBeenCalledTimes(1);
        expect(getWaitTime).toHaveBeenCalledTimes(1);
    });

    test('render with hiding photoId Message', () => {
        (config as Config).getConfig.mockImplementation(() => ({
            disableWaitingRoomPhotoIdMessage: true,
            troubleshootingLinks: {
                webkit: 'troubleshootingUrl',
                chrome: 'troubleshootingUrl',
                unknown: 'troubleshootingUrl',
            },
        }));
        const { container } = render(
            <Provider store={store}>
                <WaitingRoomComponent {...defaultProps} />
            </Provider>,
        );
        expect(container).toMatchSnapshot();
    });

    test('<WaitingRoomComponent />, no email', () => {
        const { container } = render(
            <Provider store={store}>
                <WaitingRoomComponent
                    {...{
                        ...defaultProps,
                        userDetails: { ...presenterUserDetailsNoEmail },
                    }}
                />
            </Provider>,
        );
        expect(container).toMatchSnapshot();
    });

    test('<WaitingRoomComponent /> calls enter waiting room on mount', () => {
        shallow(<WaitingRoomComponent {...defaultProps} />).dive();
        expect(Analytics.sendEvent).toHaveBeenCalledWith({
            eventAction: 'waitingRoomEnter',
            eventName: 'enter waiting room',
            type: 'success',
            visitId: 'testVisitID',
        });

        expect(Analytics.sendPageView).toHaveBeenCalledWith({
            destinationURL: '/visit/room/anteRoom',
        });
    });

    test('<WaitingRoomComponent /> correctly triggers chat', () => {
        const wrapper = shallow(
            <WaitingRoomComponent {...defaultProps} />,
        ).dive();

        wrapper.find(ChatButton).first().simulate('click');
        expect(defaultProps.onChatClick).toBeCalledTimes(1);
        expect(Analytics.sendEvent).toHaveBeenCalledWith({
            eventAction: 'click',
            eventName: 'Have questions? Chat with our clinic staff',
            type: 'button',
        });
        expect(Analytics.sendPageView).toHaveBeenCalledWith({
            destinationURL: '/visit/room/anteRoom',
        });
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'chat_engage',
            location: 'waiting room',
            visit_id: 'testVisitID',
        });
    });

    test('renders with waitoffline flag on, and not in caregiverassigned state', () => {
        defaultProps.status = 'waitingroom';
        when(mockGetFeatureFlag)
            .calledWith(FeatureFlags.enableManuallyEnteringWaitoffline)
            .mockReturnValue(true);

        const wrapper = shallow(
            <WaitingRoomComponent {...defaultProps} />,
        ).dive();
        expect(wrapper).toMatchSnapshot();
        expect(wrapper.find(ChatButton).length).toBe(1);
    });

    test('renders with waitoffline flag off, and in caregiverassigned state', () => {
        defaultProps.status = 'caregiverassigned';
        when(mockGetFeatureFlag)
            .calledWith(FeatureFlags.enableManuallyEnteringWaitoffline)
            .mockReturnValue(false);

        const wrapper = shallow(
            <WaitingRoomComponent {...defaultProps} />,
        ).dive();
        expect(toJson(wrapper)).toMatchSnapshot();
        expect(wrapper.find(ChatButton).length).toBe(1);
    });

    describe('cancel button', () => {
        function getCancelVisitLink(
            enableFeatureFlag: boolean,
            enableCancelButton: boolean,
            notSeenByProvider: boolean,
        ) {
            when(mockGetFeatureFlag)
                .calledWith(FeatureFlags.cancellation)
                .mockReturnValue(enableFeatureFlag)
                .defaultReturnValue(false);

            const timestamps = {
                invisit: notSeenByProvider
                    ? undefined
                    : '2023-10-26T19:33:15.123Z',
            };

            const wrapper = shallow(
                <WaitingRoomComponent
                    enableCancelButton={enableCancelButton}
                    timestamps={timestamps}
                    {...defaultProps}
                />,
            ).dive();

            return wrapper.find('[data-uitest="cancelVisitLink"]');
        }

        test('should not render when feature flag is disabled', () => {
            expect(getCancelVisitLink(false, true, true).exists()).toBeFalsy();
        });
        test('should not render when cancel button is false', () => {
            expect(getCancelVisitLink(true, false, true).exists()).toBeFalsy();
        });
        test('should not render when already seen by provider', () => {
            expect(getCancelVisitLink(true, true, false).exists()).toBeFalsy();
        });
        test('should render when all conditions are true', () => {
            expect(getCancelVisitLink(true, true, true).exists()).toBeTruthy();
        });

        test('cancel button fires analytics when clicked', () => {
            getCancelVisitLink(true, true, true).simulate('click');
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'cta_click',
                text: 'cancel visit',
            });
        });
    });

    describe('<WaitingRoomComponent /> instruction video', () => {
        let props: WaitingRoomProps;
        beforeEach(() => {
            props = {
                visitId: 'testVisitID',
                onChatClick: vi.fn(),
                userDetails: presenterUserDetails,
                brand: 'providence',
                health: healthChecks,
                healthInfo: healthInfoPassed,
                isTestVisit: false,
                lostConnection: false,
                runTests: vi.fn(),
                cancelVisit: vi.fn(),
                changeCam: vi.fn(),
                changeMic: vi.fn(),
                chatIsVisible: false,
                enableInstructionVideo: true,
            } as unknown as WaitingRoomProps;
        });

        it('does not show video when status is none', () => {
            const wrapper = shallow(<WaitingRoomComponent {...props} />).dive();
            expect(wrapper.find(InstructionVideoComponent).length).toBe(0);
        });

        it('does not show self check component when video is playing', () => {
            featureFlags.getFeatureFlag = () => true;
            const wrapper = shallow(<WaitingRoomComponent {...props} />).dive();
            wrapper.setState({ videoStatus: VideoStatus.PLAYING });

            expect(toJson(wrapper)).toMatchSnapshot();
        });

        it('shows self check component when video is not playing', () => {
            const wrapper = shallow(<WaitingRoomComponent {...props} />).dive();

            expect(toJson(wrapper)).toMatchSnapshot();
        });

        it('does not show video with status queued, health check not passed', () => {
            props.healthInfo = healthInfoNotPassed;
            const wrapper = shallow(<WaitingRoomComponent {...props} />).dive();
            wrapper.setState({ videoStatus: VideoStatus.QUEUED });
            expect(wrapper.find(InstructionVideoComponent).length).toBe(0);
        });

        it('plays video once status is queued and health check is healthy', () => {
            featureFlags.getFeatureFlag = () => true;
            const wrapper = shallow(<WaitingRoomComponent {...props} />).dive();
            wrapper.setState({ videoStatus: VideoStatus.QUEUED });
            expect(wrapper.find(InstructionVideoComponent).length).toBe(1);
            expect(wrapper.state('videoStatus')).toEqual(VideoStatus.PLAYING);
        });

        it('shows video when status is playing, health check passed', () => {
            featureFlags.getFeatureFlag = () => true;
            const wrapper = shallow(<WaitingRoomComponent {...props} />).dive();
            wrapper.setState({ videoStatus: VideoStatus.PLAYING });
            expect(wrapper.find(InstructionVideoComponent).length).toBe(1);
        });

        it('shows video when status is ended, health check passed', () => {
            featureFlags.getFeatureFlag = () => true;
            const wrapper = shallow(<WaitingRoomComponent {...props} />).dive();
            wrapper.setState({ videoStatus: VideoStatus.ENDED });
            expect(wrapper.find(InstructionVideoComponent).length).toBe(1);
        });

        it('shows video when status is minimized, health check passed', () => {
            const wrapper = shallow(<WaitingRoomComponent {...props} />).dive();
            wrapper.setState({ videoStatus: VideoStatus.MINIMIZED });
            expect(wrapper.find(InstructionVideoComponent).length).toBe(1);
        });

        it('calls updateVideoState after X seconds', () => {
            vi.spyOn(global, 'setTimeout');
            props.waitingRoomVideoDelayInMs = 1000;
            props.healthInfo = healthInfoNotPassed;
            const wrapper = shallow(<WaitingRoomComponent {...props} />).dive();
            expect(wrapper.state('videoStatus')).toEqual(VideoStatus.NONE);
            expect(setTimeout).toHaveBeenCalledTimes(2);
            expect(setTimeout).toHaveBeenCalledWith(expect.any(Function), 1000);

            wrapper.setState({ videoStatus: VideoStatus.QUEUED });
            expect(wrapper.state('videoStatus')).toEqual(VideoStatus.QUEUED);
            wrapper.setProps({ ...props, healthInfo: healthInfoPassed });
            // now that status is queued and health check is healthy, should be moved to 'playing'
            expect(wrapper.state('videoStatus')).toEqual(VideoStatus.PLAYING);
        });

        describe('Troubleshooting link', () => {
            test('it fires analytics correctly', () => {
                const wrapper = shallow(
                    <WaitingRoomComponent enableCancelButton {...props} />,
                ).dive();

                expect(wrapper.find(Link).length).toBe(2);
                wrapper.find(Link).at(0).simulate('click');
                expect(Analytics.sendEvent).toHaveBeenCalledWith({
                    eventAction: 'click',
                    eventName: 'Troubleshoot Your Audio/Video Settings',
                    type: 'button',
                });
                expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                    eventName: 'cta_click',
                    click_text: 'Troubleshoot Your Audio/Video Settings',
                    click_url: 'troubleshootingUrl',
                });
            });
        });

        describe('video functions', () => {
            let mockVideoPlayer: {
                playVideo: Mock;
                pauseVideo: Mock;
                stopVideo: Mock;
            };
            beforeEach(() => {
                mockVideoPlayer = {
                    playVideo: vi.fn(),
                    pauseVideo: vi.fn(),
                    stopVideo: vi.fn(),
                };
            });

            it('calls playVideo() on ready', () => {
                const wrapper = shallow(
                    <WaitingRoomComponent {...props} />,
                ).dive();
                wrapper.setState({ videoStatus: VideoStatus.QUEUED });
                wrapper
                    .find(InstructionVideoComponent)
                    .simulate('videoReady', { target: mockVideoPlayer });

                expect(mockVideoPlayer.playVideo).toHaveBeenCalledTimes(1);
            });

            it('sets state to playing on play video', () => {
                featureFlags.getFeatureFlag = () => true;
                const wrapper = shallow(
                    <WaitingRoomComponent {...props} />,
                ).dive();
                wrapper.setState({ videoStatus: VideoStatus.QUEUED });
                wrapper.find(InstructionVideoComponent).simulate('playVideo');

                expect(wrapper.state('videoStatus')).toEqual(
                    VideoStatus.PLAYING,
                );
            });

            it('calls stopVideo() on end, and state to be ended_or_minimized', () => {
                featureFlags.getFeatureFlag = () => true;
                const wrapper = shallow(
                    <WaitingRoomComponent {...props} />,
                ).dive();
                wrapper.setState({ videoStatus: VideoStatus.PLAYING });
                wrapper
                    .find(InstructionVideoComponent)
                    .simulate('videoReady', { target: mockVideoPlayer });
                wrapper.find(InstructionVideoComponent).simulate('endVideo');

                expect(mockVideoPlayer.stopVideo).toHaveBeenCalledTimes(1);
                expect(wrapper.state('videoStatus')).toEqual(VideoStatus.ENDED);
            });

            it('sets state to error on video error', () => {
                featureFlags.getFeatureFlag = () => true;
                const wrapper = shallow(
                    <WaitingRoomComponent {...props} />,
                ).dive();
                wrapper.setState({ videoStatus: VideoStatus.QUEUED });
                wrapper
                    .find(InstructionVideoComponent)
                    .simulate('videoError', { data: 'oops!' });

                expect(wrapper.state('videoStatus')).toEqual(VideoStatus.ERROR);
            });

            it('sets state to error on vimeo video error', () => {
                featureFlags.getFeatureFlag = () => true;
                const wrapper = shallow(
                    <WaitingRoomComponent {...props} />,
                ).dive();
                wrapper.setState({ videoStatus: VideoStatus.QUEUED });
                const vimeoProps = wrapper
                    .find(InstructionVideoComponent)
                    .prop(
                        'vimeoProps',
                    ) as InstructionVideoComponentProps['vimeoProps'];
                vimeoProps.onVideoErrorVimeo({
                    message: 'Vimeo error!',
                    name: 'vimeoError',
                });

                expect(wrapper.state('videoStatus')).toEqual(VideoStatus.ERROR);
                expect(wrapper.state('vimeoPlaying')).toEqual(false);
            });

            it('updates camera and fires analytics', () => {
                const wrapper = shallow(
                    <WaitingRoomComponent {...props} />,
                ).dive();
                (
                    wrapper.find(CallSelfCheckComponent).props() as {
                        onCameraChange: (
                            event: React.ChangeEvent<HTMLSelectElement>,
                        ) => void;
                    }
                ).onCameraChange({
                    target: { value: testDeviceId },
                } as React.ChangeEvent<HTMLSelectElement>);
                expect(Analytics.sendEvent).toHaveBeenCalledWith({
                    eventAction: 'formEngagement',
                    formEngagement: {
                        formName: 'video/audio settings',
                        fieldName: 'video settings',
                        fieldValue: 'complete',
                    },
                });
            });

            it('updates mic and fires analytics', () => {
                const wrapper = shallow(
                    <WaitingRoomComponent {...props} />,
                ).dive();
                (
                    wrapper.find(CallSelfCheckComponent).props() as {
                        onAudioChange: (
                            event: React.ChangeEvent<HTMLSelectElement>,
                        ) => void;
                    }
                ).onAudioChange({
                    target: { value: testDeviceId },
                } as React.ChangeEvent<HTMLSelectElement>);
                expect(Analytics.sendEvent).toHaveBeenCalledWith({
                    eventAction: 'formEngagement',
                    formEngagement: {
                        formName: 'video/audio settings',
                        fieldName: 'audio settings',
                        fieldValue: 'complete',
                    },
                });
            });
        });
    });
});
