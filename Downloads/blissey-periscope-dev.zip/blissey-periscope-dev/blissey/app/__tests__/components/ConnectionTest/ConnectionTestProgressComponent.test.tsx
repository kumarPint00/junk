import * as React from 'react';
import { shallow } from 'enzyme';

import LinearProgress from '@mui/material/LinearProgress';

import { ConnectionTestProgressComponent } from '../../../src/components/ConnectionTest/ConnectionTestProgressComponent';

describe('<ConnectionTestProgressComponent />', () => {
    describe('Check skeleton with shallow rendering', () => {
        const connectionTestProgressComponent = (
            <ConnectionTestProgressComponent />
        );

        const wrapper = shallow(connectionTestProgressComponent);

        it('renders as a div', () => {
            expect(wrapper.type()).toBe('div');
        });

        it('contains contains a progress bar', () => {
            expect(wrapper.find(LinearProgress).length).toBe(1);
        });
    });
});
