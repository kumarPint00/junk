import * as React from 'react';
import { ReactWrapper, render } from 'enzyme';

import { TestStatus } from '@common/video';
import { ConnectionTestComponent } from '@components/ConnectionTest/ConnectionTestComponent';
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';
import { vi } from 'vitest';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { errorEvent: vi.fn() },
}));

describe('<ConnectionTestComponent />', () => {
    const defaultProps = {
        userDetails: {
            id: '1',
            displayName: 'Test',
            givenName: 'Given',
            familyName: 'Family',
            email: 'test@test.com',
            token: 'test-token',
            expiration: 10,
        },
        health: {
            healthCheckProgress: 0,
            networkStatus: TestStatus.NotRun,
            camStatus: TestStatus.NotRun,
            micStatus: TestStatus.NotRun,
            mediaPermissionStatus: undefined,
            publishStatus: TestStatus.NotRun,
        },
        healthInfo: {
            healthCheckStatus: HealthCheckStatus.Unknown,
        },
        runTests: vi.fn(),
        isProvider: false,
        lostConnection: false,
        i18n: {
            t: vi.fn(),
        },
    };

    it('renders correctly', () => {
        const component = render(
            <ConnectionTestComponent.WrappedComponent {...defaultProps} />,
        ) as ReactWrapper;

        expect(component).toMatchSnapshot();
    });

    it('renders progress component if healthCheckProgress is not 0', () => {
        const newProps = {
            ...defaultProps,
            health: {
                ...defaultProps.health,
                healthCheckProgress: 1,
            },
        };
        const component = render(
            <ConnectionTestComponent.WrappedComponent {...newProps} />,
        ) as ReactWrapper;

        expect(
            component.find('div[data-uitest="testconnectionprogress"]').length,
        ).toBe(1);
    });

    it('renders complete component if lostConnection is true', () => {
        const newProps = {
            ...defaultProps,
            healthCheckProgress: 1,
            lostConnection: true,
        };
        const component = render(
            <ConnectionTestComponent.WrappedComponent {...newProps} />,
        ) as ReactWrapper;
        const completeComponent = component.find(
            'div[data-uitest="testconnectionbutton"]',
        ) as ReactWrapper;
        expect(completeComponent.length).toBe(1);
        expect(completeComponent.find('div .header').text()).toBe(
            'waiting-room.tech-check.errors.connectionIssueHeader',
        );
        expect(completeComponent.find('div .message').text()).toBe(
            'waiting-room.tech-check.errors.connectionIssueDescription',
        );
    });
});
