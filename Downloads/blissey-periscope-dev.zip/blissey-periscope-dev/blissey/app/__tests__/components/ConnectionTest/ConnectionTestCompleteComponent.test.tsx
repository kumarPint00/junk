import * as React from 'react';
import { ShallowWrapper, shallow } from 'enzyme';

import { TestStatus } from '@common/video';
import { ConnectionTestCompleteComponent } from '@components/ConnectionTest/ConnectionTestCompleteComponent';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { errorEvent: vi.fn() },
}));

describe('<ConnectionTestCompleteComponent />', () => {
    const defaultProps = {
        passed: true,
        isProvider: true,
        health: {
            healthCheckProgress: 0,
            networkStatus: TestStatus.Passed,
            camStatus: TestStatus.Passed,
            micStatus: TestStatus.Passed,
            publishStatus: TestStatus.Passed,
            mediaPermissionStatus: undefined,
        },
        onClick: vi.fn(),
    };

    describe('Check pass case skeleton', () => {
        const connectionTestCompleteComponent = (
            <ConnectionTestCompleteComponent {...defaultProps} />
        );
        const wrapper = shallow(connectionTestCompleteComponent).dive();

        it('renders as a div', () => {
            expect(wrapper.type()).toBe('div');
        });

        it('contains several divs', () => {
            expect(wrapper.find('div').length).toBe(3);
        });
    });

    describe('Check fail case skeleton', () => {
        let wrapper: ShallowWrapper;
        const props = { ...defaultProps };
        props.passed = false;
        const connectionTestCompleteComponent = (
            <ConnectionTestCompleteComponent {...props} />
        );

        beforeEach(() => {
            wrapper = shallow(connectionTestCompleteComponent).dive();
        });

        it('renders as a div', () => {
            expect(wrapper.type()).toBe('div');
            expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
                text: 'waiting-room.tech-check.errors.genericIssue',
                type: 'waiting-room.tech-check.errors.unknownIssueHeader',
            });
        });

        it('contains several divs', () => {
            expect(wrapper.find('div').length).toBe(3);
        });
    });

    describe('Check buttons', () => {
        let props: typeof defaultProps;
        beforeEach(() => {
            props = { ...defaultProps };
            props.passed = false;
            props.onClick = vi.fn();
        });

        it('when retest is clicked after success, the test is rerun', () => {
            const connectionTestCompleteComponent = (
                <ConnectionTestCompleteComponent {...props} />
            );
            const wrapper = shallow(connectionTestCompleteComponent).dive();
            wrapper.find('.container').simulate('click');
            expect(props.onClick).toHaveBeenCalledTimes(1);
        });

        it('when retest is clicked after failure, the test is rerun', () => {
            const connectionTestCompleteComponent = (
                <ConnectionTestCompleteComponent {...props} />
            );
            const wrapper = shallow(connectionTestCompleteComponent).dive();
            wrapper.find('.container').simulate('click');
            expect(props.onClick).toHaveBeenCalledTimes(1);
        });
    });
});
