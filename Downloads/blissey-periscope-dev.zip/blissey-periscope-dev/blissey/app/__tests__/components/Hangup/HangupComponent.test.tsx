import * as React from 'react';
import { render } from '@testing-library/react';
import { Hangup } from '../../../src/components/Hangup/Hangup';

describe('<Hangup />', () => {
    test('should match snapshot', () => {
        const { container } = render(
            <Hangup caregiverPortalLink={'http://testLink.com'} />,
        );
        expect(container).toMatchSnapshot();
    });
});
