import * as React from 'react';
import { shallow } from 'enzyme';
import { UserDetails } from '@dexcare/circus-saturn';
import { EstimatedWaitTime } from '@components/EstimatedWaitTime/EstimatedWaitTime';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';
import toJson from 'enzyme-to-json';

vi.mock('@clients/VisitService/VisitServiceClient');
vi.mock('@dexcare/circus-jupiter');
vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { interactionEvent: vi.fn() },
}));

interface EstimatedWaitTime {
    formatEstimateAsOf(timestamp?: string | Date): string;
    submitWaitingRoomEvent(estimatedSeconds?: number): void;
    formatDate(): string;
}

describe('<EstimatedWaitTime />', () => {
    const userDetails: UserDetails = {
        id: 'testId',
        displayName: 'testDisplayName',
        givenName: 'testGivenName',
        familyName: 'testFamilyName',
        email: 'email@email.com',
        roles: [''],
        token: 'token',
        expiration: 1,
    };

    const props = (loading: boolean = true) => ({
        visitId: 'visitId',
        userDetails,
        brand: 'providence',
        initialWait: 1,
        waitTimeInfo: {
            estimatedWaitTimeMessage: 'nhan is cool',
            estimatedWaitTimeSeconds: 60,
            estimateGeneratedAt: '2021-10-10T10:10:10Z',
            waitTimeLocalizationInfo: {
                waitTimeMapKey: 'key',
                timeMinSeconds: 300,
                timeMaxSeconds: 600,
                modality: 'virtual',
            },
            loading,
        },
    });

    afterEach(() => {
        vi.clearAllMocks();
    });

    it('exists loading true', () => {
        const wrapper = shallow<typeof EstimatedWaitTime>(
            <EstimatedWaitTime {...props(true)} />,
        );
        expect(wrapper).toBeTruthy();
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    it('exists loading false', () => {
        const wrapper = shallow<typeof EstimatedWaitTime>(
            <EstimatedWaitTime {...props(true)} />,
        );
        expect(wrapper).toBeTruthy();
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    it.skip('gets estimate as of string correctly', () => {
        // TODO: Test needs updated for localization
        const wrapper = shallow<typeof EstimatedWaitTime>(
            <EstimatedWaitTime {...props()} />,
        );
        const result: string = (
            wrapper.dive().instance() as unknown as EstimatedWaitTime
        ).formatEstimateAsOf('2019-01-14T22:49:59.540Z');
        // We can't do a strict equal because output depends on timezone of machine
        expect(result.match(/waitEstimation_/)).not.toBe(null);
    });

    it('correctly fires analytics event with estimated wait time seconds', () => {
        const wrapper = shallow<typeof EstimatedWaitTime>(
            <EstimatedWaitTime {...props()} />,
        );
        (
            wrapper.dive().instance() as unknown as EstimatedWaitTime
        ).submitWaitingRoomEvent(60);
        const date = (
            wrapper.dive().instance() as unknown as EstimatedWaitTime
        ).formatDate();
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'enter_waiting_room',
            appt_date: date,
            visit_id: 'visitId',
            wait_time: '1 min',
        });
    });

    it('correctly fires analytics event with estimated wait time seconds as null', () => {
        const wrapper = shallow<typeof EstimatedWaitTime>(
            <EstimatedWaitTime {...props()} />,
        );
        (
            wrapper.dive().instance() as unknown as EstimatedWaitTime
        ).submitWaitingRoomEvent(null);
        const date = (
            wrapper.dive().instance() as unknown as EstimatedWaitTime
        ).formatDate();
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'enter_waiting_room',
            appt_date: date,
            visit_id: 'visitId',
            wait_time: 'unknown',
        });
    });

    it('correctly fires analytics event without estimated wait time seconds', () => {
        const wrapper = shallow<typeof EstimatedWaitTime>(
            <EstimatedWaitTime {...props()} />,
        );
        wrapper.dive().instance().state = {};
        (
            wrapper.dive().instance() as unknown as EstimatedWaitTime
        ).submitWaitingRoomEvent();
        const date = (
            wrapper.dive().instance() as unknown as EstimatedWaitTime
        ).formatDate();

        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'enter_waiting_room',
            appt_date: date,
            visit_id: 'visitId',
            wait_time: 'unknown',
        });
    });
});
