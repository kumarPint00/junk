import { shallow } from 'enzyme';
import * as React from 'react';

import { UserDetails } from '@dexcare/circus-saturn';

import CallSelfCheckComponent, {
    Props,
} from '@components/CallSelfCheck/CallSelfCheckComponent';
import { DeviceSelectionComponent } from '@components/DeviceSelection/DeviceSelectionComponent';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';

vi.mock('@utils/BrowserCheck', () => ({
    getBrowser() {
        return 'chrome';
    },
}));

vi.mock('@utils/FeatureFlags', async () => {
    const original = await vi.importActual('@utils/FeatureFlags');
    return {
        ...(original as object),
        getArrayFeatureFlag: () => undefined,
    };
});

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { errorEvent: vi.fn() },
}));
import { HealthCheckStatus } from '@common/ConnectionTest/HealthCheckStatus';
import { initialState } from '@redux/modules/health';
import {
    ErrorMessageConfig,
    mediaAccessDeniedConfig,
} from '@common/techCheckErrorMessages';
import { vi } from 'vitest';
import { DeviceSelectionComponentProps } from '@components/DeviceSelection/DeviceSelectionComponentInterfaces';
import { render } from '@testing-library/react';

const userDetails: UserDetails = {
    id: '1',
    displayName: 'provider',
    givenName: 'Provider',
    familyName: 'ofProviders',
    email: 'provider@fakeEmail.com',
    token: 'fakeToken',
    expiration: 2,
};

const getCallSelfCheckComponent = (overrides: Partial<Props> = {}) => {
    const props: Props = {
        visitId: '',
        selfViewId: 'testCallSelfCheckComponent',
        lostConnection: false,
        disabled: false,
        userDetails: userDetails,
        videoDeviceId: 'camera',
        audioDeviceId: 'audio',
        healthInfo: {
            healthCheckStatus: HealthCheckStatus.Unknown,
        },
        health: initialState,
        videoDevices: [],
        audioDevices: [],
        isBlurEnabled: false,
        onAudioChange: vi.fn(),
        onCameraChange: vi.fn(),
        ...overrides,
    };
    return <CallSelfCheckComponent.WrappedComponent {...props} />;
};

describe('<CallSelfCheckComponent />', () => {
    afterEach(() => {
        vi.clearAllMocks();
    });
    describe('DeviceSelectionComponent', () => {
        test('it exists', () => {
            const wrapper = shallow(getCallSelfCheckComponent());
            expect(
                wrapper.find(DeviceSelectionComponent).exists(),
            ).toBeTruthy();
        });

        test('it matches selected camera', () => {
            const wrapper = shallow(
                getCallSelfCheckComponent({
                    videoDevices: [
                        {
                            label: 'Camera',
                            value: 'camera',
                        },
                    ],
                }),
            );
            wrapper.setState({ selectedCamera: 'camera' });
            const deviceSelectionProps = wrapper
                .find(DeviceSelectionComponent)
                .first()
                .props() as DeviceSelectionComponentProps;
            expect(deviceSelectionProps.selectedCamera).toEqual('camera');
        });

        test('it matches selected audio', () => {
            const wrapper = shallow(
                getCallSelfCheckComponent({
                    audioDevices: [
                        {
                            label: 'Mic',
                            value: 'audio',
                        },
                    ],
                }),
            );
            wrapper.setState({ selectedAudio: 'audio' });
            const deviceSelectionProps = wrapper
                .find(DeviceSelectionComponent)
                .first()
                .props() as DeviceSelectionComponentProps;
            expect(deviceSelectionProps.selectedAudio).toEqual('audio');
        });
    });

    test('renders', () => {
        const { container } = render(getCallSelfCheckComponent());
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).not.toHaveBeenCalled();
    });

    test('renders, with error', () => {
        const { container } = render(
            getCallSelfCheckComponent({
                health: {
                    ...initialState,
                    mediaPermissionStatus: 'denied',
                },
                healthInfo: {
                    healthCheckStatus: HealthCheckStatus.Unhealthy,
                    errorConfig: mediaAccessDeniedConfig as ErrorMessageConfig,
                },
            }),
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: 'waiting-room.tech-check.errors.mediaPermissionIssueDescription',
            type: 'media access',
        });
    });
});
