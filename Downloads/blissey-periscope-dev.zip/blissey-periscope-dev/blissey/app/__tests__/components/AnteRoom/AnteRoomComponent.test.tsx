import * as sinon from 'sinon';
import { mount, ReactWrapper } from 'enzyme';
import { render, fireEvent } from '@testing-library/react';
import * as React from 'react';
import { Provider } from 'react-redux';
import { AnteRoomComponentProps } from '@components/AnteRoom/AnteRoomComponentInterfaces';
import { getLocalState } from '@redux/middleware/localStorage';
import { initialState } from '@redux/modules';
import configureStore from 'redux-mock-store';
import { Button, Props as ButtonProps } from '@components/Button';
import { UserDetails } from '@dexcare/circus-saturn';
import { HealthCheckStatus } from '../../../src/common/ConnectionTest/HealthCheckStatus';
import { TestStatus } from '@common/video';

import { AnteRoomComponent } from '@components/AnteRoom/AnteRoomComponent';
import { TState } from '@redux/modules/health';
import { vi } from 'vitest';

const fakeUserDetails: UserDetails = {
    id: '1',
    displayName: 'provider',
    givenName: 'Provider',
    familyName: 'ofProviders',
    email: 'provider@fakeEmail.com',
    token: 'fakeToken',
    expiration: 2,
};

const healthChecks: TState = {
    healthCheckProgress: 0,
    networkStatus: TestStatus.NotRun,
    camStatus: TestStatus.NotRun,
    micStatus: TestStatus.NotRun,
    mediaPermissionStatus: 'allowed',
    publishStatus: TestStatus.NotRun,
};

const healthInfoPassed = {
    healthCheckStatus: HealthCheckStatus.Healthy,
    errorNumber: 0,
    errorMessage: '',
};

const onConnectClick = sinon.stub();

const localState = getLocalState(initialState);
const mockStore = configureStore([]);
const store = mockStore(localState);

const getAnteRoomComponent = (overrides = {}) => {
    const props = {
        visitId: '',
        selfCheckCompleted: true,
        userDetails: fakeUserDetails,
        onConnect: onConnectClick,
        health: healthChecks,
        healthInfo: healthInfoPassed,
        changeCam: vi.fn(),
        changeMic: vi.fn(),
        runTests: vi.fn(),
        lostConnection: false,
        ...overrides,
    } as unknown as AnteRoomComponentProps;
    return (
        <Provider store={store}>
            <AnteRoomComponent {...props} />
        </Provider>
    );
};

vi.mock('react-i18next', () => ({
    withTranslation:
        () =>
        <P extends object>(Component: React.FunctionComponent<P>) => {
            const WrappedComponent = (props: P) => (
                <Component {...props} t={() => ''} i18n={{ t: () => '' }} />
            );
            WrappedComponent.displayName = `withTranslation(${
                Component.displayName || Component.name || 'Component'
            })`;
            return WrappedComponent;
        },
}));

describe('<AnteRoomComponent />', () => {
    describe('valid stream', () => {
        test('Before connect click', () => {
            const { container } = render(
                getAnteRoomComponent({
                    selfCheckCompleted: false,
                }),
            );
            expect(container).toMatchSnapshot();
        });

        test('After connect click', () => {
            const { container } = render(getAnteRoomComponent());
            expect(container).toMatchSnapshot();
        });

        test('Healthcheck is running', () => {
            const { container } = render(
                getAnteRoomComponent({
                    health: {
                        healthCheckProgress: 50,
                        networkStatus: TestStatus.NotRun,
                        camStatus: TestStatus.NotRun,
                        micStatus: TestStatus.NotRun,
                        mediaPermissionStatus: 'allowed',
                        publishStatus: TestStatus.NotRun,
                    },
                }),
            );
            expect(container).toMatchSnapshot();
        });

        test('On success click', () => {
            const wrapper = mount(getAnteRoomComponent());
            const button = wrapper.find(Button).first() as ReactWrapper<
                ButtonProps,
                object,
                React.Component<ButtonProps, object, object>
            >;
            expect(button.props().disabled).toBeTruthy();
        });

        // no idea why but this test cant find a button element to click
        // plz investigate...
        test.skip('On connect click', () => {
            const wrapper = render(
                getAnteRoomComponent({
                    selfCheckCompleted: false,
                }),
            );

            const buttonElement = wrapper.getByRole('button');
            expect(buttonElement.getAttribute('disabled')).toBeFalsy();

            fireEvent.click(buttonElement);
            sinon.assert.calledOnce(onConnectClick);
        });
    });
});
