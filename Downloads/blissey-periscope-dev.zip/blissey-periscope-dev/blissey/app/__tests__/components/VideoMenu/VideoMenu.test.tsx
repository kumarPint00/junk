import * as React from 'react';
import { render } from '@testing-library/react';
import { isProvider } from '@dexcare/circus-saturn';
import { isSupportedBrowser } from '@utils/BrowserCheck';
import { FeatureFlags, getArrayFeatureFlag } from '@utils/FeatureFlags';
import { PlayerControls } from '@components/VideoMenu/PlayerControls';
import { useSelector } from 'react-redux';
import { VideoMenu } from '../../../src/components/VideoMenu/VideoMenu';
import { vi } from 'vitest';
import { when } from 'jest-when';
import { Store } from '@redux/modules';

vi.mock('@dexcare/circus-saturn', () => ({ isProvider: vi.fn() }));
vi.mock('@utils/BrowserCheck', () => ({
    isSupportedBrowser: vi.fn(),
}));
vi.mock('@components/VideoMenu/PlayerControls', () => ({
    PlayerControls: vi.fn().mockReturnValue(<div>PlayerControls</div>),
}));
vi.mock('@utils/FeatureFlags', async () => {
    const actual = await vi.importActual('@utils/FeatureFlags');
    return {
        FeatureFlags: actual.FeatureFlags,
        getFeatureFlag: vi.fn().mockReturnValue(false),
        getArrayFeatureFlag: vi.fn(),
    };
});

const { mockDispatch } = vi.hoisted(() => ({
    mockDispatch: vi.fn(),
}));

const defaultState = {
    video: {
        localMicExists: true,
        localCamExists: true,
        isFullScreen: false,
        isCamEnabled: true,
        isMicEnabled: true,
        isChatVisible: false,
        isBlurEnabled: false,
    },
    user: {
        userDetails: {
            id: 'id',
            token: 'sometoken',
            expiration: new Date().getMilliseconds(),
            email: 'some@example.com',
            displayName: 'Name',
            givenName: 'givenName',
            familyName: 'familyName',
        },
    },
    postconsult: {
        callStartTime: 999,
    },
} as Store['All'];

vi.mock('react-redux', () => ({
    useDispatch: vi.fn().mockReturnValue(mockDispatch),
    useSelector: vi.fn(),
}));

vi.mock('../../../src/redux/modules/videoMenu', () => ({
    setIsChatVisible: vi.fn(),
    setEndCallConfirmation: vi.fn(),
    toggleFullScreen: vi.fn(),
}));

describe('<VideoMenu />', () => {
    it('hides call start time when user is patient', () => {
        vi.mocked(useSelector).mockImplementation((callback) => {
            return callback(defaultState);
        });
        when(vi.mocked(getArrayFeatureFlag))
            .calledWith(FeatureFlags.showBlurOption)
            .mockReturnValue([
                {
                    minVersion: '100',
                    name: 'chrome',
                    patient: false,
                    provider: true,
                },
            ]);
        vi.mocked(isProvider).mockReturnValue(false);
        vi.mocked(isSupportedBrowser).mockReturnValue({
            supportedBrowser: true,
            providerAvailable: true,
            patientAvailable: false,
        });
        render(
            <VideoMenu
                onCamClick={vi.fn()}
                onMicClick={vi.fn()}
                onBlurBackgroundClick={vi.fn()}
                onSwitchCameraClick={vi.fn()}
                visitId="visitId"
            />,
        );
        expect(vi.mocked(PlayerControls)).toHaveBeenCalledWith(
            expect.objectContaining({
                callStartTime: null,
            }),
            expect.any(Object),
        );
    });
    it('shows call start time when user is provider', () => {
        vi.mocked(useSelector).mockImplementation((callback) => {
            return callback(defaultState);
        });
        when(vi.mocked(getArrayFeatureFlag))
            .calledWith(FeatureFlags.showBlurOption)
            .mockReturnValue([
                {
                    minVersion: '100',
                    name: 'chrome',
                    patient: false,
                    provider: true,
                },
            ]);
        vi.mocked(isProvider).mockReturnValue(true);
        vi.mocked(isSupportedBrowser).mockReturnValue({
            supportedBrowser: true,
            providerAvailable: true,
            patientAvailable: false,
        });
        render(
            <VideoMenu
                onCamClick={vi.fn()}
                onMicClick={vi.fn()}
                onBlurBackgroundClick={vi.fn()}
                onSwitchCameraClick={vi.fn()}
                visitId="visitId"
            />,
        );
        expect(vi.mocked(PlayerControls)).toHaveBeenCalledWith(
            expect.objectContaining({
                callStartTime: 999,
            }),
            expect.any(Object),
        );
    });
    describe('when show blur feature flag is enabled for providers', () => {
        it('show background blur button is false when user is a patient', () => {
            vi.mocked(useSelector).mockImplementation((callback) => {
                return callback(defaultState);
            });
            when(vi.mocked(getArrayFeatureFlag))
                .calledWith(FeatureFlags.showBlurOption)
                .mockReturnValue([
                    {
                        minVersion: '100',
                        name: 'chrome',
                        patient: false,
                        provider: true,
                    },
                ]);
            vi.mocked(isProvider).mockReturnValue(false);
            vi.mocked(isSupportedBrowser).mockReturnValue({
                supportedBrowser: true,
                providerAvailable: true,
                patientAvailable: false,
            });
            render(
                <VideoMenu
                    onCamClick={vi.fn()}
                    onMicClick={vi.fn()}
                    onBlurBackgroundClick={vi.fn()}
                    onSwitchCameraClick={vi.fn()}
                    visitId="visitId"
                />,
            );
            expect(vi.mocked(PlayerControls)).toHaveBeenCalledWith(
                expect.objectContaining({
                    videoBackgroundControls: expect.objectContaining({
                        exists: false,
                        enabled: false,
                    }),
                }),
                expect.any(Object),
            );
        });
        it('show background blur button is true when user is a provider', () => {
            vi.mocked(useSelector).mockImplementation((callback) => {
                return callback(defaultState);
            });
            when(vi.mocked(getArrayFeatureFlag))
                .calledWith(FeatureFlags.showBlurOption)
                .mockReturnValue([
                    {
                        minVersion: '100',
                        name: 'chrome',
                        patient: false,
                        provider: true,
                    },
                ]);
            vi.mocked(isProvider).mockReturnValue(true);
            vi.mocked(isSupportedBrowser).mockReturnValue({
                supportedBrowser: true,
                providerAvailable: true,
                patientAvailable: false,
            });
            render(
                <VideoMenu
                    onCamClick={vi.fn()}
                    onMicClick={vi.fn()}
                    onBlurBackgroundClick={vi.fn()}
                    onSwitchCameraClick={vi.fn()}
                    visitId="visitId"
                />,
            );
            expect(vi.mocked(PlayerControls)).toHaveBeenCalledWith(
                expect.objectContaining({
                    videoBackgroundControls: expect.objectContaining({
                        exists: true,
                        enabled: false,
                    }),
                }),
                {},
            );
        });
    });
});
