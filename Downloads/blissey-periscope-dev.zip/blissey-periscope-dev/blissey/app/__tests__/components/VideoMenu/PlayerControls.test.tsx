import * as React from 'react';
import { render, fireEvent, configure } from '@testing-library/react';
import { vi } from 'vitest';
import { Provider } from 'react-redux';
import configureStore from 'redux-mock-store';
import '@testing-library/jest-dom';
import {
    PlayerControls,
    PlayerControlProps,
} from '@components/VideoMenu/PlayerControls';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import { when } from 'jest-when';

vi.mock('@utils/FeatureFlags', async () => {
    const actual = await vi.importActual('@utils/FeatureFlags');
    return {
        FeatureFlags: actual.FeatureFlags,
        getFeatureFlag: vi.fn(),
    };
});

const mockStore = configureStore([]);
const store = mockStore({
    user: { isProvider: true },
});

const defaultProps: PlayerControlProps = {
    micControls: {
        enabled: true,
        exists: true,
        onClick: vi.fn(),
    },
    camControls: {
        enabled: true,
        exists: true,
        onClick: vi.fn(),
    },
    videoBackgroundControls: {
        enabled: false,
        exists: true,
        onClick: vi.fn(),
    },
    isFullScreen: false,
    callStartTime: null,
    toggleFullScreen: vi.fn(),
    onEndCallClick: vi.fn(),
    onChatClick: vi.fn(),
    onSwitchCameraClick: vi.fn(),
    t: (key: string) => key,
    tReady: true,
};

const renderComponent = (overrides: Partial<PlayerControlProps> = {}) => {
    const props = { ...defaultProps, ...overrides };
    return render(
        <Provider store={store}>
            <PlayerControls {...props} />
        </Provider>,
    );
};

describe('<PlayerControls />', () => {
    configure({ testIdAttribute: 'data-uitest' });
    it('renders correctly with default props', () => {
        const component = renderComponent();
        expect(component.asFragment()).toMatchSnapshot();
    });

    it('calls the appropriate functions when buttons are clicked', () => {
        const component = renderComponent();
        const buttons = component.getAllByRole('button');

        buttons.forEach((button) => {
            fireEvent(
                button,
                new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                }),
            );
        });

        expect(defaultProps.camControls.onClick).toHaveBeenCalled();
        expect(defaultProps.micControls.onClick).toHaveBeenCalled();
        expect(defaultProps.videoBackgroundControls.onClick).toHaveBeenCalled();
        expect(defaultProps.toggleFullScreen).toHaveBeenCalled();
        expect(defaultProps.onEndCallClick).toHaveBeenCalled();
        expect(defaultProps.onChatClick).toHaveBeenCalled();
    });

    it('renders CallLengthTimer when callStartTime is provided', () => {
        const rendered = renderComponent({ callStartTime: 10000 });
        const component = rendered.getByTestId('control-callLengthTimer');

        expect(component).toBeTruthy();
    });

    it('renders camera switcher when flag enabled', () => {
        when(vi.mocked(getFeatureFlag))
            .calledWith(FeatureFlags.releaseCameraSwitcher)
            .mockReturnValue(true);
        const rendered = renderComponent();
        const component = rendered.getByTestId('control-camSwitcher');
        expect(component).toBeTruthy();
    });

    it('disables buttons when the controls do not exist', () => {
        const rendered = renderComponent({
            micControls: { ...defaultProps.micControls, exists: false },
            camControls: { ...defaultProps.camControls, exists: false },
            videoBackgroundControls: {
                ...defaultProps.videoBackgroundControls,
                exists: false,
            },
        });

        const micButton = rendered.getByTestId('control-micButton');
        const videoButton = rendered.getByTestId('control-camButton');
        // FIXME: the mic button should actually be dsiabled.
        expect(micButton).toBeTruthy();
        expect(micButton).toHaveAttribute(
            'aria-label',
            'video-conference.controls.micDisabled',
        );
        expect(videoButton).toBeTruthy();
        expect(videoButton).toHaveAttribute(
            'aria-label',
            'video-conference.controls.camDisabled',
        );
    });

    it('handles tooltip text correctly', () => {
        const { getByTestId } = renderComponent();

        const {
            micControls: { exists: micExists },
            camControls: { exists: camExists },
            videoBackgroundControls: { exists: blurBackgroundExists },
        } = defaultProps;

        const tooltipConditions = [
            {
                id: 'control-endCallButton',
                title: 'video-conference.controls.endCall',
                condition: true,
            },
            {
                id: 'fullscreencontrol-button',
                title: 'video-conference.controls.fullscreenToggle',
                condition: true,
            },
            {
                id: 'control-micButton',
                title: micExists
                    ? 'video-conference.controls.micToggle'
                    : 'video-conference.controls.micDisabled',
                condition: true,
            },
            {
                id: 'control-camButton',
                title: camExists
                    ? 'video-conference.controls.camToggle'
                    : 'video-conference.controls.camDisabled',
                condition: true,
            },
            {
                id: 'control-camSwitcher',
                title: camExists
                    ? 'video-conference.controls.camSwitch'
                    : 'video-conference.controls.camDisabled',
                condition: true,
            },
            {
                id: 'control-chatButton',
                title: 'video-conference.controls.chatToggle',
                condition: true,
            },
            {
                id: 'control-blurBackgroundButton',
                title: blurBackgroundExists
                    ? 'video-conference.controls.blurToggle'
                    : 'video-conference.controls.blurToggle_notSupported',
                condition: blurBackgroundExists,
            },
        ];

        tooltipConditions.forEach(({ id, title, condition }) => {
            if (condition) {
                const tooltip = getByTestId(id);
                expect(tooltip).toBeTruthy();
                expect(tooltip).toHaveAttribute('aria-label', title);
            }
        });
    });
});
