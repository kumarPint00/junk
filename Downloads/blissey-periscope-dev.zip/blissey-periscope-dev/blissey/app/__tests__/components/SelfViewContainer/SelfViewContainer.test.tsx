import * as React from 'react';
import { configure, render, fireEvent } from '@testing-library/react';
import { vi } from 'vitest';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import {
    SelfViewContainer,
    SelfViewContainerProps,
} from '../../../src/components/SelfViewContainer/SelfViewContainer';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { interactionEvent: vi.fn() },
}));

describe('<SelfViewContainer />', () => {
    configure({ testIdAttribute: 'data-uitest' });
    const createComponent = (
        props: SelfViewContainerProps = {} as unknown as SelfViewContainerProps,
    ) => {
        return render(<SelfViewContainer {...props} />);
    };

    test('check snapshot', () => {
        const component = createComponent();
        expect(component.container).toMatchSnapshot();
    });

    test('check snapshot with video dimensions', () => {
        const component = createComponent({
            videoHeight: 460,
            videoWidth: 680,
        } as unknown as SelfViewContainerProps);
        expect(component.container).toMatchSnapshot();
    });

    describe('click event', () => {
        configure({ testIdAttribute: 'data-uitest' });
        let component: ReturnType<typeof createComponent>;
        let selfViewDownButton: HTMLElement;

        beforeAll(() => {
            component = createComponent();
            selfViewDownButton = component.getByTestId(
                'control-selfViewButton',
            );
        });

        test('simulate click to hide self view and simulate another click to show self view again', () => {
            fireEvent.click(selfViewDownButton);
            expect(component.container).toMatchSnapshot();
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'new_pip_setting',
                value: 'non-PIP',
            });

            fireEvent.click(selfViewDownButton);
            expect(component.container).toMatchSnapshot();
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'new_pip_setting',
                value: 'PIP',
            });
        });
    });
});
