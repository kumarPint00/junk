import * as React from 'react';
import { shallow } from 'enzyme';
import { PatientFeedbackComponent } from '@components/Feedback/PatientFeedbackComponent';
import { FeatureFlags, getFeatureFlag } from '@utils/FeatureFlags';
import * as jupiter from '@dexcare/circus-jupiter';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { Mock, MockedFunction, vi } from 'vitest';
import Select from '@mui/material/Select';
import { render } from '@testing-library/react';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: {
        interactionEvent: vi.fn(),
    },
}));

vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(),
    },
}));

vi.mock('@utils/FeatureFlags', async () => {
    const original = await vi.importActual('@utils/FeatureFlags');
    return {
        ...(original as object),
        getFeatureFlag: vi.fn(),
    };
});

const mockGetFeatureFlag = getFeatureFlag as MockedFunction<
    typeof getFeatureFlag
>;
const config = {};

interface Config {
    getConfig: Mock;
}

describe('<PatientFeedbackComponent />', () => {
    beforeEach(() => {
        // FIXME: this isn't quite right way to mock this, but jupiter doesn't have types
        (jupiter.config as Config).getConfig = vi.fn(() => config);
    });
    afterEach(() => {
        vi.resetAllMocks();
    });
    it('renders snapshot', () => {
        mockGetFeatureFlag.mockImplementation((key) => {
            const flags: Record<string, boolean> = {
                [FeatureFlags.extraPatientSurvey1]: false,
                [FeatureFlags.extraPatientSurvey2]: false,
                [FeatureFlags.suppressPatientSurvey]: false,
            };

            return flags[key] || false;
        });
        const { container } = render(
            <PatientFeedbackComponent submit={vi.fn()} />,
        );
        expect(container).toMatchSnapshot();
    });

    it.skip('renders snapshots with two extra survey questions', () => {
        mockGetFeatureFlag.mockImplementation((key) => {
            const flags: Record<string, boolean> = {
                [FeatureFlags.extraPatientSurvey1]: true,
                [FeatureFlags.extraPatientSurvey2]: true,
                [FeatureFlags.suppressPatientSurvey]: false,
            };

            return flags[key] || false;
        });
        const { container } = render(
            <PatientFeedbackComponent submit={vi.fn()} />,
        );
        expect(container).toMatchSnapshot();
    });

    it.skip('calls GTM analytics if skip survey flag is on', () => {
        mockGetFeatureFlag.mockImplementation((key) => {
            const flags: Record<string, boolean> = {
                [FeatureFlags.extraPatientSurvey1]: false,
                [FeatureFlags.extraPatientSurvey2]: false,
                [FeatureFlags.suppressPatientSurvey]: true,
            };

            return flags[key] || false;
        });
        const { container } = render(
            <PatientFeedbackComponent submit={vi.fn()} />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.interactionEvent).toHaveBeenCalled();
    });
    it('fires analytics on select nps rating', () => {
        const component = shallow(
            <PatientFeedbackComponent submit={vi.fn()} />,
        ).dive();
        component
            .find(Select)
            .first()
            .simulate('change', { target: { value: 2 } });
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'click_option',
            menu_type: 'nps_rating',
            menu_item: 2,
        });
    });

    it('fires analytics on select nps rating with extra surveys enabled', () => {
        mockGetFeatureFlag.mockImplementation((key) => {
            const flags: Record<string, boolean> = {
                [FeatureFlags.extraPatientSurvey1]: true,
                [FeatureFlags.extraPatientSurvey2]: true,
                [FeatureFlags.suppressPatientSurvey]: false,
            };

            return flags[key] || false;
        });
        const component = shallow(
            <PatientFeedbackComponent submit={vi.fn()} />,
        ).dive();
        component
            .find(Select)
            .last()
            .simulate('change', { target: { value: 3 } });
        component
            .find(Select)
            .at(1)
            .simulate('change', { target: { value: 1 } });
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'click_option',
            menu_type: 'nps_survey_2',
            menu_item: 3,
        });
        expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
            eventName: 'click_option',
            menu_type: 'nps_survey_1',
            menu_item: 1,
        });
    });
});
