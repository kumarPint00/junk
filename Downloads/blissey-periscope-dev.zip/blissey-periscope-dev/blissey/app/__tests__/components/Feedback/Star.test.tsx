import * as React from 'react';
import { render } from '@testing-library/react';
import { Star } from '../../../src/components/Feedback/Star';

test('<Star /> rating is 1 and value is 1', () => {
    const { container } = render(<Star rating={1} value={1} />);
    expect(container).toMatchSnapshot();
});

test('<Star /> rating is > 1 and value is 1', () => {
    const { container } = render(<Star rating={2} value={1} />);
    expect(container).toMatchSnapshot();
});

test('<Star /> rating is 0 and value is anything', () => {
    const { container } = render(<Star rating={0} value={1} />);
    expect(container).toMatchSnapshot();
});

test('<Star /> rating is > value and value is anything', () => {
    const { container } = render(<Star rating={4} value={2} />);
    expect(container).toMatchSnapshot();
});

test('<Star /> rating is value and value is anything', () => {
    const { container } = render(<Star rating={4} value={2} />);
    expect(container).toMatchSnapshot();
});
