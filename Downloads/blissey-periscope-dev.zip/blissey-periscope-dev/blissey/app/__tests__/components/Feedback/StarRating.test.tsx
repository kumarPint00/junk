import * as React from 'react';
import { render, fireEvent } from '@testing-library/react';
import { StarRating } from '../../../src/components/Feedback/StarRating';
import { vi } from 'vitest';

test('<StarRating /> render and interact with stars', () => {
    const onStarClick = vi.fn();
    const { container } = render(
        <StarRating
            onClick={onStarClick}
            questionId="questionId"
            answerId="answerId"
        />,
    );
    const stars = container.querySelectorAll(
        '[data-uitest^="questionId-answerId-starrating-"]',
    );
    stars.forEach((star) => {
        fireEvent.mouseOver(star);
        fireEvent.click(star);
    });
    expect(container).toMatchSnapshot();
});
