import * as React from 'react';
import { mount } from 'enzyme';
import { FeedbackQuestion } from '@clients/Feedback/FeedbackQuestion';
import { FeedbackQuestionType } from '@clients/Feedback/FeedbackQuestionType';
import { FeedbackComponent } from '@components/Feedback/FeedbackComponent';
import {
    Analytics,
    V2Analytics,
} from '@dexcare/festivus-aluminum-pole-analytics';
import { Mock, vi } from 'vitest';
import { render } from '@testing-library/react';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    Analytics: {
        sendEvent: vi.fn(),
        sendPageView: vi.fn(),
    },
    V2Analytics: { interactionEvent: vi.fn() },
}));

describe('<FeedbackComponent />', () => {
    const feedbackQuestions: FeedbackQuestion[] = [
        {
            id: 'NumberFeedbackQuestion',
            text: 'NumberFeedbackQuestion',
            type: FeedbackQuestionType.Number,
            answers: [
                {
                    id: 'NumberFeedbackAnswer',
                    text: 'NumberFeedbackAnswer',
                    type: FeedbackQuestionType.Number,
                    value: 0,
                },
            ],
        },
    ];

    function getFeedbackComponent(answerStub: Mock) {
        return (
            <FeedbackComponent
                feedbackQuestions={feedbackQuestions}
                onAnswerChange={answerStub}
            />
        );
    }

    describe('Feedback Component is Rendered', () => {
        let onAnswerChangeStub: Mock;
        beforeEach(() => {
            onAnswerChangeStub = vi.fn();
        });

        it('renders all questions', () => {
            const { container } = render(
                getFeedbackComponent(onAnswerChangeStub),
            );
            expect(container).toMatchSnapshot();
        });
        it('updates on star change', () => {
            const component = mount(getFeedbackComponent(onAnswerChangeStub));
            component.find('Star').first().simulate('click');
            expect(onAnswerChangeStub).toHaveBeenCalledWith(
                1,
                'NumberFeedbackQuestion',
                'NumberFeedbackAnswer',
            );
            expect(Analytics.sendEvent).toBeCalledWith({
                eventAction: 'formEngagement',
                formEngagement: {
                    fieldName: 'NumberFeedbackQuestion',
                    fieldValue: 'complete',
                    formName: 'Visit Questionnaire',
                },
            });
            expect(V2Analytics.interactionEvent).toHaveBeenCalledWith({
                eventName: 'form_field_engage',
                form_field: 'NumberFeedbackQuestion',
                form_name: 'visit questionnaire',
            });
        });

        it('initial values', () => {
            feedbackQuestions[0].answers[0].value = 3;
            const { container } = render(
                getFeedbackComponent(onAnswerChangeStub),
            );
            expect(container).toMatchSnapshot();
        });
    });
});
