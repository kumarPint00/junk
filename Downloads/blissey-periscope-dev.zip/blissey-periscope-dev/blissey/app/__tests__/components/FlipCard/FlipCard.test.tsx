import * as React from 'react';
import { shallow } from 'enzyme';
import { FlipCard } from '@components/FlipCard/FlipCard';

describe('<FlipCard />', () => {
    const props = () => ({
        front: 'front',
        back: 'back',
    });

    it('exists', () => {
        const wrapper = shallow(<FlipCard {...props()} />);
        expect(wrapper).toBeTruthy();
    });
});
