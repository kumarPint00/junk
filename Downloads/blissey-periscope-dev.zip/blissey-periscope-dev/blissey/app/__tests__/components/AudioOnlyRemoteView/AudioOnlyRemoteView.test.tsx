import * as React from 'react';
import { render } from '@testing-library/react';

import { AudioOnlyRemoteView } from '../../../src/components/AudioOnlyRemoteView/AudioOnlyRemoteView';

const user = {
    id: 'id',
    token: 'sometoken',
    expiration: new Date(),
    email: 'some@example.com',
    displayName: 'Name',
    givenName: 'givenName',
    familyName: 'familyName',
};

test('<AudioOnlyRemoteView /> with Audio Only text', () => {
    const { container } = render(
        <AudioOnlyRemoteView user={user} audioOnly={true} />,
    );
    expect(container).toMatchSnapshot();
});

test('<AudioOnlyRemoteView /> without text', () => {
    const { container } = render(
        <AudioOnlyRemoteView user={user} audioOnly={false} />,
    );
    expect(container).toMatchSnapshot();
});
