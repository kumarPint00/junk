import * as React from 'react';
import { render } from '@testing-library/react';
import { ConferenceErrorComponent } from '../../../src/components/ConferenceError/ConferenceErrorComponent';
import { ConferenceError } from '@modules/VideoCall/ConferenceError';
import { V2Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { vi } from 'vitest';

vi.mock('@dexcare/festivus-aluminum-pole-analytics', () => ({
    V2Analytics: { errorEvent: vi.fn() },
}));

describe('<ConferenceErrorComponent />', () => {
    afterEach(() => vi.clearAllMocks());

    test('verify conference full snapshot', () => {
        const messageKey = ConferenceError[ConferenceError.ConferenceFull];
        const { container } = render(
            <ConferenceErrorComponent
                conferenceMessageKey={messageKey}
                dataUiTest="data-ui-flag"
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: 'video-conference.error-messages.roomFull',
            type: 'conference error',
        });
    });

    test('verify joined elsewhere snapshot', () => {
        const messageKey = ConferenceError[ConferenceError.JoinedElsewhere];
        const { container } = render(
            <ConferenceErrorComponent
                conferenceMessageKey={messageKey}
                dataUiTest="data-ui-flag"
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: 'video-conference.error-messages.removedFromCall',
            type: 'conference error',
        });
    });

    test('verify network issues snapshot', () => {
        const messageKey = ConferenceError[ConferenceError.NetworkIssues];
        const { container } = render(
            <ConferenceErrorComponent
                conferenceMessageKey={messageKey}
                dataUiTest="data-ui-flag"
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: 'video-conference.error-messages.networkError',
            type: 'conference error',
        });
    });

    test('verify other error snapshot', () => {
        const messageKey = ConferenceError[ConferenceError.Other];
        const { container } = render(
            <ConferenceErrorComponent
                conferenceMessageKey={messageKey}
                dataUiTest="data-ui-flag"
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).toHaveBeenCalledWith({
            text: 'video-conference.error-messages.unknownError',
            type: 'conference error',
        });
    });

    test('verify disconnected message snapshot', () => {
        const messageKey = 'DisconnectedMessage';
        const { container } = render(
            <ConferenceErrorComponent
                conferenceMessageKey={messageKey}
                dataUiTest="data-ui-flag"
            />,
        );
        expect(container).toMatchSnapshot();
    });

    test('verify reconnecting message message snapshot', () => {
        const messageKey = 'ReconnectingMessage';
        const { container } = render(
            <ConferenceErrorComponent
                conferenceMessageKey={messageKey}
                dataUiTest="data-ui-flag"
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).not.toHaveBeenCalled();
    });

    test('verify dialing message message snapshot', () => {
        const messageKey = 'DialingMessage';
        const { container } = render(
            <ConferenceErrorComponent
                conferenceMessageKey={messageKey}
                dataUiTest="data-ui-flag"
            />,
        );
        expect(container).toMatchSnapshot();
        expect(V2Analytics.errorEvent).not.toHaveBeenCalled();
    });
});
