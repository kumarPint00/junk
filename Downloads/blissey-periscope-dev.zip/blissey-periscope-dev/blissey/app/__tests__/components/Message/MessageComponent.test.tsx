import * as React from 'react';
import { render } from '@testing-library/react';

import { MessageComponent } from '../../../src/components/Message/MessageComponent';
import { MessageType } from '../../../src/components/Message/MessageInterfaces';

test('<MessageComponent /> Info, default icon', () => {
    const { container } = render(
        <MessageComponent message="test info" messageType={MessageType.Info} />,
    );
    expect(container).toMatchSnapshot();
});

test('<MessageComponent /> Action, default icon', () => {
    const { container } = render(
        <MessageComponent
            message="test action"
            messageType={MessageType.Action}
        />,
    );
    expect(container).toMatchSnapshot();
});

test('<MessageComponent /> Error, default icon', () => {
    const { container } = render(
        <MessageComponent
            message="test error"
            messageType={MessageType.Error}
        />,
    );
    expect(container).toMatchSnapshot();
});

test('<MessageComponent /> Info, custom icon', () => {
    const { container } = render(
        <MessageComponent
            icon={'finterprint'}
            message="test info"
            messageType={MessageType.Info}
        />,
    );
    expect(container).toMatchSnapshot();
});

test('<MessageComponent /> Action, custom icon', () => {
    const { container } = render(
        <MessageComponent
            icon={'description'}
            message="test action"
            messageType={MessageType.Action}
        />,
    );
    expect(container).toMatchSnapshot();
});

test('<MessageComponent /> Error, custom icon', () => {
    const { container } = render(
        <MessageComponent
            icon={'gavel'}
            message="test error"
            messageType={MessageType.Error}
        />,
    );
    expect(container).toMatchSnapshot();
});

test('<MessageComponent /> submessage', () => {
    const { container } = render(
        <MessageComponent
            subMessage={'test submessage'}
            message="test error"
            messageType={MessageType.Error}
        />,
    );
    expect(container).toMatchSnapshot();
});
