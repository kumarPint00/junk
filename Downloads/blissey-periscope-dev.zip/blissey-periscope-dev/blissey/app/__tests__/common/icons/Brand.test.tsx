import { getDomainFromBrand } from '@common/icons/Brand';
import { vi } from 'vitest';

vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(() => ({
            brandConfig: {
                swedish: {
                    domain: 'http://swed.org',
                },
            },
        })),
    },
}));

describe('getDomainFromBrand', () => {
    it('returns correct domain', () => {
        expect(getDomainFromBrand('swedish')).toBe('http://swed.org');
    });
});
