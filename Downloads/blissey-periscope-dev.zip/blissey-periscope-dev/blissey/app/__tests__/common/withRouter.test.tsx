import React from 'react';
import { render } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { withRouter, RouterProps } from '../../src/common/withRouter';

interface MockComponentProps {
    someProp: string;
}

const MockComponent: React.FC<MockComponentProps & RouterProps> = ({
    someProp,
    router,
}) => {
    return (
        <div>
            <div data-testid="some-prop">{someProp}</div>
            <div data-testid="params">{JSON.stringify(router.params)}</div>
            <div data-testid="location">{JSON.stringify(router.location)}</div>
            <div data-testid="navigate">{typeof router.navigate}</div>
        </div>
    );
};

const WrappedComponent = withRouter<MockComponentProps>(MockComponent);

describe('withRouter HOC', () => {
    it('should pass router props correctly to the wrapped component', () => {
        const testParams = { id: '123' };
        const testLocation = '/test/123';

        const { getByTestId } = render(
            <MemoryRouter initialEntries={[testLocation]}>
                <Routes>
                    <Route
                        path="/test/:id"
                        element={<WrappedComponent someProp="testProp" />}
                    />
                </Routes>
            </MemoryRouter>,
        );

        expect(getByTestId('some-prop').textContent).toBe('testProp');
        expect(getByTestId('params').textContent).toBe(
            JSON.stringify(testParams),
        );
        expect(getByTestId('location').textContent).toContain(testLocation);
        expect(getByTestId('navigate').textContent).toBe('function');
    });
});
