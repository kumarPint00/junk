import * as React from 'react';
import { render } from '@testing-library/react';

import { HeaderExpressCare } from '../../../src/common/header/HeaderExpressCare';
import { vi } from 'vitest';

vi.mock('@dexcare/circus-jupiter', () => ({
    config: {
        getConfig: vi.fn(() => ({
            siteTitle: 'express care',
        })),
    },
}));

test('<HeaderExpressCare/> with Logo', () => {
    const { container } = render(
        <HeaderExpressCare.WrappedComponent t={(key: string) => key} />,
    );
    expect(container).toMatchSnapshot();
});
