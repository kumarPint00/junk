import * as sinon from 'sinon';

import { InactivityTimer } from '../../src/common/InactivityTimer';

describe('InactivityTimer', () => {
    it('calls resetTimer (clearTimer, startTimer) when attaching', () => {
        const resetTimer = sinon.spy(InactivityTimer, 'resetTimer');
        const clearTimer = sinon.spy(InactivityTimer, 'clearTimer');
        const startTimer = sinon.spy(InactivityTimer, 'startTimer');
        InactivityTimer.attachTimeout();
        sinon.assert.calledOnce(resetTimer);
        sinon.assert.calledOnce(clearTimer);
        sinon.assert.calledOnce(startTimer);

        InactivityTimer.detachTimeout();
        resetTimer.restore();
        clearTimer.restore();
        startTimer.restore();
    });

    it('timer reset on window event', () => {
        const event = new Event('mousedown');
        const resetTimer = sinon.spy(InactivityTimer, 'resetTimer');

        InactivityTimer.attachTimeout();
        window.dispatchEvent(event);

        sinon.assert.calledTwice(resetTimer);

        InactivityTimer.detachTimeout();
        resetTimer.restore();
    });

    it('detach removes listeners', () => {
        const event = new Event('mousedown');
        const resetTimer = sinon.spy(InactivityTimer, 'resetTimer');

        InactivityTimer.attachTimeout();
        InactivityTimer.detachTimeout();
        window.dispatchEvent(event);

        // called once upon attach but not after event
        sinon.assert.calledOnce(resetTimer);
        resetTimer.restore();
    });
});
