import * as sinon from 'sinon';
import MockDate from 'mockdate';

import { TokenExpiryTimer } from '../../src/common/TokenExpiryTimer';
import { StageId } from '../../src/stageManagement/StageId';

MockDate.set('2020-01-01');
// TODO -- why does Date.now() produce system time while (new Date()).getTime() gives mocked time?
const nowTime = new Date().getTime();

describe('TokenExpiryTimer', () => {
    it('calls logoutIfCloseToExpiry when attaching from InConsult', () => {
        const logoutIfCloseToExpiry = sinon.spy(
            TokenExpiryTimer,
            'logoutIfCloseToExpiry',
        );
        TokenExpiryTimer.attachTimeout(nowTime, StageId.InConsult, 'visitId');
        sinon.assert.calledOnce(logoutIfCloseToExpiry);

        logoutIfCloseToExpiry.restore();
    });

    it('calls delayedLogoutIfTokenExpired when attaching from Hangup', () => {
        const delayedLogoutIfTokenExpired = sinon.spy(
            TokenExpiryTimer,
            'delayedLogoutIfTokenExpired',
        );
        TokenExpiryTimer.attachTimeout(
            nowTime / 1000,
            StageId.Hangup,
            'visitId',
        );
        sinon.assert.calledOnce(delayedLogoutIfTokenExpired);

        TokenExpiryTimer.detachTimeout();
        delayedLogoutIfTokenExpired.restore();
    });

    describe('getTimeToExpiry', () => {
        it('returns the millseconds left till expiration when passed an epoch time expiration IN SECONDS', () => {
            const expiration = nowTime + 1000;
            const time = TokenExpiryTimer.getTimeToExpiry(expiration / 1000);
            expect(time).toEqual(1000);
        });
        it('returns a number that will break setTimeout if passed in millseconds', () => {
            // see: https://stackoverflow.com/questions/3468607/why-does-settimeout-break-for-large-millisecond-delay-values
            const expiration = nowTime + 1000;
            const time = TokenExpiryTimer.getTimeToExpiry(expiration);
            expect(time).toEqual(1576258964200000);
        });
    });
});
