import { UserDetails, isProvider, isPresenter } from '@dexcare/circus-saturn';

describe('InactivityTimer', () => {
    it('correctly returns true if provider', () => {
        const user: UserDetails = {
            id: 'test',
            displayName: 'displayname',
            givenName: 'givenName',
            familyName: 'familyName',
            email: 'email',
            roles: ['telehealth_provider'],
            token: 'token',
            expiration: Date.now(),
        };

        expect(isProvider(user)).toBeTruthy();
    });

    it('doesnt return true if not provider', () => {
        const user: UserDetails = {
            id: 'test',
            displayName: 'displayname',
            givenName: 'givenName',
            familyName: 'familyName',
            email: 'email',
            roles: ['telehealth_presenter'],
            token: 'token',
            expiration: Date.now(),
        };

        expect(isProvider(user)).toBeFalsy();
    });

    it('correctly returns false if empty', () => {
        const user: UserDetails = {
            id: 'test',
            displayName: 'displayname',
            givenName: 'givenName',
            familyName: 'familyName',
            email: 'email',
            token: 'token',
            expiration: Date.now(),
        };

        expect(isProvider(user)).toBeFalsy();
    });

    it('correctly returns true if presenter', () => {
        const user: UserDetails = {
            id: 'test',
            displayName: 'displayname',
            givenName: 'givenName',
            familyName: 'familyName',
            email: 'email',
            roles: ['telehealth_presenter'],
            token: 'token',
            expiration: Date.now(),
        };

        expect(isPresenter(user)).toBeTruthy();
    });

    it('doesnt return true if not presenter', () => {
        const user: UserDetails = {
            id: 'test',
            displayName: 'displayname',
            givenName: 'givenName',
            familyName: 'familyName',
            email: 'email',
            roles: ['telehealth_provider'],
            token: 'token',
            expiration: Date.now(),
        };

        expect(isPresenter(user)).toBeFalsy();
    });

    it('correctly returns false if empty', () => {
        const user: UserDetails = {
            id: 'test',
            displayName: 'displayname',
            givenName: 'givenName',
            familyName: 'familyName',
            email: 'email',
            token: 'token',
            expiration: Date.now(),
        };

        expect(isPresenter(user)).toBeFalsy();
    });
});
