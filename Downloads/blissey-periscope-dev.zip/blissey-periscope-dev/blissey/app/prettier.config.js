export default {
    tabWidth: 4,
    singleQuote: true,
    trailingComma: 'all',
};
