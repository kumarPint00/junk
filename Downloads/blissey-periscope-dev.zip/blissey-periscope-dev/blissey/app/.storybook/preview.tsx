import * as React from 'react';
import { Preview } from '@storybook/react';
import { I18nextProvider } from 'react-i18next';
import { ThemeProvider } from '@mui/material/styles';
import { config } from '@dexcare/circus-jupiter';
import { init as initConferenceMessages } from '../src/common/ConferenceErrorMessage';
import {
    initI18nInstance,
    getI18nInstance,
} from '../src/common/i18n/i18nInstance';
import createBlisseyTheme from '../src/utils/createBlisseyTheme';
import defaultConfig from '../../server/config/config.json';
// import { Analytics } from '@dexcare/festivus-aluminum-pole-analytics';
import { initialize, mswLoader } from 'msw-storybook-addon';

import '../../app/src/index.css';
import { AppConfig } from '../../server/config/configInterfaces';
import { mockTranslation } from '../src/__mocks__/services/msw/Misc';

// global configuration for storybook-addon-fetch-mock
export const parameters = {
    fetchMock: {},
};

const defaultAppConfig = defaultConfig.app as unknown as AppConfig;

const i18n = getI18nInstance();

initialize();

const withI18next = (Story) => {
    config.setConfig(defaultAppConfig);
    // Analytics.setup();
    initConferenceMessages();
    initI18nInstance(
        defaultAppConfig.brandConfig[
            Object.keys(defaultAppConfig.brandConfig)[0]
        ],
    );
    return (
        <ThemeProvider theme={createBlisseyTheme(defaultAppConfig)}>
            <React.Suspense fallback={<div>loading translations...</div>}>
                <I18nextProvider i18n={i18n}>
                    <Story />
                </I18nextProvider>
            </React.Suspense>
        </ThemeProvider>
    );
};

const preview: Preview = {
    parameters: {
        fetchMock: {},
        msw: {
            handlers: [
                mockTranslation()
            ],
        },
    },
    decorators: [withI18next],
    tags: ['autodocs'],
    loaders: [mswLoader],
};

export default preview;
