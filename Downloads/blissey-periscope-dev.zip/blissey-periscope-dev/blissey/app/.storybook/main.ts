import path from 'path';
import type { StorybookConfig } from '@storybook/react-vite';

const config: StorybookConfig = {
    stories: ['../src/**/*.stories.@(js|tsx)'],
    addons: ['@storybook/addon-essentials', '@storybook/addon-actions'],
    framework: {
        name: '@storybook/react-vite',
        options: {
            builder: {
                viteConfigPath: './config/vite.config.storybook.mjs',
            },
        },
    },
    typescript: {
        reactDocgen: 'react-docgen-typescript',
    },
    staticDirs: ['../public'],
    viteFinal: async (config) => {
        if (config.resolve) {
            config.resolve.alias = {
              ...config.resolve?.alias,
            };
        }
        return config;
    }
};

export default config;
