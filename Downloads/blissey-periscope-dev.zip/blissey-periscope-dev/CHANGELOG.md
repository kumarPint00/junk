# [3.32.0](https://github.com/DexCare/telehealth.blissey/compare/3.31.1...3.32.0) (2021-12-23)


### Bug Fixes

* changed rum context to add from set. ([b02893a](https://github.com/DexCare/telehealth.blissey/commit/b02893ad3b2f4da7726c8bcfee58e172469d9ce9))
* Move the line changes to have the code in the same place as before ([8d88e12](https://github.com/DexCare/telehealth.blissey/commit/8d88e1238ee7f46bd3975cc06cf5fd9faf4b9d02))
* rollback the changes for auth timeout ([53a15d0](https://github.com/DexCare/telehealth.blissey/commit/53a15d0b17a297db20956fd91b34c72110c80a35))


### Features

* add codeName config ([bad24e3](https://github.com/DexCare/telehealth.blissey/commit/bad24e3f8f3a5aea7ad070100c6deddb1b3b91f0))
* add codename to DD RUM global context ([f9cf41c](https://github.com/DexCare/telehealth.blissey/commit/f9cf41ca3fd1d42e9d325b1f10660a171d4ac9ac))

## [3.31.1](https://github.com/DexCare/telehealth.blissey/compare/3.31.0...3.31.1) (2021-12-10)


### Bug Fixes

* analytics events updates after test session ([188ace1](https://github.com/DexCare/telehealth.blissey/commit/188ace1f13b5a3b5ea95ef6aeb13a1a4b3d2cf8a))
* set redirect link with status for kp on cancel and success ([81a561c](https://github.com/DexCare/telehealth.blissey/commit/81a561c8b20a036425058cf2dff2747023130fc3))

# [3.31.0](https://github.com/DexCare/telehealth.blissey/compare/3.30.0...3.31.0) (2021-12-03)


### Bug Fixes

* correcting function usage ([422c378](https://github.com/DexCare/telehealth.blissey/commit/422c3783aa0f6d2064c5c07c00f81f1d28a385b8))
* fire gtm correctly with or without estimated wait time seconds ([94ff494](https://github.com/DexCare/telehealth.blissey/commit/94ff4947e1af823c247496c59d3e82cda4702a2f))
* function definition and usage error ([63d7663](https://github.com/DexCare/telehealth.blissey/commit/63d76631d9b0f916783f234bf56790039600fab1))
* lint ([e654d85](https://github.com/DexCare/telehealth.blissey/commit/e654d859d156def242161d0469b9d8902d1017e2))
* reordering to correct snapshots ([899d4b0](https://github.com/DexCare/telehealth.blissey/commit/899d4b0f52467b1d0046e737fa07ec9e60fdfb2a))


### Features

* end visit link customization with the config value ending in = ([f612b49](https://github.com/DexCare/telehealth.blissey/commit/f612b49b5ed57629dd80ccebaea79c6df8d203c7))

# [3.30.0](https://github.com/DexCare/telehealth.blissey/compare/3.29.0...3.30.0) (2021-12-02)


### Bug Fixes

* change buttons to be ADA compliant ([88f4a15](https://github.com/DexCare/telehealth.blissey/commit/88f4a15e382b2c0ed5841a5c6042c3f6ea640e53))
* change icon up and down in self view ([e7b77d4](https://github.com/DexCare/telehealth.blissey/commit/e7b77d45685968c9bf33ce9b542128efbbd267bf))
* change the mic and cam off icons to gray background ([c7272ac](https://github.com/DexCare/telehealth.blissey/commit/c7272acfffdb3f88ff681c27295c87f4c61b75cf))
* change the mic and cam off icons to gray background ([457cc61](https://github.com/DexCare/telehealth.blissey/commit/457cc615f499447ece251564db00190285bd5491))
* update snapshots ([9b9cd88](https://github.com/DexCare/telehealth.blissey/commit/9b9cd884dbcf9c7142015280a265d493e40bfad5))


### Features

* add closed visit text to config to customize ([c61ac7e](https://github.com/DexCare/telehealth.blissey/commit/c61ac7e4d5ceb9de391627f446c98094ecbba547))
* add new gtm analytics ([07e9353](https://github.com/DexCare/telehealth.blissey/commit/07e9353623b293508a67f8f217c0243b855baa21))
* DC-6198 - implement UI for video stats report ([218944a](https://github.com/DexCare/telehealth.blissey/commit/218944a7d353d72fb231da1ae0c24a8c8bebe25f))
* get patientguid and providerid from visit summary and add to gtm events ([ff107b5](https://github.com/DexCare/telehealth.blissey/commit/ff107b57b69144dd5ef0e08ebac9f24656e4796f))

# [3.29.0](https://github.com/DexCare/telehealth.blissey/compare/3.28.2...3.29.0) (2021-11-08)


### Bug Fixes

* DC-6197 add in safety checks on debug lines ([d3d6ec8](https://github.com/DexCare/telehealth.blissey/commit/d3d6ec8e07bf0cfc212d501cdb7caa227944876b))
* DC-6197 Re-apply changes that disappeared from master ([1582934](https://github.com/DexCare/telehealth.blissey/commit/158293447e4b93e7f34fa66d76665f182830ae5c))
* referral error from stale state ([fbea95c](https://github.com/DexCare/telehealth.blissey/commit/fbea95c2187f7ad3577c4ff58bf7c179580c2e3d))


### Features

* add referral support ([368ca27](https://github.com/DexCare/telehealth.blissey/commit/368ca27a6d0814df233a10b6f8efb2f465d544c1))

## [3.28.2](https://github.com/DexCare/telehealth.blissey/compare/3.28.1...3.28.2) (2021-10-27)


### Bug Fixes

* reverting untested changes for session DC-6197 ([ebc3228](https://github.com/DexCare/telehealth.blissey/commit/ebc3228ef36cbcb6698dbfa6bf5c94c45ee4d68c))

## [3.28.1](https://github.com/DexCare/telehealth.blissey/compare/3.28.0...3.28.1) (2021-10-13)


### Bug Fixes

* initial fix for cookie timeout ([3bda518](https://github.com/DexCare/telehealth.blissey/commit/3bda518a9a3cb19525096ec83509c3f6b514a9d6))
* make user not crash when null user ([1f39bad](https://github.com/DexCare/telehealth.blissey/commit/1f39bad472f64a14c318af1b3fd0af64a0c4a014))
* remove expiration logic ([804047a](https://github.com/DexCare/telehealth.blissey/commit/804047ab7e1112794b64298578bf41389457d149))
* remove unused parameter ([3bcb9fc](https://github.com/DexCare/telehealth.blissey/commit/3bcb9fc2330e2861f6c597cd3b585196591d254e))

# [3.28.0](https://github.com/DexCare/telehealth.blissey/compare/3.27.4...3.28.0) (2021-10-05)


### Features

* ui dependency upgrade @dexcare/cicus-saturn ([47f56f4](https://github.com/DexCare/telehealth.blissey/commit/47f56f47bbfff0e9353cc2644358e75b87da910c))
* ui dependency upgrade @dexcare/cicus.saturn ([f4d77d6](https://github.com/DexCare/telehealth.blissey/commit/f4d77d675e1a2c2ac2655f252b2680dcaa3a1b7b))

## [3.27.4](https://github.com/DexCare/telehealth.blissey/compare/3.27.3...3.27.4) (2021-09-29)


### Bug Fixes

* correlationid not showing up in logs ([8cb8e54](https://github.com/DexCare/telehealth.blissey/commit/8cb8e541ed4f045c2850ab4bf15305385e83c46c))
* improve disable chat logic ([7eb7d51](https://github.com/DexCare/telehealth.blissey/commit/7eb7d51531f8b0df1cd7ed0e8b5369bda80966f1))
* linting ([4cb7be8](https://github.com/DexCare/telehealth.blissey/commit/4cb7be86bef6a3df7d216abd0d24784cd17d0014))
* update svg to button, add borders around buttons ([68e1211](https://github.com/DexCare/telehealth.blissey/commit/68e1211c190a3250eae60b33860ff6ffaf8c471a))

## [3.27.3](https://github.com/DexCare/telehealth.blissey/compare/3.27.2...3.27.3) (2021-09-22)


### Bug Fixes

* focus is set on heading instead of button on modal popup ([9a94df7](https://github.com/DexCare/telehealth.blissey/commit/9a94df721b8533e0f0dd36ee1e4f969738a397ed))
* remove aria id ([71220ee](https://github.com/DexCare/telehealth.blissey/commit/71220eed0ae31934da78bcb6ea0ae11682fd8148))

## [3.27.2](https://github.com/DexCare/telehealth.blissey/compare/3.27.1...3.27.2) (2021-09-21)


### Bug Fixes

* add aria-label attribute to text form for screen readers ([b3f861d](https://github.com/DexCare/telehealth.blissey/commit/b3f861d4b6d1ef5321596e8f53116f6b03d7e817))
* change icons to buttons with material ui ([643f04d](https://github.com/DexCare/telehealth.blissey/commit/643f04d623642c80138a2e0c161999916a331a2c))
* change tooltip component titles ([8806adb](https://github.com/DexCare/telehealth.blissey/commit/8806adb1923a832651493e14b102453adcb7aaf2))
* chat is disabled/enabled based on visibility ([9b3a429](https://github.com/DexCare/telehealth.blissey/commit/9b3a429abb5f30db8bf99f89b7e35239440785f8))
* linting issue on quotemarks ([eaebc6c](https://github.com/DexCare/telehealth.blissey/commit/eaebc6cd909ba8cc51a961671c6486848afdb8f5))

## [3.27.1](https://github.com/DexCare/telehealth.blissey/compare/3.27.0...3.27.1) (2021-09-16)


### Bug Fixes

* add ids so screen reader will read dialog titles ([7f9d13a](https://github.com/DexCare/telehealth.blissey/commit/7f9d13abf5e45f306582d234a675a8e31f7f61fa))
* add snackbars for camera on/off accessibility ([b2b25a2](https://github.com/DexCare/telehealth.blissey/commit/b2b25a257f2d8379c2666a6083f71a8fe02cecbf))
* cache the config - do not always read from file ([cabef36](https://github.com/DexCare/telehealth.blissey/commit/cabef3626fa8e73a3de972557c0d6ae4943f145d))
* related to dc-5860 get rid of unneeded focus event and add ids for accessibility ([785b2dd](https://github.com/DexCare/telehealth.blissey/commit/785b2dd8be1ba55cb805a771e3108fdc5983fd27))

# [3.27.0](https://github.com/DexCare/telehealth.blissey/compare/3.26.1...3.27.0) (2021-09-13)


### Bug Fixes

* change MUI id to enable screen readers to read content ([d27e2c8](https://github.com/DexCare/telehealth.blissey/commit/d27e2c8c6939606b7213e10eed97f5190401325b))
* small error on id of audio button ([55231d1](https://github.com/DexCare/telehealth.blissey/commit/55231d1f959be7f2d59eac8a0825a57f2cc5b82a))
* update circus-saturn version ([b123a39](https://github.com/DexCare/telehealth.blissey/commit/b123a39109ae0b0ef48e5daa85453745444cddbd))
* update package-lock ([e3a0ade](https://github.com/DexCare/telehealth.blissey/commit/e3a0adee063570a873c644606f9ebb5e5a0c08f0))
* update snapshots ([eebf8ec](https://github.com/DexCare/telehealth.blissey/commit/eebf8ecb75086191aedc8ecf8d27c7f47a5f81b3))


### Features

* allow config to disable patient logout of intsched ([697ab22](https://github.com/DexCare/telehealth.blissey/commit/697ab22db6d82a62357c4a4c41652cb879d589d0))

## [3.26.1](https://github.com/DexCare/telehealth.blissey/compare/3.26.0...3.26.1) (2021-09-10)


### Bug Fixes

* change the textarea and button of chat to not be tab-able unless displayed ([13b108a](https://github.com/DexCare/telehealth.blissey/commit/13b108a5a659499c5fb853edddc84a78763c87ef))
* change title of dropdown menu back ([e4b6c99](https://github.com/DexCare/telehealth.blissey/commit/e4b6c992a181cf224f88a5c7caec4ef1f8cda1ce))
* make cancel links clickable by using the enter key ([8f4642a](https://github.com/DexCare/telehealth.blissey/commit/8f4642a101eb8b4e6ff6bf4be71c9d24c9b219ac))
* make Link to skip survey tab-able and compliant with WCAG ([639aab3](https://github.com/DexCare/telehealth.blissey/commit/639aab3f796fa54bbdd494f5dfc9e980c150dcc1))
* merge with latest master branch ([84da903](https://github.com/DexCare/telehealth.blissey/commit/84da9034ecc3af955bae0194607506d6b429075b))
* screen readers will now say which option is selected from feedback menu ([ab26808](https://github.com/DexCare/telehealth.blissey/commit/ab26808e11bda542894a82ceb7dbdf6edafae29a))
* set Link component as button to allow enter and space keys to interact with link ([f1fe476](https://github.com/DexCare/telehealth.blissey/commit/f1fe476f4257b5bdd98c9872d669e7ba6f0a2368))
* small accessibility fix on chat window. Add aria-label to chat form for screen readers ([6a06bb6](https://github.com/DexCare/telehealth.blissey/commit/6a06bb6f29ff11a1eb71660046dfc71350928ec4))
* styling issues when changing link to a button component ([932df66](https://github.com/DexCare/telehealth.blissey/commit/932df66bdda236fa60d07db1f6689651245bdba0))
* typescript issues with focusevent ([6d9080d](https://github.com/DexCare/telehealth.blissey/commit/6d9080d030265994569fcc104d4d913e0f1bd6c4))
* update jest snapshots ([3026267](https://github.com/DexCare/telehealth.blissey/commit/3026267660aeccbe8c373763db91ccf02b7eafdf))
* update package.json ([f743af1](https://github.com/DexCare/telehealth.blissey/commit/f743af1f6a36c0822d843c848b12c00dd4550871))
* update snapshot ([1e26556](https://github.com/DexCare/telehealth.blissey/commit/1e265560dd111b8f07346021181cdf80ad90d737))
* update snapshots ([2a814ff](https://github.com/DexCare/telehealth.blissey/commit/2a814ff41c77bc1b2603ee7eebc101ab2c558157))
* update test files ([8b06b1c](https://github.com/DexCare/telehealth.blissey/commit/8b06b1c1e83cf4a3d8049bb434fd1e058ab10f47))
* use MUI snackbar to implement accessibility for mic on/off status ([87c5eb2](https://github.com/DexCare/telehealth.blissey/commit/87c5eb2e9786be6545fb693e3dc5464bd0e25500))

# [3.26.0](https://github.com/DexCare/telehealth.blissey/compare/3.25.0...3.26.0) (2021-08-24)


### Bug Fixes

* add version to app config ([c3e0e8f](https://github.com/DexCare/telehealth.blissey/commit/c3e0e8f67bb94a34640dfdbe658fb8c6d2ffb1d2))
* better messaging for muted devices ([a99fd20](https://github.com/DexCare/telehealth.blissey/commit/a99fd20286323a5bdfe781a6ddb9d9e99cafcb48))
* scrollbars showing up on newest chrome ([fb1bee3](https://github.com/DexCare/telehealth.blissey/commit/fb1bee3cb65d3bffdb1878a3f0674d8e8bb32885))


### Features

* add stats ([e315ba5](https://github.com/DexCare/telehealth.blissey/commit/e315ba597bef1b0e0207e95eb65975ca58589faf))
* add version to datadog ([07fb7c8](https://github.com/DexCare/telehealth.blissey/commit/07fb7c88d2b72b4236ccfd959827b577b00db953))
* better errors for when devices are muted ([d9ad69c](https://github.com/DexCare/telehealth.blissey/commit/d9ad69ccb2677e0e911c7c16928e199608c46fff))
* include rtsStats ([61d8e84](https://github.com/DexCare/telehealth.blissey/commit/61d8e840443b09ef66f417f5a552e88461f5022d))
* report error to datadog ([2fb13d9](https://github.com/DexCare/telehealth.blissey/commit/2fb13d942145daaef2fbee422c18e7a13da9c122))
* setUser ([e01278d](https://github.com/DexCare/telehealth.blissey/commit/e01278debd80c0c897da1f077de449c7fc61bac3))
* stats handler ([fffec98](https://github.com/DexCare/telehealth.blissey/commit/fffec98c4d55fe09e6e09c7f960efdb0e6496e7d))
* track version in rum as well as userId ([a64a0a5](https://github.com/DexCare/telehealth.blissey/commit/a64a0a56230b62b17e6832ae7ac3280c507f460c))

# [3.25.0](https://github.com/DexCare/telehealth.blissey/compare/3.24.0...3.25.0) (2021-08-18)


### Bug Fixes

* add dev externalIngressUrl ([c50c6ed](https://github.com/DexCare/telehealth.blissey/commit/c50c6ede12444bf0b001dc7e7471bea13e868783))
* integration does not have external ingress enabled ([8e46c4b](https://github.com/DexCare/telehealth.blissey/commit/8e46c4b715087f78a22535ae2d9314972ddf207b))
* stage deploy sets externalHost ([ab547d0](https://github.com/DexCare/telehealth.blissey/commit/ab547d00bb355746dc79d5b478b420c65e0fceb5))


### Features

* DC-5774 - add universal link ingress ([be28103](https://github.com/DexCare/telehealth.blissey/commit/be28103a731c1fbaf497ae0879ca8c13a41c5534))

# [3.24.0](https://github.com/DexCare/telehealth.blissey/compare/3.23.0...3.24.0) (2021-08-17)


### Bug Fixes

* update import ([7e1bc40](https://github.com/DexCare/telehealth.blissey/commit/7e1bc40957ddb651eefea8dd40f6f0a1b42a7984))
* wrap notify method in try / catch in case notifications are not initialized ([0555990](https://github.com/DexCare/telehealth.blissey/commit/05559901727c364f83e4cc306641828293538422))


### Features

* add message for captured devices ([a67056b](https://github.com/DexCare/telehealth.blissey/commit/a67056b62994404462265f2c07c58cd8b2af527e))
* better healthcheck ([949888d](https://github.com/DexCare/telehealth.blissey/commit/949888d15b111e3111e22cba19039aba569953dc))
* CUS-381 - message and link to rerun tech check ([e19b3c9](https://github.com/DexCare/telehealth.blissey/commit/e19b3c9b149f2abf09dec16fd7003d4b696953a0))
* only send mediaStatus result if it fails ([2af4b2d](https://github.com/DexCare/telehealth.blissey/commit/2af4b2d056c10fa9181759e0af85830a67b3f710))
* retry network tetst a second time if it fails the first time ([ef58843](https://github.com/DexCare/telehealth.blissey/commit/ef58843230917f02bafc536a669386ef8de6bf23))

# [3.23.0](https://github.com/DexCare/telehealth.blissey/compare/3.22.2...3.23.0) (2021-08-05)


### Bug Fixes

* case where logger is undefined - just use global BlisseyLogger ([9b010b8](https://github.com/DexCare/telehealth.blissey/commit/9b010b8247b9270d20c08a5e0a81c258bf2567e0))


### Features

* disable anteRoom button when healthcheck is running ([17740fe](https://github.com/DexCare/telehealth.blissey/commit/17740fedce543af025715f91f4780d033d3bf98d))

## [3.22.2](https://github.com/DexCare/telehealth.blissey/compare/3.22.1...3.22.2) (2021-07-19)


### Bug Fixes

* do not use the same publisher for waitingroom as videoroom ([7d8717e](https://github.com/DexCare/telehealth.blissey/commit/7d8717e888f43b31bc6e8389b1f5896d68f4aee9))

## [3.22.1](https://github.com/DexCare/telehealth.blissey/compare/3.22.0...3.22.1) (2021-06-29)


### Bug Fixes

* listen for visit status changes on waitingroom session also ([aab27dd](https://github.com/DexCare/telehealth.blissey/commit/aab27dd26f21decb2ce02480a7827347e39dcb40))

# [3.22.0](https://github.com/DexCare/telehealth.blissey/compare/3.21.0...3.22.0) (2021-06-29)


### Bug Fixes

* conflicting errors on mediaPermissionsDenied ([5c71c16](https://github.com/DexCare/telehealth.blissey/commit/5c71c165c3d836dc1c1781ca79d63631f4843d00))
* do not send healthcheck if test visit ([269474e](https://github.com/DexCare/telehealth.blissey/commit/269474ee29ddf6bbcd932085f4f6e72798f9e2e3))
* send correct status for cam failed ([795ce6f](https://github.com/DexCare/telehealth.blissey/commit/795ce6f1a75a2daa7c2c99533d03e1bb062fb622))
* use single quotes ([22059bc](https://github.com/DexCare/telehealth.blissey/commit/22059bc4d822fc2d3e5da0e264e7c0e2b1138597))
* wait till healthcheck passes ([45748f8](https://github.com/DexCare/telehealth.blissey/commit/45748f8ec217fa54a35cff072c567f30ed7971db))


### Features

* add network status results ([91807b4](https://github.com/DexCare/telehealth.blissey/commit/91807b4474d8c6286cc6a044a1f6d4db852503fb))
* Android App Links ([e4b5ec9](https://github.com/DexCare/telehealth.blissey/commit/e4b5ec93cc999240c0306f9f7789ca30212e52b2))
* do not join video session until healthcheck passes ([f538378](https://github.com/DexCare/telehealth.blissey/commit/f53837840509d06b182f4ec4c47febfe4515894a))
* send waitingRoomEvents on publish success or failure ([8ece9a7](https://github.com/DexCare/telehealth.blissey/commit/8ece9a78f649db4162dff3a12941c3a0c017d5c7))

# [3.21.0](https://github.com/DexCare/telehealth.blissey/compare/3.20.0...3.21.0) (2021-06-04)


### Bug Fixes

* actually fix tests ([8b5bc95](https://github.com/DexCare/telehealth.blissey/commit/8b5bc9529c56deaf85b4787576844647e03dd700))
* scroll on video screen on mobile safari ([8153545](https://github.com/DexCare/telehealth.blissey/commit/815354592e46e5cb7847d5d72b10e1c43e9fe129))
* tests ([b3a235d](https://github.com/DexCare/telehealth.blissey/commit/b3a235df958663c745c26103c7b428ad4cb386c4))


### Features

* upgrade opentok and set video content hint ([d672b5a](https://github.com/DexCare/telehealth.blissey/commit/d672b5af4e883b16d81add35ffc6dd891086e805))

# [3.20.0](https://github.com/DexCare/telehealth.blissey/compare/3.19.0...3.20.0) (2021-05-21)


### Bug Fixes

* align device icons with the dropdown ([1428791](https://github.com/DexCare/telehealth.blissey/commit/1428791f23b25f69bfab917f492c1aa9dd880750))
* css on deviceselectioncomponent for ios less than 14.4 ([7819127](https://github.com/DexCare/telehealth.blissey/commit/7819127b16230fe85b039d1af6a26cf819041d72))
* patient feedback button spacing ([1fcccb1](https://github.com/DexCare/telehealth.blissey/commit/1fcccb1674d1c069c76ac6c84108140c3d114306))
* refactor auth logic to add better logging ([f7beaac](https://github.com/DexCare/telehealth.blissey/commit/f7beaac974ddd8697e19e4968c19f898b586bf62))
* remove back to login button on error page ([82cd97e](https://github.com/DexCare/telehealth.blissey/commit/82cd97e6348e6e29d84918fb81065f0aa95e1172))
* use second level icon imports to reduce dev bundle size ([5d7f2fe](https://github.com/DexCare/telehealth.blissey/commit/5d7f2fef13d46f8efedde1adcd0b696d9cbd70c9))


### Features

* blissey calls visit service directly instead of proxying through its server ([d52f6df](https://github.com/DexCare/telehealth.blissey/commit/d52f6df4ef393293e94691e3defdbbf54ce20d76))
* move circus-lego buttons to use material-ui ([4bf1cfd](https://github.com/DexCare/telehealth.blissey/commit/4bf1cfd50a3b25ba1154dca66c2f32cf1de218a3))

# [3.19.0](https://github.com/DexCare/telehealth.blissey/compare/3.18.0...3.19.0) (2021-05-11)


### Features

* add error message for generic conflict ([042c193](https://github.com/DexCare/telehealth.blissey/commit/042c1930de804ffc76349bebbfde5e86a2988789))

# [3.18.0](https://github.com/DexCare/telehealth.blissey/compare/3.17.0...3.18.0) (2021-05-05)


### Bug Fixes

* show provider login always on core provider routes ([d424ba1](https://github.com/DexCare/telehealth.blissey/commit/d424ba1627e876ba312a9a368d5dba30269a54eb))


### Features

* able to provide a different videoId for instruction video ([e75973c](https://github.com/DexCare/telehealth.blissey/commit/e75973c4bbbf48429104ea0fbb761aac4d7d7c0b))

# [3.17.0](https://github.com/DexCare/telehealth.blissey/compare/3.16.0...3.17.0) (2021-04-30)


### Bug Fixes

* **tyto:** DC-4670 - css margin for tytocare provider view ([419392e](https://github.com/DexCare/telehealth.blissey/commit/419392e694928e7012e38183c0ceac87f7a26a6c))
* fixing how the expired page redirects to the proper branded entry point ([af1d751](https://github.com/DexCare/telehealth.blissey/commit/af1d75188ccd3ce5f72eb0b94ecb8721f0514275))


### Features

* add css transition to slide tytocare view in and out ([b737d7a](https://github.com/DexCare/telehealth.blissey/commit/b737d7a10da9701506955dda26ba23c6323fe908))

# [3.16.0](https://github.com/DexCare/telehealth.blissey/compare/3.15.0...3.16.0) (2021-04-28)


### Bug Fixes

* If there is no authenticated user, redirect to the /expired page, which will offer a signin button ([5f6d381](https://github.com/DexCare/telehealth.blissey/commit/5f6d3814055d280e1804fbeebf0cc4e35f768e0c))
* keep error icon ([50f922b](https://github.com/DexCare/telehealth.blissey/commit/50f922ba31cff531d1fa7de4dcb361735368be08))


### Features

* move last button and icons to material ui ([160ebb7](https://github.com/DexCare/telehealth.blissey/commit/160ebb7f1b24072db87eb1496f7ae4d2d77abe30))
* support custom oidc connections for kpwa ([0aeb65d](https://github.com/DexCare/telehealth.blissey/commit/0aeb65d968f7608cd2f78e208df8fff6c12adb40))

# [3.15.0](https://github.com/DexCare/telehealth.blissey/compare/3.14.0...3.15.0) (2021-04-28)


### Features

* add additional thank you component text configuration ([241d38c](https://github.com/DexCare/telehealth.blissey/commit/241d38c399646d5ff5632b6ec72575e4fbd7beaf))

# [3.14.0](https://github.com/DexCare/telehealth.blissey/compare/3.13.1...3.14.0) (2021-04-27)


### Bug Fixes

* Allowing for blissey to be tabbable and allow for users to interact with buttons using the enter key ([aeaf5bf](https://github.com/DexCare/telehealth.blissey/commit/aeaf5bf733c59671f5b9c2339d801ffd3c94ef89))
* blank self view after youtube video plays ([0ca7e5d](https://github.com/DexCare/telehealth.blissey/commit/0ca7e5d8efdf2adf62ab506b06b7e5bd8c6206ac))
* do not republish self view mount - instead use css to show or hide self view ([8768380](https://github.com/DexCare/telehealth.blissey/commit/87683805544dd933127d375124c8a96932824520))
* pull devices from healthcheck so that we do not have to ask many times in the rerenders ([8c563a6](https://github.com/DexCare/telehealth.blissey/commit/8c563a6c3494545a4e8dcf60a52f113591f71c2a))
* pulling devices before accepting permissions ([de68cd0](https://github.com/DexCare/telehealth.blissey/commit/de68cd0f15b25f1584ab8da2150f671f41dea227))
* republish on mount is required when waiting room video is on ([0e182f9](https://github.com/DexCare/telehealth.blissey/commit/0e182f98dba1694997d6beda98935a6face7c5d5))
* set UV_THREADPOOL_SIZE to reduce network errors ([87d32be](https://github.com/DexCare/telehealth.blissey/commit/87d32bea23276d994b86cd81a607137ca362a893))
* Use Date.toLocaleTimeString() instead of rolling our own time formatting ([8cb18dd](https://github.com/DexCare/telehealth.blissey/commit/8cb18ddc4f87474833b66f0dd24c341c9aa55120))


### Features

* save media permission status in redux and do not join video visit if permission is denied ([15fd577](https://github.com/DexCare/telehealth.blissey/commit/15fd5777f6f0761fc51d07af4cdefd6a21c56703))

## [3.13.1](https://github.com/DexCare/telehealth.blissey/compare/3.13.0...3.13.1) (2021-04-23)

# [3.13.0](https://github.com/DexCare/telehealth.blissey/compare/3.12.0...3.13.0) (2021-04-22)


### Features

* only join the video room after healthcheck ([34f5127](https://github.com/DexCare/telehealth.blissey/commit/34f51270d07224a667e5e62bb6ff3a7bd19b418a))

# [3.12.0](https://github.com/DexCare/telehealth.blissey/compare/3.11.0...3.12.0) (2021-04-22)


### Bug Fixes

* do not set undefined deviceId ([9a5cc05](https://github.com/DexCare/telehealth.blissey/commit/9a5cc05a49a8d37ca9f8f389ec88d43caeec05a2))
* logout of local session on auth callback ([34d368c](https://github.com/DexCare/telehealth.blissey/commit/34d368cdebe052b1a628c9c11db415432efc862d))


### Features

* tytocare error messages on visit create ([10da22c](https://github.com/DexCare/telehealth.blissey/commit/10da22c8c13ebdf4ba134fc5e0a40e13cb97dd00))

# [3.11.0](https://github.com/DexCare/telehealth.blissey/compare/3.10.0...3.11.0) (2021-04-16)


### Bug Fixes

* build ([d78cdbc](https://github.com/DexCare/telehealth.blissey/commit/d78cdbc48b0847f09b38bbda71f6eb75e138533d))
* build 2 ([a50fb0f](https://github.com/DexCare/telehealth.blissey/commit/a50fb0f561ccdb32e25bc0bdfee6e4010cea84d1))
* build 3 ([9358dfa](https://github.com/DexCare/telehealth.blissey/commit/9358dfa8d5acd8215841ce236938f3c29d9c67d3))
* package-lock.json ([8896b86](https://github.com/DexCare/telehealth.blissey/commit/8896b86b6180c8e54c579653762672e9089bc0ed))
* remove comments ([603e51b](https://github.com/DexCare/telehealth.blissey/commit/603e51b22abce3ee957de27331f2b5a653edf803))
* remove local values from config file ([bbfed5b](https://github.com/DexCare/telehealth.blissey/commit/bbfed5bd24e83a09f293da21e2f3a6603684a73f))
* tests ([90d51b7](https://github.com/DexCare/telehealth.blissey/commit/90d51b74249cd1dbdf455150a13d200cdb269872))


### Features

* change url for visit service ([5ed6e9d](https://github.com/DexCare/telehealth.blissey/commit/5ed6e9d101cd736e64e1bfd47004dff40432a5b5))
* default option as first option ([5f02679](https://github.com/DexCare/telehealth.blissey/commit/5f02679d40ec514365c541d2e375f124457cfc6e))
* feature flag toggle for browser support now includes browser version ([b06392d](https://github.com/DexCare/telehealth.blissey/commit/b06392d25224b27506bd66394f95dc543d3532e4))
* run multiple envs locally ([051c4ae](https://github.com/DexCare/telehealth.blissey/commit/051c4aebb2014ba19433c741c7e3313b164557a4))
* run multiple envs locally ([d31fa6f](https://github.com/DexCare/telehealth.blissey/commit/d31fa6f772226daadfc2c5524c419296694b1894))
* run multiple envs locally ([53c05b4](https://github.com/DexCare/telehealth.blissey/commit/53c05b46cba6902e4a3638bad92c73037dcd477f))

# [3.10.0](https://github.com/DexCare/telehealth.blissey/compare/3.9.0...3.10.0) (2021-04-16)


### Bug Fixes

* do not require config in blissey when enabling tytocare ([23c5178](https://github.com/DexCare/telehealth.blissey/commit/23c517802651614e941122c02f2e43ecccd56c39))
* respect the empty string ([5d67b66](https://github.com/DexCare/telehealth.blissey/commit/5d67b6610a4322b9acbd2de274258c734362c5f6))


### Features

* add text to config to support requested changes from hm ([20052a3](https://github.com/DexCare/telehealth.blissey/commit/20052a3376b0f2e054b72d2544e3d7aa97be4385))
* add tytocare ([3b84699](https://github.com/DexCare/telehealth.blissey/commit/3b84699a294455a8cbf25fd8266963e78a959cee))
* additional followup statement ([4567176](https://github.com/DexCare/telehealth.blissey/commit/456717660a40722113dfa6ec1fad0471eeed533a))
* configurable text for waiting room ([6c3da8b](https://github.com/DexCare/telehealth.blissey/commit/6c3da8b7a8600594e18dccb5a4ff8ebc5b2c6726))
* configure optional assistance phone message ([f0b445e](https://github.com/DexCare/telehealth.blissey/commit/f0b445e6b514ff7159c4979a76947f60f98b4234))
* configure survey text ([bd9d203](https://github.com/DexCare/telehealth.blissey/commit/bd9d2035a0e9d4ecdb4999a7c9b8336ba6d6d7ac))
* util for respecting empty strings from configs ([75107b8](https://github.com/DexCare/telehealth.blissey/commit/75107b87c1e9d59a12a292b10e34cb7773742e53))

# [3.9.0](https://github.com/DexCare/telehealth.blissey/compare/3.8.1...3.9.0) (2021-04-15)


### Bug Fixes

* a few more fixes ([64babac](https://github.com/DexCare/telehealth.blissey/commit/64babace144ad056a7f85a922674d2da3aebaff6))
* audit and lint ([52ec3a0](https://github.com/DexCare/telehealth.blissey/commit/52ec3a0edcfca1abe0daffc66608a946b0d57205))
* missed a lint ([5be6e2b](https://github.com/DexCare/telehealth.blissey/commit/5be6e2b659fc89b94b97fbc979d079c9539459db))


### Features

* gridify dogfood ([1f12bcb](https://github.com/DexCare/telehealth.blissey/commit/1f12bcb750b7adf796738c81f6148457d40551f7))
* move label to copybutton ([9c5c229](https://github.com/DexCare/telehealth.blissey/commit/9c5c229324c2bf1af0881ae03ccaf475c9fd59cf))
* showing star rating screen for KPWA ([7a47672](https://github.com/DexCare/telehealth.blissey/commit/7a47672bd6ad99d1a79caeb96f642d263e8ac12a))

## [3.8.1](https://github.com/DexCare/telehealth.blissey/compare/3.8.0...3.8.1) (2021-04-09)


### Bug Fixes

* build ([2cb942e](https://github.com/DexCare/telehealth.blissey/commit/2cb942e0c39d78b9cca2901620a462eba42d9121))
* camera issue in iphone ([7178a6d](https://github.com/DexCare/telehealth.blissey/commit/7178a6ddba4177c0844748b3ac46ad1f4ee3f8aa))

# [3.8.0](https://github.com/DexCare/telehealth.blissey/compare/3.7.2...3.8.0) (2021-04-09)


### Bug Fixes

* build ([cbec331](https://github.com/DexCare/telehealth.blissey/commit/cbec33116ee5b52ca5549a66812d075ef2c3470a))
* build ([53a826f](https://github.com/DexCare/telehealth.blissey/commit/53a826f4ed52dd2745b3581e08c92a621d7bad72))
* build 2 ([7ee141f](https://github.com/DexCare/telehealth.blissey/commit/7ee141fada0a0bdcac1b4db7d2d21a5571eea217))
* build issue ([b0f8194](https://github.com/DexCare/telehealth.blissey/commit/b0f81945821fff1b96b724d4043370c3382051b6))
* logger on safari and firefox ([1639e3f](https://github.com/DexCare/telehealth.blissey/commit/1639e3f378ed5b6a627bfedfeb078b009b779322))
* logger on safari and firefox ([54c5ad4](https://github.com/DexCare/telehealth.blissey/commit/54c5ad499b550766fd516aa4325dcb3f6f04b672))
* Setting first device for both video and audio sources ([c186169](https://github.com/DexCare/telehealth.blissey/commit/c186169ad5e0ef87b9d24f14a79b133304b3a523))
* use opentok over navigator ([fc8697e](https://github.com/DexCare/telehealth.blissey/commit/fc8697e7890ea1be52fd07982bcc291f86bd25a7))
* use opentok over navigator ([8f3a76c](https://github.com/DexCare/telehealth.blissey/commit/8f3a76c1be66f8dfa225b414bd8972dabfc6f09b))


### Features

* end visit early for provider side after clicking on end call button ([902a7be](https://github.com/DexCare/telehealth.blissey/commit/902a7bee33a031e6dbb6ee5a74528ee08b1741f4))
* Set Video Source in callselfcheckcomponent ([c476507](https://github.com/DexCare/telehealth.blissey/commit/c4765075b78ede04a119a9ca56b8e7fa254c90a2))

## [3.7.2](https://github.com/DexCare/telehealth.blissey/compare/3.7.1...3.7.2) (2021-04-07)


### Bug Fixes

* change auth to always redirect to authorize to reestablish session ([07c6a49](https://github.com/DexCare/telehealth.blissey/commit/07c6a49ec60654ded4af2933d027019fa1d613af))
* frosh dev ([f7bac57](https://github.com/DexCare/telehealth.blissey/commit/f7bac572a80508e58b12b93cc2dc0acbc3a58b93))
* remove hosts from pr yaml ([b61df53](https://github.com/DexCare/telehealth.blissey/commit/b61df53b29e570114ddd07216363e07160304058))

## [3.7.1](https://github.com/DexCare/telehealth.blissey/compare/3.7.0...3.7.1) (2021-04-03)


### Bug Fixes

* remove CPU Monitor ([6a39340](https://github.com/DexCare/telehealth.blissey/commit/6a3934070dedbf719b628d0e3b3d4c016ef3591a))

# [3.7.0](https://github.com/DexCare/telehealth.blissey/compare/3.6.0...3.7.0) (2021-04-01)


### Bug Fixes

* removing extra blank line ([e3c5d54](https://github.com/DexCare/telehealth.blissey/commit/e3c5d5499d07590ad58fac1689a970a24c87f271))


### Features

* move visit summary from rest to visit service ([9e78d8c](https://github.com/DexCare/telehealth.blissey/commit/9e78d8c767d52120c5d2fe852d3b0e3da6e58519))

# [3.6.0](https://github.com/DexCare/telehealth.blissey/compare/3.5.5...3.6.0) (2021-03-30)


### Bug Fixes

* fix call flow between intsched and blissey logout handling ([9e502fe](https://github.com/DexCare/telehealth.blissey/commit/9e502fe14541a4145f13de05e86da6d6d87383b7))
* removing comment ([f0e7b6b](https://github.com/DexCare/telehealth.blissey/commit/f0e7b6bd5163d5925cc9eaee9534460a561f915f))
* selfviewcontainer resizes based on publisher stream dimensions ([448dadf](https://github.com/DexCare/telehealth.blissey/commit/448dadf2b1cd1addf642959e439cacfa28e74072))


### Features

* Blissey Footer changes as similar as Int sched ([d70ed84](https://github.com/DexCare/telehealth.blissey/commit/d70ed84c5abed5131b4317e0fb43fc86b1e011fe))
* update charge and waive endpoints ([819d25a](https://github.com/DexCare/telehealth.blissey/commit/819d25ae656e1861d762e654b55f30e7797624f5))

## [3.5.5](https://github.com/DexCare/telehealth.blissey/compare/3.5.4...3.5.5) (2021-03-25)


### Bug Fixes

* await for provider feedback ([0a45ade](https://github.com/DexCare/telehealth.blissey/commit/0a45ade121ce5eeaaafae7977b9754d1ea1cd048))

## [3.5.4](https://github.com/DexCare/telehealth.blissey/compare/3.5.3...3.5.4) (2021-03-24)


### Bug Fixes

* pass in browser as a separate value ([59531f1](https://github.com/DexCare/telehealth.blissey/commit/59531f122b002b963cdb45acd66c477c36f50754))
* provider feedback ([24a5e75](https://github.com/DexCare/telehealth.blissey/commit/24a5e755c10a5ee36d205baad9e69827798bc1cb))

## [3.5.3](https://github.com/DexCare/telehealth.blissey/compare/3.5.2...3.5.3) (2021-03-23)


### Bug Fixes

* fix accessToken not being properly decoded before accessing expiration ([2218375](https://github.com/DexCare/telehealth.blissey/commit/2218375ee83406a006202c3ad223c854175e3143))

## [3.5.2](https://github.com/DexCare/telehealth.blissey/compare/3.5.1...3.5.2) (2021-03-23)


### Bug Fixes

* bumping typescript lib versions to allow for standard es6 functions ([0caec03](https://github.com/DexCare/telehealth.blissey/commit/0caec038e4c4ae731f152213f61e9c2c4f469e51))
* fix extra cases in support for access token use over id token ([ad8047c](https://github.com/DexCare/telehealth.blissey/commit/ad8047c2446de31ae456f8dabe994278c473a59d))

## [3.5.1](https://github.com/DexCare/telehealth.blissey/compare/3.5.0...3.5.1) (2021-03-22)


### Bug Fixes

* use visit service instead of FHIR Orch for cancel ([1e9c0c5](https://github.com/DexCare/telehealth.blissey/commit/1e9c0c5396cbb25998410aeffa9668e6e9daa0cf))

# [3.5.0](https://github.com/DexCare/telehealth.blissey/compare/3.4.0...3.5.0) (2021-03-19)


### Features

* close window for provider at the end of the visit after the star rating ([7f9b75a](https://github.com/DexCare/telehealth.blissey/commit/7f9b75aec89862396c87933adfae36c85983e279))

# [3.4.0](https://github.com/DexCare/telehealth.blissey/compare/3.3.2...3.4.0) (2021-03-18)


### Bug Fixes

* bump circus-saturn version to include accessToken in UserDetails interface ([6525373](https://github.com/DexCare/telehealth.blissey/commit/6525373713d46dd0cc04aaf1c97ff7a3d8701712))


### Features

* support custom oidc prompt and scope params ([d814bd5](https://github.com/DexCare/telehealth.blissey/commit/d814bd557a61f754796a73c7864fffaa262243ea))
* support using access tokens on patient side and fix okta logout ([cd65618](https://github.com/DexCare/telehealth.blissey/commit/cd65618122353d78f2bf3643d71109a8c3467e4e))

## [3.3.2](https://github.com/DexCare/telehealth.blissey/compare/3.3.1...3.3.2) (2021-03-10)


### Bug Fixes

* redirect to next from intsched when logout request comes from intsched ([216f916](https://github.com/DexCare/telehealth.blissey/commit/216f91630ea13e04a2d6b19007e347ddb2cf7be4))

## [3.3.1](https://github.com/DexCare/telehealth.blissey/compare/3.3.0...3.3.1) (2021-03-08)


### Bug Fixes

* configured GCR ([d014661](https://github.com/DexCare/telehealth.blissey/commit/d0146619b831a05ac4ae339211faf03e7ce6f6b2))
* declined visit should send user to the visit has been declined page ([3038b1d](https://github.com/DexCare/telehealth.blissey/commit/3038b1debd995b53f8ef27f94e12c989d76d3ab5))
* notFoundModule logging ([772e96c](https://github.com/DexCare/telehealth.blissey/commit/772e96ce375b10b08b3691450ca21de494eba5fb))

# [3.3.0](https://github.com/DexCare/telehealth.blissey/compare/3.2.1...3.3.0) (2021-03-04)


### Bug Fixes

* moving flag from launch darkly to sidecar. ([32024b9](https://github.com/DexCare/telehealth.blissey/commit/32024b93af94bf1bb0fb5b96e421650126d4ba97))
* PR build issue ([506ba44](https://github.com/DexCare/telehealth.blissey/commit/506ba442a4d9efd847259c5e9c124a0d00ef516b))
* update local config.json file with chat headerText ([f12395d](https://github.com/DexCare/telehealth.blissey/commit/f12395df118b79a742d75e778dd005055c659c68))


### Features

* DC-3971 - logic to check logout referer to guard against infinite redirects ([420f5be](https://github.com/DexCare/telehealth.blissey/commit/420f5bedb357fa2cd78ec5e22886f327aaab3500))
* Hide PhotoId message in waitingroom for KPWA ([aec4057](https://github.com/DexCare/telehealth.blissey/commit/aec40572aa7fc632aad8a4fcac768322baab2b3c))
* Hiding prescription text for KPWA ([e703cbd](https://github.com/DexCare/telehealth.blissey/commit/e703cbd582e8effe04e890f57d43a4c32ca7f1d0))

## [3.2.1](https://github.com/DexCare/telehealth.blissey/compare/3.2.0...3.2.1) (2021-03-02)

# [3.2.0](https://github.com/DexCare/telehealth.blissey/compare/3.1.2...3.2.0) (2021-02-24)


### Bug Fixes

* build issue ([cf471e1](https://github.com/DexCare/telehealth.blissey/commit/cf471e1d1b28a9c4ce54e17296bf752f456d1a07))
* Credit card charge call made async without wait DC-3797 + Kubernetes script command update ([18a4636](https://github.com/DexCare/telehealth.blissey/commit/18a4636420a3f298c1a92de1ba2704ebba887006))
* patient feedback issue in kaiju ([13b6e79](https://github.com/DexCare/telehealth.blissey/commit/13b6e79741f7d1bb6ef502cfdd82c694411a36ee))


### Features

* Pass Optional Text Header to Chat Component ([a5a4e78](https://github.com/DexCare/telehealth.blissey/commit/a5a4e7845ff832a47bdbb117069a74eb4014fa87))

## [3.1.2](https://github.com/DexCare/telehealth.blissey/compare/3.1.1...3.1.2) (2021-02-17)


### Bug Fixes

* camera warning button styles ([3a5d802](https://github.com/DexCare/telehealth.blissey/commit/3a5d80249736a5280244b1e19328b578bb09be6e))
* cancel link margin ([bc0e67b](https://github.com/DexCare/telehealth.blissey/commit/bc0e67b7fd2ec6a418ad80aff21da4d29115856c))
* css import ([0f07f39](https://github.com/DexCare/telehealth.blissey/commit/0f07f39528dc4e7625d40038b9aa97d6f064c91a))
* css import ([d1d05a1](https://github.com/DexCare/telehealth.blissey/commit/d1d05a1959861017ec194b675e89709e818a4062))
* keep underline in waitingroom link ([9659295](https://github.com/DexCare/telehealth.blissey/commit/9659295839d80cc58578181a751547aad3fb3ca6))

## [3.1.1](https://github.com/DexCare/telehealth.blissey/compare/3.1.0...3.1.1) (2021-02-09)


### Bug Fixes

* in promtion pipeline, retreive tag after it has been updated by semantic release ([b73b9a5](https://github.com/DexCare/telehealth.blissey/commit/b73b9a5e05574e1ad8e2e1157f8e04da20a75d31))

# [3.1.0](https://github.com/DexCare/telehealth.blissey/compare/3.0.165...3.1.0) (2021-02-09)


### Bug Fixes

* automation tests fix ([9e8afe2](https://github.com/DexCare/telehealth.blissey/commit/9e8afe29223f71e485589716460ebfdeb907dc7b))
* build ([da80436](https://github.com/DexCare/telehealth.blissey/commit/da80436adcc538761a371c37c71df6e89fa108d9))
* build pipeline ([998af91](https://github.com/DexCare/telehealth.blissey/commit/998af91f7bc1240ebbf5e298d2a622d379572840))
* chat button was disabled ([b74d500](https://github.com/DexCare/telehealth.blissey/commit/b74d50096fbe0e3e7bbfe2cf875e8014797d11b0))
* code review changes ([2f8ec73](https://github.com/DexCare/telehealth.blissey/commit/2f8ec73bf4c1fbb5863ba121d767a37aaec91a0a))
* code review fixes ([e779858](https://github.com/DexCare/telehealth.blissey/commit/e7798586e7c10693ec665f8ee34fb0cb157c21c0))
* failied unit tests ([dffbd51](https://github.com/DexCare/telehealth.blissey/commit/dffbd5173c82635c58759028be9141299ffac89d))
* failing tests ([4938b70](https://github.com/DexCare/telehealth.blissey/commit/4938b704d9b6132d0068b58cdd5ed4e9d96dddef))
* GHA token ([111edb1](https://github.com/DexCare/telehealth.blissey/commit/111edb15f171a742d940dbbf5c3f403c152a2c4e))


### Features

* ADA Changes ([0dd5164](https://github.com/DexCare/telehealth.blissey/commit/0dd5164a71ff4ab00c94de58e1a17eef4d815322))
* changing red color value for endcall button ([623931f](https://github.com/DexCare/telehealth.blissey/commit/623931f7da3e0e7856d2d78eda9a5b79eb3329a3))
* code review changes ([05bd1b0](https://github.com/DexCare/telehealth.blissey/commit/05bd1b01eb04b3b76910b280959d639edb19fa4b))
* code review changes ([abe335a](https://github.com/DexCare/telehealth.blissey/commit/abe335a24a21e22ae0b892eaf79ec7eafe0a2e9e))
* janine changes ([81d56b7](https://github.com/DexCare/telehealth.blissey/commit/81d56b7d683d690bb21aa169a27978d2d20c2be0))
* janine changes ([41a4bb7](https://github.com/DexCare/telehealth.blissey/commit/41a4bb78c5813441671c5a4176aeefd3ad12b8a4))
* upgrade to node14 ([25984fd](https://github.com/DexCare/telehealth.blissey/commit/25984fd5d1d6fc9ab255147d77a614e68403b724))
* Virtual Patient Survey - ADA updates required for KPWA ([d3cf575](https://github.com/DexCare/telehealth.blissey/commit/d3cf57509c7504bdab38303fd2551e06336d3830))

## [3.0.165](https://github.com/DexCare/telehealth.blissey/compare/3.0.164...3.0.165) (2021-01-29)


### Bug Fixes

* reset the version ([fd536bb](https://github.com/DexCare/telehealth.blissey/commit/fd536bb73584259d22c5d213ae0d6b7fc763c9b5))

## [3.0.164](https://github.com/DexCare/telehealth.blissey/compare/3.0.163...3.0.164) (2021-01-23)


### Bug Fixes

* final testing of the promote pipeline ([ec97513](https://github.com/DexCare/telehealth.blissey/commit/ec97513654c5289f01b9fbb0374084ced37e4710))

## [3.0.163](https://github.com/DexCare/telehealth.blissey/compare/3.0.162...3.0.163) (2021-01-23)


### Bug Fixes

* testing the pipeline ([daacdc6](https://github.com/DexCare/telehealth.blissey/commit/daacdc6720fe433796d587803918a4962b60fae5))
* testing the promote pipeline ([a68c563](https://github.com/DexCare/telehealth.blissey/commit/a68c5638d12340a149b201e85a34f57ba3bd3414))

## [3.0.162](https://github.com/DexCare/telehealth.blissey/compare/3.0.161...3.0.162) (2021-01-23)


### Bug Fixes

* testing the promote pipeline ([ada5fdc](https://github.com/DexCare/telehealth.blissey/commit/ada5fdcbc34126f1faf03c7a9dd50352dfc8a8b5))
* whitespace change for testing the promote ([d69e81a](https://github.com/DexCare/telehealth.blissey/commit/d69e81a96511c48f2f5d2dc0aefe11be1efd0567))

## [3.0.162](https://github.com/DexCare/telehealth.blissey/compare/3.0.161...3.0.162) (2021-01-23)


### Bug Fixes

* configure GHA workflow files ([8612e62](https://github.com/DexCare/telehealth.blissey/commit/8612e627e3bd77ba780a26572ec812194f2f413e))
* configure GHA workflow files ([91424e6](https://github.com/DexCare/telehealth.blissey/commit/91424e6b725d4f54c23e361efb90bdaa51561df6))
* correcting the spelling of charts ([43accd8](https://github.com/DexCare/telehealth.blissey/commit/43accd863db74f300be27f1422abd925051f40dd))
* Increased the timeout-minutes ([b088a22](https://github.com/DexCare/telehealth.blissey/commit/b088a2253a5c2664d696284040d939ac4f05eb16))
* Increased the timeout-minutes ([a325ff7](https://github.com/DexCare/telehealth.blissey/commit/a325ff765a105f1c6be6ecac450b338a2c5f35e1))
* just for testing the Dockerfile ([7ddec76](https://github.com/DexCare/telehealth.blissey/commit/7ddec76d8aa736913d1cbbc592c6d81705fc8574))
* lint and handle nulls ([948476d](https://github.com/DexCare/telehealth.blissey/commit/948476d766927c6150e31d30ab2f71b95f0852fb))
* make jwt-helper part of blissey app ([da7c839](https://github.com/DexCare/telehealth.blissey/commit/da7c839064a568f87a95f66045741b7d1430e921))
* moved calculate tag&release step above docker ([7014c32](https://github.com/DexCare/telehealth.blissey/commit/7014c32881ff24aa69878b645ddfedf88f2b6b37))
* renamed chart to charts ([ff1698d](https://github.com/DexCare/telehealth.blissey/commit/ff1698d77df861fd3d808857aa694a5a78e9a6c0))
* renamed chart to charts ([98606d3](https://github.com/DexCare/telehealth.blissey/commit/98606d38e54772dbed81e14afd7a390a8d45cfcc))
* renamed chart to charts ([d6b1fa3](https://github.com/DexCare/telehealth.blissey/commit/d6b1fa3bb0334195ae87c4e17667ec0c86ce3a7d))
* running the docker build step twice ([92c1164](https://github.com/DexCare/telehealth.blissey/commit/92c11646a3d4c45b6464df7e0a703733aa943c5f))
* running the docker step twice ([eb2df84](https://github.com/DexCare/telehealth.blissey/commit/eb2df8457f78d8974ed208a950641e8050f384dd))
* running the docker step twice ([f30665e](https://github.com/DexCare/telehealth.blissey/commit/f30665ee28154d9170573603f69af4ec0c89e7cb))
* testing the promote pipeline ([6deaa13](https://github.com/DexCare/telehealth.blissey/commit/6deaa1358d1e638a6fcd34ac5eaaf01b635880a6))
* testing the promote pipeline ([6165b57](https://github.com/DexCare/telehealth.blissey/commit/6165b572d5da037b8e308510349b1fe6ca6a9b02))
* try to fix the path ([6c9ca0d](https://github.com/DexCare/telehealth.blissey/commit/6c9ca0d44c094d9e6e0e204f1928eca13ac1ba1c))
* trying to fix the error ([db4bf05](https://github.com/DexCare/telehealth.blissey/commit/db4bf05d1ebb2efcd14f0a03e37ea0c75a78d7c8))
* trying to fix the error ([8651d7a](https://github.com/DexCare/telehealth.blissey/commit/8651d7a6f5eef62dca97b2cb8311f8c31aa98ad3))
* trying to fix the path ([48e612d](https://github.com/DexCare/telehealth.blissey/commit/48e612dc1aaf179971105e2e2d8f3e676ab55075))
* trying to fix the path ([d92e851](https://github.com/DexCare/telehealth.blissey/commit/d92e851ff42bb10fd047f969edf6a85c8d1ed54a))
* trying to set the right path ([310a039](https://github.com/DexCare/telehealth.blissey/commit/310a0399eb6b68e072f38f9c6b64b0f54ec4016c))
* updated path ([14ab021](https://github.com/DexCare/telehealth.blissey/commit/14ab02191cf6292480d74e3f3a8554cf0fbbee13))
* updated path to find the Dockerfile ([d4c7c83](https://github.com/DexCare/telehealth.blissey/commit/d4c7c8322ce73033d10cfa615e56c2e836db3130))

## [3.0.162](https://github.com/DexCare/telehealth.blissey/compare/3.0.161...3.0.162) (2021-01-23)


### Bug Fixes

* configure GHA workflow files ([8612e62](https://github.com/DexCare/telehealth.blissey/commit/8612e627e3bd77ba780a26572ec812194f2f413e))
* configure GHA workflow files ([91424e6](https://github.com/DexCare/telehealth.blissey/commit/91424e6b725d4f54c23e361efb90bdaa51561df6))
* correcting the spelling of charts ([43accd8](https://github.com/DexCare/telehealth.blissey/commit/43accd863db74f300be27f1422abd925051f40dd))
* Increased the timeout-minutes ([b088a22](https://github.com/DexCare/telehealth.blissey/commit/b088a2253a5c2664d696284040d939ac4f05eb16))
* Increased the timeout-minutes ([a325ff7](https://github.com/DexCare/telehealth.blissey/commit/a325ff765a105f1c6be6ecac450b338a2c5f35e1))
* just for testing the Dockerfile ([7ddec76](https://github.com/DexCare/telehealth.blissey/commit/7ddec76d8aa736913d1cbbc592c6d81705fc8574))
* lint and handle nulls ([948476d](https://github.com/DexCare/telehealth.blissey/commit/948476d766927c6150e31d30ab2f71b95f0852fb))
* make jwt-helper part of blissey app ([da7c839](https://github.com/DexCare/telehealth.blissey/commit/da7c839064a568f87a95f66045741b7d1430e921))
* moved calculate tag&release step above docker ([7014c32](https://github.com/DexCare/telehealth.blissey/commit/7014c32881ff24aa69878b645ddfedf88f2b6b37))
* renamed chart to charts ([ff1698d](https://github.com/DexCare/telehealth.blissey/commit/ff1698d77df861fd3d808857aa694a5a78e9a6c0))
* renamed chart to charts ([98606d3](https://github.com/DexCare/telehealth.blissey/commit/98606d38e54772dbed81e14afd7a390a8d45cfcc))
* renamed chart to charts ([d6b1fa3](https://github.com/DexCare/telehealth.blissey/commit/d6b1fa3bb0334195ae87c4e17667ec0c86ce3a7d))
* running the docker build step twice ([92c1164](https://github.com/DexCare/telehealth.blissey/commit/92c11646a3d4c45b6464df7e0a703733aa943c5f))
* running the docker step twice ([f30665e](https://github.com/DexCare/telehealth.blissey/commit/f30665ee28154d9170573603f69af4ec0c89e7cb))
* testing the promote pipeline ([6deaa13](https://github.com/DexCare/telehealth.blissey/commit/6deaa1358d1e638a6fcd34ac5eaaf01b635880a6))
* testing the promote pipeline ([6165b57](https://github.com/DexCare/telehealth.blissey/commit/6165b572d5da037b8e308510349b1fe6ca6a9b02))
* try to fix the path ([6c9ca0d](https://github.com/DexCare/telehealth.blissey/commit/6c9ca0d44c094d9e6e0e204f1928eca13ac1ba1c))
* trying to fix the error ([db4bf05](https://github.com/DexCare/telehealth.blissey/commit/db4bf05d1ebb2efcd14f0a03e37ea0c75a78d7c8))
* trying to fix the error ([8651d7a](https://github.com/DexCare/telehealth.blissey/commit/8651d7a6f5eef62dca97b2cb8311f8c31aa98ad3))
* trying to fix the path ([48e612d](https://github.com/DexCare/telehealth.blissey/commit/48e612dc1aaf179971105e2e2d8f3e676ab55075))
* trying to fix the path ([d92e851](https://github.com/DexCare/telehealth.blissey/commit/d92e851ff42bb10fd047f969edf6a85c8d1ed54a))
* trying to set the right path ([310a039](https://github.com/DexCare/telehealth.blissey/commit/310a0399eb6b68e072f38f9c6b64b0f54ec4016c))
* updated path ([14ab021](https://github.com/DexCare/telehealth.blissey/commit/14ab02191cf6292480d74e3f3a8554cf0fbbee13))
* updated path to find the Dockerfile ([d4c7c83](https://github.com/DexCare/telehealth.blissey/commit/d4c7c8322ce73033d10cfa615e56c2e836db3130))

## [3.0.162](https://github.com/DexCare/telehealth.blissey/compare/3.0.161...3.0.162) (2021-01-23)


### Bug Fixes

* configure GHA workflow files ([8612e62](https://github.com/DexCare/telehealth.blissey/commit/8612e627e3bd77ba780a26572ec812194f2f413e))
* configure GHA workflow files ([91424e6](https://github.com/DexCare/telehealth.blissey/commit/91424e6b725d4f54c23e361efb90bdaa51561df6))
* correcting the spelling of charts ([43accd8](https://github.com/DexCare/telehealth.blissey/commit/43accd863db74f300be27f1422abd925051f40dd))
* Increased the timeout-minutes ([b088a22](https://github.com/DexCare/telehealth.blissey/commit/b088a2253a5c2664d696284040d939ac4f05eb16))
* Increased the timeout-minutes ([a325ff7](https://github.com/DexCare/telehealth.blissey/commit/a325ff765a105f1c6be6ecac450b338a2c5f35e1))
* just for testing the Dockerfile ([7ddec76](https://github.com/DexCare/telehealth.blissey/commit/7ddec76d8aa736913d1cbbc592c6d81705fc8574))
* lint and handle nulls ([948476d](https://github.com/DexCare/telehealth.blissey/commit/948476d766927c6150e31d30ab2f71b95f0852fb))
* make jwt-helper part of blissey app ([da7c839](https://github.com/DexCare/telehealth.blissey/commit/da7c839064a568f87a95f66045741b7d1430e921))
* moved calculate tag&release step above docker ([7014c32](https://github.com/DexCare/telehealth.blissey/commit/7014c32881ff24aa69878b645ddfedf88f2b6b37))
* renamed chart to charts ([ff1698d](https://github.com/DexCare/telehealth.blissey/commit/ff1698d77df861fd3d808857aa694a5a78e9a6c0))
* renamed chart to charts ([98606d3](https://github.com/DexCare/telehealth.blissey/commit/98606d38e54772dbed81e14afd7a390a8d45cfcc))
* renamed chart to charts ([d6b1fa3](https://github.com/DexCare/telehealth.blissey/commit/d6b1fa3bb0334195ae87c4e17667ec0c86ce3a7d))
* running the docker build step twice ([92c1164](https://github.com/DexCare/telehealth.blissey/commit/92c11646a3d4c45b6464df7e0a703733aa943c5f))
* try to fix the path ([6c9ca0d](https://github.com/DexCare/telehealth.blissey/commit/6c9ca0d44c094d9e6e0e204f1928eca13ac1ba1c))
* trying to fix the error ([db4bf05](https://github.com/DexCare/telehealth.blissey/commit/db4bf05d1ebb2efcd14f0a03e37ea0c75a78d7c8))
* trying to fix the error ([8651d7a](https://github.com/DexCare/telehealth.blissey/commit/8651d7a6f5eef62dca97b2cb8311f8c31aa98ad3))
* trying to fix the path ([48e612d](https://github.com/DexCare/telehealth.blissey/commit/48e612dc1aaf179971105e2e2d8f3e676ab55075))
* trying to fix the path ([d92e851](https://github.com/DexCare/telehealth.blissey/commit/d92e851ff42bb10fd047f969edf6a85c8d1ed54a))
* trying to set the right path ([310a039](https://github.com/DexCare/telehealth.blissey/commit/310a0399eb6b68e072f38f9c6b64b0f54ec4016c))
* updated path ([14ab021](https://github.com/DexCare/telehealth.blissey/commit/14ab02191cf6292480d74e3f3a8554cf0fbbee13))
* updated path to find the Dockerfile ([d4c7c83](https://github.com/DexCare/telehealth.blissey/commit/d4c7c8322ce73033d10cfa615e56c2e836db3130))
