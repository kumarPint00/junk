import {
  CompleteCustomerEnvironment,
  getCustomerEnvironmentComplete,
  VirtualPrecheckLibrary,
  VirtualWaitingRoomLibrary,
  VirtualProviderPortalEntryLibrary,
  VideoVisitLibrary,
  assignAvailableTestProvider,
  virtualCleanupById,
  generateQRCodeVideo,
  providerChromeCapability,
  setReportPortalTestAttributes,
  remote,
  path,
} from '@dexcare/pegasus';

describe('Virtual Visit __customer__', () => {
  let environment: CompleteCustomerEnvironment;
  let precheck: VirtualPrecheckLibrary;
  let visitId: string;
  let waitingRoom: VirtualWaitingRoomLibrary;
  let providerBrowser: WebdriverIO.Browser;
  let providerVisit: VideoVisitLibrary;

  before(async () => {
    environment = await getCustomerEnvironmentComplete('__codename__');
    setReportPortalTestAttributes(environment);

    precheck = new VirtualPrecheckLibrary(environment);
  });

  it('Happy Path [DC-####] [__grepTags__]', async function () {
    const testTimeout = this.timeout()
            + parseInt(process.env.VISIT_LENGTH || '0', 10) * 60000;
    this.timeout(testTimeout);
    const practiceId = environment.ui.virtual.virtualVisitPractice
            || environment.dynamicPractice.practiceId;
    /* Create virtual visit */
    if (['kp'].includes(environment.customerName)) {
      waitingRoom = await precheck.flow.happy
      // .injectAuthKp()
        .min(practiceId)
        .then(async (authPatient) => authPatient.flow.happy.minKp())
        .then(async (visitReason) => visitReason.flow.happy.minKp())
        .then(async (summary) => summary.flow.happy.min());
    } else {
      waitingRoom = await precheck.flow.happy
      // .injectAuth()
        .min(practiceId)
        .then(async (authPatient) => authPatient.flow.happy.min())
        .then(async (selectDemographics) => selectDemographics.flow.happy.min())
        .then(async (demographics) => demographics.flow.happy.min())
        .then(async (visitReason) => visitReason.flow.happy.min())
        .then(async (paymentOptions) => paymentOptions.flow.happy.min())
        .then(async (insurance) => insurance.flow.happy.min())
        .then(async (summary) => summary.flow.happy.min());
    }
    visitId = await waitingRoom.flow.happy.getVisitId();
    await waitingRoom.flow.happy.min();
    /* Assign visit to available provider */
    const providerId = await assignAvailableTestProvider(
      environment,
      visitId,
      practiceId,
    );
    const provider = environment.dynamicProviderAccounts.find((x) => x.providerId === providerId);

    /* Create provider QR video */
    await generateQRCodeVideo({
      fps: 30,
      seconds: 30,
      testName: 'virtual-visit',
      videoOrigin: 'provider',
    });

    /* Init provider browser */
    providerBrowser = await remote({
      capabilities: providerChromeCapability,
      hostname: browser.config.hostname,
      port: browser.config.port,
      logLevel: browser.config.logLevel,
    });

    /* Join visit */
    const providerPortalEntry = new VirtualProviderPortalEntryLibrary(
      environment,
      providerBrowser,
    );
    providerVisit = await providerPortalEntry.flow.happy
      .min()
      .then(async (authPage) => authPage.flow.happy.min(provider?.email, provider?.password))
      .then(async (dashboard) => dashboard.flow.happy.activeVisit(visitId))
      .then(async (visitDetails) => visitDetails.flow.happy.startVisit(visitId))
      .then(async (providerWaitingRoom) => providerWaitingRoom.flow.happy.min());
    /* Complete video visit */
    await providerVisit.flow.happy.provider();
    // TODO: add patient video visit validation
  });

  after(async function () {
    if (providerBrowser) {
      if (this.currentTest?.state === 'failed') {
        const fileName = path.basename(__filename).split('.')[0];
        await providerBrowser.saveScreenshot(
          path.join(
            '.',
            'logs',
            'junit',
            `${fileName}-providerBrowser.png`,
          ),
        );
      }
      await providerBrowser.deleteSession();
    }
    await virtualCleanupById(environment, visitId); // TODO: Only after failure?
  });
});
