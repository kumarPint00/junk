import {
    CompleteCustomerEnvironment,
    getCustomerEnvironmentComplete,
    VirtualPrecheckLibrary,
    VirtualWaitingRoomLibrary,
    virtualCleanupById,
    VisitServiceV8Setup,
    setReportPortalTestAttributes
} from '@dexcare/pegasus';

describe('Waiting Room __customer__', function () {
    let environment: CompleteCustomerEnvironment;
    let visitId: string;
    before(async function () {
        environment = await getCustomerEnvironmentComplete('__codename__');
        setReportPortalTestAttributes(environment);

        /* Enable Providers */
        await new VisitServiceV8Setup(
            environment,
        ).action.internal.enableProvider();
    });

    it(`Happy Path [DC-####] [__grepTags__]`, async function () {
        const precheck = new VirtualPrecheckLibrary(environment);
        let waitingRoom: VirtualWaitingRoomLibrary;
        if (['kp'].includes(environment.customerName)) {
            waitingRoom = await precheck.flow.happy
                // .injectAuthKp()
                .min()
                .then(async (authPatient) => authPatient.flow.happy.minKp())
                .then(async (visitReason) => visitReason.flow.happy.minKp())
                .then(async (summary) => summary.flow.happy.min());
        } else {
            waitingRoom = await precheck.flow.happy
                // .injectAuth()
                .min()
                .then(async (authPatient) => authPatient.flow.happy.min())
                .then(async (selectDemographics) =>
                    selectDemographics.flow.happy.min(),
                )
                .then(async (demographics) => demographics.flow.happy.min())
                .then(async (visitReason) => visitReason.flow.happy.min())
                .then(async (paymentOptions) => paymentOptions.flow.happy.min())
                .then(async (insurance) => insurance.flow.happy.min())
                .then(async (summary) => summary.flow.happy.min());
        }
        visitId = await waitingRoom.flow.happy.getVisitId();
        await waitingRoom.flow.happy.max();
    });

    after(async function () {
        await virtualCleanupById(environment, visitId); // TODO: Only after failure?
    });
});
