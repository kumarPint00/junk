module.exports = {
    extends: ['@dexcare/eslint-config'],
    parserOptions: {
        tsconfigRootDir: __dirname,
        project: [
            './tsconfig.json',
            './__tests__/tsconfig.json',
            './blissey/app/tsconfig.json',
            './blissey/server/tsconfig.json',
        ],
        sourceType: 'module',
        ecmaVersion: 'ESNext',
    },
    rules: {
        '@typescript-eslint/no-unsafe-member-access': 'warn',
    },
};
