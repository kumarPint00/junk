
CLOUD KITCHEN PRINT ASSETS — PLACEHOLDER SET

FILES:
- insert_A6_front.png / insert_A6_back.png — A6 (148x105mm) @300DPI, ready for print
- visiting_card_front.png / visiting_card_back.png — 3.5x2in @300DPI
- logo_sticker_round_3in.png — 3in round sticker @300DPI (transparent PNG)
- tamper_seal_8x2cm.png — tamper-evident seal @300DPI

PLACEHOLDERS TO REPLACE:
- Brand name: ETERNAL KITCHEN
- FSSAI no.: FSSAI: 12345678901234
- WhatsApp: 919999999999
- Instagram: @eternalkitchen

QR CODES:
- Insert & Back QR → https://wa.me/919999999999?text=Hi%20PACK30
- Visiting card QR → https://wa.me/919999999999?text=Hi%20CARD30

OFFER CODES (track channels):
- PACK30 (inside packaging insert)
- CARD30 (visiting card)
- PG50 (PG/hostel flyers — not included here but we can add)
- SOC50 (society stalls — not included here but we can add)

HOW TO CUSTOMIZE:
Tell me your actual Brand, FSSAI, WhatsApp number, and Instagram,
and I’ll regenerate the set with updated QR codes & text.
If you already have a logo, share it; I’ll drop it into the sticker and headers.

PRINT NOTES:
- Provide PNGs directly to the printer, or I can export vector/PDF on request.
- Colors are neutral black/white to keep print cost low; we can brand with your palette later.
