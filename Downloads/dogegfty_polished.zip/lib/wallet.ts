export async function connectWallet(): Promise<{ address: string }> {
  return new Promise(resolve => setTimeout(() => resolve({ address: '0xAbC123...DEF456' }), 400));
}
export const formatAddress = (addr: string) => addr.slice(0, 6) + '...' + addr.slice(-4);
