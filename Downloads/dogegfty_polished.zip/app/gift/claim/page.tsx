'use client';
import { Box, Button, TextField, Typography } from '@mui/material';
import { useState } from 'react';
import { claimPack } from '@/lib/escrow';
import { GiftPack } from '@/types/gift';
import { useRouter } from 'next/navigation';

export default function ClaimPage() {
  const router = useRouter();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [pack, setPack] = useState<GiftPack | null>(null);

  const handleClaim = async () => {
    const res = await claimPack(code.trim().toUpperCase());
    if (!res) {
      setError('Invalid code');
    } else {
      setPack(res);
    }
  };

  if (pack) {
    return (
      <Box maxWidth={700} mx="auto" px={2} py={4}>
        <Typography variant="h4" mb={2}>🎉 Gift Unlocked!</Typography>
        <Typography mb={2}>Message: {pack.message}</Typography>
        <Typography mb={2}>Items:</Typography>
        {pack.items.map(i => <Typography key={i.id}>• {i.name}</Typography>)}
        <Button variant="contained" sx={{ mt: 3 }} onClick={() => router.push('/')}>Back to Home</Button>
      </Box>
    );
  }

  return (
    <Box maxWidth={500} mx="auto" px={2} py={4}>
      <Typography variant="h4" mb={2}>Claim Gift Pack</Typography>
      <TextField fullWidth label="Secret Code" value={code} onChange={e => { setError(''); setCode(e.target.value); }}/>
      {error && <Typography color="error" mt={1}>{error}</Typography>}
      <Button variant="contained" sx={{ mt: 3 }} onClick={handleClaim}>Unlock</Button>
    </Box>
  );
}
