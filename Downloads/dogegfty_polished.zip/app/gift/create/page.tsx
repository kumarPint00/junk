import { redirect } from 'next/navigation';
export default function CreateRoot() {
  redirect('/gift/create/select');
}
