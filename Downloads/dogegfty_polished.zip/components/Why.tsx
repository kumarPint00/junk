import { Container, Box, Typography, Button } from '@mui/material';
import Section from '@/components/Section';

export default function Why() {
  return (
    <Section id="why" sx={{ py: 8, textAlign: 'center' }}>
      <Container maxWidth="sm">
        <Typography variant="h4" fontWeight={800} mb={2}>
          Why DogeGF <Box component="span" sx={{ color: 'secondary.main' }}>?</Box>
        </Typography>
        <Typography mb={4} color="text.secondary">
          “DogeGF stands for kindness, community, and heart. With DogeGiFty, we're turning that into action —
          empowering everyday people to spread kindness in a fun, decentralized way.”
        </Typography>
        <Button variant="contained" sx={{ bgcolor: 'primary.main', color: '#fff' }}>
          Learn more ↗
        </Button>
      </Container>
    </Section>
  );
}
