'use client';
import { Container, Box, Typography, Button, Snackbar, Alert } from '@mui/material';
import { useState } from 'react';
import Section from '@/components/Section';

export default function ComingSoon() {
  const [sent, setSent] = useState(false);
  return (
    <Section sx={{ bgcolor: 'primary.main', color: '#fff', py: 12, textAlign: 'center' }}>
      <Container maxWidth="md">
        <Typography fontWeight={700} fontSize={18} mb={1}>
          Coming soon..
        </Typography>
        <Typography variant="h2" fontWeight={800} mb={2}>
          “Kindness for Causes” 🎗️
        </Typography>
        <Typography mb={4} fontSize={16}>
          We’re building tools to support NGOs, associations, and community initiatives. Soon, you’ll be able
          to send gift packs directly to verified causes—transparent, secure, and full of meaning.
        </Typography>
        <Button
          variant="contained"
          sx={{ bgcolor: '#fff', color: 'primary.main', fontWeight: 700 }}
          onClick={() => setSent(true)}
        >
          Notify Me
        </Button>
        <Snackbar open={sent} autoHideDuration={3000} onClose={() => setSent(false)}>
          <Alert severity="success" variant="filled" sx={{ bgcolor: 'secondary.main' }}>
            We’ll let you know!
          </Alert>
        </Snackbar>
      </Container>
    </Section>
  );
}
