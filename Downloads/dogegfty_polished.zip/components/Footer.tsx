import { Container, Box, Grid, Typography, Link, IconButton } from '@mui/material';
import FacebookIcon from '@mui/icons-material/Facebook';
import InstagramIcon from '@mui/icons-material/Instagram';
import TwitterIcon from '@mui/icons-material/Twitter';
import TelegramIcon from '@mui/icons-material/Telegram';

export default function Footer() {
  return (
    <Box sx={{ bgcolor: '#FFF2ED', py: 8, mt: 8 }}>
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} md={3}>
            <Box display="flex" alignItems="center" gap={1} mb={1}>
              <Box component="img" src="/logo.png" alt="logo" sx={{ height: 32 }} />
              <Typography variant="h6" fontWeight={800}>
                DogeGiFty
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={6} md={2}>
            <Typography fontWeight={700} mb={1}>
              Quick Links
            </Typography>
            <Link href="#" underline="none" color="inherit" display="block" mb={0.5}>
              About DogeGiFty
            </Link>
            <Link href="#" underline="none" color="inherit" display="block" mb={0.5}>
              How It Works
            </Link>
            <Link href="#" underline="none" color="inherit" display="block">
              DogeGF Website
            </Link>
          </Grid>
          <Grid item xs={6} md={2}>
            <Typography fontWeight={700} mb={1}>
              Support
            </Typography>
            <Link href="#" underline="none" color="inherit" display="block" mb={0.5}>
              Contact
            </Link>
            <Link href="#" underline="none" color="inherit" display="block">
              Terms & Privacy
            </Link>
          </Grid>
          <Grid item xs={12} md={3}>
            <Typography fontWeight={700} mb={1}>
              Stay Connected
            </Typography>
            <IconButton>
              <FacebookIcon />
            </IconButton>
            <IconButton>
              <InstagramIcon />
            </IconButton>
            <IconButton>
              <TwitterIcon />
            </IconButton>
            <IconButton>
              <TelegramIcon />
            </IconButton>
          </Grid>
        </Grid>
        <Typography textAlign="center" mt={4} fontSize={14}>
          2025 DogeGF. All rights reserved.
        </Typography>
      </Container>
    </Box>
  );
}
