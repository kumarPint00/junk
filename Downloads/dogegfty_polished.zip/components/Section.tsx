'use client';
import { motion } from 'framer-motion';
import { Box, BoxProps } from '@mui/material';
import { forwardRef } from 'react';

const variants = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0 }
};

const Section = forwardRef<HTMLDivElement, BoxProps>(({ children, ...props }, ref) => (
  <Box
    component={motion.div}
    ref={ref}
    variants={variants}
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true, amount: 0.3 }}
    transition={{ duration: 0.6, ease: 'easeOut' }}
    {...props}
  >
    {children}
  </Box>
));

Section.displayName = 'Section';
export default Section;
