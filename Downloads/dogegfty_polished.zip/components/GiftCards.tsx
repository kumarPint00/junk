import { Container, Box, Grid, Card, CardContent, Typography, Button } from '@mui/material';
import Image from 'next/image';
import Section from '@/components/Section';

export default function GiftCards() {
  return (
    <Section id="gift">
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          <Grid item xs={12} md={6}>
            <Card
              sx={{
                bgcolor: 'primary.main',
                color: '#fff',
                position: 'relative',
                minHeight: { xs: 260, md: 320 },
                overflow: 'hidden',
                '&:after': {
                  content: '""',
                  position: 'absolute',
                  inset: 0,
                  background: 'linear-gradient(120deg, rgba(255,255,255,.08) 20%, transparent 60%)'
                }
              }}
            >
              <CardContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, height: 1 }}>
                <Box>
                  <Typography variant="h5" fontWeight={700} mb={1}>
                    Create a Gift Pack
                  </Typography>
                  <Typography mb={2}>
                    Choose an amount, add a message, and send crypto as a unique digital gift.
                  </Typography>
                </Box>
                <Button
                  variant="contained"
                  sx={{ bgcolor: 'secondary.main', alignSelf: 'flex-start' }}
                  href="/gift/create/select"
                >
                  Start Gifting
                </Button>
              </CardContent>
              <Box sx={{ position: 'absolute', bottom: -10, right: 24, width: 140, pointerEvents: 'none' }}>
                <Image src="/giftbox-left.png" alt="" width={140} height={140} />
              </Box>
            </Card>
          </Grid>

          <Grid item xs={12} md={6}>
            <Card
              sx={{
                bgcolor: '#FFD7E8',
                color: '#E35785',
                position: 'relative',
                minHeight: { xs: 260, md: 320 },
                overflow: 'hidden',
                '&:after': {
                  content: '""',
                  position: 'absolute',
                  inset: 0,
                  background: 'linear-gradient(120deg, rgba(255,255,255,.15) 20%, transparent 60%)'
                }
              }}
            >
              <CardContent sx={{ display: 'flex', flexDirection: 'column', gap: 2, height: 1 }}>
                <Box>
                  <Typography variant="h5" fontWeight={700} mb={1}>
                    Claim a Gift Pack
                  </Typography>
                  <Typography mb={2}>
                    Your gift is ready to claim. Just follow a few steps to unlock it.
                  </Typography>
                </Box>
                <Button
                  variant="contained"
                  sx={{ bgcolor: 'primary.main', color: '#fff', alignSelf: 'flex-start' }}
                  href="/gift/claim"
                >
                  Start Claiming
                </Button>
              </CardContent>
              <Box sx={{ position: 'absolute', bottom: -10, right: 24, width: 140, pointerEvents: 'none' }}>
                <Image src="/giftbox-right.png" alt="" width={140} height={140} />
              </Box>
            </Card>
          </Grid>
        </Grid>
      </Container>
    </Section>
  );
}
