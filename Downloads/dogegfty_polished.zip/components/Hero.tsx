import { Container, Grid, Typography, Box } from '@mui/material';
import Image from 'next/image';
import Section from '@/components/Section';

export default function Hero() {
  return (
    <Section sx={{ background: 'linear-gradient(135deg,#FFF2ED 0%,#FFEAFB 100%)', py: { xs: 6, md: 10 } }}>
      <Container maxWidth="lg">
        <Grid container spacing={4} alignItems="center">
          <Grid item xs={12} md={6}>
            <Typography variant="h1" mb={2}>
              Send <Box component="span" sx={{ color: 'secondary.main' }}>Kindness,</Box>{' '}
              <Box component="span" sx={{ color: 'primary.main' }}>Onchain.</Box>
            </Typography>
            <Typography sx={{ fontSize: 18, color: 'text.secondary' }}>
              Send Onchain gifts in seconds. DogeGiFty makes it easy to spread kind gestures. Powered by DogeGF.
            </Typography>
          </Grid>
          <Grid item xs={12} md={6} textAlign="center">
            <Image src="/doge-gift.png" alt="Gift Doge" width={480} height={480} priority style={{ borderRadius: 16, maxWidth: '100%', height: 'auto' }} />
          </Grid>
        </Grid>
      </Container>
    </Section>
  );
}
