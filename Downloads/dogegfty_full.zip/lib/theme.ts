import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: { main: '#0B39C6' },
    secondary: { main: '#FF4B82' },
    background: { default: '#FAF8FC', paper: '#FFF' },
    text: { primary: '#1F2250', secondary: '#555770' }
  },
  shape: { borderRadius: 12 },
  typography: {
    fontFamily: 'Inter, system-ui, sans-serif',
    h1: { fontWeight: 800, fontSize: '2.75rem' },
    h2: { fontWeight: 800, fontSize: '2.25rem' },
    button: { textTransform: 'none', fontWeight: 700 }
  },
  components: {
    MuiButton: { styleOverrides: { root: { borderRadius: 8, padding: '10px 22px', boxShadow: 'none' } } },
    MuiCard: { styleOverrides: { root: { borderRadius: 16 } } }
  }
});
export default theme;
