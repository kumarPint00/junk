import { Box, Typography, Button } from '@mui/material';
export default function Why(){
  return(
    <Box sx={{py:8,textAlign:'center'}} id="why">
      <Typography variant="h4" fontWeight={800} mb={2}>Why DogeGF <Box component="span" sx={{color:'secondary.main'}}>?</Box></Typography>
      <Typography maxWidth={700} mx="auto" mb={4} color="text.secondary">
        “DogeGF stands for kindness, community, and heart...”
      </Typography>
      <Button variant="contained" sx={{bgcolor:'primary.main',color:'#fff'}}>Learn more ↗</Button>
    </Box>
  )
}
