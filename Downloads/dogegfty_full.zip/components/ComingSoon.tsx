import { Box, Typography, Button } from '@mui/material';
export default function ComingSoon(){
  return(
    <Box sx={{bgcolor:'primary.main',color:'#fff',py:12,textAlign:'center'}}>
      <Box maxWidth={1000} mx="auto" px={2}>
        <Typography fontWeight={700} fontSize={18} mb={1}>Coming soon..</Typography>
        <Typography variant="h2" fontWeight={800} mb={2}>“Kindness for Causes” 🎗️</Typography>
        <Typography mb={4} fontSize={16}>We’re building tools to support NGOs, associations, and community initiatives.</Typography>
        <Button variant="contained" sx={{bgcolor:'#fff',color:'primary.main',fontWeight:700}}>Notify Me</Button>
      </Box>
    </Box>
  )
}
