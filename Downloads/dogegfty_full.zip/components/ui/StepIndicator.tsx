import { Stepper, Step, StepLabel } from '@mui/material';

export default function StepIndicator({ activeStep }: { activeStep: number }) {
  const steps = ['Select', 'Message', 'Seal', 'Confirm'];
  return (
    <Stepper activeStep={activeStep} alternativeLabel sx={{ my: 4 }}>
      {steps.map(label => (
        <Step key={label}><StepLabel>{label}</StepLabel></Step>
      ))}
    </Stepper>
  );
}
