import { Box, Grid, Card, CardContent, Typography, Button } from '@mui/material';
export default function GiftCards() {
  return (
    <Box sx={{ mt: 8, px: 2 }} id="gift">
      <Grid container spacing={4} maxWidth={1200} mx="auto">
        <Grid item xs={12} md={6}>
          <Card sx={{ bgcolor: 'primary.main', color: '#fff', position: 'relative', minHeight: 320 }}>
            <CardContent sx={{ position: 'relative', zIndex: 1 }}>
              <Typography variant="h5" fontWeight={700} mb={1}>Create a Gift Pack</Typography>
              <Typography mb={3}>Choose an amount, add a message, and send crypto as a unique digital gift.</Typography>
              <Button variant="contained" sx={{ bgcolor: 'secondary.main' }} href="/gift/create/select">Start Gifting</Button>
            </CardContent>
            <Box component="img" src="/giftbox-left.png" alt="" sx={{ position: 'absolute', bottom: -10, right: 24, width: 140 }} />
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card sx={{ bgcolor: '#FFD7E8', color: '#E35785', position: 'relative', minHeight: 320 }}>
            <CardContent sx={{ position: 'relative', zIndex: 1 }}>
              <Typography variant="h5" fontWeight={700} mb={1}>Claim a Gift Pack</Typography>
              <Typography mb={3}>Your gift is ready to claim. Just follow a few steps to unlock it.</Typography>
              <Button variant="contained" sx={{ bgcolor: 'primary.main', color: '#fff' }} href="/gift/claim">Start Claiming</Button>
            </CardContent>
            <Box component="img" src="/giftbox-right.png" alt="" sx={{ position: 'absolute', bottom: -10, right: 24, width: 140 }} />
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
