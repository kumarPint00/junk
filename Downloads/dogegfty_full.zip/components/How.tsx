import { Box, Grid, Paper, Typography } from '@mui/material';
const steps=[
  {title:'Create a Gift Pack',desc:'Add tokens, NFTs, or both—whatever kindness looks like to you.',img:'/giftbox-card.png'},
  {title:'Generate a Secret Code',desc:'Lock your gift with a unique code. The pack goes into escrow until someone claims it with the code.',img:'/lock-card.png'},
  {title:'Share & Surprise',desc:'Send the secret code to a friend, loved one, or stranger. Only they can unlock the pack and claim your gift.',img:'/heart-card.png'},
];
export default function How(){
  return(
    <Box sx={{bgcolor:'#E9F2FF',py:10}}>
      <Box maxWidth={1200} mx="auto" px={2}>
        <Typography variant="h4" fontWeight={800} color="primary.main" mb={4}>How It Works</Typography>
        <Grid container spacing={4}>
          {steps.map(s=>(
            <Grid key={s.title} item xs={12} md={4}>
              <Paper elevation={0} sx={{p:4,borderRadius:4,minHeight:240}}>
                <Box component="img" src={s.img} alt="" sx={{height:60,mb:2}} />
                <Typography variant="h6" fontWeight={700} mb={1}>{s.title}</Typography>
                <Typography color="text.secondary">{s.desc}</Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Box>
  )
}
