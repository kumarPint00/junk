'use client';
import { AppBar, Toolbar, Button, Box, Typography } from '@mui/material';
import Link from 'next/link';
import { useState } from 'react';
import { connectWallet, formatAddress } from '@/lib/wallet';
export default function Navbar(){
  const [wallet,setWallet]=useState('');
  const [loading,setLoading]=useState(false);
  const connect=async()=>{setLoading(true);const r=await connectWallet();setWallet(formatAddress(r.address));setLoading(false);}
  return(
    <AppBar position="sticky" elevation={0} sx={{bgcolor:'transparent',py:1}}>
      <Toolbar sx={{maxWidth:1200,mx:'auto',width:'100%',justifyContent:'space-between'}}>
        <Box display="flex" alignItems="center" gap={1}>
          <Link href="/"><Box component="img" src="/logo.png" alt="" sx={{height:36}}/></Link>
          <Typography variant="h6" fontWeight={800}>DogeGiFty</Typography>
        </Box>
        <Box display="flex" alignItems="center" gap={1}>
          <Link href="#how" passHref legacyBehavior><Button sx={{bgcolor:'#FFE0E9',color:'#F64668'}}>How It Works</Button></Link>
          <Link href="#why" passHref legacyBehavior><Button sx={{bgcolor:'#FFE0E9',color:'#F64668'}}>Why DogeGF</Button></Link>
          <Button variant="contained" onClick={connect} sx={{bgcolor:'white',color:'primary.main'}}>
            {wallet|| (loading?'Connecting...':'Connect Wallet')}
          </Button>
        </Box>
      </Toolbar>
    </AppBar>
  )
}
