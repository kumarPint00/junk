import { Box, Grid, Typography } from '@mui/material';
export default function Hero() {
  return (
    <Box sx={{ py: { xs: 6, md: 10 }, px: 2, background: 'linear-gradient(135deg,#FFF2ED 0%,#FFEAFB 100%)' }}>
      <Grid container spacing={4} alignItems="center" maxWidth={1200} mx="auto">
        <Grid item xs={12} md={6}>
          <Typography variant="h1" sx={{ lineHeight: 1.05, mb: 2 }}>
            Send <Box component="span" sx={{ color: 'secondary.main' }}>Kindness,</Box>{' '}
            <Box component="span" sx={{ color: 'primary.main' }}>Onchain.</Box>
          </Typography>
          <Typography sx={{ fontSize: 18, color: 'text.secondary' }}>
            Send Onchain gifts in seconds. DogeGiFty makes it easy to spread kind gestures. Powered by DogeGF.
          </Typography>
        </Grid>
        <Grid item xs={12} md={6} textAlign="center">
          <Box component="img" src="/doge-gift.png" alt="gift" sx={{ maxWidth: 360, width: '80%', borderRadius: 4 }} />
        </Grid>
      </Grid>
    </Box>
  );
}
