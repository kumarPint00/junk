import type { Express } from "express";
import { createServer, type Server } from "http";
import cookieParser from "cookie-parser";
import { z } from "zod";
import { storage } from "./storage";
import { authenticate, requireAdmin, requireAuth, type AuthRequest } from "./middleware/auth";
import { hashPassword, verifyPassword, generateToken, generateInviteToken } from "./utils/crypto";
import { sendEmail, generateInviteEmail, generateAccessRequestEmail, generateAccessResponseEmail } from "./services/email";
import { 
  registerUserSchema, 
  loginSchema, 
  inviteUserSchema, 
  insertAccessRequestSchema, 
  updateAccessRequestSchema,
  updateUserSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.use(cookieParser());

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = registerUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Hash password
      const hashedPassword = await hashPassword(userData.password);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
        status: "active", // First user is active by default
      });

      // Generate token
      const token = generateToken({ userId: user.id });
      
      // Set cookie
      res.cookie("token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      });

      res.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          status: user.status,
        },
        token,
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ message: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Verify password
      const isValid = await verifyPassword(password, user.password);
      if (!isValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      if (user.status !== "active") {
        return res.status(401).json({ message: "Account not activated" });
      }

      // Generate token
      const token = generateToken({ userId: user.id });
      
      // Set cookie
      res.cookie("token", token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      });

      res.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          status: user.status,
        },
        token,
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(400).json({ message: "Login failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    res.clearCookie("token");
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/auth/me", authenticate, (req: AuthRequest, res) => {
    res.json({ user: req.user });
  });

  // Invite acceptance
  app.post("/api/auth/accept-invite", async (req, res) => {
    try {
      const { token, password } = req.body;
      
      if (!token || !password) {
        return res.status(400).json({ message: "Token and password required" });
      }

      // Find user by invite token
      const user = await storage.getUserByInviteToken(token);
      if (!user) {
        return res.status(400).json({ message: "Invalid or expired invite token" });
      }

      // Hash password and activate user
      const hashedPassword = await hashPassword(password);
      const updatedUser = await storage.updateUser(user.id, {
        password: hashedPassword,
        status: "active",
        inviteToken: undefined,
      });

      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to activate account" });
      }

      // Generate token
      const authToken = generateToken({ userId: updatedUser.id });
      
      // Set cookie
      res.cookie("token", authToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      });

      res.json({
        user: {
          id: updatedUser.id,
          email: updatedUser.email,
          name: updatedUser.name,
          role: updatedUser.role,
          status: updatedUser.status,
        },
        token: authToken,
      });
    } catch (error) {
      console.error("Accept invite error:", error);
      res.status(500).json({ message: "Failed to accept invitation" });
    }
  });

  // User routes
  app.get("/api/users", authenticate, async (req: AuthRequest, res) => {
    try {
      const users = await storage.getAllUsers();
      const sanitizedUsers = users.map(user => ({
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        status: user.status,
        createdAt: user.createdAt,
      }));
      
      res.json(sanitizedUsers);
    } catch (error) {
      console.error("Get users error:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post("/api/users/invite", authenticate, requireAdmin, async (req: AuthRequest, res) => {
    try {
      const inviteData = inviteUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(inviteData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      // Generate invite token
      const inviteToken = generateInviteToken();
      
      // Create user with pending status
      const user = await storage.createUser({
        ...inviteData,
        password: "temp", // Will be set when invitation is accepted
        status: "pending",
        invitedBy: req.user!.id,
        inviteToken,
      });

      // Send invitation email
      const emailData = generateInviteEmail(user.name, inviteToken, user.role);
      emailData.to = user.email;
      
      const emailSent = await sendEmail(emailData);
      if (!emailSent) {
        console.warn("Failed to send invitation email");
      }

      res.json({
        message: "Invitation sent successfully",
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          status: user.status,
        },
      });
    } catch (error) {
      console.error("Invite user error:", error);
      res.status(500).json({ message: "Failed to send invitation" });
    }
  });

  app.put("/api/users/:id", authenticate, requireAdmin, async (req: AuthRequest, res) => {
    try {
      const { id } = req.params;
      
      // Validate request body
      const updates = updateUserSchema.parse(req.body);
      
      // Prevent users from changing their own role (self-demotion)
      if (id === req.user!.id && updates.role !== req.user!.role) {
        return res.status(400).json({ 
          message: "You cannot change your own role" 
        });
      }
      
      // Get current user being updated
      const userToUpdate = await storage.getUser(id);
      if (!userToUpdate) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // If demoting an admin, check if they're the last admin
      if (userToUpdate.role === "admin" && updates.role !== "admin") {
        const allUsers = await storage.getAllUsers();
        const adminCount = allUsers.filter(u => u.role === "admin").length;
        
        if (adminCount <= 1) {
          return res.status(400).json({ 
            message: "Cannot demote the last remaining admin. Promote another user first." 
          });
        }
      }
      
      const updatedUser = await storage.updateUser(id, updates);
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update user" });
      }

      res.json({
        id: updatedUser.id,
        email: updatedUser.email,
        name: updatedUser.name,
        role: updatedUser.role,
        status: updatedUser.status,
      });
    } catch (error) {
      console.error("Update user error:", error);
      
      // Handle Zod validation errors
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid request data",
          errors: error.errors 
        });
      }
      
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete("/api/users/:id", authenticate, requireAdmin, async (req: AuthRequest, res) => {
    try {
      const { id } = req.params;
      
      // Don't allow deleting self
      if (id === req.user!.id) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }

      const deleted = await storage.deleteUser(id);
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Delete user error:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Access request routes
  app.post("/api/access-requests", authenticate, async (req: AuthRequest, res) => {
    try {
      if (req.user!.role === "admin") {
        return res.status(400).json({ message: "Admins don't need to request access" });
      }

      // Check if user already has a pending request
      const existingRequests = await storage.getAccessRequestsByUser(req.user!.id);
      const pendingRequest = existingRequests.find(r => r.status === "pending");
      
      if (pendingRequest) {
        return res.status(400).json({ message: "You already have a pending request" });
      }

      // Get user's inviter (admin who invited them)
      const user = await storage.getUser(req.user!.id);
      if (!user || !user.invitedBy) {
        return res.status(400).json({ message: "Cannot determine who to send request to" });
      }

      const request = await storage.createAccessRequest({
        userId: req.user!.id,
        requestedBy: user.invitedBy,
        status: "pending",
        message: req.body.message || "",
      });

      // Send notification to the admin who invited this user
      const inviter = await storage.getUser(user.invitedBy);
      if (inviter) {
        const emailData = generateAccessRequestEmail(user.name, user.email);
        emailData.to = inviter.email;
        await sendEmail(emailData);
      }

      res.json(request);
    } catch (error) {
      console.error("Create access request error:", error);
      res.status(500).json({ message: "Failed to create access request" });
    }
  });

  app.get("/api/access-requests", authenticate, requireAdmin, async (req: AuthRequest, res) => {
    try {
      const requests = await storage.getPendingAccessRequests();
      
      // Populate user details
      const requestsWithUsers = await Promise.all(
        requests.map(async (request) => {
          const user = await storage.getUser(request.userId);
          return {
            ...request,
            user: user ? {
              id: user.id,
              name: user.name,
              email: user.email,
            } : null,
          };
        })
      );

      res.json(requestsWithUsers);
    } catch (error) {
      console.error("Get access requests error:", error);
      res.status(500).json({ message: "Failed to fetch access requests" });
    }
  });

  app.put("/api/access-requests/:id", authenticate, requireAdmin, async (req: AuthRequest, res) => {
    try {
      const { id } = req.params;
      const { status, message } = updateAccessRequestSchema.parse(req.body);
      
      const request = await storage.getAccessRequest(id);
      if (!request) {
        return res.status(404).json({ message: "Request not found" });
      }

      // Update request
      const updatedRequest = await storage.updateAccessRequest(id, {
        status,
        message,
        reviewedBy: req.user!.id,
        reviewedAt: new Date(),
      });

      if (!updatedRequest) {
        return res.status(500).json({ message: "Failed to update request" });
      }

      // If approved, update user role
      if (status === "approved") {
        await storage.updateUser(request.userId, { role: "admin" });
      }

      // Send notification email to requester
      const user = await storage.getUser(request.userId);
      if (user) {
        const emailData = generateAccessResponseEmail(status === "approved", user.name);
        emailData.to = user.email;
        await sendEmail(emailData);
      }

      res.json(updatedRequest);
    } catch (error) {
      console.error("Update access request error:", error);
      res.status(500).json({ message: "Failed to update access request" });
    }
  });

  // Seed initial data endpoint (for development)
  app.get("/api/seed", async (req, res) => {
    try {
      const existingAdmin = await storage.getUserByEmail("admin@test.com");
      if (existingAdmin) {
        return res.json({ message: "Seed data already exists", users: await storage.getAllUsers() });
      }

      // Create initial admin user
      const hashedPassword = await hashPassword("admin123");
      const adminUser = await storage.createUser({
        email: "admin@test.com",
        password: hashedPassword,
        name: "Admin User",
        role: "admin",
        status: "active",
      });

      // Create a guest user for testing
      const guestHashedPassword = await hashPassword("guest123");
      const guestUser = await storage.createUser({
        email: "guest@test.com",
        password: guestHashedPassword,
        name: "Guest User",
        role: "guest",
        status: "active",
      });

      console.log("Initial seed data created successfully");
      res.json({ 
        message: "Seed data created successfully", 
        users: [
          { email: adminUser.email, role: adminUser.role, status: adminUser.status },
          { email: guestUser.email, role: guestUser.role, status: guestUser.status }
        ]
      });
    } catch (error) {
      console.error("Seed error:", error);
      res.status(500).json({ message: "Failed to seed data", error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Stats endpoint
  app.get("/api/stats", authenticate, async (req: AuthRequest, res) => {
    try {
      const users = await storage.getAllUsers();
      const requests = await storage.getPendingAccessRequests();
      
      const stats = {
        totalUsers: users.length,
        adminUsers: users.filter(u => u.role === "admin").length,
        guestUsers: users.filter(u => u.role === "guest").length,
        pendingInvites: users.filter(u => u.status === "pending").length,
        pendingRequests: requests.length,
        activeUsers: users.filter(u => u.status === "active").length,
      };

      res.json(stats);
    } catch (error) {
      console.error("Get stats error:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
