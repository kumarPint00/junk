import { type User, type InsertUser, type AccessRequest, type InsertAccessRequest, type Session } from "@shared/schema";
import { randomUUID } from "crypto";
import mongoose from "mongoose";

// MongoDB connection
const MONGODB_URI = process.env.MONGODB_URI || "mongodb+srv://admin:admin@task1.ulereve.mongodb.net/?retryWrites=true&w=majority&appName=Task1";

// MongoDB schemas
const userSchema = new mongoose.Schema({
  _id: { type: String, default: () => randomUUID() },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String, required: true },
  role: { type: String, enum: ["admin", "guest"], default: "admin" },
  status: { type: String, enum: ["active", "pending", "inactive"], default: "pending" },
  invitedBy: { type: String, ref: "User" },
  inviteToken: String,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
}, { _id: false });

const accessRequestSchema = new mongoose.Schema({
  _id: { type: String, default: () => randomUUID() },
  userId: { type: String, required: true, ref: "User" },
  requestedBy: { type: String, required: true, ref: "User" },
  status: { type: String, enum: ["pending", "approved", "rejected"], default: "pending" },
  message: String,
  reviewedBy: { type: String, ref: "User" },
  reviewedAt: Date,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
}, { _id: false });

const sessionSchema = new mongoose.Schema({
  _id: { type: String },
  userId: { type: String, required: true, ref: "User" },
  expiresAt: { type: Date, required: true },
  createdAt: { type: Date, default: Date.now },
}, { _id: false });

const UserModel = mongoose.model("User", userSchema);
const AccessRequestModel = mongoose.model("AccessRequest", accessRequestSchema);
const SessionModel = mongoose.model("Session", sessionSchema);

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByInviteToken(token: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;
  getAllUsers(): Promise<User[]>;
  
  // Access request methods
  createAccessRequest(request: InsertAccessRequest): Promise<AccessRequest>;
  getAccessRequest(id: string): Promise<AccessRequest | undefined>;
  getAccessRequestsByUser(userId: string): Promise<AccessRequest[]>;
  getPendingAccessRequests(): Promise<AccessRequest[]>;
  updateAccessRequest(id: string, updates: Partial<AccessRequest>): Promise<AccessRequest | undefined>;
  
  // Session methods
  createSession(session: { id: string; userId: string; expiresAt: Date }): Promise<Session>;
  getSession(id: string): Promise<Session | undefined>;
  deleteSession(id: string): Promise<boolean>;
}

export class MongoStorage implements IStorage {
  private connected = false;

  async connect() {
    if (this.connected) return;
    
    try {
      await mongoose.connect(MONGODB_URI);
      this.connected = true;
      console.log("Connected to MongoDB");
    } catch (error) {
      console.error("MongoDB connection error:", error);
      throw error;
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    await this.connect();
    const user = await UserModel.findById(id).lean();
    return user ? { ...user, id: user._id } as User : undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    await this.connect();
    const user = await UserModel.findOne({ email }).lean();
    return user ? { ...user, id: user._id } as User : undefined;
  }

  async getUserByInviteToken(token: string): Promise<User | undefined> {
    await this.connect();
    const user = await UserModel.findOne({ inviteToken: token }).lean();
    return user ? { ...user, id: user._id } as User : undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    await this.connect();
    const id = randomUUID();
    const userData = {
      ...insertUser,
      _id: id,
      updatedAt: new Date(),
    };
    
    const user = new UserModel(userData);
    await user.save();
    
    return { ...userData, id } as User;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    await this.connect();
    const user = await UserModel.findByIdAndUpdate(
      id,
      { ...updates, updatedAt: new Date() },
      { new: true }
    ).lean();
    
    return user ? { ...user, id: user._id } as User : undefined;
  }

  async deleteUser(id: string): Promise<boolean> {
    await this.connect();
    const result = await UserModel.findByIdAndDelete(id);
    return !!result;
  }

  async getAllUsers(): Promise<User[]> {
    await this.connect();
    const users = await UserModel.find().lean();
    return users.map(user => ({ ...user, id: user._id } as User));
  }

  async createAccessRequest(request: InsertAccessRequest): Promise<AccessRequest> {
    await this.connect();
    const id = randomUUID();
    const requestData = {
      ...request,
      _id: id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    const accessRequest = new AccessRequestModel(requestData);
    await accessRequest.save();
    
    return { 
      ...requestData, 
      id,
      createdAt: requestData.createdAt,
      updatedAt: requestData.updatedAt,
      reviewedAt: request.reviewedAt || null,
    } as AccessRequest;
  }

  async getAccessRequest(id: string): Promise<AccessRequest | undefined> {
    await this.connect();
    const request = await AccessRequestModel.findById(id).lean();
    return request ? { ...request, id: request._id } as AccessRequest : undefined;
  }

  async getAccessRequestsByUser(userId: string): Promise<AccessRequest[]> {
    await this.connect();
    const requests = await AccessRequestModel.find({ userId }).lean();
    return requests.map(request => ({ ...request, id: request._id } as AccessRequest));
  }

  async getPendingAccessRequests(): Promise<AccessRequest[]> {
    await this.connect();
    const requests = await AccessRequestModel.find({ status: "pending" })
      .populate("userId", "name email")
      .lean();
    return requests.map(request => ({ ...request, id: request._id } as AccessRequest));
  }

  async updateAccessRequest(id: string, updates: Partial<AccessRequest>): Promise<AccessRequest | undefined> {
    await this.connect();
    const request = await AccessRequestModel.findByIdAndUpdate(
      id,
      { ...updates, updatedAt: new Date() },
      { new: true }
    ).lean();
    
    return request ? { ...request, id: request._id } as AccessRequest : undefined;
  }

  async createSession(session: { id: string; userId: string; expiresAt: Date }): Promise<Session> {
    await this.connect();
    const sessionData = {
      ...session,
      _id: session.id,
      createdAt: new Date(),
    };
    
    const sessionDoc = new SessionModel(sessionData);
    await sessionDoc.save();
    
    return { 
      ...sessionData, 
      id: session.id,
      createdAt: sessionData.createdAt,
    } as Session;
  }

  async getSession(id: string): Promise<Session | undefined> {
    await this.connect();
    const session = await SessionModel.findById(id).lean();
    return session ? { ...session, id: session._id } as Session : undefined;
  }

  async deleteSession(id: string): Promise<boolean> {
    await this.connect();
    const result = await SessionModel.findByIdAndDelete(id);
    return !!result;
  }
}

export const storage = new MongoStorage();
