// SendGrid integration - using Replit SendGrid blueprint
import { MailService } from '@sendgrid/mail';

if (!process.env.SENDGRID_API_KEY) {
  throw new Error("SENDGRID_API_KEY environment variable must be set");
}

const mailService = new MailService();
mailService.setApiKey(process.env.SENDGRID_API_KEY);

// Note: The FROM_EMAIL must be a verified sender identity in your SendGrid account
// You can verify an email address or domain at: https://sendgrid.com/docs/for-developers/sending-email/sender-identity/
const FROM_EMAIL = process.env.FROM_EMAIL || "test@example.com";

export interface EmailData {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail(data: EmailData): Promise<boolean> {
  try {
    console.log("Attempting to send email via SendGrid:", {
      to: data.to,
      from: FROM_EMAIL,
      subject: data.subject,
      hasHtml: !!data.html,
      hasText: !!data.text
    });

    await mailService.send({
      to: data.to,
      from: FROM_EMAIL,
      subject: data.subject,
      text: data.text,
      html: data.html,
    });
    
    console.log("Email sent successfully via SendGrid to:", data.to);
    return true;
  } catch (error: any) {
    console.error("SendGrid email error:", {
      message: error.message,
      code: error.code,
      response: error.response?.body,
      to: data.to,
      from: FROM_EMAIL
    });
    
    // Log specific SendGrid errors for debugging
    if (error.response?.body?.errors) {
      console.error("SendGrid API errors:", error.response.body.errors);
    }
    
    return false;
  }
}

export function generateInviteEmail(name: string, inviteToken: string, role: string): EmailData {
  const baseUrl = process.env.BASE_URL || "http://localhost:5000";
  const inviteUrl = `${baseUrl}/accept-invite?token=${inviteToken}`;
  
  return {
    to: "",
    subject: "You've been invited to UserFlow",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #2563eb;">Welcome to UserFlow</h1>
        <p>Hi ${name},</p>
        <p>You've been invited to join UserFlow as a <strong>${role}</strong>.</p>
        <p>Click the button below to accept your invitation and set up your account:</p>
        <a href="${inviteUrl}" style="background-color: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 16px 0;">Accept Invitation</a>
        <p>Or copy and paste this link into your browser:</p>
        <p style="word-break: break-all; color: #6b7280;">${inviteUrl}</p>
        <p>This invitation will expire in 7 days.</p>
        <p>Best regards,<br>The UserFlow Team</p>
      </div>
    `,
    text: `Welcome to UserFlow! You've been invited as a ${role}. Accept your invitation: ${inviteUrl}`,
  };
}

export function generateAccessRequestEmail(requesterName: string, requesterEmail: string): EmailData {
  return {
    to: "",
    subject: "Admin Access Request - UserFlow",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #f59e0b;">Admin Access Request</h1>
        <p>A user has requested admin access to UserFlow:</p>
        <div style="background-color: #f3f4f6; padding: 16px; border-radius: 6px; margin: 16px 0;">
          <p><strong>Name:</strong> ${requesterName}</p>
          <p><strong>Email:</strong> ${requesterEmail}</p>
        </div>
        <p>Please review this request in your UserFlow dashboard.</p>
        <p>Best regards,<br>The UserFlow System</p>
      </div>
    `,
    text: `Admin access request from ${requesterName} (${requesterEmail}). Please review in your dashboard.`,
  };
}

export function generateAccessResponseEmail(approved: boolean, requesterName: string): EmailData {
  const status = approved ? "approved" : "rejected";
  const color = approved ? "#10b981" : "#ef4444";
  
  return {
    to: "",
    subject: `Admin Access Request ${approved ? "Approved" : "Rejected"} - UserFlow`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: ${color};">Access Request ${approved ? "Approved" : "Rejected"}</h1>
        <p>Hi ${requesterName},</p>
        <p>Your admin access request has been <strong>${status}</strong>.</p>
        ${approved 
          ? "<p>You now have admin privileges and can manage users and access requests.</p>" 
          : "<p>If you have questions about this decision, please contact your administrator.</p>"
        }
        <p>Best regards,<br>The UserFlow Team</p>
      </div>
    `,
    text: `Your admin access request has been ${status}.`,
  };
}
