import { z } from "zod";

// User schema and types
export const insertUserSchema = z.object({
  email: z.string().email(),
  password: z.string(),
  name: z.string(),
  role: z.enum(["admin", "guest"]).default("admin"),
  status: z.enum(["active", "pending", "inactive"]).default("pending"),
  invitedBy: z.string().optional(),
  inviteToken: z.string().optional(),
});

export const registerUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().min(1),
  role: z.enum(["admin", "guest"]).default("admin"),
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export const inviteUserSchema = z.object({
  email: z.string().email(),
  name: z.string().min(1),
  role: z.enum(["admin", "guest"]),
});

export const updateUserSchema = z.object({
  name: z.string().min(1),
  role: z.enum(["admin", "guest"]),
});

// Access request schema and types
export const insertAccessRequestSchema = z.object({
  userId: z.string(),
  requestedBy: z.string(),
  status: z.enum(["pending", "approved", "rejected"]).default("pending"),
  message: z.string().optional(),
  reviewedBy: z.string().optional(),
  reviewedAt: z.date().optional(),
});

export const updateAccessRequestSchema = z.object({
  status: z.enum(["approved", "rejected"]),
  message: z.string().optional(),
});

// MongoDB document types
export interface User {
  id: string;
  email: string;
  password: string;
  name: string;
  role: "admin" | "guest";
  status: "active" | "pending" | "inactive";
  invitedBy?: string;
  inviteToken?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface AccessRequest {
  id: string;
  userId: string;
  requestedBy: string;
  status: "pending" | "approved" | "rejected";
  message?: string;
  reviewedBy?: string;
  reviewedAt?: Date;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Session {
  id: string;
  userId: string;
  expiresAt: Date;
  createdAt?: Date;
}

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type RegisterUser = z.infer<typeof registerUserSchema>;
export type LoginUser = z.infer<typeof loginSchema>;
export type InviteUser = z.infer<typeof inviteUserSchema>;
export type UpdateUser = z.infer<typeof updateUserSchema>;
export type InsertAccessRequest = z.infer<typeof insertAccessRequestSchema>;
export type UpdateAccessRequest = z.infer<typeof updateAccessRequestSchema>;
