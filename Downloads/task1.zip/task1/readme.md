# run `npm i -f` in terminal

# run `npm run build` in terminal

# run `npm run start` in terminal

# open browser on link http://localhost:5000
