export interface User {
  id: string;
  email: string;
  name: string;
  role: "admin" | "guest";
  status: "active" | "pending" | "inactive";
  createdAt?: string;
}

export interface AccessRequest {
  id: string;
  userId: string;
  requestedBy: string;
  status: "pending" | "approved" | "rejected";
  message?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt?: string;
  user?: {
    id: string;
    name: string;
    email: string;
  };
}

export interface AuthUser {
  id: string;
  email: string;
  role: "admin" | "guest";
}

export interface Stats {
  totalUsers: number;
  adminUsers: number;
  guestUsers: number;
  pendingInvites: number;
  pendingRequests: number;
  activeUsers: number;
}
