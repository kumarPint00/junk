import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Header } from "@/components/layout/header";
import { DataTable } from "@/components/ui/data-table";
import { InviteUserModal } from "@/components/modals/invite-user-modal";
import { EditUserModal } from "@/components/modals/edit-user-modal";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { User } from "@/types/user";

export default function Users() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [inviteModalOpen, setInviteModalOpen] = useState(false);
  const [deleteUser, setDeleteUser] = useState<User | null>(null);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ["/api/users"],
    queryFn: () => api.users.getAll(),
  });

  const deleteMutation = useMutation({
    mutationFn: (userId: string) => api.users.delete(userId),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "User deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      setDeleteUser(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete user",
        variant: "destructive",
      });
    },
  });

  const requestAdminMutation = useMutation({
    mutationFn: () => api.accessRequests.create("Requesting admin access to better assist the team"),
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Admin access request sent successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send request",
        variant: "destructive",
      });
    },
  });

  const handleEditUser = (userToEdit: User) => {
    setEditingUser(userToEdit);
    setEditModalOpen(true);
  };

  const handleDeleteUser = (userToDelete: User) => {
    setDeleteUser(userToDelete);
  };

  const confirmDelete = () => {
    if (deleteUser) {
      deleteMutation.mutate(deleteUser.id);
    }
  };

  const handleInviteUser = () => {
    setInviteModalOpen(true);
  };

  const handleRequestAdmin = () => {
    requestAdminMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col">
        <Header 
          title="Users" 
          description="Loading..."
        />
        <main className="flex-1 p-6">
          <div className="bg-card rounded-lg border border-border p-8 text-center">
            <div className="animate-pulse space-y-4">
              <div className="h-4 bg-muted rounded w-32 mx-auto"></div>
              <div className="space-y-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-12 bg-muted rounded"></div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header 
        title="Users" 
        description="View and manage all system users"
        onInviteUser={user?.role === "admin" ? handleInviteUser : undefined}
        onRequestAdmin={user?.role === "guest" ? handleRequestAdmin : undefined}
      />
      
      <main className="flex-1 p-6">
        <DataTable
          users={users}
          onEdit={user?.role === "admin" ? handleEditUser : undefined}
          onDelete={user?.role === "admin" ? handleDeleteUser : undefined}
        />
      </main>

      {/* Invite User Modal */}
      <InviteUserModal 
        open={inviteModalOpen}
        onClose={() => setInviteModalOpen(false)}
      />

      {/* Edit User Modal */}
      <EditUserModal 
        open={editModalOpen}
        onClose={() => {
          setEditModalOpen(false);
          setEditingUser(null);
        }}
        user={editingUser}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteUser} onOpenChange={() => setDeleteUser(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete User</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <strong>{deleteUser?.name}</strong>? 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-delete-cancel">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-delete-confirm"
            >
              Delete User
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
