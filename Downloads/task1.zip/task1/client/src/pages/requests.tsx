import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { AccessRequest } from "@/types/user";
import { Check, X, Clock } from "lucide-react";

export default function Requests() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["/api/access-requests"],
    queryFn: () => api.accessRequests.getAll(),
    enabled: user?.role === "admin",
  });

  const updateRequestMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: "approved" | "rejected" }) => 
      api.accessRequests.update(id, { status }),
    onSuccess: (data, variables) => {
      const action = variables.status === "approved" ? "approved" : "rejected";
      toast({
        title: "Success",
        description: `Request ${action} successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/access-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update request",
        variant: "destructive",
      });
    },
  });

  const handleApprove = (request: AccessRequest) => {
    updateRequestMutation.mutate({ id: request.id, status: "approved" });
  };

  const handleReject = (request: AccessRequest) => {
    updateRequestMutation.mutate({ id: request.id, status: "rejected" });
  };

  const getUserInitials = (name: string) => {
    return name.split(" ").map(n => n[0]).join("").toUpperCase();
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return "";
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (user?.role !== "admin") {
    return (
      <div className="flex-1 flex flex-col">
        <Header 
          title="Access Denied" 
          description="You don't have permission to view this page"
        />
        <main className="flex-1 p-6">
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">Admin access required</p>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col">
        <Header 
          title="Access Requests" 
          description="Loading..."
        />
        <main className="flex-1 p-6">
          <Card>
            <CardContent className="p-8">
              <div className="animate-pulse space-y-4">
                {[...Array(3)].map((_, i) => (
                  <div key={i} className="flex items-center justify-between p-4 border border-border rounded">
                    <div className="flex items-center space-x-4">
                      <div className="h-10 w-10 bg-muted rounded-full"></div>
                      <div className="space-y-2">
                        <div className="h-4 bg-muted rounded w-32"></div>
                        <div className="h-3 bg-muted rounded w-48"></div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <div className="h-8 w-16 bg-muted rounded"></div>
                      <div className="h-8 w-16 bg-muted rounded"></div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header 
        title="Access Requests" 
        description="Review and manage requests for admin privileges"
      />
      
      <main className="flex-1 p-6">
        <Card>
          <CardHeader>
            <CardTitle>Admin Access Requests</CardTitle>
          </CardHeader>
          <CardContent>
            {requests.length > 0 ? (
              <div className="space-y-4">
                {requests.map((request: AccessRequest) => (
                  <div 
                    key={request.id} 
                    className="flex items-center justify-between p-6 border border-border rounded-lg"
                    data-testid={`request-${request.id}`}
                  >
                    <div className="flex items-center space-x-4">
                      <Avatar>
                        <AvatarFallback className="bg-muted text-muted-foreground">
                          {request.user ? getUserInitials(request.user.name) : "U"}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="text-sm font-medium text-foreground" data-testid={`request-name-${request.id}`}>
                          {request.user?.name || "Unknown User"}
                        </h4>
                        <p className="text-sm text-muted-foreground" data-testid={`request-email-${request.id}`}>
                          {request.user?.email || "No email"}
                        </p>
                        <div className="flex items-center text-xs text-muted-foreground mt-1">
                          <Clock className="h-3 w-3 mr-1" />
                          <span>Requested {formatDate(request.createdAt)}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Button
                        onClick={() => handleApprove(request)}
                        disabled={updateRequestMutation.isPending}
                        className="bg-green-500 text-white hover:bg-green-600"
                        size="sm"
                        data-testid={`button-approve-${request.id}`}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        Approve
                      </Button>
                      <Button
                        onClick={() => handleReject(request)}
                        disabled={updateRequestMutation.isPending}
                        variant="destructive"
                        size="sm"
                        data-testid={`button-reject-${request.id}`}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Reject
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="h-12 w-12 mx-auto bg-muted rounded-full flex items-center justify-center mb-4">
                  <Clock className="h-6 w-6 text-muted-foreground" />
                </div>
                <p className="text-muted-foreground">No pending requests</p>
                <p className="text-sm text-muted-foreground mt-1">
                  All access requests will appear here for review
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
