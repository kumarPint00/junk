import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Header } from "@/components/layout/header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Shield, Clock, HandMetal } from "lucide-react";

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ["/api/stats"],
    queryFn: () => api.stats.get(),
  });

  const statsCards = [
    {
      title: "Total Users",
      value: stats?.totalUsers || 0,
      icon: Users,
      color: "bg-blue-100 text-blue-600",
    },
    {
      title: "Admins",
      value: stats?.adminUsers || 0,
      icon: Shield,
      color: "bg-green-100 text-green-600",
    },
    {
      title: "Pending Invites",
      value: stats?.pendingInvites || 0,
      icon: Clock,
      color: "bg-amber-100 text-amber-600",
    },
    {
      title: "Pending Requests",
      value: stats?.pendingRequests || 0,
      icon: HandMetal,
      color: "bg-purple-100 text-purple-600",
    },
  ];

  const activities = [
    {
      id: "1",
      type: "user-joined",
      message: "Sarah Wilson joined as Admin",
      time: "2 hours ago",
      icon: "user-plus",
      color: "bg-green-100 text-green-600",
    },
    {
      id: "2",
      type: "access-request",
      message: "Mike Chen requested admin access",
      time: "4 hours ago",
      icon: "shield",
      color: "bg-blue-100 text-blue-600",
    },
    {
      id: "3",
      type: "invitation",
      message: "Invitation sent to alex@company.com",
      time: "1 day ago",
      icon: "mail",
      color: "bg-amber-100 text-amber-600",
    },
  ];

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col">
        <Header
          title="Dashboard"
          description="Loading..."
        />
        <main className="flex-1 p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <div className="animate-pulse">
                    <div className="h-4 bg-muted rounded w-24 mb-2"></div>
                    <div className="h-8 bg-muted rounded w-16"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      <Header
        title="Dashboard"
        description="Manage your team and access controls"
      />

      <main className="flex-1 p-6 space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {statsCards.map((stat) => {
            const Icon = stat.icon;
            return (
              <Card key={stat.title} data-testid={`card-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <div className={`p-2 rounded-lg ${stat.color}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="ml-4">
                      <p className="text-2xl font-semibold text-foreground" data-testid={`stat-${stat.title.toLowerCase().replace(/\s+/g, '-')}`}>
                        {stat.value}
                      </p>
                      <p className="text-sm text-muted-foreground">{stat.title}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Recent Activity */}
        {/* <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {activities.length > 0 ? (
              activities.map((activity) => (
                <div 
                  key={activity.id} 
                  className="flex items-center space-x-4 p-3 rounded-lg bg-muted/50"
                  data-testid={`activity-${activity.id}`}
                >
                  <div className={`h-8 w-8 rounded-full flex items-center justify-center ${activity.color}`}>
                    {activity.icon === "user-plus" && <Users className="h-4 w-4" />}
                    {activity.icon === "shield" && <Shield className="h-4 w-4" />}
                    {activity.icon === "mail" && <Clock className="h-4 w-4" />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-foreground">{activity.message}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center text-muted-foreground py-8">
                <p>No recent activity</p>
              </div>
            )}
          </CardContent>
        </Card> */}
      </main>
    </div>
  );
}
