import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Bell, Shield } from "lucide-react";

interface HeaderProps {
  title: string;
  description: string;
  onInviteUser?: () => void;
  onRequestAdmin?: () => void;
}

export function Header({ title, description, onInviteUser, onRequestAdmin }: HeaderProps) {
  const { user } = useAuth();

  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
    queryFn: () => api.stats.get(),
    enabled: !!user,
  });

  return (
    <header className="bg-card border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">{title}</h1>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
        
        <div className="flex items-center space-x-4">
          {/* Notifications */}
          <Button variant="ghost" size="sm" className="relative">
            <Bell className="h-4 w-4" />
            {stats && (stats.pendingInvites + stats.pendingRequests) > 0 && (
              <Badge
                variant="destructive"
                className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center text-xs"
              >
                {stats.pendingInvites + stats.pendingRequests}
              </Badge>
            )}
          </Button>
          
          {/* Admin Actions */}
          {user?.role === "admin" && onInviteUser && (
            <Button onClick={onInviteUser} data-testid="button-invite-user">
              <Plus className="h-4 w-4 mr-2" />
              Invite User
            </Button>
          )}
          
          {/* Guest Actions */}
          {user?.role === "guest" && onRequestAdmin && (
            <Button 
              variant="outline"
              onClick={onRequestAdmin}
              className="bg-amber-50 border-amber-200 text-amber-700 hover:bg-amber-100"
              data-testid="button-request-admin"
            >
              <Shield className="h-4 w-4 mr-2" />
              Request Admin Access
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
