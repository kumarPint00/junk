import { apiRequest } from "@/lib/queryClient";

export interface LoginData {
  email: string;
  password: string;
}

export interface RegisterData {
  email: string;
  password: string;
  name: string;
  role: "admin" | "guest";
}

export interface InviteData {
  email: string;
  name: string;
  role: "admin" | "guest";
}

export interface AcceptInviteData {
  token: string;
  password: string;
}

export interface UpdateAccessRequestData {
  status: "approved" | "rejected";
  message?: string;
}

export const api = {
  auth: {
    login: async (data: LoginData) => {
      const response = await apiRequest("POST", "/api/auth/login", data);
      return response.json();
    },
    
    register: async (data: RegisterData) => {
      const response = await apiRequest("POST", "/api/auth/register", data);
      return response.json();
    },
    
    logout: async () => {
      const response = await apiRequest("POST", "/api/auth/logout");
      return response.json();
    },
    
    getMe: async () => {
      const response = await apiRequest("GET", "/api/auth/me");
      return response.json();
    },
    
    acceptInvite: async (data: AcceptInviteData) => {
      const response = await apiRequest("POST", "/api/auth/accept-invite", data);
      return response.json();
    },
  },
  
  users: {
    getAll: async () => {
      const response = await apiRequest("GET", "/api/users");
      return response.json();
    },
    
    invite: async (data: InviteData) => {
      const response = await apiRequest("POST", "/api/users/invite", data);
      return response.json();
    },
    
    update: async (id: string, data: Partial<{ name: string; role: string }>) => {
      const response = await apiRequest("PUT", `/api/users/${id}`, data);
      return response.json();
    },
    
    delete: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/users/${id}`);
      return response.json();
    },
  },
  
  accessRequests: {
    create: async (message?: string) => {
      const response = await apiRequest("POST", "/api/access-requests", { message });
      return response.json();
    },
    
    getAll: async () => {
      const response = await apiRequest("GET", "/api/access-requests");
      return response.json();
    },
    
    update: async (id: string, data: UpdateAccessRequestData) => {
      const response = await apiRequest("PUT", `/api/access-requests/${id}`, data);
      return response.json();
    },
  },
  
  stats: {
    get: async () => {
      const response = await apiRequest("GET", "/api/stats");
      return response.json();
    },
  },
};
