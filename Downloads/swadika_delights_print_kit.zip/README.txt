
PRINT KIT — Swadika Delights

Files (300 DPI, print-ready):
- insert_A6_front.png / insert_A6_back.png
- visiting_card_front.png / visiting_card_back.png
- logo_sticker_round_3in.png
- tamper_seal_8x2cm.png

Details used:
- Brand: Swadika Delights
- WhatsApp: +918826882676
- Email: swadikadelights@gmail.com
- FSSAI: (add your number)

QR Codes:
- Insert & Back: https://wa.me/918826882676?text=Hi%20PACK30
- Visiting Card: https://wa.me/918826882676?text=Hi%20CARD30

Next steps:
- Share your FSSAI number (I’ll update print).
- If you have a logo or brand colors, I can add them.
- Want PG/Society flyers with unique codes? Say the word.
