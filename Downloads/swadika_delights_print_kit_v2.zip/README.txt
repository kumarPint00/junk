
PRINT KIT — Swadika Delights (v2)

Included (300 DPI):
- insert_A6_front.png / insert_A6_back.png
- visiting_card_front.png / visiting_card_back.png
- logo_sticker_round_3in.png
- tamper_seal_8x2cm.png
- flyer_A5_PG_HOSTEL.png
- flyer_A5_SOCIETY.png

Details:
- Brand: Swadika Delights
- WhatsApp: +918826882676
- Email: swadikadelights@gmail.com
- Instagram: @swadikadelights
- FSSAI: 22725105001188

WhatsApp QR codes are prefilled with texts: PACK30 (insert), CARD30 (card), PG50 (PG/Hostel), SOC50 (Society).
